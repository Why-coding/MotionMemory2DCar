import numpy as np
import pytest

from intersection_rl.geometry import Polyline, build_route_path, outgoing_point, stop_point


@pytest.mark.parametrize("approach", ["N", "E", "S", "W"])
@pytest.mark.parametrize("route", ["left", "straight", "right"])
def test_all_route_paths_are_finite_and_nonzero(approach, route):
    lane = 0 if route == "left" else 1
    path = Polyline(build_route_path(approach, lane, route, 4.0, 65.0, 10.0))
    assert path.length > 100.0
    position, heading = path.sample(path.length / 2.0)
    assert np.isfinite(position).all()
    assert np.isfinite(heading)


def test_polyline_projection_round_trip():
    path = Polyline(np.array([[0.0, 0.0], [10.0, 0.0], [10.0, 10.0]]))
    progress, distance = path.project(np.array([7.0, 2.0]))
    assert progress == pytest.approx(7.0)
    assert distance == pytest.approx(2.0)


@pytest.mark.parametrize("lane", range(4))
def test_straight_route_preserves_lane_center(lane):
    points = build_route_path("N", lane, "straight", 4.0, 65.0, 16.0, 4)
    np.testing.assert_allclose(points[1], stop_point("N", lane, 4.0, 16.0))
    np.testing.assert_allclose(points[-1], outgoing_point("S", lane, 65.0, 4.0, 16.0))


def test_turns_join_expected_destination_lane_centers():
    left = build_route_path("N", 0, "left", 4.0, 65.0, 16.0, 4)
    right = build_route_path("N", 3, "right", 4.0, 65.0, 16.0, 4)
    np.testing.assert_allclose(left[-2], outgoing_point("E", 0, 0.0, 4.0, 16.0))
    np.testing.assert_allclose(right[-2], outgoing_point("W", 3, 0.0, 4.0, 16.0))
