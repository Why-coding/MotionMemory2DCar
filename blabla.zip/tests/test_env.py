import numpy as np

from intersection_rl.config import EnvConfig
from intersection_rl.cli import rule_based_actions
from intersection_rl.env import IntersectionEnv


def make_env():
    return IntersectionEnv(
        EnvConfig(
            min_cars=8,
            max_cars=12,
            episode_seconds=2.0,
            seed=3,
        )
    )


def test_reset_has_expected_shapes_and_vehicle_count():
    env = make_env()
    observation, info = env.reset(seed=3)
    assert observation.shape == (12, env.OBSERVATION_SIZE)
    assert observation.dtype == np.float32
    assert 8 <= info["active_mask"].sum() <= 12
    assert env.observation_space.contains(observation)


def test_step_returns_per_vehicle_reward():
    env = make_env()
    env.reset(seed=4)
    action = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    observation, reward, terminated, truncated, info = env.step(action)
    assert observation.shape == (12, env.OBSERVATION_SIZE)
    assert reward.shape == (12,)
    assert isinstance(terminated, bool)
    assert isinstance(truncated, bool)
    assert "collisions" in info
    assert "red_light_violations" in info


def test_seeded_reset_is_reproducible():
    env = make_env()
    first, _ = env.reset(seed=9)
    second, _ = env.reset(seed=9)
    np.testing.assert_allclose(first, second)


def test_episode_truncates():
    env = make_env()
    env.reset(seed=2)
    action = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    truncated = False
    for _ in range(env.config.max_steps):
        _, _, _, truncated, _ = env.step(action)
    assert truncated


def test_rule_based_driver_returns_valid_actions():
    env = make_env()
    env.reset(seed=5)
    actions = rule_based_actions(env)
    assert env.action_space.contains(actions)


def test_four_lane_environment_supports_exact_car_count():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=4, min_cars=24, max_cars=24, seed=4
        )
    )
    observation, info = env.reset(seed=4)
    assert observation.shape == (24, env.OBSERVATION_SIZE)
    assert info["active_mask"].sum() == 24
    assert env.config.intersection_half_size >= 16.0


def test_renderer_background_is_light_blue():
    env = IntersectionEnv(
        EnvConfig(min_cars=1, max_cars=1), render_mode="rgb_array"
    )
    env.reset(seed=1)
    frame = env.render()
    np.testing.assert_array_equal(frame[0, 0], [173, 216, 230])
    env.close()


def test_five_lane_environment_supports_user_selected_car_count():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=5, min_cars=32, max_cars=32, seed=5
        )
    )
    observation, info = env.reset(seed=5)
    assert observation.shape == (32, env.OBSERVATION_SIZE)
    assert info["active_mask"].sum() == 32
    assert env.config.intersection_half_size >= 20.0


def test_protected_left_phase_separates_left_and_through_movements():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=True,
            seed=1,
        )
    )
    env.reset(seed=1)
    left, through = env.vehicles
    left.approach = through.approach = "N"
    left.route = "left"
    through.route = "straight"
    assert env._signal_phase()[0] == "NS_LEFT_GREEN"
    assert env._movement_has_green(left)
    assert not env._movement_has_green(through)
    env.elapsed_seconds = env.config.left_signal_green_seconds
    assert env._signal_phase()[0] == "NS_GREEN"
    assert not env._movement_has_green(left)
    assert env._movement_has_green(through)


def test_unprotected_left_detects_opposing_straight_conflict():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=False,
            seed=2,
        )
    )
    env.reset(seed=2)
    left, opposing = env.vehicles
    left.approach = "N"
    left.route = "left"
    opposing.approach = "S"
    opposing.route = "straight"
    opposing.progress = opposing.stop_progress - 5.0
    opposing.speed = 5.0
    assert env._movement_has_green(left)
    assert env._left_turn_conflict(left)


def test_destination_lanes_are_randomized_across_traffic():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=5,
            min_cars=40,
            max_cars=40,
            seed=12,
        )
    )
    env.reset(seed=12)
    destination_lanes = {vehicle.destination_lane for vehicle in env.vehicles}
    assert len(destination_lanes) >= 3
    assert all(0 <= lane < 5 for lane in destination_lanes)


def test_lateral_action_moves_vehicle_toward_route_center():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=3))
    env.reset(seed=3)
    vehicle = env.vehicles[0]
    vehicle.lateral_offset = 0.5
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [0.0, -1.0]  # Coast and steer left.
    env.step(actions)
    assert vehicle.lateral_offset < 0.5


def configure_right_on_red_conflict(env):
    right, crossing = env.vehicles[:2]
    right.approach = "N"
    right.route = "right"
    right.lane = env.config.lanes_per_approach - 1
    crossing.approach = "E"
    crossing.route = "straight"
    crossing.progress = crossing.stop_progress - 5.0
    crossing.speed = 5.0
    env.elapsed_seconds = env.config.signal_green_seconds + env.config.signal_yellow_seconds
    return right, crossing


def test_right_on_red_requires_clear_cross_traffic():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=True,
            seed=6,
        )
    )
    env.reset(seed=6)
    right, crossing = configure_right_on_red_conflict(env)
    assert env._can_turn_right_on_red(right)
    assert env._right_turn_conflict(right)
    assert not env._movement_permitted(right)
    crossing.active = False
    assert not env._right_turn_conflict(right)
    assert env._movement_permitted(right)


def test_right_on_red_can_be_disabled():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=False,
            seed=7,
        )
    )
    env.reset(seed=7)
    right, _ = configure_right_on_red_conflict(env)
    assert not env._can_turn_right_on_red(right)
    assert not env._movement_permitted(right)


def test_unsafe_right_on_red_records_yield_violation():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=True,
            seed=8,
        )
    )
    env.reset(seed=8)
    right, _ = configure_right_on_red_conflict(env)
    right.progress = right.stop_progress - 0.05
    right.speed = 3.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    _, _, _, _, info = env.step(actions)
    assert info["right_yield_violations"] == 1
    assert info["red_light_violations"] == 0


def test_right_turns_spawn_only_in_rightmost_lane():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=5,
            min_cars=80,
            max_cars=80,
            seed=22,
        )
    )
    env.reset(seed=22)
    right_turns = [vehicle for vehicle in env.vehicles if vehicle.route == "right"]
    assert right_turns
    assert all(vehicle.lane == 4 for vehicle in right_turns)


def test_rectangular_collision_detects_side_overlap():
    env = IntersectionEnv(EnvConfig(min_cars=2, max_cars=2, seed=30))
    env.reset(seed=30)
    first, second = env.vehicles[:2]
    second.path = first.path
    second.progress = first.progress
    second.lateral_offset = first.lateral_offset + env.config.vehicle_width * 0.4
    collisions = env._detect_collisions()
    assert collisions[first.vehicle_id]
    assert collisions[second.vehicle_id]


def test_close_rectangles_get_proximity_penalty_without_collision():
    env = IntersectionEnv(EnvConfig(min_cars=2, max_cars=2, seed=31))
    env.reset(seed=31)
    first, second = env.vehicles[:2]
    second.path = first.path
    second.progress = first.progress + env.config.vehicle_length + 1.0
    second.lateral_offset = first.lateral_offset
    collisions = np.zeros(env.config.max_cars, dtype=bool)
    proximity = env._detect_proximity_violations(collisions)
    assert proximity[first.vehicle_id]
    assert proximity[second.vehicle_id]


def test_curriculum_randomizes_episode_settings_with_fixed_shapes():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=5,
            max_cars=24,
            lanes_per_approach=5,
            curriculum_enabled=True,
            curriculum_min_lanes=2,
            curriculum_max_lanes=5,
            curriculum_min_cars=5,
            curriculum_max_cars=24,
            seed=44,
        )
    )
    shapes = set()
    lane_counts = set()
    active_counts = set()
    left_modes = set()
    right_modes = set()
    for seed in range(44, 60):
        observation, info = env.reset(seed=seed)
        shapes.add(observation.shape)
        lane_counts.add(info["episode_lanes_per_approach"])
        active_counts.add(int(info["active_mask"].sum()))
        left_modes.add(info["episode_protected_left_signal"])
        right_modes.add(info["episode_allow_right_on_red"])
    assert shapes == {(24, env.OBSERVATION_SIZE)}
    assert len(lane_counts) > 1
    assert len(active_counts) > 1
    assert left_modes == {False, True}
    assert right_modes == {False, True}


def test_curriculum_caps_active_cars_to_sampled_lane_capacity():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=5,
            max_cars=64,
            lanes_per_approach=5,
            curriculum_enabled=True,
            curriculum_min_lanes=2,
            curriculum_max_lanes=2,
            curriculum_min_cars=5,
            curriculum_max_cars=64,
            seed=55,
        )
    )
    for seed in range(55, 65):
        _, info = env.reset(seed=seed)
        assert info["active_mask"].sum() <= env._lane_capacity(2)
        assert info["active_mask"].sum() <= 64
