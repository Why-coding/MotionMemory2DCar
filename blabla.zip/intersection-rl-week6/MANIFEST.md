# Intersection RL Week 6 Package

This package contains the latest Week 6 code, selected staged checkpoints, training metrics, evaluation results, graph SVGs, and graph-generation script.

## Selected Checkpoints

- `checkpoints/stage1_lane4_centered_v4_best.npz`
- `checkpoints/stage2_lane4_centered_v4_best.npz`
- `checkpoints/stage3_lane4_centered_v6_best.npz`

Only these latest selected staged checkpoints are included. Older exploratory checkpoints are intentionally excluded.

## Results

- `results/evaluations.csv`: full evaluation log from the current workspace.
- `results/latest_evaluations_selected.csv`: filtered rows for the selected Stage 1, Stage 2, and Stage 3 checkpoints.
- `checkpoints/*_train_metrics.csv`: training metrics for the selected staged runs.

## Graphs

Pre-generated SVG graphs are in `graphs/`.

To regenerate graphs from CSV files:

```bash
python scripts/generate_graphs.py --eval-csv results/evaluations.csv --metrics-dir checkpoints --out-dir graphs
```

## Latest Status

- Stage 1 shield-off meets the current target.
- Stage 2 and Stage 3 remain below the 75% shield-off completion target.
- Stage 3 right-on-red is implemented and exercised, but the hard 3-lane / 14-car setting is not demo-ready.
