# Intersection RL Simulator

A four-way traffic-intersection simulator and a parameter-sharing PPO policy
based on the project plan in `PP1.png`, `PP2.png`, and `PP3.png`.

For the formal engineering report, see [`REPORT.md`](REPORT.md).

The current runnable milestone implements **Week 5** and **Week 6**:

- Four-way signalized intersection with one to five incoming lanes per approach.
- Dedicated left-turn-capable left lane and right-turn-capable right lane.
- Eight to twelve vehicles with left, straight, and right routes.
- Kinematic vehicle model with longitudinal and lateral control.
- Shared PyTorch PPO policy controlling continuous acceleration and continuous steering for every active vehicle.
- Rewards for progress, rectangular collisions, all-around proximity, red-light violations, front spacing, and
  control smoothness.
- Pygame visualization and headless training/evaluation.

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
```

## Run

Inspect the simulator with the rule-based baseline:

```bash
intersection-rl simulate --episodes 3
```

Train PPO and save a policy:

```bash
intersection-rl train --steps 100000 \
  --checkpoint checkpoints/ppo_intersection.npz
```

Evaluate or visualize the trained policy:

```bash
intersection-rl evaluate checkpoints/ppo_intersection.npz --episodes 20
intersection-rl simulate --policy checkpoints/ppo_intersection.npz
```

Run tests:

```bash
pytest
```

## Agent Interface

The environment has one stable slot per configured vehicle:

- Observation: `(cars, 34)` float array.
- Actions: `(cars, 2)` continuous float array. Column 0 is normalized acceleration `[-1, 1]`; column 1 is normalized steering `[-1, 1]`.
- Reward: `(cars,)` per-vehicle float array.
- `info["active_mask"]`: identifies active vehicle slots.
- `info["safety_overrides"]`: counts training-aware safety shield overrides for the current step.
- `info["completed_clean"]` and `info["failed_vehicles"]`: separate clean completions from failed vehicles.

The PPO network is shared between cars. During training, each active car is one
sample, which allows the policy to generalize to different traffic counts.


## Training Across Configurations

The policy network is shared across vehicle slots, so it can technically run on
`--cars` values different from training because every active car uses the same
observation/action model. That does not guarantee good behavior. A checkpoint
trained only on `--lanes 4 --cars 20` may run on `--lanes 5 --cars 64`, but it
will not necessarily generalize safely unless those configurations appear during
training or evaluation.

Fixed-config training uses one configuration per command. Curriculum training
keeps one fixed maximum tensor shape and randomizes the active scenario at every
episode reset:

```bash
intersection-rl train --curriculum \
  --curriculum-min-lanes 2 --curriculum-max-lanes 5 \
  --curriculum-min-cars 5 --curriculum-max-cars 64 \
  --steps 100000 --checkpoint checkpoints/week6_curriculum.npz
```

During curriculum training:

- the PPO tensor shape stays fixed at `(curriculum_max_cars, ...)`
- inactive vehicle slots are ignored through `active_mask`
- lane count is sampled each episode
- active vehicle count is sampled each episode and capped by road capacity
- protected/yield left signal mode is randomized each episode
- right-on-red on/off is randomized each episode
- random seeds, routes, destination lanes, and initial offsets vary per episode

A curriculum-trained checkpoint is the better choice for evaluation across
multiple layouts, for example 4 lanes/20 cars and 5 lanes/64 cars.



## Predictive Observation Signals

The policy observation now includes short-horizon predictive conflict signals in addition to reactive state. The environment projects active vehicles forward over a small horizon and reports whether the ego vehicle is likely to see a future collision/proximity conflict, how soon that conflict occurs, whether another vehicle has priority, whether the intersection is occupied, and whether conflicting traffic is approaching. These predictive features are cached once per simulator state and reused by both reward and observation code, so long training runs do not recompute the same future vehicle-pair rollout for every active car.

These are learning signals, not a full hard-coded planner. PPO still chooses acceleration and steering, but it now receives earlier information before an actual collision/proximity penalty happens. This is intended to help the policy learn to slow/yield before a conflict and keep centered when no lane-change behavior is needed.

Because the observation size increased from 26 to 34, old checkpoints are loaded through a compatibility path: old first-layer weights are copied into the original 26 feature columns, while the new predictive-feature columns are initialized to zero so old behavior is not randomly perturbed. For best results, retrain or fine-tune after this change.

Latest long Stage 1 run:

    .venv/bin/intersection-rl train --curriculum-stage 1 --steps 500000 --save-interval-updates 25 --checkpoint checkpoints/stage1_torch_predictive_long.npz

The run used 500,224 environment steps, 2,050,125 active policy samples, and 113.896 simulated vehicle-hours. That run exposed the remaining environment bugs: lane drift inflated proximity counts, active vehicles at timeout were reported as incomplete instead of failed/stuck, and the reservation layer was too broad.

## PyTorch PPO

The PPO trainer now uses PyTorch instead of the earlier custom NumPy backpropagation code. The public CLI remains the same, and checkpoints are still saved as `.npz` files for simple packaging. New checkpoints store PyTorch state-dict arrays; older NumPy checkpoints can still be loaded by the compatibility path.

Why this matters:

- PyTorch gives production-grade automatic differentiation and Adam optimization.
- It is easier to scale the policy network and add richer losses for steering/lane-change behavior.
- It supports GPU acceleration when available.
- It reduces risk from hand-written gradient bugs in PPO.

The policy still learns continuous acceleration and steering. Lane centering is handled through reward and lane-drift metrics, not by removing steering from the policy.

## Safety-Aware RL Training

Continuous PPO still controls acceleration and steering, but the environment can apply a training-aware safety shield before vehicle motion. During training, the shield handles red/yield stop-line hazards and front-gap hazards, and unsafe requests are still penalized through reward terms. This keeps rollouts safer without hiding the policy mistake from PPO.

Evaluation and simulation use one additional demo-safety layer: a geometric intersection reservation check. It holds a vehicle before the stop line only for occupied or higher-priority vehicles whose route footprints can actually conflict with the ego route. This avoids unnecessary waiting for non-conflicting traffic while still preventing shared-conflict-zone collisions. The reservation layer is intentionally disabled during PPO training because training with it produced a conservative local optimum with many shield overrides and almost no clean completions.

The shield is enabled by default and can be disabled for ablation:

```bash
intersection-rl train --lanes 2 --cars 12 --safety-shield off
intersection-rl evaluate checkpoints/week6_best.npz --safety-shield off
```

For curriculum, prefer staged training before full random curriculum. Stage N+1 can now warm-start from Stage N with `--init-checkpoint`:

```bash
intersection-rl train --curriculum-stage 1 --steps 100000 \
  --checkpoint checkpoints/stage1.npz
intersection-rl train --curriculum-stage 2 --steps 150000 \
  --init-checkpoint checkpoints/stage1_best.npz \
  --checkpoint checkpoints/stage2.npz
intersection-rl train --curriculum-stage 3 --steps 200000 \
  --init-checkpoint checkpoints/stage2_best.npz \
  --checkpoint checkpoints/stage3.npz
```

Stages progress from low-density protected-left scenarios to full Week 6 randomization. Training logs include clean completions, failures, collisions, proximity, red/yield violations, safety overrides, progress, and safety score. Evaluate each stage before moving to the next; do not jump directly from Stage 1 to full random curriculum.

### Latest Demo Checkpoint

Recommended controlled demo setting:

```bash
intersection-rl evaluate checkpoints/demo_8car_lane_centered_finetune_best.npz   --lanes 2 --cars 8 --left-signal protected --right-on-red off   --episodes 50 --episode-seconds 60
```

Measured result after the lane-centering, timeout-accounting, shield-hold, and geometric reservation fixes:

```text
mean_completed=8.00 / 8 (100.00%)
mean_failed=0.00
mean_incomplete=0.00
collisions=0
proximity_vehicles=0
proximity_events=0
red_violations=0
left_yield=0
right_yield=0
right_lane=0
lane_drift=0
shield_action_pct=10.84
unsafe_action_pct=8.35
vehicle_hours=2.926 over the 50-episode evaluation
```

A short 50,176-step fine-tune from that checkpoint produced `checkpoints/demo_8car_lane_centered_geometric_finetune.npz`, but it did not beat the recommended checkpoint on shield dependence. Its best checkpoint stayed safe with 100% completion, but shield action percentage was 11.23%, so `checkpoints/demo_8car_lane_centered_finetune_best.npz` remains the recommended demo policy.

The 8-car demo is now clean in the controlled Stage 1 setting. The next work is to repeat this staged process for Stage 2 and higher-density curriculum, not to jump directly to full 5-lane/64-car random traffic.

## Checkpoint Saving

Training writes three kinds of checkpoints:

- final checkpoint: the exact `--checkpoint` path
- best checkpoint: `<name>_best.npz`, based on rollout safety score, not reward alone
- periodic checkpoints: `<name>_update_XXXX.npz` every `--save-interval-updates` PPO updates

Example:

```bash
intersection-rl train --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on \
  --steps 100000 --save-interval-updates 5 \
  --checkpoint checkpoints/week6_continuous.npz
```

Set `--save-interval-updates 0` to disable periodic intermediate checkpoints.

## Safety And Collision Model

Vehicles are modeled as oriented rectangles using length, width, and heading.
Collision detection uses rectangle overlap, so side contacts and angled contacts
are detected, not only point-distance contacts. Proximity now uses
oriented-rectangle clearance, not center distance. This fixed the earlier bug
where normal adjacent-lane cars could be counted as proximity violations because
the old center-distance threshold was wider than the lane separation. The reward
still penalizes close non-overlapping rectangles, and evaluation reports both
`collisions` and `proximity` counts.


## Evaluation Metrics

Evaluation now prints raw counts and percentages. Important fields:

- `proximity_events`: number of close vehicle pairs.
- `proximity_vehicles`: responsible vehicle count; same-lane following marks only the rear vehicle.
- `red_violations`: illegal stop-line crossings only; legal right-on-red is reported separately as `right_on_red_entries`.
- `lane_drift`: active steps where a car rides near the lane edge.
- `active_action_samples`: number of policy decisions made for active vehicles.
- `vehicle_hours`: `active_action_samples * dt / 3600`.

Training logs also print `samples`, rollout `veh_hr`, and a final `training_summary` with total environment steps, active policy samples, simulated environment-hours, and vehicle-hours.

## Week Mapping

The source contains `Week N` comments at the implementation and extension
points.

| Week | Plan and code status |
| --- | --- |
| 5 | Implemented: two-lane signals, kinematics, 8–12 cars, PPO, core rewards |
| 6 | Implemented: 1-5 lanes, protected or yielding left turns, random destination lanes, lateral lane following, right-on-red yielding, and rightmost-lane enforcement |
| 7 | Planned: kinodynamics, speed limits, merge lanes, jerk and merge rewards |
| 8 | Planned: shoulder/parking lanes, parked cars, crosswalk pedestrians |
| 9 | Planned: jaywalking, lane changes, pedestrian braking and safety rewards |
| 10 | Planned: per-car goals and cut-in scenarios |
| 11 | Planned: unprotected turns, stop signs, noise, occlusion, ROS bag adapter |
| 12 | Planned: Nissan simulator deployment and sim-to-sim calibration |

The remaining rows need separate implementation and validation. They are not hidden
behind configuration flags in the current Week 5 environment.

## Choose Lanes and Cars

Use `--lanes` from 1 to 5 and `--cars` for an exact vehicle count:

```bash
intersection-rl simulate --lanes 3 --cars 20
intersection-rl simulate --lanes 4 --cars 32
intersection-rl simulate --lanes 5 --cars 5
```

Train and evaluate with the same layout:

```bash
intersection-rl train --lanes 4 --cars 32 --steps 100000 \
  --checkpoint checkpoints/ppo_4lane_32cars.npz
intersection-rl evaluate checkpoints/ppo_4lane_32cars.npz \
  --lanes 4 --cars 32
```

One to five incoming lanes per approach are supported. The default road length
fits up to 24 cars per selected lane count, for example 48 cars with two lanes
or 120 cars with five lanes.

## Left-Turn Signal Mode

Use a dedicated protected left signal:

```bash
intersection-rl simulate --lanes 4 --cars 20 --left-signal protected
```

During each protected-left phase, only left-turn movements on that road axis
have green. The through signal is red. During the following through phase, the
left signal is red.

Use permissive left turns with yielding:

```bash
intersection-rl simulate --lanes 4 --cars 20 --left-signal yield
```

In yield mode, left turns share the through green and must wait for opposing
straight traffic. Each vehicle receives a random valid outgoing destination
lane. Lateral offset, target lane, and turn conflict are included in the policy
observation; steering and lane-centering rewards allow PPO to learn route
following.

Policy checkpoints created before the continuous-action interface are incompatible.
Retrain with the selected `--left-signal`, `--right-on-red`, `--lanes`, and `--cars` settings.

## Right Turn On Red

Right-on-red is enabled by default. A vehicle may use it only from the
rightmost incoming lane and only after conflicting traffic clears:

```bash
intersection-rl simulate --lanes 4 --cars 20 --right-on-red on
```

Disable it when a scenario prohibits right-on-red:

```bash
intersection-rl simulate --lanes 4 --cars 20 --right-on-red off
```

The policy observes whether right-on-red is available, whether conflicting
traffic is present, and whether it is in the rightmost lane. Unsafe yielding,
red-light entry, and wrong-lane right turns have separate penalties and
reported evaluation counters.

## Docker

Do not copy the local `.venv` into the container. Docker installs clean,
container-compatible dependencies from `pyproject.toml`.

Build after unzipping the project:

```bash
docker-compose build
```

Run training headlessly and keep the checkpoint on the host:

```bash
docker-compose run --rm intersection-rl \
  train --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on \
  --steps 100000 --checkpoint checkpoints/week6.npz
```

Evaluate a saved policy:

```bash
docker-compose run --rm intersection-rl \
  evaluate checkpoints/week6.npz \
  --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on \
  --episodes 100
```

### Simulator Window On Linux

Allow the local Docker user to access X11, then launch the simulator:

```bash
xhost +local:docker
docker-compose run --rm simulator \
  simulate --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on
xhost -local:docker
```

The X11 command is for Linux desktops. Windows and macOS need an external X
server, or training/evaluation can be run headlessly without a simulator
window.

### Create A Transfer Zip

Create a clean archive without the machine-specific virtual environment:

```bash
zip -r intersection-rl-week6.zip . \
  -x '.venv/*' '.pytest_cache/*' '__pycache__/*' \
     'intersection_rl.egg-info/*' 'checkpoints/*' '*.zip'
```

Include `checkpoints/*.npz` separately only when a trained policy must also be
transferred. Docker Compose mounts the local `checkpoints/` directory, so new
checkpoints remain available after containers exit.

By default, Compose writes files as Linux user/group `1000:1000`. If the host
account uses different IDs, prefix commands with:

```bash
HOST_UID=$(id -u) HOST_GID=$(id -g) docker-compose run --rm intersection-rl \
  train --curriculum --curriculum-min-lanes 2 --curriculum-max-lanes 5 \
  --curriculum-min-cars 5 --curriculum-max-cars 64 \
  --steps 100000 --checkpoint checkpoints/week6_curriculum.npz
```
