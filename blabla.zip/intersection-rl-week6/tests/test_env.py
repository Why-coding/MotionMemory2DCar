import numpy as np

from intersection_rl.config import EnvConfig
from intersection_rl.cli import curriculum_stage_config, rule_based_actions
from intersection_rl.env import IntersectionEnv
from intersection_rl.geometry import Polyline, build_route_path


def make_env():
    return IntersectionEnv(
        EnvConfig(
            min_cars=8,
            max_cars=12,
            episode_seconds=2.0,
            seed=3,
        )
    )


def rebuild_vehicle_path(env, vehicle):
    vehicle.destination_lane = min(
        vehicle.destination_lane, env.episode_lanes_per_approach - 1
    )
    vehicle.path = Polyline(
        build_route_path(
            vehicle.approach,
            vehicle.lane,
            vehicle.route,
            env.config.lane_width,
            env.config.road_length,
            env.config.intersection_half_size,
            env.episode_lanes_per_approach,
            vehicle.destination_lane,
        )
    )
    vehicle.stop_progress, _ = vehicle.path.project(vehicle.path.points[1])


def test_reset_has_expected_shapes_and_vehicle_count():
    env = make_env()
    observation, info = env.reset(seed=3)
    assert observation.shape == (12, env.OBSERVATION_SIZE)
    assert observation.dtype == np.float32
    assert 8 <= info["active_mask"].sum() <= 12
    assert env.observation_space.contains(observation)


def test_step_returns_per_vehicle_reward():
    env = make_env()
    env.reset(seed=4)
    action = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    observation, reward, terminated, truncated, info = env.step(action)
    assert observation.shape == (12, env.OBSERVATION_SIZE)
    assert reward.shape == (12,)
    assert isinstance(terminated, bool)
    assert isinstance(truncated, bool)
    assert "collisions" in info
    assert "red_light_violations" in info
    assert "failed_vehicles" in info


def test_seeded_reset_is_reproducible():
    env = make_env()
    first, _ = env.reset(seed=9)
    second, _ = env.reset(seed=9)
    np.testing.assert_allclose(first, second)


def test_episode_truncates():
    env = make_env()
    env.reset(seed=2)
    action = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    truncated = False
    for _ in range(env.config.max_steps):
        _, _, _, truncated, _ = env.step(action)
    assert truncated


def test_rule_based_driver_returns_valid_actions():
    env = make_env()
    env.reset(seed=5)
    actions = rule_based_actions(env)
    assert env.action_space.contains(actions)


def test_four_lane_environment_supports_exact_car_count():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=4, min_cars=24, max_cars=24, seed=4
        )
    )
    observation, info = env.reset(seed=4)
    assert observation.shape == (24, env.OBSERVATION_SIZE)
    assert info["active_mask"].sum() == 24
    assert env.config.intersection_half_size >= 16.0


def test_renderer_background_is_light_blue():
    env = IntersectionEnv(
        EnvConfig(min_cars=1, max_cars=1), render_mode="rgb_array"
    )
    env.reset(seed=1)
    frame = env.render()
    np.testing.assert_array_equal(frame[0, 0], [173, 216, 230])
    env.close()


def test_five_lane_environment_supports_user_selected_car_count():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=5, min_cars=32, max_cars=32, seed=5
        )
    )
    observation, info = env.reset(seed=5)
    assert observation.shape == (32, env.OBSERVATION_SIZE)
    assert info["active_mask"].sum() == 32
    assert env.config.intersection_half_size >= 20.0


def test_protected_left_phase_separates_left_and_through_movements():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=True,
            seed=1,
        )
    )
    env.reset(seed=1)
    left, through = env.vehicles
    left.approach = through.approach = "N"
    left.route = "left"
    through.route = "straight"
    assert env._signal_phase()[0] == "NS_LEFT_GREEN"
    assert env._movement_has_green(left)
    assert not env._movement_has_green(through)
    env.elapsed_seconds = env.config.left_signal_green_seconds
    assert env._signal_phase()[0] == "NS_GREEN"
    assert not env._movement_has_green(left)
    assert env._movement_has_green(through)


def test_unprotected_left_detects_opposing_straight_conflict():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=False,
            seed=2,
        )
    )
    env.reset(seed=2)
    left, opposing = env.vehicles
    left.approach = "N"
    left.route = "left"
    opposing.approach = "S"
    opposing.route = "straight"
    opposing.progress = opposing.stop_progress - 5.0
    opposing.speed = 5.0
    assert env._movement_has_green(left)
    assert env._left_turn_conflict(left)


def test_destination_lanes_are_randomized_across_traffic():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=5,
            min_cars=40,
            max_cars=40,
            seed=12,
        )
    )
    env.reset(seed=12)
    destination_lanes = {vehicle.destination_lane for vehicle in env.vehicles}
    assert len(destination_lanes) >= 3
    assert all(0 <= lane < 5 for lane in destination_lanes)


def test_lateral_action_moves_vehicle_toward_route_center():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=3))
    env.reset(seed=3)
    vehicle = env.vehicles[0]
    vehicle.lateral_offset = 0.5
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [0.0, -1.0]  # Coast and steer left.
    env.step(actions)
    assert vehicle.lateral_offset < 0.5


def configure_right_on_red_conflict(env):
    right, crossing = env.vehicles[:2]
    right.approach = "N"
    right.route = "right"
    right.lane = env.config.lanes_per_approach - 1
    crossing.approach = "E"
    crossing.route = "straight"
    crossing.progress = crossing.stop_progress - 5.0
    crossing.speed = 5.0
    env.elapsed_seconds = env.config.signal_green_seconds + env.config.signal_yellow_seconds
    return right, crossing


def test_closed_signal_approach_penalizes_acceleration_before_red_violation():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            seed=11,
        )
    )
    env.reset(seed=11)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.progress = vehicle.stop_progress - 6.0
    vehicle.speed = 2.0
    env.elapsed_seconds = 0.0
    accelerate = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    brake = np.zeros_like(accelerate)
    accelerate[vehicle.vehicle_id] = [1.0, 0.0]
    brake[vehicle.vehicle_id] = [-1.0, 0.0]

    _, accelerate_reward, _, _, _ = env.step(accelerate)
    env.reset(seed=11)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.progress = vehicle.stop_progress - 6.0
    vehicle.speed = 2.0
    env.elapsed_seconds = 0.0
    _, brake_reward, _, _, _ = env.step(brake)

    assert brake_reward[vehicle.vehicle_id] > accelerate_reward[vehicle.vehicle_id]


def test_safety_filter_overrides_unsafe_red_light_acceleration():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            safety_filter_enabled=True,
            seed=13,
        )
    )
    env.reset(seed=13)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.progress = vehicle.stop_progress - 4.0
    vehicle.speed = 5.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [1.0, 0.0]

    _, rewards, _, _, info = env.step(actions)

    assert info["safety_overrides"] == 1
    assert info["unsafe_requests"] == 1
    assert vehicle.acceleration < 0.0
    assert rewards[vehicle.vehicle_id] < 0.0


def test_safety_filter_reserves_intersection_entry():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=False,
            safety_filter_enabled=True,
            seed=33,
        )
    )
    env.reset(seed=33)
    first, second = env.vehicles[:2]
    first.approach = "N"
    first.route = "straight"
    second.approach = "E"
    second.route = "straight"
    rebuild_vehicle_path(env, first)
    rebuild_vehicle_path(env, second)
    first.progress = first.stop_progress - 3.0
    first.speed = 4.0
    second.progress = second.stop_progress - 4.0
    second.speed = 4.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[second.vehicle_id] = [1.0, 0.0]

    _, _, _, _, info = env.step(actions)

    assert info["safety_overrides"] >= 1
    assert second.acceleration < 0.0


def test_safety_filter_brakes_for_occupied_intersection():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=False,
            safety_filter_enabled=True,
            seed=34,
        )
    )
    env.reset(seed=34)
    entering, inside = env.vehicles[:2]
    entering.approach = "N"
    entering.route = "straight"
    inside.approach = "E"
    inside.route = "straight"
    entering.lane = 0
    entering.destination_lane = 0
    inside.lane = 1
    inside.destination_lane = 0
    rebuild_vehicle_path(env, entering)
    rebuild_vehicle_path(env, inside)
    entering.progress = entering.stop_progress - 3.0
    entering.speed = 4.0
    inside.progress = inside.stop_progress + 1.0
    inside.speed = 4.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[entering.vehicle_id] = [0.0, 0.0]

    _, _, _, _, info = env.step(actions)

    assert info["safety_overrides"] >= 1
    assert entering.acceleration < 0.0


def test_safety_filter_clamps_before_closed_stop_line():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            safety_filter_enabled=True,
            seed=35,
        )
    )
    env.reset(seed=35)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.progress = vehicle.stop_progress - 0.02
    vehicle.speed = 3.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [1.0, 0.0]

    _, _, _, _, info = env.step(actions)

    assert info["red_light_violations"] == 0
    assert info["safety_overrides"] == 1
    assert vehicle.progress < vehicle.stop_progress
    assert vehicle.active


def test_safety_filter_can_be_disabled_but_unsafe_request_is_penalized():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            safety_filter_enabled=False,
            seed=14,
        )
    )
    env.reset(seed=14)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.progress = vehicle.stop_progress - 4.0
    vehicle.speed = 5.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [1.0, 0.0]

    env.step(actions)

    assert vehicle.acceleration > 0.0


def test_observation_includes_safety_features():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=15))
    observation, _ = env.reset(seed=15)
    assert env.OBSERVATION_SIZE == 34
    assert observation.shape == (1, 34)
    assert env.observation_space.contains(observation)


def test_curriculum_stage_presets_start_easy_and_scale_up():
    first = curriculum_stage_config(1)
    last = curriculum_stage_config(5)
    assert first["max_cars"] < last["max_cars"]
    assert first["max_lanes"] < last["max_lanes"]
    assert not first["randomize_left"]
    assert last["randomize_left"]


def test_right_on_red_requires_clear_cross_traffic():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=True,
            seed=6,
        )
    )
    env.reset(seed=6)
    right, crossing = configure_right_on_red_conflict(env)
    assert env._can_turn_right_on_red(right)
    assert env._right_turn_conflict(right)
    assert not env._movement_permitted(right)
    crossing.active = False
    assert not env._right_turn_conflict(right)
    assert env._movement_permitted(right)


def test_right_on_red_can_be_disabled():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=False,
            seed=7,
        )
    )
    env.reset(seed=7)
    right, _ = configure_right_on_red_conflict(env)
    assert not env._can_turn_right_on_red(right)
    assert not env._movement_permitted(right)


def test_unsafe_right_on_red_records_yield_violation():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=True,
            safety_filter_enabled=False,
            seed=8,
        )
    )
    env.reset(seed=8)
    right, _ = configure_right_on_red_conflict(env)
    right.progress = right.stop_progress - 0.05
    right.speed = 3.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    _, _, _, _, info = env.step(actions)
    assert info["right_yield_violations"] == 1
    assert info["red_light_violations"] == 0
    assert info["failed_vehicles"] == 1
    assert not right.active


def test_red_light_violator_is_removed_from_active_traffic():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            allow_right_on_red=False,
            safety_filter_enabled=False,
            seed=9,
        )
    )
    env.reset(seed=9)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.progress = vehicle.stop_progress - 0.05
    vehicle.speed = 3.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    _, _, terminated, _, info = env.step(actions)
    assert info["red_light_violations"] == 1
    assert info["completed_vehicles"] == 0
    assert info["failed_vehicles"] == 1
    assert not vehicle.active
    assert vehicle.failed
    assert terminated


def test_right_turns_spawn_only_in_rightmost_lane():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=5,
            min_cars=80,
            max_cars=80,
            seed=22,
        )
    )
    env.reset(seed=22)
    right_turns = [vehicle for vehicle in env.vehicles if vehicle.route == "right"]
    assert right_turns
    assert all(vehicle.lane == 4 for vehicle in right_turns)


def test_rectangular_collision_detects_side_overlap():
    env = IntersectionEnv(EnvConfig(min_cars=2, max_cars=2, seed=30))
    env.reset(seed=30)
    first, second = env.vehicles[:2]
    second.path = first.path
    second.progress = first.progress
    second.lateral_offset = first.lateral_offset + env.config.vehicle_width * 0.4
    collisions = env._detect_collisions()
    assert collisions[first.vehicle_id]
    assert collisions[second.vehicle_id]


def test_close_rectangles_get_proximity_penalty_without_collision():
    env = IntersectionEnv(EnvConfig(min_cars=2, max_cars=2, seed=31))
    env.reset(seed=31)
    first, second = env.vehicles[:2]
    second.path = first.path
    second.approach = first.approach
    second.lane = first.lane
    second.route = first.route
    second.progress = first.progress + env.config.vehicle_length + 0.5
    second.lateral_offset = first.lateral_offset
    collisions = np.zeros(env.config.max_cars, dtype=bool)
    proximity, events = env._detect_proximity_violations(collisions)
    assert events == 1
    assert proximity[first.vehicle_id]
    assert not proximity[second.vehicle_id]


def test_adjacent_lane_rectangles_are_not_proximity_violations():
    env = IntersectionEnv(EnvConfig(lanes_per_approach=2, min_cars=2, max_cars=2, seed=32))
    env.reset(seed=32)
    first, second = env.vehicles[:2]
    second.path = first.path
    second.progress = first.progress
    second.lateral_offset = first.lateral_offset + env.config.lane_width
    collisions = np.zeros(env.config.max_cars, dtype=bool)
    proximity, events = env._detect_proximity_violations(collisions)
    assert events == 0
    assert not proximity[first.vehicle_id]
    assert not proximity[second.vehicle_id]


def test_curriculum_randomizes_episode_settings_with_fixed_shapes():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=5,
            max_cars=24,
            lanes_per_approach=5,
            curriculum_enabled=True,
            curriculum_min_lanes=2,
            curriculum_max_lanes=5,
            curriculum_min_cars=5,
            curriculum_max_cars=24,
            seed=44,
        )
    )
    shapes = set()
    lane_counts = set()
    active_counts = set()
    left_modes = set()
    right_modes = set()
    for seed in range(44, 60):
        observation, info = env.reset(seed=seed)
        shapes.add(observation.shape)
        lane_counts.add(info["episode_lanes_per_approach"])
        active_counts.add(int(info["active_mask"].sum()))
        left_modes.add(info["episode_protected_left_signal"])
        right_modes.add(info["episode_allow_right_on_red"])
    assert shapes == {(24, env.OBSERVATION_SIZE)}
    assert len(lane_counts) > 1
    assert len(active_counts) > 1
    assert left_modes == {False, True}
    assert right_modes == {False, True}


def test_stage2_curriculum_progression_scales_8_10_11_12_cars():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=8,
            max_cars=12,
            lanes_per_approach=2,
            protected_left_signal=True,
            allow_right_on_red=False,
            curriculum_enabled=True,
            curriculum_min_lanes=2,
            curriculum_max_lanes=2,
            curriculum_min_cars=8,
            curriculum_max_cars=12,
            curriculum_progression_enabled=True,
            curriculum_stage=2,
            stage2_phase1_episodes=2,
            stage2_phase2_episodes=4,
            stage2_phase3_episodes=6,
            seed=50,
        )
    )

    counts = []
    for seed in range(50, 59):
        _, info = env.reset(seed=seed)
        counts.append(int(info["active_mask"].sum()))

    assert counts[:2] == [8, 8]
    assert counts[2:4] == [10, 10]
    assert counts[4:6] == [11, 11]
    assert counts[6:8] == [12, 12]
    assert 8 <= counts[8] <= 12


def test_stage3_curriculum_progression_scales_lanes_and_right_on_red_load():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=8,
            max_cars=16,
            lanes_per_approach=3,
            protected_left_signal=True,
            allow_right_on_red=True,
            curriculum_enabled=True,
            curriculum_min_lanes=2,
            curriculum_max_lanes=3,
            curriculum_min_cars=8,
            curriculum_max_cars=16,
            curriculum_randomize_right_on_red=False,
            curriculum_progression_enabled=True,
            curriculum_stage=3,
            stage3_phase1_episodes=2,
            stage3_phase2_episodes=4,
            stage3_phase3_episodes=6,
            stage3_phase4_episodes=8,
            stage3_phase5_episodes=10,
            stage3_phase6_episodes=12,
            seed=60,
        )
    )

    states = []
    for seed in range(60, 73):
        _, info = env.reset(seed=seed)
        states.append((
            info["episode_lanes_per_approach"],
            int(info["active_mask"].sum()),
            info["episode_allow_right_on_red"],
        ))

    assert states[:2] == [(2, 8, True), (2, 8, True)]
    assert states[2:4] == [(2, 10, True), (2, 10, True)]
    assert states[4:6] == [(2, 12, True), (2, 12, True)]
    assert states[6:8] == [(3, 10, True), (3, 10, True)]
    assert states[8:10] == [(3, 12, True), (3, 12, True)]
    assert states[10:12] == [(3, 14, True), (3, 14, True)]
    final_lanes, final_cars, final_right_on_red = states[12]
    assert 2 <= final_lanes <= 3
    assert 8 <= final_cars <= 16
    assert final_right_on_red


def test_curriculum_caps_active_cars_to_sampled_lane_capacity():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=5,
            max_cars=64,
            lanes_per_approach=5,
            curriculum_enabled=True,
            curriculum_min_lanes=2,
            curriculum_max_lanes=2,
            curriculum_min_cars=5,
            curriculum_max_cars=64,
            seed=55,
        )
    )
    for seed in range(55, 65):
        _, info = env.reset(seed=seed)
        assert info["active_mask"].sum() <= env._lane_capacity(2)
        assert info["active_mask"].sum() <= 64


def test_train_parser_accepts_init_checkpoint():
    from intersection_rl.cli import build_parser

    args = build_parser().parse_args([
        "train",
        "--curriculum-stage",
        "2",
        "--init-checkpoint",
        "checkpoints/stage1_best.npz",
        "--checkpoint",
        "checkpoints/stage2.npz",
    ])

    assert args.curriculum_stage == 2
    assert str(args.init_checkpoint) == "checkpoints/stage1_best.npz"
    assert str(args.checkpoint) == "checkpoints/stage2.npz"


def test_legal_right_on_red_entry_is_not_red_violation():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=True,
            safety_filter_enabled=False,
            seed=36,
        )
    )
    env.reset(seed=36)
    right, crossing = configure_right_on_red_conflict(env)
    crossing.active = False
    right.progress = right.stop_progress - 0.05
    right.speed = 3.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    _, _, _, _, info = env.step(actions)

    assert info["right_on_red_entries"] == 1
    assert info["red_light_violations"] == 0
    assert info["right_yield_violations"] == 0


def test_lateral_offset_is_clamped_inside_lane():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=37))
    env.reset(seed=37)
    vehicle = env.vehicles[0]
    vehicle.lateral_offset = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [0.0, 1.0]

    for _ in range(50):
        env.step(actions)

    assert abs(vehicle.lateral_offset) <= env._max_lateral_offset()
    assert env._max_lateral_offset() < env.config.lane_width / 2.0



def test_zero_steering_recenters_lateral_offset():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=41))
    env.reset(seed=41)
    vehicle = env.vehicles[0]
    vehicle.lateral_offset = 0.8
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    env.step(actions)

    assert abs(vehicle.lateral_offset) < 0.8


def test_timeout_active_vehicle_counts_as_failed_not_incomplete():
    env = IntersectionEnv(
        EnvConfig(min_cars=1, max_cars=1, episode_seconds=0.2, seed=42)
    )
    env.reset(seed=42)
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    _, _, terminated, truncated, info = env.step(actions)

    assert truncated
    assert terminated
    assert info["completed_vehicles"] == 0
    assert info["failed_vehicles"] == 1
    assert info["timeout_failures"] == 1
    assert not env.vehicles[0].active
    assert env.vehicles[0].failed

def test_observation_includes_predictive_conflict_features():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=False,
            safety_filter_enabled=False,
            seed=38,
        )
    )
    observation, _ = env.reset(seed=38)
    first, second = env.vehicles[:2]
    first.approach = "N"
    first.route = "straight"
    second.approach = "E"
    second.route = "straight"
    rebuild_vehicle_path(env, first)
    rebuild_vehicle_path(env, second)
    first.progress = first.stop_progress - 3.0
    first.speed = 4.0
    second.progress = second.stop_progress - 3.0
    second.speed = 4.0
    env.elapsed_seconds = 0.0

    observation = env._get_observation()

    assert observation[first.vehicle_id, 26] >= 0.0
    assert observation[first.vehicle_id, 27] >= 0.0
    assert observation[first.vehicle_id, 30] in (0.0, 1.0)
    assert observation[first.vehicle_id, 31] in (0.0, 1.0)
    assert observation[first.vehicle_id, 32] in (0.0, 1.0)
    assert 0.0 <= observation[first.vehicle_id, 33] <= 1.0
