from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.distributions import Normal

from intersection_rl.config import PPOConfig


class SharedActorCritic(nn.Module):
    """Shared PyTorch MLP with a Gaussian continuous-action policy."""

    min_log_std = -2.5
    max_log_std = -0.5

    def __init__(
        self,
        observation_size: int,
        hidden_size: int,
        action_size: int = 2,
        seed: int = 7,
    ) -> None:
        super().__init__()
        torch.manual_seed(seed)
        self.observation_size = observation_size
        self.hidden_size = hidden_size
        self.action_size = action_size
        self.policy_body = nn.Sequential(
            nn.Linear(observation_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh(),
        )
        self.policy_head = nn.Linear(hidden_size, action_size)
        self.value_head = nn.Linear(hidden_size, 1)
        self.log_std = nn.Parameter(torch.full((action_size,), -1.0))
        self._init_weights()

    def _init_weights(self) -> None:
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.orthogonal_(module.weight, gain=np.sqrt(2.0))
                nn.init.zeros_(module.bias)
        nn.init.orthogonal_(self.policy_head.weight, gain=0.01)
        nn.init.zeros_(self.policy_head.bias)
        nn.init.orthogonal_(self.value_head.weight, gain=1.0)
        nn.init.zeros_(self.value_head.bias)

    @property
    def device(self) -> torch.device:
        return next(self.parameters()).device

    def _tensor(self, array: np.ndarray) -> torch.Tensor:
        return torch.as_tensor(array, dtype=torch.float32, device=self.device)

    def _forward_tensor(self, observations: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        features = self.policy_body(observations)
        mean = torch.tanh(self.policy_head(features))
        values = self.value_head(features).squeeze(-1)
        return mean, values

    def forward(self, observations: np.ndarray) -> tuple[np.ndarray, np.ndarray, tuple[()]]:
        with torch.no_grad():
            mean, values = self._forward_tensor(self._tensor(observations))
        return mean.cpu().numpy(), values.cpu().numpy(), ()

    def distribution(self, observations: torch.Tensor) -> tuple[Normal, torch.Tensor, torch.Tensor]:
        mean, values = self._forward_tensor(observations)
        log_std = torch.clamp(self.log_std, self.min_log_std, self.max_log_std)
        std = torch.exp(log_std).expand_as(mean)
        return Normal(mean, std), mean, values

    def act(
        self,
        observations: np.ndarray,
        rng: np.random.Generator | None = None,
        deterministic: bool = False,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        del rng
        with torch.no_grad():
            obs = self._tensor(observations)
            dist, mean, values = self.distribution(obs)
            actions = mean if deterministic else dist.sample()
            actions = torch.clamp(actions, -1.0, 1.0)
            log_probs = dist.log_prob(actions).sum(dim=-1)
        return (
            actions.cpu().numpy().astype(np.float32),
            log_probs.cpu().numpy().astype(np.float32),
            values.cpu().numpy().astype(np.float32),
        )

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        state = {name: tensor.detach().cpu().numpy() for name, tensor in self.state_dict().items()}
        metadata = {
            "format": np.array("torch_state_npz"),
            "observation_size": np.array(self.observation_size),
            "hidden_size": np.array(self.hidden_size),
            "action_size": np.array(self.action_size),
        }
        np.savez(path, **state, **metadata)

    def load(self, path: str | Path) -> None:
        data = np.load(path, allow_pickle=False)
        keys = set(data.files)
        state = self.state_dict()
        if "policy_body.0.weight" in keys:
            loaded_state = dict(state)
            for name in state:
                if name not in keys:
                    continue
                source = torch.as_tensor(data[name], dtype=state[name].dtype)
                if source.shape == state[name].shape:
                    loaded_state[name] = source
                elif name == "policy_body.0.weight" and source.shape[0] == state[name].shape[0]:
                    target = state[name].clone()
                    width = min(source.shape[1], target.shape[1])
                    target.zero_()
                    target[:, :width] = source[:, :width]
                    loaded_state[name] = target
                else:
                    raise ValueError(
                        f"Checkpoint tensor {name} has incompatible shape {tuple(source.shape)}; "
                        f"expected {tuple(state[name].shape)}"
                    )
            self.load_state_dict(loaded_state)
            return
        old_keys = {"w1", "b1", "w2", "b2", "wp", "bp", "log_std", "wv", "bv"}
        if old_keys.issubset(keys):
            with torch.no_grad():
                old_w1 = torch.as_tensor(data["w1"].T, dtype=torch.float32)
                self.policy_body[0].weight.zero_()
                self.policy_body[0].weight[:, : old_w1.shape[1]].copy_(old_w1)
                self.policy_body[0].bias.copy_(torch.as_tensor(data["b1"], dtype=torch.float32))
                self.policy_body[2].weight.copy_(torch.as_tensor(data["w2"].T, dtype=torch.float32))
                self.policy_body[2].bias.copy_(torch.as_tensor(data["b2"], dtype=torch.float32))
                self.policy_head.weight.copy_(torch.as_tensor(data["wp"].T, dtype=torch.float32))
                self.policy_head.bias.copy_(torch.as_tensor(data["bp"], dtype=torch.float32))
                self.value_head.weight.copy_(torch.as_tensor(data["wv"].T, dtype=torch.float32))
                self.value_head.bias.copy_(torch.as_tensor(data["bv"], dtype=torch.float32))
                self.log_std.copy_(torch.as_tensor(data["log_std"], dtype=torch.float32))
            return
        raise ValueError(f"Unsupported checkpoint format: {path}")


@dataclass(slots=True)
class Rollout:
    observations: np.ndarray
    actions: np.ndarray
    log_probs: np.ndarray
    rewards: np.ndarray
    values: np.ndarray
    dones: np.ndarray
    masks: np.ndarray
    last_values: np.ndarray
    info_metrics: dict[str, float]

    def advantages_and_returns(
        self, gamma: float, gae_lambda: float
    ) -> tuple[np.ndarray, np.ndarray]:
        advantages = np.zeros_like(self.rewards)
        gae = np.zeros(self.rewards.shape[1], dtype=np.float32)
        for time_index in reversed(range(len(self.rewards))):
            next_values = (
                self.last_values
                if time_index == len(self.rewards) - 1
                else self.values[time_index + 1]
            )
            nonterminal = 1.0 - self.dones[time_index]
            delta = (
                self.rewards[time_index]
                + gamma * next_values * nonterminal
                - self.values[time_index]
            )
            gae = delta + gamma * gae_lambda * nonterminal * gae
            gae *= self.masks[time_index]
            advantages[time_index] = gae
        return advantages, advantages + self.values


class PPOTrainer:
    """PPO trainer using one shared continuous PyTorch policy for all vehicle slots."""

    def __init__(self, env, config: PPOConfig) -> None:
        self.env = env
        self.config = config
        self.rng = np.random.default_rng(config.seed)
        torch.manual_seed(config.seed)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = SharedActorCritic(
            env.OBSERVATION_SIZE,
            config.hidden_size,
            env.ACTION_SIZE,
            seed=config.seed,
        ).to(self.device)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=config.learning_rate)
        self.observation, self.info = env.reset(seed=config.seed)

    def collect_rollout(self) -> Rollout:
        storage: dict[str, list[np.ndarray]] = {
            key: []
            for key in (
                "observations",
                "actions",
                "log_probs",
                "rewards",
                "values",
                "dones",
                "masks",
            )
        }
        info_metrics = {
            "completed_clean": 0.0,
            "failed": 0.0,
            "collisions": 0.0,
            "proximity": 0.0,
            "proximity_events": 0.0,
            "red": 0.0,
            "left_yield": 0.0,
            "right_yield": 0.0,
            "right_lane": 0.0,
            "lane_drift": 0.0,
            "right_on_red_entries": 0.0,
            "safety_overrides": 0.0,
            "policy_samples": 0.0,
            "env_steps": 0.0,
            "unsafe_requests": 0.0,
            "progress": 0.0,
            "safety_score": 0.0,
        }
        for _ in range(self.config.rollout_steps):
            actions, log_probs, values = self.model.act(self.observation)
            mask = self.info["active_mask"].copy()
            active_count = float(mask.sum())
            next_observation, rewards, terminated, truncated, next_info = self.env.step(actions)
            rewards = np.clip(rewards, -self.config.reward_clip, self.config.reward_clip)
            info_metrics["completed_clean"] += float(next_info.get("completed_delta", 0))
            info_metrics["failed"] += float(next_info.get("failed_delta", 0))
            info_metrics["collisions"] += float(next_info.get("collisions", 0))
            info_metrics["proximity"] += float(next_info.get("proximity_violations", 0))
            info_metrics["proximity_events"] += float(next_info.get("proximity_events", 0))
            info_metrics["red"] += float(next_info.get("red_light_violations", 0))
            info_metrics["left_yield"] += float(next_info.get("left_yield_violations", 0))
            info_metrics["right_yield"] += float(next_info.get("right_yield_violations", 0))
            info_metrics["right_lane"] += float(next_info.get("right_lane_violations", 0))
            info_metrics["lane_drift"] += float(next_info.get("lane_drift_warnings", 0))
            info_metrics["right_on_red_entries"] += float(next_info.get("right_on_red_entries", 0))
            info_metrics["safety_overrides"] += float(next_info.get("safety_overrides", 0))
            info_metrics["policy_samples"] += active_count
            info_metrics["env_steps"] += 1.0
            info_metrics["unsafe_requests"] += float(next_info.get("unsafe_requests", 0))
            info_metrics["progress"] += float(next_info.get("progress_delta", 0.0))
            info_metrics["safety_score"] += float(next_info.get("safety_score", 0.0))
            done = terminated or truncated
            storage["observations"].append(self.observation.copy())
            storage["actions"].append(actions)
            storage["log_probs"].append(log_probs)
            storage["rewards"].append(rewards)
            storage["values"].append(values)
            storage["dones"].append(np.full_like(rewards, float(done)))
            storage["masks"].append(mask)
            self.observation, self.info = next_observation, next_info
            if done:
                self.observation, self.info = self.env.reset()

        _, last_values, _ = self.model.forward(self.observation)
        arrays = {key: np.asarray(value) for key, value in storage.items()}
        return Rollout(**arrays, last_values=last_values, info_metrics=info_metrics)

    def update(self, rollout: Rollout) -> dict[str, float]:
        advantages, returns = rollout.advantages_and_returns(
            self.config.gamma, self.config.gae_lambda
        )
        active = rollout.masks.reshape(-1).astype(bool)
        observations = rollout.observations.reshape(-1, rollout.observations.shape[-1])[active]
        actions = rollout.actions.reshape(-1, rollout.actions.shape[-1])[active]
        old_log_probs = rollout.log_probs.reshape(-1)[active]
        advantages = advantages.reshape(-1)[active]
        returns = returns.reshape(-1)[active]
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        obs_t = torch.as_tensor(observations, dtype=torch.float32, device=self.device)
        act_t = torch.as_tensor(actions, dtype=torch.float32, device=self.device)
        old_log_t = torch.as_tensor(old_log_probs, dtype=torch.float32, device=self.device)
        adv_t = torch.as_tensor(advantages, dtype=torch.float32, device=self.device)
        ret_t = torch.as_tensor(returns, dtype=torch.float32, device=self.device)

        indices = np.arange(len(actions))
        metrics: dict[str, float] = {}
        update_count = 0
        for _ in range(self.config.update_epochs):
            self.rng.shuffle(indices)
            for start in range(0, len(indices), self.config.minibatch_size):
                batch_np = indices[start : start + self.config.minibatch_size]
                batch = torch.as_tensor(batch_np, dtype=torch.long, device=self.device)
                dist, _, values = self.model.distribution(obs_t[batch])
                log_probs = dist.log_prob(act_t[batch]).sum(dim=-1)
                entropy = dist.entropy().sum(dim=-1).mean()
                ratio = torch.exp(log_probs - old_log_t[batch])
                unclipped = ratio * adv_t[batch]
                clipped = torch.clamp(
                    ratio,
                    1.0 - self.config.clip_ratio,
                    1.0 + self.config.clip_ratio,
                ) * adv_t[batch]
                policy_loss = -torch.min(unclipped, clipped).mean()
                value_loss = 0.5 * torch.mean((values - ret_t[batch]) ** 2)
                loss = (
                    policy_loss
                    + self.config.value_coefficient * value_loss
                    - self.config.entropy_coefficient * entropy
                )
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
                self.optimizer.step()
                with torch.no_grad():
                    self.model.log_std.clamp_(
                        self.model.min_log_std,
                        self.model.max_log_std,
                    )
                approximate_kl = torch.mean(old_log_t[batch] - log_probs).item()
                batch_metrics = {
                    "policy_loss": float(policy_loss.item()),
                    "value_loss": float(value_loss.item()),
                    "entropy": float(entropy.item()),
                    "approximate_kl": float(approximate_kl),
                }
                for key, value in batch_metrics.items():
                    metrics[key] = metrics.get(key, 0.0) + value
                update_count += 1
        metrics = {key: value / update_count for key, value in metrics.items()}
        active_rewards = rollout.rewards[rollout.masks.astype(bool)]
        metrics["rollout_mean_reward"] = float(active_rewards.mean())
        metrics.update(rollout.info_metrics)
        return metrics

    def train(self, checkpoint_path: str | Path) -> SharedActorCritic:
        checkpoint_path = Path(checkpoint_path)
        completed_steps = 0
        total_policy_samples = 0.0
        total_vehicle_hours = 0.0
        update_index = 0
        best_safety_score = -float("inf")
        while completed_steps < self.config.total_steps:
            rollout = self.collect_rollout()
            metrics = self.update(rollout)
            completed_steps += self.config.rollout_steps
            total_policy_samples += metrics.get("policy_samples", 0.0)
            total_vehicle_hours += (
                metrics.get("policy_samples", 0.0) * self.env.config.dt / 3600.0
            )
            update_index += 1
            if metrics["safety_score"] > best_safety_score:
                best_safety_score = metrics["safety_score"]
                best_path = checkpoint_path.with_name(
                    f"{checkpoint_path.stem}_best{checkpoint_path.suffix}"
                )
                self.model.save(best_path)
            if self.config.checkpoint_interval_updates > 0 and (
                update_index % self.config.checkpoint_interval_updates == 0
            ):
                interim_path = checkpoint_path.with_name(
                    f"{checkpoint_path.stem}_update_{update_index:04d}{checkpoint_path.suffix}"
                )
                self.model.save(interim_path)
            print(
                f"update={update_index:04d} steps={completed_steps:07d} "
                f"reward={metrics['rollout_mean_reward']:+.4f} "
                f"policy={metrics['policy_loss']:+.4f} "
                f"value={metrics['value_loss']:.4f} "
                f"entropy={metrics['entropy']:.3f} "
                f"kl={metrics['approximate_kl']:+.5f} "
                f"score={metrics['safety_score']:+.1f} "
                f"clean={metrics['completed_clean']:.0f} "
                f"failed={metrics['failed']:.0f} "
                f"coll={metrics['collisions']:.0f} "
                f"prox={metrics['proximity']:.0f}/{metrics.get('proximity_events', 0):.0f} "
                f"red={metrics['red']:.0f} "
                f"yield={metrics['left_yield'] + metrics['right_yield']:.0f} "
                f"drift={metrics.get('lane_drift', 0):.0f} "
                f"progress={metrics['progress']:.1f} "
                f"shield={metrics['safety_overrides']:.0f} "
                f"samples={metrics.get('policy_samples', 0):.0f} "
                f"veh_hr={metrics.get('policy_samples', 0) * self.env.config.dt / 3600.0:.3f}"
            )
        self.model.save(checkpoint_path)
        print(
            f"training_summary env_steps={completed_steps} "
            f"policy_samples={total_policy_samples:.0f} "
            f"simulated_env_hours={completed_steps * self.env.config.dt / 3600.0:.3f} "
            f"vehicle_hours={total_vehicle_hours:.3f}"
        )
        return self.model
