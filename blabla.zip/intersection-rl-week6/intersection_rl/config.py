from dataclasses import dataclass


@dataclass(slots=True)
class EnvConfig:
    """Configuration for the intersection simulator."""

    # Week 5: initial two-lane, signalized, four-way intersection.
    max_cars: int = 12
    min_cars: int = 8
    lanes_per_approach: int = 2
    lane_width: float = 4.0
    road_length: float = 65.0
    intersection_half_size: float = 10.0
    dt: float = 0.2
    episode_seconds: float = 60.0
    signal_green_seconds: float = 12.0
    signal_yellow_seconds: float = 3.0
    protected_left_signal: bool = False
    left_signal_green_seconds: float = 5.0
    left_yield_distance: float = 22.0
    allow_right_on_red: bool = True
    right_yield_distance: float = 24.0
    lateral_speed: float = 1.2
    lane_centering_gain: float = 0.9
    lane_edge_steering_damping: float = 0.75
    initial_lateral_noise: float = 0.8
    max_speed: float = 13.4
    max_acceleration: float = 2.5
    comfortable_braking: float = 4.0
    vehicle_length: float = 4.5
    vehicle_width: float = 1.8
    collision_distance: float = 3.2
    proximity_clearance: float = 0.75
    lane_edge_margin: float = 0.1
    lane_drift_warning_ratio: float = 0.8
    safety_filter_enabled: bool = True
    intersection_reservation_enabled: bool = True
    intersection_reservation_distance: float = 12.0
    proximity_filter_clearance: float = 1.5
    safety_override_penalty: float = 0.8
    unsafe_acceleration_penalty: float = 0.3
    ttc_warning_seconds: float = 3.0
    ttc_critical_seconds: float = 1.5
    minimum_front_gap: float = 7.0
    prediction_horizon_seconds: float = 2.0
    prediction_step_seconds: float = 0.5
    conflict_lookahead_distance: float = 18.0
    predicted_conflict_penalty: float = 0.8
    predicted_proximity_penalty: float = 0.25
    progress_reward: float = 0.35
    permitted_speed_reward: float = 0.04
    permitted_acceleration_reward: float = 0.04
    permitted_idle_penalty: float = 1.0
    clean_completion_bonus: float = 40.0
    timeout_failure_penalty: float = 8.0
    seed: int | None = None
    curriculum_enabled: bool = False
    curriculum_min_lanes: int = 1
    curriculum_max_lanes: int = 5
    curriculum_min_cars: int = 5
    curriculum_max_cars: int = 64
    curriculum_randomize_left_signal: bool = True
    curriculum_randomize_right_on_red: bool = True

    def __post_init__(self) -> None:
        if not 1 <= self.lanes_per_approach <= 5:
            raise ValueError("lanes_per_approach must be between 1 and 5")
        if self.min_cars < 1 or self.max_cars < self.min_cars:
            raise ValueError("car counts must satisfy 1 <= min_cars <= max_cars")
        if not 1 <= self.curriculum_min_lanes <= self.curriculum_max_lanes <= 5:
            raise ValueError("curriculum lanes must satisfy 1 <= min <= max <= 5")
        if not 1 <= self.curriculum_min_cars <= self.curriculum_max_cars:
            raise ValueError("curriculum cars must satisfy 1 <= min <= max")
        if self.curriculum_enabled and self.max_cars < self.curriculum_max_cars:
            raise ValueError("max_cars must be >= curriculum_max_cars")
        if self.curriculum_enabled and self.min_cars > self.curriculum_min_cars:
            raise ValueError("min_cars must be <= curriculum_min_cars")
        maximum_lane_count = max(self.lanes_per_approach, self.curriculum_max_lanes)
        minimum_intersection_size = maximum_lane_count * self.lane_width
        self.intersection_half_size = max(
            self.intersection_half_size, minimum_intersection_size
        )

    @property
    def max_steps(self) -> int:
        return round(self.episode_seconds / self.dt)


@dataclass(slots=True)
class PPOConfig:
    """Hyperparameters for the dependency-light NumPy PPO implementation."""

    # Week 6: completed lane scaling, turn signals, right-on-red, and yielding.
    # Week 7: replace kinematics with kinodynamics, speed limits, and merges.
    # Week 8: add parking lanes, parked cars, crosswalks, and pedestrians.
    # Week 9: add jaywalking and vehicle lane changes.
    # Week 10: add per-car goals and cut-in scenario generation.
    # Week 11: add unprotected turns, noise, occlusion, and ROS bag adapters.
    # Week 12: calibrate and deploy the policy in the Nissan simulator.

    # Week 5: shared PPO policy for all active cars.
    total_steps: int = 100_000
    rollout_steps: int = 256
    update_epochs: int = 8
    minibatch_size: int = 512
    hidden_size: int = 64
    learning_rate: float = 3e-4
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_ratio: float = 0.2
    value_coefficient: float = 0.5
    entropy_coefficient: float = 0.001
    max_grad_norm: float = 0.5
    checkpoint_interval_updates: int = 10
    reward_clip: float = 20.0
    seed: int = 7
