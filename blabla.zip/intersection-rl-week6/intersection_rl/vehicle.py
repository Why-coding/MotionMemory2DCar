from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from intersection_rl.geometry import Polyline


@dataclass(slots=True)
class Vehicle:
    vehicle_id: int
    approach: str
    lane: int
    route: str
    destination_lane: int
    path: Polyline
    stop_progress: float
    progress: float
    speed: float
    acceleration: float = 0.0
    lateral_offset: float = 0.0
    steering: float = 0.0
    active: bool = True
    collided: bool = False
    failed: bool = False
    crossed_on_red: bool = False
    previous_position: np.ndarray = field(default_factory=lambda: np.zeros(2))

    def pose(self) -> tuple[np.ndarray, float]:
        position, heading = self.path.sample(self.progress)
        normal = np.array([-np.sin(heading), np.cos(heading)])
        return position + normal * self.lateral_offset, heading

    def step(
        self,
        requested_acceleration: float,
        requested_steering: float,
        dt: float,
        max_speed: float,
        lateral_speed: float,
        max_lateral_offset: float,
        lane_centering_gain: float = 0.0,
        lane_edge_steering_damping: float = 0.0,
    ) -> None:
        self.acceleration = requested_acceleration
        self.steering = 0.0
        self.lateral_offset = 0.0
        self.speed = float(
            np.clip(self.speed + requested_acceleration * dt, 0.0, max_speed)
        )
        self.previous_position = self.pose()[0]
        self.progress += self.speed * dt
        if self.progress >= self.path.length:
            self.active = False
