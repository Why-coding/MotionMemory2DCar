from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from intersection_rl.config import EnvConfig
from intersection_rl.geometry import (
    APPROACHES,
    ROUTES,
    Polyline,
    build_route_path,
)
from intersection_rl.vehicle import Vehicle


class IntersectionEnv(gym.Env[np.ndarray, np.ndarray]):
    """Multi-agent four-way intersection with a parameter-sharing interface.

    The first dimension of the observation and action arrays is a stable vehicle
    slot. Inactive slots are masked in ``info["active_mask"]`` and ignored.
    """

    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 5}
    OBSERVATION_SIZE = 34
    ACTION_SIZE = 2

    def __init__(
        self,
        config: EnvConfig | None = None,
        render_mode: str | None = None,
    ) -> None:
        super().__init__()
        self.config = config or EnvConfig()
        self.render_mode = render_mode
        self.observation_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(self.config.max_cars, self.OBSERVATION_SIZE),
            dtype=np.float32,
        )
        self.action_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(self.config.max_cars, self.ACTION_SIZE),
            dtype=np.float32,
        )
        self.vehicles: list[Vehicle] = []
        self.elapsed_seconds = 0.0
        self.step_count = 0
        self.completed_vehicles = 0
        self.failed_vehicles = 0
        self.safety_overrides = 0
        self._collision_pairs: set[tuple[int, int]] = set()
        self._predictive_cache_key: tuple[tuple[int, bool, float, float, float], ...] | None = None
        self._predictive_cache: np.ndarray | None = None
        self._route_conflict_cache: dict[tuple[tuple[object, ...], tuple[object, ...]], bool] = {}
        self._renderer = None
        self.episode_lanes_per_approach = self.config.lanes_per_approach
        self.episode_protected_left_signal = self.config.protected_left_signal
        self.episode_allow_right_on_red = self.config.allow_right_on_red

    # Week 5: initialize 8-12 vehicles on legal two-lane movements.
    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed if seed is not None else self.config.seed)
        self.elapsed_seconds = 0.0
        self.step_count = 0
        self.completed_vehicles = 0
        self.failed_vehicles = 0
        self.safety_overrides = 0
        self._collision_pairs.clear()
        self._predictive_cache_key = None
        self._predictive_cache = None
        self._route_conflict_cache.clear()
        self.vehicles = []
        self._sample_episode_configuration()
        requested_count = (options or {}).get("vehicle_count")
        capacity = self._lane_capacity(self.episode_lanes_per_approach)
        min_count = self.config.min_cars
        max_count = min(self.config.max_cars, capacity)
        if min_count > max_count:
            raise ValueError(
                "sampled lane count cannot fit the configured minimum cars"
            )
        count = int(
            requested_count
            if requested_count is not None
            else self.np_random.integers(min_count, max_count + 1)
        )
        if not min_count <= count <= max_count:
            raise ValueError("vehicle_count must be inside configured bounds")
        self._spawn_vehicles(count)
        observation = self._get_observation()
        info = self._get_info(np.zeros(self.config.max_cars, dtype=np.float32))
        if self.render_mode == "human":
            self.render()
        return observation, info


    def _sample_episode_configuration(self) -> None:
        if not self.config.curriculum_enabled:
            self.episode_lanes_per_approach = self.config.lanes_per_approach
            self.episode_protected_left_signal = self.config.protected_left_signal
            self.episode_allow_right_on_red = self.config.allow_right_on_red
            return
        self.episode_lanes_per_approach = int(
            self.np_random.integers(
                self.config.curriculum_min_lanes,
                self.config.curriculum_max_lanes + 1,
            )
        )
        self.config.min_cars = self.config.curriculum_min_cars
        self.config.max_cars = self.config.curriculum_max_cars
        self.episode_protected_left_signal = (
            bool(self.np_random.integers(2))
            if self.config.curriculum_randomize_left_signal
            else self.config.protected_left_signal
        )
        self.episode_allow_right_on_red = (
            bool(self.np_random.integers(2))
            if self.config.curriculum_randomize_right_on_red
            else self.config.allow_right_on_red
        )


    def _lane_capacity(self, lane_count: int) -> int:
        queue_spacing = self.config.vehicle_length + 5.0
        maximum_queue_levels = max(
            1, int((self.config.road_length - 12.0) / queue_spacing) + 1
        )
        return 4 * lane_count * maximum_queue_levels

    def _spawn_vehicles(self, count: int) -> None:
        queue_spacing = self.config.vehicle_length + 5.0
        queue_levels = int(np.ceil(count / (4 * self.episode_lanes_per_approach)))
        maximum_queue_levels = max(
            1, int((self.config.road_length - 12.0) / queue_spacing) + 1
        )
        if queue_levels > maximum_queue_levels:
            capacity = self._lane_capacity(self.episode_lanes_per_approach)
            raise ValueError(
                f"{count} cars do not fit on the configured roads; maximum is {capacity}"
            )
        slot_candidates = [
            (approach, lane, queue_index)
            for queue_index in range(queue_levels)
            for approach in APPROACHES
            for lane in range(self.episode_lanes_per_approach)
        ]
        selected = self.np_random.choice(
            len(slot_candidates), size=count, replace=False
        )
        for vehicle_id, slot_index in enumerate(selected):
            approach, lane, queue_index = slot_candidates[int(slot_index)]
            # Week 6: route permissions adapt to the selected lane count.
            if self.episode_lanes_per_approach == 1:
                legal_routes: Sequence[str] = ("left", "straight", "right")
            elif lane == 0:
                legal_routes = ("left", "straight")
            elif lane == self.episode_lanes_per_approach - 1:
                legal_routes = ("straight", "right")
            else:
                legal_routes = ("straight",)
            route = str(self.np_random.choice(legal_routes))
            # Week 6: each movement may target any outgoing lane.
            destination_lane = int(
                self.np_random.integers(self.episode_lanes_per_approach)
            )
            path = Polyline(
                build_route_path(
                    approach,
                    lane,
                    route,
                    self.config.lane_width,
                    self.config.road_length,
                    self.config.intersection_half_size,
                    self.episode_lanes_per_approach,
                    destination_lane,
                )
            )
            stop_progress, _ = path.project(
                path.points[1]
            )
            progress = max(0.0, stop_progress - 12.0 - queue_index * queue_spacing)
            speed = float(self.np_random.uniform(3.0, 8.0))
            self.vehicles.append(
                Vehicle(
                    vehicle_id=vehicle_id,
                    approach=approach,
                    lane=lane,
                    route=route,
                    destination_lane=destination_lane,
                    path=path,
                    stop_progress=stop_progress,
                    progress=progress,
                    speed=speed,
                    lateral_offset=float(
                        self.np_random.uniform(
                            -self.config.initial_lateral_noise,
                            self.config.initial_lateral_noise,
                        )
                    ),
                )
            )

    # Week 5: basic longitudinal kinematic model and traffic-rule events.
    def step(
        self, action: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, bool, bool, dict[str, Any]]:
        actions = np.asarray(action, dtype=np.float32)
        if actions.shape != (self.config.max_cars, self.ACTION_SIZE):
            raise ValueError(
                f"action must have shape ({self.config.max_cars}, {self.ACTION_SIZE})"
            )
        actions = np.clip(actions, -1.0, 1.0)

        previous_active = np.array(
            [vehicle.active for vehicle in self.vehicles], dtype=bool
        )
        previous_progress = np.array(
            [vehicle.progress for vehicle in self.vehicles], dtype=np.float32
        )
        red_violations = np.zeros(self.config.max_cars, dtype=bool)
        left_yield_violations = np.zeros(self.config.max_cars, dtype=bool)
        right_yield_violations = np.zeros(self.config.max_cars, dtype=bool)
        right_on_red_entries = np.zeros(self.config.max_cars, dtype=bool)
        right_lane_violations = np.zeros(self.config.max_cars, dtype=bool)
        lane_drift_warnings = np.zeros(self.config.max_cars, dtype=bool)
        safety_overrides = np.zeros(self.config.max_cars, dtype=bool)
        unsafe_requests = np.zeros(self.config.max_cars, dtype=bool)

        for vehicle in self.vehicles:
            if not vehicle.active:
                continue
            acceleration_command = float(actions[vehicle.vehicle_id, 0])
            acceleration = (
                acceleration_command * self.config.max_acceleration
                if acceleration_command >= 0.0
                else acceleration_command * self.config.comfortable_braking
            )
            steering = float(actions[vehicle.vehicle_id, 1])
            acceleration = float(
                np.clip(
                    acceleration,
                    -self.config.comfortable_braking,
                    self.config.max_acceleration,
                )
            )
            acceleration, override, unsafe_request = self._filter_acceleration(
                vehicle,
                acceleration,
                acceleration_command,
            )
            safety_overrides[vehicle.vehicle_id] = override
            unsafe_requests[vehicle.vehicle_id] = unsafe_request
            was_before_stop = vehicle.progress < vehicle.stop_progress
            movement_permitted_before = self._movement_permitted(vehicle)
            entry_blocked = self._intersection_entry_risk(vehicle)
            left_conflict = self._left_turn_conflict(vehicle)
            right_conflict = self._right_turn_conflict(vehicle)
            right_on_red = self._can_turn_right_on_red(vehicle)
            vehicle.step(
                acceleration,
                steering,
                self.config.dt,
                self.config.max_speed,
                self.config.lateral_speed,
                self._max_lateral_offset(),
                self.config.lane_centering_gain,
                self.config.lane_edge_steering_damping,
            )
            lane_drift_warnings[vehicle.vehicle_id] = self._lane_drift_warning(vehicle)
            crossed_stop = was_before_stop and vehicle.progress >= vehicle.stop_progress
            if (
                crossed_stop
                and self.config.safety_filter_enabled
                and (not movement_permitted_before or entry_blocked)
            ):
                vehicle.progress = vehicle.stop_progress - 0.05
                vehicle.speed = 0.0
                vehicle.acceleration = -self.config.comfortable_braking
                safety_overrides[vehicle.vehicle_id] = True
                unsafe_requests[vehicle.vehicle_id] = True
                crossed_stop = False
            if crossed_stop:
                if vehicle.route == "right" and not self._is_rightmost_lane(vehicle):
                    right_lane_violations[vehicle.vehicle_id] = True
                if self._movement_has_green(vehicle):
                    pass
                elif right_on_red:
                    right_on_red_entries[vehicle.vehicle_id] = True
                    if right_conflict:
                        right_yield_violations[vehicle.vehicle_id] = True
                else:
                    vehicle.crossed_on_red = True
                    red_violations[vehicle.vehicle_id] = True
                if left_conflict:
                    left_yield_violations[vehicle.vehicle_id] = True

        progress_delta = float(
            sum(
                max(0.0, vehicle.progress - previous_progress[vehicle.vehicle_id])
                for vehicle in self.vehicles
                if previous_active[vehicle.vehicle_id]
            )
        )
        self._predictive_cache_key = None
        self._predictive_cache = None
        collision_flags = self._detect_collisions()
        proximity_flags, proximity_events = self._detect_proximity_violations(collision_flags)
        self.elapsed_seconds += self.config.dt
        self.step_count += 1

        rewards = self._calculate_rewards(
            previous_progress,
            collision_flags,
            red_violations,
            left_yield_violations,
            right_yield_violations,
            right_lane_violations,
            proximity_flags,
            lane_drift_warnings,
            safety_overrides,
            unsafe_requests,
        )
        failed_flags = (
            collision_flags
            | red_violations
            | left_yield_violations
            | right_yield_violations
            | right_lane_violations
        )
        completed_delta = 0
        failed_delta = 0
        timeout_delta = 0
        truncated = self.step_count >= self.config.max_steps
        for vehicle in self.vehicles:
            if previous_active[vehicle.vehicle_id] and not vehicle.active:
                self.completed_vehicles += 1
                completed_delta += 1
            if failed_flags[vehicle.vehicle_id] and vehicle.active:
                vehicle.failed = True
                vehicle.active = False
                self.failed_vehicles += 1
                failed_delta += 1
            elif truncated and vehicle.active:
                vehicle.failed = True
                vehicle.active = False
                rewards[vehicle.vehicle_id] -= self.config.timeout_failure_penalty
                self.failed_vehicles += 1
                failed_delta += 1
                timeout_delta += 1
        safety_override_count = int(safety_overrides.sum())
        self.safety_overrides += safety_override_count
        terminated = not any(vehicle.active for vehicle in self.vehicles)
        observation = self._get_observation()
        info = self._get_info(rewards)
        info["collisions"] = int(collision_flags.sum() // 2)
        info["proximity_violations"] = int(proximity_flags.sum())
        info["proximity_events"] = proximity_events
        info["red_light_violations"] = int(red_violations.sum())
        info["left_yield_violations"] = int(left_yield_violations.sum())
        info["right_yield_violations"] = int(right_yield_violations.sum())
        info["right_lane_violations"] = int(right_lane_violations.sum())
        info["lane_drift_warnings"] = int(lane_drift_warnings.sum())
        info["right_on_red_entries"] = int(right_on_red_entries.sum())
        info["safety_overrides"] = safety_override_count
        info["unsafe_requests"] = int(unsafe_requests.sum())
        info["completed_delta"] = completed_delta
        info["failed_delta"] = failed_delta
        info["timeout_failures"] = timeout_delta
        info["progress_delta"] = progress_delta
        info["safety_score"] = self._safety_score(
            completed_delta,
            failed_delta,
            int(collision_flags.sum() // 2),
            int(proximity_flags.sum()),
            int(red_violations.sum()),
            int(left_yield_violations.sum()),
            int(right_yield_violations.sum()),
            int(right_lane_violations.sum()),
            int(lane_drift_warnings.sum()),
            safety_override_count,
            progress_delta,
        )

        if self.render_mode == "human":
            self.render()
        return observation, rewards, terminated, truncated, info

    def _vehicle_corners(self, vehicle: Vehicle) -> np.ndarray:
        center, heading = vehicle.pose()
        forward = np.array([np.cos(heading), np.sin(heading)])
        lateral = np.array([-np.sin(heading), np.cos(heading)])
        half_length = self.config.vehicle_length / 2.0
        half_width = self.config.vehicle_width / 2.0
        return np.array(
            [
                center + forward * half_length + lateral * half_width,
                center + forward * half_length - lateral * half_width,
                center - forward * half_length - lateral * half_width,
                center - forward * half_length + lateral * half_width,
            ]
        )

    def _vehicle_corners_at(
        self,
        vehicle: Vehicle,
        progress: float,
        lateral_offset: float | None = None,
    ) -> np.ndarray:
        center, heading = vehicle.path.sample(progress)
        normal = np.array([-np.sin(heading), np.cos(heading)])
        offset = vehicle.lateral_offset if lateral_offset is None else lateral_offset
        center = center + normal * offset
        forward = np.array([np.cos(heading), np.sin(heading)])
        lateral = np.array([-np.sin(heading), np.cos(heading)])
        half_length = self.config.vehicle_length / 2.0
        half_width = self.config.vehicle_width / 2.0
        return np.array(
            [
                center + forward * half_length + lateral * half_width,
                center + forward * half_length - lateral * half_width,
                center - forward * half_length - lateral * half_width,
                center - forward * half_length + lateral * half_width,
            ]
        )

    def _polygons_overlap(self, first_corners: np.ndarray, second_corners: np.ndarray) -> bool:
        axes = []
        for corners in (first_corners, second_corners):
            for index in (0, 1):
                edge = corners[(index + 1) % 4] - corners[index]
                axis = np.array([-edge[1], edge[0]])
                axis /= max(np.linalg.norm(axis), 1e-8)
                axes.append(axis)
        for axis in axes:
            first_min, first_max = self._project_polygon(first_corners, axis)
            second_min, second_max = self._project_polygon(second_corners, axis)
            if first_max < second_min or second_max < first_min:
                return False
        return True

    def _polygon_clearance(self, first_corners: np.ndarray, second_corners: np.ndarray) -> float:
        if self._polygons_overlap(first_corners, second_corners):
            return 0.0
        best = float("inf")
        for corners, other in ((first_corners, second_corners), (second_corners, first_corners)):
            for point in corners:
                for index in range(4):
                    start = other[index]
                    end = other[(index + 1) % 4]
                    best = min(best, self._point_segment_distance(point, start, end))
        return best

    @staticmethod
    def _project_polygon(points: np.ndarray, axis: np.ndarray) -> tuple[float, float]:
        projected = points @ axis
        return float(projected.min()), float(projected.max())

    def _rectangles_overlap(self, first: Vehicle, second: Vehicle) -> bool:
        return self._polygons_overlap(
            self._vehicle_corners(first),
            self._vehicle_corners(second),
        )

    @staticmethod
    def _point_segment_distance(
        point: np.ndarray,
        start: np.ndarray,
        end: np.ndarray,
    ) -> float:
        segment = end - start
        length_sq = float(np.dot(segment, segment))
        if length_sq <= 1e-12:
            return float(np.linalg.norm(point - start))
        fraction = float(np.clip(np.dot(point - start, segment) / length_sq, 0.0, 1.0))
        closest = start + fraction * segment
        return float(np.linalg.norm(point - closest))

    def _rectangle_clearance(self, first: Vehicle, second: Vehicle) -> float:
        return self._polygon_clearance(
            self._vehicle_corners(first),
            self._vehicle_corners(second),
        )

    def _detect_collisions(self) -> np.ndarray:
        flags = np.zeros(self.config.max_cars, dtype=bool)
        active = [vehicle for vehicle in self.vehicles if vehicle.active]
        for first_index, first in enumerate(active):
            for second in active[first_index + 1 :]:
                pair = (
                    min(first.vehicle_id, second.vehicle_id),
                    max(first.vehicle_id, second.vehicle_id),
                )
                if pair not in self._collision_pairs and self._rectangles_overlap(
                    first, second
                ):
                    self._collision_pairs.add(pair)
                    first.collided = True
                    second.collided = True
                    flags[first.vehicle_id] = True
                    flags[second.vehicle_id] = True
        return flags

    def _proximity_responsible_ids(self, first: Vehicle, second: Vehicle) -> tuple[int, ...]:
        same_lane_following = (
            first.approach == second.approach
            and first.lane == second.lane
            and first.route == second.route
        )
        if same_lane_following:
            rear = first if first.progress < second.progress else second
            return (rear.vehicle_id,)
        return first.vehicle_id, second.vehicle_id

    def _detect_proximity_violations(self, collisions: np.ndarray) -> tuple[np.ndarray, int]:
        flags = np.zeros(self.config.max_cars, dtype=bool)
        events = 0
        active = [vehicle for vehicle in self.vehicles if vehicle.active]
        for first_index, first in enumerate(active):
            for second in active[first_index + 1 :]:
                if collisions[first.vehicle_id] or collisions[second.vehicle_id]:
                    continue
                if self._rectangle_clearance(first, second) < self.config.proximity_clearance:
                    events += 1
                    for vehicle_id in self._proximity_responsible_ids(first, second):
                        flags[vehicle_id] = True
        return flags, events

    # Week 5: reward traffic compliance, safety, progress, spacing, and lane path.
    def _calculate_rewards(
        self,
        previous_progress: np.ndarray,
        collisions: np.ndarray,
        red_violations: np.ndarray,
        left_yield_violations: np.ndarray,
        right_yield_violations: np.ndarray,
        right_lane_violations: np.ndarray,
        proximity_violations: np.ndarray,
        lane_drift_warnings: np.ndarray,
        safety_overrides: np.ndarray,
        unsafe_requests: np.ndarray,
    ) -> np.ndarray:
        rewards = np.zeros(self.config.max_cars, dtype=np.float32)
        for vehicle in self.vehicles:
            vehicle_id = vehicle.vehicle_id
            progress = max(0.0, vehicle.progress - previous_progress[vehicle_id])
            distance_to_stop = vehicle.stop_progress - vehicle.progress
            movement_permitted = self._movement_permitted(vehicle)
            stopping_zone = max(10.0, vehicle.speed * 2.0)
            must_yield_before_stop = (
                not movement_permitted
                and 0.0 < distance_to_stop < stopping_zone
            )
            reward = self.config.progress_reward * progress
            if must_yield_before_stop:
                reward -= 0.12 * progress
                reward -= 0.04 * vehicle.speed
                reward -= 0.15 * max(0.0, vehicle.acceleration)
                if vehicle.speed < 0.5:
                    reward += 0.05
            reward -= 0.01  # Discourage blocking the intersection indefinitely.
            reward -= 0.004 * abs(vehicle.acceleration)
            # Week 6: lateral control must converge to the assigned route center.
            lane_limit = max(self._max_lateral_offset(), 1e-3)
            lateral_ratio = abs(vehicle.lateral_offset) / lane_limit
            reward -= 0.16 * lateral_ratio
            reward -= 0.02 * abs(vehicle.steering)
            if lane_drift_warnings[vehicle_id]:
                reward -= 0.8
            if vehicle.lateral_offset * vehicle.steering > 0.0:
                reward -= 0.08 * abs(vehicle.steering)

            front_gap, front_relative_speed, front_ttc = self._front_vehicle_metrics(vehicle)
            if front_gap < self.config.vehicle_length + 2.0:
                reward -= 0.3
            if front_gap < self.config.minimum_front_gap:
                reward -= 0.08 * (self.config.minimum_front_gap - front_gap)
            if front_ttc < self.config.ttc_warning_seconds:
                reward -= 0.25 * (self.config.ttc_warning_seconds - front_ttc)
            if front_ttc < self.config.ttc_critical_seconds:
                reward -= 1.0
            if safety_overrides[vehicle_id]:
                reward -= self.config.safety_override_penalty
            if unsafe_requests[vehicle_id]:
                reward -= self.config.unsafe_acceleration_penalty
            if proximity_violations[vehicle_id]:
                reward -= 2.0
            predicted_collision, predicted_proximity, *_ = self._predictive_features()[vehicle_id]
            reward -= self.config.predicted_conflict_penalty * predicted_collision
            reward -= self.config.predicted_proximity_penalty * predicted_proximity
            if movement_permitted and front_gap > self.config.minimum_front_gap and not must_yield_before_stop:
                reward += self.config.permitted_speed_reward * (vehicle.speed / self.config.max_speed)
                reward += self.config.permitted_acceleration_reward * max(0.0, vehicle.acceleration)
                if vehicle.speed < 1.0:
                    reward -= self.config.permitted_idle_penalty
            if collisions[vehicle_id]:
                reward -= 12.0
            if red_violations[vehicle_id]:
                reward -= 5.0
            if left_yield_violations[vehicle_id]:
                reward -= 4.0
            if right_yield_violations[vehicle_id]:
                reward -= 4.0
            if right_lane_violations[vehicle_id]:
                reward -= 5.0
            if (
                not vehicle.active
                and not vehicle.failed
                and previous_progress[vehicle_id] < vehicle.path.length
            ):
                reward += self.config.clean_completion_bonus

            # Week 7: jerk, explicit speed-limit, and merge-yield terms belong here.
            # Week 9: pedestrian braking and lane-change safety terms belong here.
            # Week 10: goal progress and risky late lane-change terms belong here.
            rewards[vehicle_id] = reward
        return rewards

    def _max_lateral_offset(self) -> float:
        return max(
            0.0,
            (self.config.lane_width - self.config.vehicle_width) / 2.0
            - self.config.lane_edge_margin,
        )

    def _lane_drift_warning(self, vehicle: Vehicle) -> bool:
        return abs(vehicle.lateral_offset) >= (
            self.config.lane_drift_warning_ratio * self._max_lateral_offset()
        )

    # Week 6: selectable protected-left or permissive-left signal plan.
    def _signal_phase(self) -> tuple[str, float]:
        green = self.config.signal_green_seconds
        yellow = self.config.signal_yellow_seconds
        if self.episode_protected_left_signal:
            left = self.config.left_signal_green_seconds
            segment = left + green + yellow
            time_in_cycle = self.elapsed_seconds % (2.0 * segment)
            axis = "NS" if time_in_cycle < segment else "EW"
            local_time = time_in_cycle % segment
            if local_time < left:
                return f"{axis}_LEFT_GREEN", local_time / left
            if local_time < left + green:
                return f"{axis}_GREEN", (local_time - left) / green
            return f"{axis}_YELLOW", (local_time - left - green) / yellow

        cycle = 2.0 * (green + yellow)
        time_in_cycle = self.elapsed_seconds % cycle
        if time_in_cycle < green:
            return "NS_GREEN", time_in_cycle / green
        if time_in_cycle < green + yellow:
            return "NS_YELLOW", (time_in_cycle - green) / yellow
        if time_in_cycle < 2.0 * green + yellow:
            return "EW_GREEN", (time_in_cycle - green - yellow) / green
        return "EW_YELLOW", (time_in_cycle - 2.0 * green - yellow) / yellow

    def _movement_has_green(self, vehicle: Vehicle) -> bool:
        return self._has_green(vehicle.approach, vehicle.route)

    def _has_green(self, approach: str, route: str = "straight") -> bool:
        phase, _ = self._signal_phase()
        axis = "NS" if approach in ("N", "S") else "EW"
        if self.episode_protected_left_signal and route == "left":
            return phase == f"{axis}_LEFT_GREEN"
        return phase == f"{axis}_GREEN"

    def _left_turn_conflict(self, vehicle: Vehicle) -> bool:
        if (
            self.episode_protected_left_signal
            or vehicle.route != "left"
            or not self._movement_has_green(vehicle)
        ):
            return False
        opposite = {"N": "S", "S": "N", "E": "W", "W": "E"}[
            vehicle.approach
        ]
        for other in self.vehicles:
            if (
                not other.active
                or other.approach != opposite
                or other.route != "straight"
            ):
                continue
            distance_to_stop = other.stop_progress - other.progress
            if (
                -2.0 * self.config.intersection_half_size
                <= distance_to_stop
                <= self.config.left_yield_distance
                and other.speed > 0.5
            ):
                return True
        return False

    def _is_rightmost_lane(self, vehicle: Vehicle) -> bool:
        return vehicle.lane == self.episode_lanes_per_approach - 1

    def _can_turn_right_on_red(self, vehicle: Vehicle) -> bool:
        if (
            not self.episode_allow_right_on_red
            or vehicle.route != "right"
            or not self._is_rightmost_lane(vehicle)
            or self._movement_has_green(vehicle)
        ):
            return False
        phase, _ = self._signal_phase()
        axis = "NS" if vehicle.approach in ("N", "S") else "EW"
        return phase != f"{axis}_YELLOW"

    def _right_turn_conflict(self, vehicle: Vehicle) -> bool:
        if not self._can_turn_right_on_red(vehicle):
            return False
        vehicle_axis = "NS" if vehicle.approach in ("N", "S") else "EW"
        for other in self.vehicles:
            if not other.active or other.vehicle_id == vehicle.vehicle_id:
                continue
            other_axis = "NS" if other.approach in ("N", "S") else "EW"
            opposite = {"N": "S", "S": "N", "E": "W", "W": "E"}[
                vehicle.approach
            ]
            conflicts_by_direction = (
                other_axis != vehicle_axis
                or (other.approach == opposite and other.route == "left")
            )
            if not conflicts_by_direction:
                continue
            distance_to_stop = other.stop_progress - other.progress
            approaching_conflict = (
                self._movement_has_green(other)
                and -2.0 * self.config.intersection_half_size
                <= distance_to_stop
                <= self.config.right_yield_distance
                and other.speed > 0.5
            )
            inside_intersection = (
                -2.0 * self.config.intersection_half_size
                <= distance_to_stop
                <= 0.0
            )
            if approaching_conflict or inside_intersection:
                return True
        return False

    def _movement_permitted(self, vehicle: Vehicle) -> bool:
        if self._movement_has_green(vehicle):
            return not self._left_turn_conflict(vehicle)
        return self._can_turn_right_on_red(vehicle) and not self._right_turn_conflict(
            vehicle
        )

    def _front_vehicle_metrics(self, vehicle: Vehicle) -> tuple[float, float, float]:
        gap = self.config.road_length * 2.0
        front_speed = vehicle.speed
        for other in self.vehicles:
            if (
                other.vehicle_id == vehicle.vehicle_id
                or not other.active
                or other.approach != vehicle.approach
                or other.lane != vehicle.lane
                or other.progress <= vehicle.progress
            ):
                continue
            candidate_gap = other.progress - vehicle.progress
            if candidate_gap < gap:
                gap = candidate_gap
                front_speed = other.speed
        relative_speed = max(0.0, vehicle.speed - front_speed)
        ttc = gap / max(relative_speed, 1e-3) if relative_speed > 0.05 else self.config.road_length * 2.0
        return float(gap), float(relative_speed), float(ttc)

    def _front_gap(self, vehicle: Vehicle) -> float:
        return self._front_vehicle_metrics(vehicle)[0]

    def _stopping_distance(self, vehicle: Vehicle) -> float:
        return vehicle.speed**2 / (2.0 * max(self.config.comfortable_braking, 1e-3))

    def _inside_intersection(self, vehicle: Vehicle) -> bool:
        distance_to_stop = vehicle.stop_progress - vehicle.progress
        clear_distance = 2.0 * self.config.intersection_half_size + self.config.vehicle_length
        return -clear_distance <= distance_to_stop <= 0.0

    def _intersection_entry_risk(self, vehicle: Vehicle) -> bool:
        if not self.config.intersection_reservation_enabled:
            return False
        distance_to_stop = vehicle.stop_progress - vehicle.progress
        if distance_to_stop <= 0.0:
            return False
        lookahead = max(
            self.config.intersection_reservation_distance,
            self._stopping_distance(vehicle) + 2.0,
        )
        if distance_to_stop > lookahead or not self._movement_permitted(vehicle):
            return False
        for other in self.vehicles:
            if other.vehicle_id == vehicle.vehicle_id or not other.active:
                continue
            if not self._has_conflicting_route(vehicle, other):
                continue
            if self._inside_intersection(other):
                return True
            other_distance_to_stop = other.stop_progress - other.progress
            if (
                0.0 < other_distance_to_stop <= self.config.intersection_reservation_distance
                and self._movement_permitted(other)
            ):
                other_has_priority = (
                    other_distance_to_stop < distance_to_stop - 1.0
                    or (
                        abs(other_distance_to_stop - distance_to_stop) <= 1.0
                        and other.vehicle_id < vehicle.vehicle_id
                    )
                )
                if other_has_priority:
                    return True
        return False

    def _proximity_risk(self, vehicle: Vehicle) -> bool:
        for other in self.vehicles:
            if other.vehicle_id == vehicle.vehicle_id or not other.active:
                continue
            if (
                self._rectangle_clearance(vehicle, other)
                < self.config.proximity_filter_clearance
            ):
                return True
        return False

    def _time_to_stop_line(self, vehicle: Vehicle) -> float:
        distance = vehicle.stop_progress - vehicle.progress
        if distance <= 0.0:
            return 0.0
        return distance / max(vehicle.speed, 0.1)

    def _has_conflicting_route(self, first: Vehicle, second: Vehicle) -> bool:
        if first.approach == second.approach and first.lane == second.lane:
            return True
        first_key = self._route_conflict_key(first)
        second_key = self._route_conflict_key(second)
        key = (first_key, second_key) if first_key <= second_key else (second_key, first_key)
        cached = self._route_conflict_cache.get(key)
        if cached is not None:
            return cached
        conflict = self._route_footprints_conflict(first, second)
        self._route_conflict_cache[key] = conflict
        return conflict

    def _route_conflict_key(self, vehicle: Vehicle) -> tuple[object, ...]:
        return (
            vehicle.approach,
            vehicle.lane,
            vehicle.route,
            vehicle.destination_lane,
            self.episode_lanes_per_approach,
            round(vehicle.stop_progress, 3),
            round(vehicle.path.length, 3),
        )

    def _route_footprints_conflict(self, first: Vehicle, second: Vehicle) -> bool:
        clear_distance = 2.0 * self.config.intersection_half_size + 18.0
        first_start = max(0.0, first.stop_progress - self.config.vehicle_length)
        second_start = max(0.0, second.stop_progress - self.config.vehicle_length)
        first_end = min(first.path.length, first.stop_progress + clear_distance)
        second_end = min(second.path.length, second.stop_progress + clear_distance)
        first_samples = np.linspace(first_start, first_end, 9)
        second_samples = np.linspace(second_start, second_end, 9)
        conflict_clearance = self.config.proximity_clearance + 0.25
        for first_progress in first_samples:
            first_corners = self._vehicle_corners_at(first, float(first_progress), lateral_offset=0.0)
            for second_progress in second_samples:
                second_corners = self._vehicle_corners_at(second, float(second_progress), lateral_offset=0.0)
                if self._polygon_clearance(first_corners, second_corners) < conflict_clearance:
                    return True
        return False

    def _predictive_state_key(self) -> tuple[tuple[int, bool, float, float, float], ...]:
        return tuple(
            (
                vehicle.vehicle_id,
                vehicle.active,
                round(vehicle.progress, 3),
                round(vehicle.speed, 3),
                round(vehicle.lateral_offset, 3),
            )
            for vehicle in self.vehicles
        )

    def _predictive_features(self) -> np.ndarray:
        key = self._predictive_state_key()
        if self._predictive_cache_key == key and self._predictive_cache is not None:
            return self._predictive_cache

        horizon = self.config.prediction_horizon_seconds
        step = self.config.prediction_step_seconds
        times = np.arange(step, horizon + 1e-6, step)
        features = np.zeros((self.config.max_cars, 10), dtype=np.float32)
        features[:, 2] = 1.0
        features[:, 3] = 1.0
        features[:, 4] = 1.0
        features[:, 7] = 1.0
        active = [vehicle for vehicle in self.vehicles if vehicle.active]
        time_to_stop = {
            vehicle.vehicle_id: min(self._time_to_stop_line(vehicle), horizon)
            for vehicle in active
        }
        future_corners: dict[tuple[int, float], np.ndarray] = {}
        for vehicle in active:
            lateral_limit = max(self._max_lateral_offset(), 1e-3)
            lateral_ratio = abs(vehicle.lateral_offset) / lateral_limit
            center_steer = np.clip(-vehicle.lateral_offset / lateral_limit, -1.0, 1.0)
            features[vehicle.vehicle_id, 2] = 1.0
            features[vehicle.vehicle_id, 3] = time_to_stop[vehicle.vehicle_id] / max(horizon, 1e-3)
            features[vehicle.vehicle_id, 4] = 1.0
            features[vehicle.vehicle_id, 7] = 1.0
            features[vehicle.vehicle_id, 8] = np.clip(lateral_ratio, 0.0, 1.0)
            features[vehicle.vehicle_id, 9] = float(center_steer)
            for time in times:
                progress = min(vehicle.path.length, vehicle.progress + vehicle.speed * time)
                future_corners[(vehicle.vehicle_id, float(time))] = self._vehicle_corners_at(vehicle, progress)

        for first_index, first in enumerate(active):
            first_time = time_to_stop[first.vehicle_id]
            for second in active[first_index + 1 :]:
                if not self._has_conflicting_route(first, second):
                    continue
                second_time = time_to_stop[second.vehicle_id]
                first_occupied = self._inside_intersection(first)
                second_occupied = self._inside_intersection(second)
                first_distance = first.stop_progress - first.progress
                second_distance = second.stop_progress - second.progress
                if second_occupied:
                    features[first.vehicle_id, 5] = 1.0
                    features[first.vehicle_id, 4] = 0.0
                if first_occupied:
                    features[second.vehicle_id, 5] = 1.0
                    features[second.vehicle_id, 4] = 0.0
                if (
                    0.0 < second_distance <= self.config.conflict_lookahead_distance
                    and self._movement_permitted(second)
                ):
                    features[first.vehicle_id, 6] = 1.0
                if (
                    0.0 < first_distance <= self.config.conflict_lookahead_distance
                    and self._movement_permitted(first)
                ):
                    features[second.vehicle_id, 6] = 1.0

                second_priority = (
                    second_occupied
                    or second_time < first_time - 0.25
                    or (abs(second_time - first_time) <= 0.25 and second.vehicle_id < first.vehicle_id)
                )
                first_priority = (
                    first_occupied
                    or first_time < second_time - 0.25
                    or (abs(second_time - first_time) <= 0.25 and first.vehicle_id < second.vehicle_id)
                )
                if second_priority:
                    features[first.vehicle_id, 4] = 0.0
                if first_priority:
                    features[second.vehicle_id, 4] = 0.0

                for time in times:
                    first_corners = future_corners[(first.vehicle_id, float(time))]
                    second_corners = future_corners[(second.vehicle_id, float(time))]
                    clearance = self._polygon_clearance(first_corners, second_corners)
                    clearance_norm = np.clip(clearance / self.config.road_length, 0.0, 1.0)
                    features[first.vehicle_id, 7] = min(features[first.vehicle_id, 7], clearance_norm)
                    features[second.vehicle_id, 7] = min(features[second.vehicle_id, 7], clearance_norm)
                    if clearance < self.config.proximity_clearance:
                        for ego, other_time in ((first, second_time), (second, first_time)):
                            vehicle_id = ego.vehicle_id
                            features[vehicle_id, 1] = 1.0
                            features[vehicle_id, 2] = min(features[vehicle_id, 2], float(time) / max(horizon, 1e-3))
                            features[vehicle_id, 3] = min(features[vehicle_id, 3], other_time / max(horizon, 1e-3))
                    if self._polygons_overlap(first_corners, second_corners):
                        for ego, other_time in ((first, second_time), (second, first_time)):
                            vehicle_id = ego.vehicle_id
                            features[vehicle_id, 0] = 1.0
                            features[vehicle_id, 1] = 1.0
                            features[vehicle_id, 2] = min(features[vehicle_id, 2], float(time) / max(horizon, 1e-3))
                            features[vehicle_id, 3] = min(features[vehicle_id, 3], other_time / max(horizon, 1e-3))
                        break

        self._predictive_cache_key = key
        self._predictive_cache = np.clip(features, -1.0, 1.0)
        return self._predictive_cache

    def _predictive_conflict_metrics(self, vehicle: Vehicle) -> tuple[float, ...]:
        return tuple(float(value) for value in self._predictive_features()[vehicle.vehicle_id])

    def _safety_risk(self, vehicle: Vehicle) -> tuple[bool, bool]:
        distance_to_stop = vehicle.stop_progress - vehicle.progress
        stopping_distance = self._stopping_distance(vehicle)
        movement_permitted = self._movement_permitted(vehicle)
        closed_signal_risk = (
            not movement_permitted
            and 0.0 < distance_to_stop < max(10.0, stopping_distance + 4.0)
        )
        front_gap, _, front_ttc = self._front_vehicle_metrics(vehicle)
        front_risk = (
            front_gap < self.config.minimum_front_gap
            or front_ttc < self.config.ttc_warning_seconds
        )
        conflict_risk = self._left_turn_conflict(vehicle) or self._right_turn_conflict(vehicle)
        reservation_risk = self._intersection_entry_risk(vehicle)
        return (
            closed_signal_risk
            or front_risk
            or conflict_risk
            or reservation_risk,
            front_risk,
        )

    def _filter_acceleration(
        self,
        vehicle: Vehicle,
        acceleration: float,
        acceleration_command: float,
    ) -> tuple[float, bool, bool]:
        unsafe, front_risk = self._safety_risk(vehicle)
        unsafe_request = unsafe and acceleration_command > 0.05
        if not self.config.safety_filter_enabled or not unsafe:
            return acceleration, False, unsafe_request
        if vehicle.speed < 0.2:
            held_acceleration = min(acceleration, 0.0)
            return held_acceleration, acceleration > 0.0, unsafe_request
        forced_brake = -self.config.comfortable_braking
        if front_risk:
            forced_brake = -self.config.comfortable_braking
        if acceleration <= forced_brake + 1e-6:
            return acceleration, False, unsafe_request
        return min(acceleration, forced_brake), True, unsafe_request

    @staticmethod
    def _safety_score(
        completed_delta: int,
        failed_delta: int,
        collisions: int,
        proximity: int,
        red_violations: int,
        left_yield: int,
        right_yield: int,
        right_lane: int,
        lane_drift: int,
        safety_overrides: int,
        progress_delta: float,
    ) -> float:
        return float(
            100.0 * completed_delta
            + 2.0 * progress_delta
            - 50.0 * failed_delta
            - 80.0 * collisions
            - 5.0 * proximity
            - 40.0 * red_violations
            - 30.0 * (left_yield + right_yield)
            - 30.0 * right_lane
            - 0.2 * lane_drift
            - 0.5 * safety_overrides
        )

    def _nearest_vehicle(self, vehicle: Vehicle) -> float:
        position, _ = vehicle.pose()
        distance = self.config.road_length * 2.0
        for other in self.vehicles:
            if other.vehicle_id == vehicle.vehicle_id or not other.active:
                continue
            other_position, _ = other.pose()
            distance = min(distance, float(np.linalg.norm(position - other_position)))
        return distance

    def _get_observation(self) -> np.ndarray:
        observation = np.zeros(
            (self.config.max_cars, self.OBSERVATION_SIZE), dtype=np.float32
        )
        phase, phase_progress = self._signal_phase()
        for vehicle in self.vehicles:
            if not vehicle.active:
                continue
            position, heading = vehicle.pose()
            distance_to_stop = vehicle.stop_progress - vehicle.progress
            route_one_hot = [float(vehicle.route == route) for route in ROUTES]
            axis_green = float(self._movement_has_green(vehicle))
            axis_yellow = float(
                phase
                == f"{'NS' if vehicle.approach in ('N', 'S') else 'EW'}_YELLOW"
            )
            front_gap, front_relative_speed, front_ttc = self._front_vehicle_metrics(vehicle)
            predictive_values = self._predictive_features()[vehicle.vehicle_id]
            values = [
                vehicle.speed / self.config.max_speed,
                vehicle.acceleration / self.config.comfortable_braking,
                np.clip(
                    distance_to_stop / self.config.road_length,
                    -1.0,
                    1.0,
                ),
                axis_green,
                axis_yellow,
                1.0 - axis_green - axis_yellow,
                np.clip(
                    front_gap / self.config.road_length, 0.0, 1.0
                ),
                np.clip(
                    self._nearest_vehicle(vehicle) / self.config.road_length,
                    0.0,
                    1.0,
                ),
                vehicle.progress / vehicle.path.length,
                vehicle.lane / max(1, self.episode_lanes_per_approach - 1),
                *route_one_hot,
                np.sin(heading),
                np.cos(heading),
                phase_progress,
                vehicle.destination_lane
                / max(1, self.episode_lanes_per_approach - 1),
                np.clip(
                    vehicle.lateral_offset / self.config.lane_width, -1.0, 1.0
                ),
                float(self._left_turn_conflict(vehicle)),
                float(self._can_turn_right_on_red(vehicle)),
                float(self._right_turn_conflict(vehicle)),
                float(self._is_rightmost_lane(vehicle)),
                np.clip(
                    front_relative_speed / self.config.max_speed,
                    0.0,
                    1.0,
                ),
                np.clip(
                    front_ttc / 10.0,
                    0.0,
                    1.0,
                ),
                np.clip(
                    self._stopping_distance(vehicle)
                    / max(abs(distance_to_stop), 1.0),
                    0.0,
                    1.0,
                ),
                float(self._movement_permitted(vehicle)),
                *predictive_values[:8],
            ]
            observation[vehicle.vehicle_id] = np.asarray(values, dtype=np.float32)
        return np.clip(observation, -1.0, 1.0)

    def _get_info(self, rewards: np.ndarray) -> dict[str, Any]:
        active_mask = np.zeros(self.config.max_cars, dtype=np.float32)
        for vehicle in self.vehicles:
            active_mask[vehicle.vehicle_id] = float(vehicle.active)
        return {
            "active_mask": active_mask,
            "mean_active_reward": float(
                rewards[active_mask.astype(bool)].mean()
                if active_mask.any()
                else 0.0
            ),
            "completed_vehicles": self.completed_vehicles,
            "completed_clean": self.completed_vehicles,
            "failed_vehicles": self.failed_vehicles,
            "cumulative_safety_overrides": self.safety_overrides,
            "signal_phase": self._signal_phase()[0],
            "elapsed_seconds": self.elapsed_seconds,
            "episode_lanes_per_approach": self.episode_lanes_per_approach,
            "episode_protected_left_signal": self.episode_protected_left_signal,
            "episode_allow_right_on_red": self.episode_allow_right_on_red,
        }

    def render(self) -> np.ndarray | None:
        if self._renderer is None:
            from intersection_rl.rendering import IntersectionRenderer

            self._renderer = IntersectionRenderer(self.config, self.render_mode)
        return self._renderer.render(self)

    def close(self) -> None:
        if self._renderer is not None:
            self._renderer.close()
            self._renderer = None

