from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


APPROACHES = ("N", "E", "S", "W")
ROUTES = ("left", "straight", "right")

HEADINGS = {
    "N": np.array([0.0, 1.0]),
    "E": np.array([-1.0, 0.0]),
    "S": np.array([0.0, -1.0]),
    "W": np.array([1.0, 0.0]),
}

LEFT_DESTINATION = {"N": "E", "E": "S", "S": "W", "W": "N"}
STRAIGHT_DESTINATION = {"N": "S", "E": "W", "S": "N", "W": "E"}
RIGHT_DESTINATION = {"N": "W", "E": "N", "S": "E", "W": "S"}


def right_vector(direction: np.ndarray) -> np.ndarray:
    return np.array([-direction[1], direction[0]])


def stop_point(
    approach: str,
    lane: int,
    lane_width: float,
    intersection_half_size: float,
) -> np.ndarray:
    heading = HEADINGS[approach]
    lateral = right_vector(heading)
    lane_offset = (lane + 0.5) * lane_width
    return -heading * intersection_half_size + lateral * lane_offset


def outgoing_point(
    destination: str,
    lane: int,
    distance: float,
    lane_width: float,
    intersection_half_size: float,
) -> np.ndarray:
    incoming_heading = HEADINGS[destination]
    outgoing_heading = -incoming_heading
    # Outgoing traffic uses the other half of the destination road.
    lateral = -right_vector(incoming_heading) * ((lane + 0.5) * lane_width)
    return outgoing_heading * (intersection_half_size + distance) + lateral


def quadratic_bezier(
    start: np.ndarray,
    control: np.ndarray,
    end: np.ndarray,
    count: int,
) -> np.ndarray:
    t = np.linspace(0.0, 1.0, count)[:, None]
    return (1.0 - t) ** 2 * start + 2.0 * (1.0 - t) * t * control + t**2 * end


def build_route_path(
    approach: str,
    lane: int,
    route: str,
    lane_width: float,
    road_length: float,
    intersection_half_size: float,
    lanes_per_approach: int = 2,
    destination_lane: int | None = None,
) -> np.ndarray:
    """Build a smooth centerline polyline for one legal vehicle movement."""
    heading = HEADINGS[approach]
    stop = stop_point(approach, lane, lane_width, intersection_half_size)
    start = stop - heading * road_length

    if route == "left":
        destination = LEFT_DESTINATION[approach]
        default_destination_lane = 0
    elif route == "right":
        destination = RIGHT_DESTINATION[approach]
        default_destination_lane = lanes_per_approach - 1
    else:
        destination = STRAIGHT_DESTINATION[approach]
        default_destination_lane = lane
    if destination_lane is None:
        destination_lane = default_destination_lane
    if not 0 <= destination_lane < lanes_per_approach:
        raise ValueError("destination_lane must be on the destination road")

    end = outgoing_point(
        destination,
        destination_lane,
        road_length,
        lane_width,
        intersection_half_size,
    )
    entry = stop + heading * 1.0
    exit_edge = outgoing_point(
        destination,
        destination_lane,
        0.0,
        lane_width,
        intersection_half_size,
    )
    if route == "straight":
        return np.stack((start, stop, exit_edge, end))

    # The origin provides a stable, readable curve for both turn directions.
    curve = quadratic_bezier(entry, np.zeros(2), exit_edge, 18)
    return np.vstack((start, stop, curve, end))


@dataclass(slots=True)
class Polyline:
    points: np.ndarray
    _segments: np.ndarray = field(init=False, repr=False)
    _lengths: np.ndarray = field(init=False, repr=False)
    _cumulative: np.ndarray = field(init=False, repr=False)

    def __post_init__(self) -> None:
        segments = np.diff(self.points, axis=0)
        lengths = np.linalg.norm(segments, axis=1)
        self._segments = segments
        self._lengths = lengths
        self._cumulative = np.concatenate(([0.0], np.cumsum(lengths)))

    @property
    def length(self) -> float:
        return float(self._cumulative[-1])

    def sample(self, progress: float) -> tuple[np.ndarray, float]:
        progress = float(np.clip(progress, 0.0, self.length))
        index = min(
            int(np.searchsorted(self._cumulative, progress, side="right") - 1),
            len(self._segments) - 1,
        )
        segment_length = max(self._lengths[index], 1e-6)
        fraction = (progress - self._cumulative[index]) / segment_length
        position = self.points[index] + fraction * self._segments[index]
        direction = self._segments[index] / segment_length
        heading = float(np.arctan2(direction[1], direction[0]))
        return position, heading

    def project(self, point: np.ndarray) -> tuple[float, float]:
        """Return progress and distance of the closest point on this path."""
        best_distance = float("inf")
        best_progress = 0.0
        for index, segment in enumerate(self._segments):
            length_sq = float(np.dot(segment, segment))
            fraction = float(
                np.clip(np.dot(point - self.points[index], segment) / length_sq, 0, 1)
            )
            projected = self.points[index] + fraction * segment
            distance = float(np.linalg.norm(point - projected))
            if distance < best_distance:
                best_distance = distance
                best_progress = self._cumulative[index] + fraction * self._lengths[index]
        return float(best_progress), best_distance
