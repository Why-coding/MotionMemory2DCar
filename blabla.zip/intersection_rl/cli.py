from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from intersection_rl.config import EnvConfig, PPOConfig
from intersection_rl.env import IntersectionEnv
from intersection_rl.ppo import PPOTrainer, SharedActorCritic


def add_environment_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--lanes", type=int, choices=range(1, 6), default=2,
        help="incoming lanes per approach (1-5)",
    )
    parser.add_argument(
        "--cars", type=int,
        help="exact number of cars; defaults to a random 8-12",
    )
    parser.add_argument(
        "--left-signal",
        choices=("protected", "yield"),
        default="yield",
        help="protected left arrow or permissive left turn with yielding",
    )
    parser.add_argument(
        "--right-on-red",
        choices=("on", "off"),
        default="on",
        help="allow right turns on red after yielding",
    )
    parser.add_argument(
        "--safety-shield",
        choices=("on", "off"),
        default="on",
        help="training-aware safety filter for red/yield/front-gap hazards",
    )


def environment_config(args: argparse.Namespace) -> EnvConfig:
    if args.cars is not None and args.cars < 1:
        raise ValueError("--cars must be at least 1")
    car_counts = (
        {"min_cars": args.cars, "max_cars": args.cars}
        if args.cars is not None
        else {}
    )
    return EnvConfig(
        lanes_per_approach=args.lanes,
        protected_left_signal=args.left_signal == "protected",
        allow_right_on_red=args.right_on_red == "on",
        safety_filter_enabled=args.safety_shield == "on",
        seed=args.seed,
        **car_counts
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Four-way intersection simulator and PPO policy"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    simulate = subparsers.add_parser("simulate", help="Run the visual simulator")
    simulate.add_argument("--episodes", type=int, default=3)
    simulate.add_argument("--seed", type=int, default=7)
    add_environment_arguments(simulate)
    simulate.add_argument(
        "--policy",
        type=Path,
        help="Optional .npz checkpoint; without it cars use a rule-based driver",
    )

    train = subparsers.add_parser("train", help="Train the shared PPO policy")
    train.add_argument("--steps", type=int, default=100_000)
    train.add_argument("--seed", type=int, default=7)
    train.add_argument(
        "--save-interval-updates",
        type=int,
        default=10,
        help="save an intermediate checkpoint every N PPO updates; 0 disables",
    )
    train.add_argument(
        "--curriculum",
        action="store_true",
        help="randomize lanes, active cars, left-signal mode, and right-on-red per episode",
    )
    train.add_argument(
        "--curriculum-stage",
        type=int,
        choices=range(1, 6),
        help="staged curriculum preset from easy traffic to full Week 6 traffic",
    )
    train.add_argument("--curriculum-min-lanes", type=int, default=2)
    train.add_argument("--curriculum-max-lanes", type=int, default=5)
    train.add_argument("--curriculum-min-cars", type=int, default=5)
    train.add_argument("--curriculum-max-cars", type=int, default=64)
    add_environment_arguments(train)
    train.add_argument(
        "--checkpoint", type=Path, default=Path("checkpoints/ppo_intersection.npz")
    )
    train.add_argument(
        "--init-checkpoint",
        type=Path,
        help="optional checkpoint used to warm-start this training run",
    )

    evaluate = subparsers.add_parser("evaluate", help="Evaluate a checkpoint")
    evaluate.add_argument("policy", type=Path)
    evaluate.add_argument("--episodes", type=int, default=20)
    evaluate.add_argument("--seed", type=int, default=101)
    add_environment_arguments(evaluate)
    return parser


def rule_based_actions(env: IntersectionEnv) -> np.ndarray:
    """A Week 5 baseline used to inspect the simulator before training."""
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    for vehicle in env.vehicles:
        if not vehicle.active:
            continue
        distance_to_stop = vehicle.stop_progress - vehicle.progress
        front_gap = env._front_gap(vehicle)
        should_stop = (
            not env._movement_permitted(vehicle)
            and 0.0 < distance_to_stop < max(8.0, vehicle.speed * 1.5)
        )
        too_close = front_gap < env.config.vehicle_length + 5.0
        acceleration = 0.0
        if should_stop or too_close:
            acceleration = -1.0
        elif vehicle.speed < env.config.max_speed * 0.75:
            acceleration = 0.6
        steering = float(np.clip(-vehicle.lateral_offset, -1.0, 1.0))
        actions[vehicle.vehicle_id] = [acceleration, steering]
    return actions


def curriculum_stage_config(stage: int) -> dict[str, object]:
    presets: dict[int, dict[str, object]] = {
        1: {
            "min_lanes": 1,
            "max_lanes": 2,
            "min_cars": 4,
            "max_cars": 8,
            "left_signal": True,
            "right_on_red": False,
            "randomize_left": False,
            "randomize_right": False,
        },
        2: {
            "min_lanes": 2,
            "max_lanes": 2,
            "min_cars": 8,
            "max_cars": 12,
            "left_signal": True,
            "right_on_red": False,
            "randomize_left": False,
            "randomize_right": False,
        },
        3: {
            "min_lanes": 2,
            "max_lanes": 3,
            "min_cars": 8,
            "max_cars": 16,
            "left_signal": True,
            "right_on_red": True,
            "randomize_left": False,
            "randomize_right": True,
        },
        4: {
            "min_lanes": 3,
            "max_lanes": 4,
            "min_cars": 12,
            "max_cars": 32,
            "left_signal": False,
            "right_on_red": True,
            "randomize_left": True,
            "randomize_right": True,
        },
        5: {
            "min_lanes": 4,
            "max_lanes": 5,
            "min_cars": 20,
            "max_cars": 64,
            "left_signal": False,
            "right_on_red": True,
            "randomize_left": True,
            "randomize_right": True,
        },
    }
    return presets[stage]


def load_model(env: IntersectionEnv, checkpoint: Path) -> SharedActorCritic:
    model = SharedActorCritic(
        env.OBSERVATION_SIZE, PPOConfig().hidden_size, env.ACTION_SIZE
    )
    model.load(checkpoint)
    return model


def simulate(args: argparse.Namespace) -> None:
    env = IntersectionEnv(environment_config(args), render_mode="human")
    rng = np.random.default_rng(args.seed)
    model = load_model(env, args.policy) if args.policy else None
    try:
        for episode in range(args.episodes):
            observation, info = env.reset(seed=args.seed + episode)
            done = False
            episode_reward = 0.0
            while not done:
                if model is None:
                    actions = rule_based_actions(env)
                else:
                    actions, _, _ = model.act(
                        observation, rng, deterministic=True
                    )
                observation, rewards, terminated, truncated, info = env.step(actions)
                episode_reward += float(rewards.sum())
                done = terminated or truncated
            print(
                f"episode={episode + 1} reward={episode_reward:.2f} "
                f"completed_clean={info['completed_clean']} "
                f"failed={info['failed_vehicles']} "
                f"shield={info['cumulative_safety_overrides']}"
            )
    finally:
        env.close()


def train(args: argparse.Namespace) -> None:
    if args.curriculum_stage is not None:
        stage = curriculum_stage_config(args.curriculum_stage)
        env_config = EnvConfig(
            min_cars=int(stage["min_cars"]),
            max_cars=int(stage["max_cars"]),
            lanes_per_approach=int(stage["max_lanes"]),
            protected_left_signal=bool(stage["left_signal"]),
            allow_right_on_red=bool(stage["right_on_red"]),
            safety_filter_enabled=args.safety_shield == "on",
            intersection_reservation_enabled=False,
            seed=args.seed,
            curriculum_enabled=True,
            curriculum_min_lanes=int(stage["min_lanes"]),
            curriculum_max_lanes=int(stage["max_lanes"]),
            curriculum_min_cars=int(stage["min_cars"]),
            curriculum_max_cars=int(stage["max_cars"]),
            curriculum_randomize_left_signal=bool(stage["randomize_left"]),
            curriculum_randomize_right_on_red=bool(stage["randomize_right"]),
        )
    elif args.curriculum:
        env_config = EnvConfig(
            min_cars=args.curriculum_min_cars,
            max_cars=args.curriculum_max_cars,
            lanes_per_approach=args.curriculum_max_lanes,
            protected_left_signal=args.left_signal == "protected",
            allow_right_on_red=args.right_on_red == "on",
            safety_filter_enabled=args.safety_shield == "on",
            intersection_reservation_enabled=False,
            seed=args.seed,
            curriculum_enabled=True,
            curriculum_min_lanes=args.curriculum_min_lanes,
            curriculum_max_lanes=args.curriculum_max_lanes,
            curriculum_min_cars=args.curriculum_min_cars,
            curriculum_max_cars=args.curriculum_max_cars,
        )
    else:
        env_config = environment_config(args)
        env_config.intersection_reservation_enabled = False
    env = IntersectionEnv(env_config)
    config = PPOConfig(
        total_steps=args.steps,
        seed=args.seed,
        checkpoint_interval_updates=args.save_interval_updates,
    )
    try:
        trainer = PPOTrainer(env, config)
        if args.init_checkpoint is not None:
            trainer.model.load(args.init_checkpoint)
        trainer.train(args.checkpoint)
        print(f"saved={args.checkpoint}")
    finally:
        env.close()


def evaluate(args: argparse.Namespace) -> None:
    env = IntersectionEnv(environment_config(args))
    model = load_model(env, args.policy)
    rng = np.random.default_rng(args.seed)
    rewards: list[float] = []
    completions: list[int] = []
    failures: list[int] = []
    shields: list[int] = []
    collisions = 0
    violations = 0
    left_yield_violations = 0
    right_yield_violations = 0
    right_lane_violations = 0
    proximity_violations = 0
    try:
        for episode in range(args.episodes):
            observation, _ = env.reset(seed=args.seed + episode)
            done = False
            episode_reward = 0.0
            while not done:
                actions, _, _ = model.act(observation, rng, deterministic=True)
                observation, reward, terminated, truncated, info = env.step(actions)
                episode_reward += float(reward.sum())
                collisions += info["collisions"]
                proximity_violations += info["proximity_violations"]
                violations += info["red_light_violations"]
                left_yield_violations += info["left_yield_violations"]
                right_yield_violations += info["right_yield_violations"]
                right_lane_violations += info["right_lane_violations"]
                done = terminated or truncated
            rewards.append(episode_reward)
            completions.append(info["completed_clean"])
            failures.append(info["failed_vehicles"])
            shields.append(info["cumulative_safety_overrides"])
    finally:
        env.close()
    print(
        f"episodes={args.episodes} mean_reward={np.mean(rewards):.2f} "
        f"mean_completed={np.mean(completions):.2f} "
        f"mean_failed={np.mean(failures):.2f} "
        f"mean_shield={np.mean(shields):.2f} "
        f"collisions={collisions} proximity={proximity_violations} red_violations={violations} "
        f"left_yield={left_yield_violations} "
        f"right_yield={right_yield_violations} "
        f"right_lane={right_lane_violations}"
    )


def main() -> None:
    args = build_parser().parse_args()
    {"simulate": simulate, "train": train, "evaluate": evaluate}[args.command](args)


if __name__ == "__main__":
    main()
