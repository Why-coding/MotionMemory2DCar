from dataclasses import dataclass


@dataclass(slots=True)
class EnvConfig:
    """Configuration for the intersection simulator."""

    # Week 5: initial two-lane, signalized, four-way intersection.
    max_cars: int = 12
    min_cars: int = 8
    lanes_per_approach: int = 2
    lane_width: float = 4.0
    road_length: float = 65.0
    intersection_half_size: float = 10.0
    dt: float = 0.2
    episode_seconds: float = 60.0
    signal_green_seconds: float = 12.0
    signal_yellow_seconds: float = 3.0
    protected_left_signal: bool = False
    left_signal_green_seconds: float = 5.0
    left_yield_distance: float = 22.0
    allow_right_on_red: bool = True
    right_yield_distance: float = 24.0
    lateral_speed: float = 1.2
    initial_lateral_noise: float = 0.8
    max_speed: float = 13.4
    max_acceleration: float = 2.5
    comfortable_braking: float = 4.0
    vehicle_length: float = 4.5
    vehicle_width: float = 1.8
    collision_distance: float = 3.2
    seed: int | None = None
    curriculum_enabled: bool = False
    curriculum_min_lanes: int = 1
    curriculum_max_lanes: int = 5
    curriculum_min_cars: int = 5
    curriculum_max_cars: int = 64
    curriculum_randomize_left_signal: bool = True
    curriculum_randomize_right_on_red: bool = True

    def __post_init__(self) -> None:
        if not 1 <= self.lanes_per_approach <= 5:
            raise ValueError("lanes_per_approach must be between 1 and 5")
        if self.min_cars < 1 or self.max_cars < self.min_cars:
            raise ValueError("car counts must satisfy 1 <= min_cars <= max_cars")
        if not 1 <= self.curriculum_min_lanes <= self.curriculum_max_lanes <= 5:
            raise ValueError("curriculum lanes must satisfy 1 <= min <= max <= 5")
        if not 1 <= self.curriculum_min_cars <= self.curriculum_max_cars:
            raise ValueError("curriculum cars must satisfy 1 <= min <= max")
        if self.curriculum_enabled and self.max_cars < self.curriculum_max_cars:
            raise ValueError("max_cars must be >= curriculum_max_cars")
        if self.curriculum_enabled and self.min_cars > self.curriculum_min_cars:
            raise ValueError("min_cars must be <= curriculum_min_cars")
        maximum_lane_count = max(self.lanes_per_approach, self.curriculum_max_lanes)
        minimum_intersection_size = maximum_lane_count * self.lane_width
        self.intersection_half_size = max(
            self.intersection_half_size, minimum_intersection_size
        )

    @property
    def max_steps(self) -> int:
        return round(self.episode_seconds / self.dt)


@dataclass(slots=True)
class PPOConfig:
    """Hyperparameters for the dependency-light NumPy PPO implementation."""

    # Week 6: completed lane scaling, turn signals, right-on-red, and yielding.
    # Week 7: replace kinematics with kinodynamics, speed limits, and merges.
    # Week 8: add parking lanes, parked cars, crosswalks, and pedestrians.
    # Week 9: add jaywalking and vehicle lane changes.
    # Week 10: add per-car goals and cut-in scenario generation.
    # Week 11: add unprotected turns, noise, occlusion, and ROS bag adapters.
    # Week 12: calibrate and deploy the policy in the Nissan simulator.

    # Week 5: shared PPO policy for all active cars.
    total_steps: int = 100_000
    rollout_steps: int = 256
    update_epochs: int = 8
    minibatch_size: int = 512
    hidden_size: int = 64
    learning_rate: float = 3e-4
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_ratio: float = 0.2
    value_coefficient: float = 0.5
    entropy_coefficient: float = 0.01
    max_grad_norm: float = 0.5
    checkpoint_interval_updates: int = 10
    seed: int = 7
