from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from intersection_rl.config import PPOConfig


LOG_2PI = float(np.log(2.0 * np.pi))


class Adam:
    def __init__(self, parameters: list[np.ndarray], learning_rate: float) -> None:
        self.parameters = parameters
        self.learning_rate = learning_rate
        self.m = [np.zeros_like(parameter) for parameter in parameters]
        self.v = [np.zeros_like(parameter) for parameter in parameters]
        self.step_count = 0

    def step(self, gradients: list[np.ndarray], max_grad_norm: float) -> None:
        norm = np.sqrt(sum(float(np.sum(gradient**2)) for gradient in gradients))
        scale = min(1.0, max_grad_norm / (norm + 1e-8))
        self.step_count += 1
        for index, (parameter, gradient) in enumerate(
            zip(self.parameters, gradients)
        ):
            gradient = gradient * scale
            self.m[index] = 0.9 * self.m[index] + 0.1 * gradient
            self.v[index] = 0.999 * self.v[index] + 0.001 * gradient**2
            m_hat = self.m[index] / (1.0 - 0.9**self.step_count)
            v_hat = self.v[index] / (1.0 - 0.999**self.step_count)
            parameter -= self.learning_rate * m_hat / (np.sqrt(v_hat) + 1e-8)


class SharedActorCritic:
    """Shared MLP with a Gaussian continuous-action policy."""

    def __init__(
        self,
        observation_size: int,
        hidden_size: int,
        action_size: int = 2,
        seed: int = 7,
    ) -> None:
        rng = np.random.default_rng(seed)

        def layer(fan_in: int, fan_out: int, gain: float = np.sqrt(2.0)):
            limit = gain * np.sqrt(3.0 / fan_in)
            return rng.uniform(-limit, limit, (fan_in, fan_out)).astype(np.float32)

        self.w1 = layer(observation_size, hidden_size)
        self.b1 = np.zeros(hidden_size, dtype=np.float32)
        self.w2 = layer(hidden_size, hidden_size)
        self.b2 = np.zeros(hidden_size, dtype=np.float32)
        self.wp = layer(hidden_size, action_size, gain=0.01)
        self.bp = np.zeros(action_size, dtype=np.float32)
        self.log_std = np.full(action_size, -1.0, dtype=np.float32)
        self.min_log_std = -2.5
        self.max_log_std = -0.5
        self.wv = layer(hidden_size, 1, gain=1.0)
        self.bv = np.zeros(1, dtype=np.float32)
        self.parameters = [
            self.w1,
            self.b1,
            self.w2,
            self.b2,
            self.wp,
            self.bp,
            self.log_std,
            self.wv,
            self.bv,
        ]

    def forward(
        self, observations: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, tuple[np.ndarray, ...]]:
        first_pre = observations @ self.w1 + self.b1
        first = np.tanh(first_pre)
        second_pre = first @ self.w2 + self.b2
        second = np.tanh(second_pre)
        raw_mean = second @ self.wp + self.bp
        mean = np.tanh(raw_mean)
        values = (second @ self.wv + self.bv).squeeze(-1)
        return mean, values, (observations, first, second, raw_mean, mean)

    def log_prob(self, actions: np.ndarray, mean: np.ndarray) -> np.ndarray:
        log_std = np.clip(self.log_std, self.min_log_std, self.max_log_std)
        std = np.exp(log_std)
        normalized = (actions - mean) / std
        per_dim = -0.5 * (normalized**2 + 2.0 * log_std + LOG_2PI)
        return per_dim.sum(axis=-1)

    def entropy(self) -> float:
        log_std = np.clip(self.log_std, self.min_log_std, self.max_log_std)
        return float(np.sum(log_std + 0.5 * (1.0 + LOG_2PI)))

    def act(
        self,
        observations: np.ndarray,
        rng: np.random.Generator,
        deterministic: bool = False,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        mean, values, _ = self.forward(observations)
        if deterministic:
            actions = mean
        else:
            log_std = np.clip(self.log_std, self.min_log_std, self.max_log_std)
            actions = mean + rng.normal(size=mean.shape) * np.exp(log_std)
        actions = np.clip(actions, -1.0, 1.0).astype(np.float32)
        log_probs = self.log_prob(actions, mean)
        return actions, log_probs, values

    def gradients(
        self,
        observations: np.ndarray,
        actions: np.ndarray,
        old_log_probs: np.ndarray,
        advantages: np.ndarray,
        returns: np.ndarray,
        clip_ratio: float,
        value_coefficient: float,
        entropy_coefficient: float,
    ) -> tuple[list[np.ndarray], dict[str, float]]:
        mean, values, cache = self.forward(observations)
        log_probs = self.log_prob(actions, mean)
        ratio = np.exp(log_probs - old_log_probs)
        unclipped = ratio * advantages
        clipped_ratio = np.clip(ratio, 1.0 - clip_ratio, 1.0 + clip_ratio)
        clipped = clipped_ratio * advantages
        policy_loss = -float(np.mean(np.minimum(unclipped, clipped)))

        use_unclipped = unclipped <= clipped
        coefficient = np.zeros_like(advantages)
        coefficient[use_unclipped] = (
            -advantages[use_unclipped] * ratio[use_unclipped] / len(actions)
        )
        log_std = np.clip(self.log_std, self.min_log_std, self.max_log_std)
        std = np.exp(log_std)
        variance = std**2
        d_logprob_d_mean = (actions - mean) / variance
        d_logprob_d_log_std = ((actions - mean) ** 2 / variance) - 1.0
        d_mean = coefficient[:, None] * d_logprob_d_mean
        grad_log_std = (coefficient[:, None] * d_logprob_d_log_std).sum(axis=0)

        entropy = self.entropy()
        grad_log_std -= entropy_coefficient * np.ones_like(self.log_std)

        value_error = values - returns
        value_loss = 0.5 * float(np.mean(value_error**2))
        d_values = value_coefficient * value_error / len(actions)

        observations, first, second, raw_mean, mean = cache
        d_raw_mean = d_mean * (1.0 - mean**2)
        grad_wp = second.T @ d_raw_mean
        grad_bp = d_raw_mean.sum(axis=0)
        grad_wv = second.T @ d_values[:, None]
        grad_bv = np.array([d_values.sum()], dtype=np.float32)
        d_second = d_raw_mean @ self.wp.T + d_values[:, None] @ self.wv.T
        d_second_pre = d_second * (1.0 - second**2)
        grad_w2 = first.T @ d_second_pre
        grad_b2 = d_second_pre.sum(axis=0)
        d_first = d_second_pre @ self.w2.T
        d_first_pre = d_first * (1.0 - first**2)
        grad_w1 = observations.T @ d_first_pre
        grad_b1 = d_first_pre.sum(axis=0)
        approximate_kl = float(np.mean(old_log_probs - log_probs))

        gradients = [
            grad_w1,
            grad_b1,
            grad_w2,
            grad_b2,
            grad_wp,
            grad_bp,
            grad_log_std,
            grad_wv,
            grad_bv,
        ]
        metrics = {
            "policy_loss": policy_loss,
            "value_loss": value_loss,
            "entropy": entropy,
            "approximate_kl": approximate_kl,
        }
        return gradients, metrics

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        np.savez(
            path,
            w1=self.w1,
            b1=self.b1,
            w2=self.w2,
            b2=self.b2,
            wp=self.wp,
            bp=self.bp,
            log_std=self.log_std,
            wv=self.wv,
            bv=self.bv,
        )

    def load(self, path: str | Path) -> None:
        data = np.load(path)
        for name in ("w1", "b1", "w2", "b2", "wp", "bp", "log_std", "wv", "bv"):
            getattr(self, name)[...] = data[name]


@dataclass(slots=True)
class Rollout:
    observations: np.ndarray
    actions: np.ndarray
    log_probs: np.ndarray
    rewards: np.ndarray
    values: np.ndarray
    dones: np.ndarray
    masks: np.ndarray
    last_values: np.ndarray
    info_metrics: dict[str, float]

    def advantages_and_returns(
        self, gamma: float, gae_lambda: float
    ) -> tuple[np.ndarray, np.ndarray]:
        advantages = np.zeros_like(self.rewards)
        gae = np.zeros(self.rewards.shape[1], dtype=np.float32)
        for time_index in reversed(range(len(self.rewards))):
            next_values = (
                self.last_values
                if time_index == len(self.rewards) - 1
                else self.values[time_index + 1]
            )
            nonterminal = 1.0 - self.dones[time_index]
            delta = (
                self.rewards[time_index]
                + gamma * next_values * nonterminal
                - self.values[time_index]
            )
            gae = delta + gamma * gae_lambda * nonterminal * gae
            gae *= self.masks[time_index]
            advantages[time_index] = gae
        return advantages, advantages + self.values


class PPOTrainer:
    """PPO trainer using one shared continuous policy for all vehicle slots."""

    def __init__(self, env, config: PPOConfig) -> None:
        self.env = env
        self.config = config
        self.rng = np.random.default_rng(config.seed)
        self.model = SharedActorCritic(
            env.OBSERVATION_SIZE,
            config.hidden_size,
            env.ACTION_SIZE,
            seed=config.seed,
        )
        self.optimizer = Adam(self.model.parameters, config.learning_rate)
        self.observation, self.info = env.reset(seed=config.seed)

    def collect_rollout(self) -> Rollout:
        storage: dict[str, list[np.ndarray]] = {
            key: []
            for key in (
                "observations",
                "actions",
                "log_probs",
                "rewards",
                "values",
                "dones",
                "masks",
            )
        }
        info_metrics = {
            "completed_clean": 0.0,
            "failed": 0.0,
            "collisions": 0.0,
            "proximity": 0.0,
            "red": 0.0,
            "left_yield": 0.0,
            "right_yield": 0.0,
            "right_lane": 0.0,
            "safety_overrides": 0.0,
            "unsafe_requests": 0.0,
            "progress": 0.0,
            "safety_score": 0.0,
        }
        for _ in range(self.config.rollout_steps):
            actions, log_probs, values = self.model.act(
                self.observation, self.rng
            )
            mask = self.info["active_mask"].copy()
            next_observation, rewards, terminated, truncated, next_info = (
                self.env.step(actions)
            )
            rewards = np.clip(
                rewards,
                -self.config.reward_clip,
                self.config.reward_clip,
            )
            info_metrics["completed_clean"] += float(next_info.get("completed_delta", 0))
            info_metrics["failed"] += float(next_info.get("failed_delta", 0))
            info_metrics["collisions"] += float(next_info.get("collisions", 0))
            info_metrics["proximity"] += float(next_info.get("proximity_violations", 0))
            info_metrics["red"] += float(next_info.get("red_light_violations", 0))
            info_metrics["left_yield"] += float(next_info.get("left_yield_violations", 0))
            info_metrics["right_yield"] += float(next_info.get("right_yield_violations", 0))
            info_metrics["right_lane"] += float(next_info.get("right_lane_violations", 0))
            info_metrics["safety_overrides"] += float(next_info.get("safety_overrides", 0))
            info_metrics["unsafe_requests"] += float(next_info.get("unsafe_requests", 0))
            info_metrics["progress"] += float(next_info.get("progress_delta", 0.0))
            info_metrics["safety_score"] += float(next_info.get("safety_score", 0.0))
            done = terminated or truncated
            storage["observations"].append(self.observation.copy())
            storage["actions"].append(actions)
            storage["log_probs"].append(log_probs)
            storage["rewards"].append(rewards)
            storage["values"].append(values)
            storage["dones"].append(np.full_like(rewards, float(done)))
            storage["masks"].append(mask)
            self.observation, self.info = next_observation, next_info
            if done:
                self.observation, self.info = self.env.reset()

        _, last_values, _ = self.model.forward(self.observation)
        arrays = {key: np.asarray(value) for key, value in storage.items()}
        return Rollout(**arrays, last_values=last_values, info_metrics=info_metrics)

    def update(self, rollout: Rollout) -> dict[str, float]:
        advantages, returns = rollout.advantages_and_returns(
            self.config.gamma, self.config.gae_lambda
        )
        active = rollout.masks.reshape(-1).astype(bool)
        observations = rollout.observations.reshape(
            -1, rollout.observations.shape[-1]
        )[active]
        actions = rollout.actions.reshape(-1, rollout.actions.shape[-1])[active]
        old_log_probs = rollout.log_probs.reshape(-1)[active]
        advantages = advantages.reshape(-1)[active]
        returns = returns.reshape(-1)[active]
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        indices = np.arange(len(actions))
        metrics: dict[str, float] = {}
        update_count = 0
        for _ in range(self.config.update_epochs):
            self.rng.shuffle(indices)
            for start in range(0, len(indices), self.config.minibatch_size):
                batch = indices[start : start + self.config.minibatch_size]
                gradients, batch_metrics = self.model.gradients(
                    observations[batch],
                    actions[batch],
                    old_log_probs[batch],
                    advantages[batch],
                    returns[batch],
                    self.config.clip_ratio,
                    self.config.value_coefficient,
                    self.config.entropy_coefficient,
                )
                self.optimizer.step(gradients, self.config.max_grad_norm)
                self.model.log_std[...] = np.clip(
                    self.model.log_std,
                    self.model.min_log_std,
                    self.model.max_log_std,
                )
                for key, value in batch_metrics.items():
                    metrics[key] = metrics.get(key, 0.0) + value
                update_count += 1
        metrics = {key: value / update_count for key, value in metrics.items()}
        active_rewards = rollout.rewards[rollout.masks.astype(bool)]
        metrics["rollout_mean_reward"] = float(active_rewards.mean())
        metrics.update(rollout.info_metrics)
        return metrics

    def train(self, checkpoint_path: str | Path) -> SharedActorCritic:
        checkpoint_path = Path(checkpoint_path)
        completed_steps = 0
        update_index = 0
        best_safety_score = -float("inf")
        while completed_steps < self.config.total_steps:
            rollout = self.collect_rollout()
            metrics = self.update(rollout)
            completed_steps += self.config.rollout_steps
            update_index += 1
            if metrics["safety_score"] > best_safety_score:
                best_safety_score = metrics["safety_score"]
                best_path = checkpoint_path.with_name(
                    f"{checkpoint_path.stem}_best{checkpoint_path.suffix}"
                )
                self.model.save(best_path)
            if self.config.checkpoint_interval_updates > 0 and (
                update_index % self.config.checkpoint_interval_updates == 0
            ):
                interim_path = checkpoint_path.with_name(
                    f"{checkpoint_path.stem}_update_{update_index:04d}{checkpoint_path.suffix}"
                )
                self.model.save(interim_path)
            print(
                f"update={update_index:04d} steps={completed_steps:07d} "
                f"reward={metrics['rollout_mean_reward']:+.4f} "
                f"policy={metrics['policy_loss']:+.4f} "
                f"value={metrics['value_loss']:.4f} "
                f"entropy={metrics['entropy']:.3f} "
                f"kl={metrics['approximate_kl']:+.5f} "
                f"score={metrics['safety_score']:+.1f} "
                f"clean={metrics['completed_clean']:.0f} "
                f"failed={metrics['failed']:.0f} "
                f"coll={metrics['collisions']:.0f} "
                f"prox={metrics['proximity']:.0f} "
                f"red={metrics['red']:.0f} "
                f"yield={metrics['left_yield'] + metrics['right_yield']:.0f} "
                f"progress={metrics['progress']:.1f} "
                f"shield={metrics['safety_overrides']:.0f}"
            )
        self.model.save(checkpoint_path)
        return self.model
