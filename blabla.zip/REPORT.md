# Intersection RL Engineering Report

## 1. Executive Summary

This project builds a lightweight four-way intersection simulator and trains a
shared reinforcement-learning policy for autonomous-driving behavior inside that
simulator. The current implementation covers the Week 5 and Week 6 milestones
from the project plan.

The simulator currently supports:

- One to five incoming lanes per approach.
- Four-way traffic-light-controlled intersection.
- Protected left-turn signal mode or permissive/yielding left-turn mode.
- Right turns on green.
- Optional right turn on red after yielding.
- Right-turn enforcement from the rightmost lane.
- Random outgoing destination lane assignment.
- Continuous acceleration and continuous steering actions.
- Oriented-rectangle collision detection using vehicle length, width, and heading.
- Proximity penalties when cars are too close but not yet overlapping.
- Curriculum training across randomized lane counts, car counts, signal modes,
  right-on-red settings, route choices, destination lanes, and seeds.
- PPO training with final, best, and intermediate checkpoint saving.

The current codebase is intentionally dependency-light. It uses `numpy`,
`gymnasium`, and `pygame`; it does not depend on PyTorch or Stable-Baselines3.
This makes the simulator easy to run in local Python and Docker environments,
but it also means the PPO implementation is a compact in-repository
implementation rather than an industrial RL stack.

## 2. Project Goals

The project goal is to create an intersection simulator and train an RL policy
that can learn traffic-rule-compliant behavior. The simulator is built in stages
so that complexity is added only after the policy and environment interface are
understood.

The high-level goals are:

- Build a controllable intersection simulator.
- Model cars, lanes, routes, stop lines, traffic lights, and interactions.
- Define policy observations and actions explicitly.
- Train a shared policy using PPO.
- Add traffic complexity week by week.
- Keep code modular enough to extend toward later project phases such as
  speed limits, merging, pedestrians, stop signs, noise, ROS bag compatibility,
  and simulator deployment.

## 3. Repository Structure

| File | Responsibility |
| --- | --- |
| `intersection_rl/config.py` | Environment and PPO configuration dataclasses. |
| `intersection_rl/env.py` | Main Gymnasium-compatible simulator environment. |
| `intersection_rl/geometry.py` | Road, lane, route, and polyline geometry helpers. |
| `intersection_rl/vehicle.py` | Vehicle state and kinematic update model. |
| `intersection_rl/ppo.py` | Shared Gaussian actor-critic PPO implementation. |
| `intersection_rl/cli.py` | Command-line interface for simulation, training, and evaluation. |
| `intersection_rl/rendering.py` | Pygame renderer for visual simulation. |
| `tests/` | Regression tests for geometry, environment behavior, and PPO numerics. |
| `README.md` | User-facing setup, Docker, and command reference. |
| `REPORT.md` | Formal engineering report and design record. |
| `Dockerfile`, `compose.yaml` | Container execution support. |

## 4. Current Technical Status

Current milestone: Week 6 complete.

Implemented:

- Week 5 base simulator and PPO loop.
- Week 6 lane scaling, turn-signal logic, right-on-red, and lane-following
  behavior.
- Curriculum training across multiple configurations.
- Continuous action policy.
- Rectangle-based collision and proximity penalty.
- Docker packaging.

Not yet implemented:

- Week 7 kinodynamic vehicle model.
- Speed limits and speed-limit rewards.
- Merge lanes and merge-yield behavior.
- Pedestrians, parked vehicles, jaywalking, stop signs, occlusion, ROS bag
  adapter, Nissan simulator deployment.

## 5. Simulator Design

### 5.1 Intersection Layout

The simulator represents a four-way intersection with approaches:

- North (`N`)
- East (`E`)
- South (`S`)
- West (`W`)

Each approach can have one to five incoming lanes. The road geometry uses a
centerline representation for each route. A route is represented by a `Polyline`
object, and each vehicle tracks progress along that polyline.

The route types are:

- `left`
- `straight`
- `right`

### 5.2 Lane Convention

Lanes are indexed from `0` to `lanes_per_approach - 1`.

Current lane-use rules:

- If there is one lane, it can serve left, straight, or right movements.
- Lane `0` is the left/straight lane.
- The rightmost lane is the straight/right lane.
- Intermediate lanes are straight-only.
- Right turns are legal only from the rightmost lane.

This rule was chosen because it matches the Week 6 project requirement for
rightmost-lane right turns while keeping route generation simple and explicit.

### 5.3 Destination Lane Assignment

Each vehicle receives a random valid outgoing destination lane. This was added
because training only one fixed lane-to-lane route would not teach a general
route-following policy.

Rationale:

- If every straight vehicle always exits into the same lane, the policy can
  overfit to one centerline.
- Random destination lanes force the observation to include route and target
  lane information.
- The lateral steering action and lane-centering reward give PPO a way to learn
  lane-following behavior.

### 5.4 Stop Lines

Stop lines are encoded in route geometry as the second route point. Each vehicle
stores `stop_progress`, which is the path-progress value at the stop line.

The policy does not receive raw world coordinates of the stop line. Instead, it
receives normalized distance to the stop line. This is more compact and easier
for a shared policy to learn from across approaches.

### 5.5 Vehicle Model

The current vehicle model is kinematic, not kinodynamic.

Vehicle state includes:

- Route progress.
- Speed.
- Acceleration.
- Lateral offset from route centerline.
- Steering command.
- Active/completed flag.
- Collision flag.
- Route type.
- Origin lane.
- Destination lane.

Vehicle position and heading are sampled from the route polyline. Lateral offset
is applied perpendicular to the route heading. This gives a simple steering
model without requiring full bicycle dynamics yet.

Rationale:

- Week 5 required a basic kinematic model.
- A simple route-progress model is easier to validate than a full dynamic model.
- Later Week 7 work can replace this with a kinodynamic model while preserving
  the high-level observation/reward structure.

## 6. Policy Interface

### 6.1 Multi-Agent Shape

The simulator exposes a fixed slot tensor:

```text
observation: (max_cars, 22)
action:      (max_cars, 2)
reward:      (max_cars,)
```

Each row corresponds to one vehicle slot. Not every slot must be active. The
`active_mask` in `info` tells PPO which slots should contribute to training.

Rationale:

- PPO requires consistent rollout array shapes.
- Curriculum training may vary active car count per episode.
- Fixed slots plus `active_mask` allow one policy to train across different car
  counts without changing tensor shapes.

### 6.2 Observation Vector

Each active vehicle receives a 22-dimensional normalized observation.

| Index/Group | Meaning | Reason |
| --- | --- | --- |
| 0 | Speed normalized by max speed | Required for longitudinal control. |
| 1 | Acceleration normalized by braking limit | Helps policy understand current motion trend. |
| 2 | Distance to stop line normalized by road length | Needed for stopping at lights and turn decisions. |
| 3 | Movement green flag | Tells whether the intended movement currently has green. |
| 4 | Yellow flag for vehicle axis | Helps policy avoid entering late in phase. |
| 5 | Red/no-green proxy | Helps signal compliance. |
| 6 | Front gap normalized by road length | Supports car following and safe distance. |
| 7 | Nearest vehicle distance normalized | Supports interaction awareness beyond same-lane front gap. |
| 8 | Route progress fraction | Helps know whether vehicle is before, inside, or after intersection. |
| 9 | Current lane index normalized | Needed for lane/rule context. |
| 10-12 | Route one-hot: left, straight, right | Defines intended maneuver. |
| 13 | `sin(heading)` | Encodes heading without angle discontinuity. |
| 14 | `cos(heading)` | Encodes heading without angle discontinuity. |
| 15 | Signal phase progress | Provides timing context. |
| 16 | Destination lane normalized | Needed for random destination lane following. |
| 17 | Lateral offset normalized by lane width | Needed for steering/lane centering. |
| 18 | Left-turn conflict flag | Needed for permissive left-turn yielding. |
| 19 | Right-on-red availability flag | Needed for right-on-red decision. |
| 20 | Right-turn conflict flag | Needed for yielding before right-on-red. |
| 21 | Rightmost-lane flag | Needed for right-turn legality. |

Important design choice:

The observation avoids absolute world coordinates where possible. Normalized
route-relative features are used because the same policy controls cars from all
approaches and should generalize across directions.

### 6.3 Action Vector

The action for each vehicle is continuous:

```text
action[0] = normalized acceleration in [-1, 1]
action[1] = normalized steering in [-1, 1]
```

Mapping:

- Positive acceleration command maps to `max_acceleration`.
- Negative acceleration command maps to `comfortable_braking`.
- Steering command changes lateral offset from route centerline.

Rationale:

The earlier implementation used discrete accelerate/coast/brake and left/center/right steering. Based on manager feedback, continuous acceleration is more realistic and avoids uncomfortable discrete go/stop behavior. Lateral steering is kept because Week 6 now includes random destination lanes and lane-following behavior.

## 7. Reward Design

The current reward is per vehicle.

| Reward/Penalty | Current Purpose |
| --- | --- |
| Progress reward | Encourages moving through the route. |
| Step penalty | Discourages indefinite blocking. |
| Acceleration penalty | Discourages excessive acceleration/braking. |
| Lateral offset penalty | Encourages lane-center tracking. |
| Steering penalty | Discourages unnecessary steering oscillation. |
| Front-gap penalty | Penalizes following too closely in the same lane. |
| Proximity penalty | Penalizes all-around too-close vehicles before collision. |
| Collision penalty | Large penalty for rectangle overlap. |
| Red-light penalty | Penalizes entering without legal movement permission. |
| Left-yield penalty | Penalizes permissive left turn when opposing straight traffic has priority. |
| Right-yield penalty | Penalizes unsafe right-on-red when conflict exists. |
| Wrong-lane right-turn penalty | Penalizes right turn from non-rightmost lane. |
| Completion bonus | Rewards finishing the route. |

### 7.1 Safe Distance

Safe distance is represented in two ways:

1. Same-lane front gap check:
   ```text
   front_gap < vehicle_length + 2.0
   ```
2. General proximity detection using all active vehicles:
   ```text
   center_clearance < safe_clearance
   ```

The second term was added because same-lane front gap alone misses side and
angled near-collisions. This directly addresses the concern that vehicles need
length, width, and orientation in collision/safety modeling.

### 7.2 Collision Model

Vehicles are modeled as oriented rectangles. Corners are computed from:

- Vehicle center.
- Heading.
- Vehicle length.
- Vehicle width.

Rectangle overlap is checked using separating-axis projection. This detects:

- Front collisions.
- Rear collisions.
- Side collisions.
- Angled overlap.

Rationale:

The original point-distance collision check was too approximate. It could miss
side contacts or over-penalize situations depending on center distance. Rectangle
overlap better represents real vehicle footprint.

## 8. Traffic Signal and Rule Model

### 8.1 Protected Left-Turn Mode

In protected mode, each axis has a left-turn phase followed by a through phase:

```text
NS_LEFT_GREEN -> NS_GREEN -> NS_YELLOW -> EW_LEFT_GREEN -> EW_GREEN -> EW_YELLOW
```

During left phase:

- Left-turning vehicles on the active axis may proceed.
- Through traffic on that axis remains red.

During through phase:

- Straight/right movements may proceed.
- Protected left turns are red.

Rationale:

This matches the requirement that a dedicated left signal should be green first,
then the other signal should be green, and each should be red when the other is
green.

### 8.2 Permissive Left-Turn Mode

In yield mode, left turns share the through green. A left-turning vehicle must
yield if an opposing straight vehicle is close to or inside the intersection.

Conflict check uses:

- Opposing approach.
- Opposing vehicle route equals `straight`.
- Distance to opposing vehicle stop line.
- Opposing vehicle speed.

Rationale:

The left-turning car needs to learn that green does not always mean safe to
proceed. The `left_turn_conflict` observation flag and yield penalty expose this
rule to PPO.

### 8.3 Right Turn On Red

Right-on-red is optional and enabled by default.

A right turn on red is legal only if:

- Right-on-red is enabled.
- Vehicle route is `right`.
- Vehicle is in the rightmost incoming lane.
- The normal movement signal is not already green.
- The phase is not yellow for that axis.
- No conflicting perpendicular or opposing-left traffic is close/inside the
  intersection.

If a vehicle enters right-on-red with conflict, it receives a right-yield
penalty. If it turns right from the wrong lane, it receives a wrong-lane penalty.

## 9. Curriculum Training

### 9.1 Why Curriculum Was Added

A policy trained only on one setting, for example four lanes and 20 cars, can be
executed on a different setting, but it may not behave safely. Generalization
requires exposure to multiple layouts during training.

The curriculum mode solves this by randomizing the active scenario at each
episode reset while keeping PPO tensors fixed.

### 9.2 Curriculum Parameters

CLI example:

```bash
intersection-rl train --curriculum \
  --curriculum-min-lanes 2 --curriculum-max-lanes 5 \
  --curriculum-min-cars 5 --curriculum-max-cars 64 \
  --steps 100000 \
  --checkpoint checkpoints/week6_curriculum.npz
```

Curriculum randomizes:

- Active lane count.
- Active car count.
- Protected/yield left signal mode.
- Right-on-red on/off.
- Random route choices.
- Random destination lanes.
- Initial offsets and seeds.

### 9.3 Fixed Tensor Shape

The environment still has fixed shapes:

```text
observation: (curriculum_max_cars, 22)
action:      (curriculum_max_cars, 2)
```

Inactive vehicle slots are masked out using `active_mask`. This is necessary
because PPO rollout arrays must have stable shapes across updates.

### 9.4 Capacity Handling

If the sampled lane count cannot physically fit the requested maximum car count,
the active car count is capped by road capacity. This prevents invalid episodes
such as too many queued vehicles for a short road.

## 10. PPO Design

### 10.1 Shared Policy

One shared actor-critic network controls all active vehicles. Each active car is
one sample in the PPO update.

Rationale:

- Reduces model size.
- Allows learning a general driving rule rather than a vehicle-specific rule.
- Supports variable active vehicle count through masking.

### 10.2 Continuous Gaussian Actor

The actor outputs a mean action vector. Exploration is done by sampling from a
Gaussian distribution with learned log standard deviation.

The sampled action is clipped to `[-1, 1]` before being sent to the environment.

### 10.3 Checkpointing

Training saves:

- Final checkpoint: exact `--checkpoint` path.
- Best checkpoint: `<name>_best.npz` based on rollout mean reward.
- Periodic checkpoint: `<name>_update_XXXX.npz` every configured number of PPO
  updates.

Rationale:

Saving only at the end is risky because RL training can become unstable. Best
and intermediate checkpoints allow recovery from earlier better policies.

## 11. Validation and Tests

Current test count: 40 passing tests.

Test categories:

- Geometry path construction.
- Route projection.
- Environment reset and step shapes.
- Reproducible seeded resets.
- Episode truncation.
- Rule-based baseline action validity.
- Four-lane and five-lane exact car counts.
- Renderer background output.
- Protected left-turn phase separation.
- Permissive left-turn conflict detection.
- Destination lane randomization.
- Lateral action behavior.
- Right-on-red conflict and disabling behavior.
- Unsafe right-on-red violation counter.
- Right turns only from rightmost lane.
- Rectangle collision detection.
- Proximity violation detection.
- Curriculum randomized episode settings with fixed tensor shapes.
- Curriculum capacity capping.
- Continuous Gaussian PPO actor shapes.
- Short PPO rollout/update finite metrics.

Smoke tests performed during development:

- Visual/render path with `rgb_array` mode.
- Fixed-config PPO training.
- Curriculum PPO training.
- Checkpoint saving for final, best, and update checkpoints.
- Docker build and containerized training/evaluation.

## 12. Week-by-Week Engineering Record

## Week 5: Base Simulator and PPO Policy

### 12.1 Goal

Create the first runnable intersection simulation and train a PPO policy in that
environment.

### 12.2 Implemented Modules

| Module | Week 5 Responsibility |
| --- | --- |
| `env.py` | Base multi-agent intersection environment. |
| `geometry.py` | Four-way route centerlines and stop-line projection. |
| `vehicle.py` | Vehicle state and basic kinematic stepping. |
| `ppo.py` | Initial shared PPO trainer. |
| `rendering.py` | Pygame visualization. |
| `cli.py` | Simulate, train, and evaluate commands. |

### 12.3 Week 5 Environment Features

- Four-way intersection.
- Traffic light phases.
- Stop lines before intersection.
- Initial two-lane assumption.
- 8-12 vehicles by default.
- Left/straight/right route choices.
- Kinematic vehicle progression along route paths.
- Per-vehicle observations, actions, and rewards.

### 12.4 Week 5 Policy Inputs

The first version included motion state, signal state, route type, lane index,
front gap, nearest vehicle distance, route progress, and heading.

### 12.5 Week 5 Policy Outputs

The first version used discrete actions. This was later changed to continuous
actions after feedback that discrete go/coast/stop is not comfortable or
realistic enough.

Current output is continuous acceleration and steering.

### 12.6 Week 5 Rewards

Implemented rewards/penalties:

- Positive progress reward.
- Small time penalty.
- Acceleration penalty.
- Collision penalty.
- Red-light violation penalty.
- Front-gap penalty.
- Completion bonus.

### 12.7 Week 5 Design Rationale

The first simulator was intentionally simple. A full driving simulator can
become too complex before the RL interface is validated. The Week 5 design
prioritized:

- Clear state/action/reward interface.
- Fast training loop.
- Visual inspection.
- Minimal dependencies.
- Easy extension for later weeks.

### 12.8 Week 5 Bugs and Fixes

| Bug / Issue | Cause | Fix |
| --- | --- | --- |
| Image viewer sandbox failed while reading plan images. | Local environment sandbox had `bwrap` networking failure. | Used OCR and local image-processing tools instead. |
| Initial collision penalty repeated every overlapping frame. | Collision was detected every step for the same pair. | Added `_collision_pairs` so each pair collision is counted once. |
| Cars were not centered correctly in lanes. | Outgoing route geometry converged to a single lane. | Added lane-aware outgoing points and destination lane handling. |
| Stop-line rendering span was too wide. | Stop line was drawn across incoming and outgoing lanes. | Restricted stop-line drawing to incoming lane width. |
| Rule-based baseline typo. | Used `vehicle.apach` instead of `vehicle.approach`. | Corrected attribute and added regression test. |
| Slotted `Polyline` cached fields failed. | Dataclass with `slots=True` did not declare cached fields. | Added `_segments`, `_lengths`, and `_cumulative` fields. |

## Week 6: Lane Scaling, Turning Rules, and Curriculum

### 12.9 Goal

Increase simulator realism by supporting more lanes and more detailed turning
rules, then prepare training for multiple configurations.

### 12.10 Implemented Week 6 Features

- Configurable one to five lanes per approach.
- Exact configurable vehicle count.
- Protected left-turn signal mode.
- Permissive left-turn yielding mode.
- Right turns on green.
- Optional right turn on red.
- Right-on-red conflict yielding.
- Right-turn restriction to rightmost lane.
- Random destination lane assignment.
- Continuous acceleration and steering.
- Rectangle collision model.
- Proximity/safe-distance penalty.
- Curriculum training across randomized configurations.
- Best and intermediate checkpoint saving.

### 12.11 Week 6 Policy Inputs Added

Week 6 added or emphasized:

- Destination lane.
- Lateral offset.
- Left-turn conflict flag.
- Right-on-red availability flag.
- Right-turn conflict flag.
- Rightmost-lane flag.

### 12.12 Week 6 Policy Outputs

Current policy output:

```text
continuous acceleration command in [-1, 1]
continuous steering command in [-1, 1]
```

Reason for this choice:

- Continuous acceleration is more realistic than discrete accelerate/coast/brake.
- Steering is needed because vehicles can receive random destination lanes.
- Keeping both controls continuous allows smoother behavior and aligns better
  with later kinodynamic work.

### 12.13 Week 6 Rule Details

Protected left:

- Left arrow green first.
- Through green after left phase.
- Left movement red while through is green.

Permissive left:

- Left shares through green.
- Left yields to opposing straight traffic.

Right-on-red:

- Only if enabled.
- Only from rightmost lane.
- Only if conflicting traffic is clear.
- Penalized if unsafe.

### 12.14 Week 6 Curriculum Rationale

Without curriculum, a model trained on one layout may fail on another. The
curriculum was added to expose the policy to a distribution of scenarios.

The curriculum keeps fixed tensor shapes but randomizes active scenario details.
This preserves PPO compatibility while improving policy generalization.

### 12.15 Week 6 Bugs and Fixes

| Bug / Issue | Cause | Fix |
| --- | --- | --- |
| Training with one config did not guarantee generalization. | PPO tensor shape was fixed to one car count. | Added curriculum with fixed max slots and active masks. |
| Curriculum could sample more cars than road could fit. | Active car count did not consider lane capacity. | Added `_lane_capacity()` and capacity-aware sampling. |
| Rendering originally used base lane count during curriculum. | Renderer referenced static config instead of sampled episode state. | Renderer now uses `episode_lanes_per_approach` and episode modes. |
| Discrete action space conflicted with smooth-control feedback. | Initial PPO actor was categorical. | Replaced actor with Gaussian continuous policy. |
| Old checkpoints became incompatible after action-space change. | Actor output changed from 9 discrete logits to 2 continuous means. | Documented incompatibility; retraining required. |
| Point collision did not represent vehicle footprint. | Collision used center distance. | Added oriented rectangle overlap using vehicle length, width, heading. |
| Safe-distance penalty was too narrow. | Only same-lane front gap was penalized. | Added all-around proximity penalty. |
| Docker zip included stale extracted folder and manager screenshot. | Zip command did not exclude old extracted copy and `PP4.jpeg`. | Rebuilt zip with explicit exclusions. |
| Docker-generated checkpoints were root-owned. | Compose ran container as root. | Added host UID/GID mapping in Compose. |

## Week 7: Planned Kinodynamics, Speed Limits, and Merge Lanes

### 12.16 Goal

Move from basic kinematics toward more realistic driving dynamics and add speed
limit/merge behavior.

### 12.17 Planned Features

- Kinodynamic vehicle model.
- Speed limit per road segment.
- Randomized initial speed, including some vehicles above speed limit.
- Merge lanes on selected approaches.
- Merge-yield logic.
- Jerk/smoothness reward.
- Speed-limit reward/penalty.

### 12.18 Planned Policy Input Additions

- Speed limit value.
- Current speed-limit violation flag or margin.
- Merge lane availability.
- Distance to merge end.
- Nearby vehicles in target lane.
- Acceleration history or jerk estimate.

### 12.19 Planned Reward Additions

- Penalize speeding.
- Penalize high jerk.
- Reward smooth acceleration.
- Penalize unsafe merge.
- Reward yielding to immediate one or two vehicles during merge.

### 12.20 Engineering Risk

The current route-following model assumes each vehicle has a fixed route
centerline. Merge behavior may require dynamic path selection or explicit lane
change state. That should be designed carefully before coding.

## Week 8: Planned Parking Lanes and Pedestrians

### 12.21 Goal

Add static and dynamic obstacles around the intersection.

### 12.22 Planned Features

- Shoulder or parking lanes.
- Parked cars near straight and turning paths.
- Crosswalks.
- Pedestrian crossing behavior.

### 12.23 Planned Policy Input Additions

- Parked-car distance and relative position.
- Crosswalk occupancy.
- Pedestrian position, velocity, and crossing intent.
- Distance to crosswalk.

### 12.24 Planned Reward Additions

- Penalize close passes near parked vehicles.
- Penalize failure to yield to pedestrian.
- Penalize blocking crosswalk.

## Week 9: Planned Jaywalking and Lane Changes

### 12.25 Goal

Add more dynamic, less structured behavior.

### 12.26 Planned Features

- Jaywalking pedestrians.
- Vehicle lane changes.
- Unsafe lane-change detection.
- Lane changes inside intersection detection.

### 12.27 Planned Policy Input Additions

- Adjacent lane occupancy.
- Pedestrian off-crosswalk position.
- Time-to-collision estimate.
- Lane-change permission/constraint flags.

### 12.28 Planned Reward Additions

- Penalize risky lane changes.
- Penalize lane changes inside intersection.
- Reward safe deceleration near pedestrians.
- Penalize hard braking only when avoidable.

## Week 10: Planned Goal-Conditioned Behavior and Cut-In

### 12.29 Goal

Give each vehicle a goal and train goal-conditioned navigation.

### 12.30 Planned Features

- Per-vehicle goal.
- Goal progress reward.
- Necessary lane-change behavior.
- Late lane-change penalty.
- Cut-in scenarios when target lane is full.

### 12.31 Planned Policy Input Additions

- Goal route/lane encoding.
- Distance to goal.
- Required lane-change indicator.
- Target-lane gap estimate.

### 12.32 Planned Reward Additions

- Goal progress.
- Correct final lane/route.
- Penalize last-moment risky lane changes.
- Reward successful safe cut-in.

## Week 11: Planned Unprotected Turns, Stop Signs, Noise, and ROS Bag Format

### 12.33 Goal

Reduce idealized-simulator assumptions.

### 12.34 Planned Features

- Stop-sign-controlled intersections.
- Unprotected turns without traffic lights.
- Sensor noise.
- Occlusions.
- Dropouts.
- ROS bag compatible input/output format.

### 12.35 Planned Policy Input Additions

- Stop-sign distance.
- Stop-sign compliance state.
- Occlusion flags.
- Sensor confidence/noise estimates.

### 12.36 Engineering Risk

Noise and occlusion should not simply randomize observations without a clear
model. The simulator should define what is hidden, delayed, or corrupted and
how that maps to realistic perception limitations.

## Week 12: Planned Nissan Simulator Deployment

### 12.37 Goal

Deploy the trained policy to the Nissan simulator and reduce sim-to-sim gap.

### 12.38 Planned Work

- Adapter from current simulator observation format to Nissan simulator data.
- Policy export/loading path.
- Scenario matching between simulators.
- Sim-to-sim validation metrics.
- Final presentation.

### 12.39 Sim-to-Sim Gap Risks

Current simulator is lightweight and idealized. Differences may include:

- Vehicle dynamics.
- Coordinate frames.
- Time step.
- Road geometry.
- Traffic light encoding.
- Object detection/perception format.
- Collision/contact model.

## 13. Known Limitations

Current limitations:

- Vehicle model is still simple kinematic route-following, not full dynamics.
- PPO implementation is custom NumPy, not a mature RL library.
- No explicit jerk term yet.
- No speed limit yet.
- No merge lanes yet.
- No pedestrians or parked vehicles yet.
- No stop signs yet.
- No perception noise/occlusion yet.
- No ROS bag adapter yet.
- No Nissan simulator adapter yet.
- Training quality is not guaranteed by tests; tests validate functionality and
  numerical sanity, not final policy performance.

## 14. Recommended Manager Update Format

For each update, report in this structure:

1. What changed this week.
2. Policy inputs added or changed.
3. Policy outputs added or changed.
4. Reward terms added or changed.
5. Traffic rules modeled.
6. Assumptions made.
7. Bugs found and fixes.
8. Tests/validation run.
9. Current limitations.
10. Next planned work.

Example summary for current state:

- Implemented Week 6 turning rules and curriculum training.
- Policy input is a 22-dimensional per-car vector.
- Policy output is continuous acceleration and steering.
- Collision uses oriented rectangles, not point masses.
- Safe-distance penalty includes same-lane front gap and all-around proximity.
- Curriculum randomizes lanes, car counts, signal modes, right-on-red, routes,
  destination lanes, and seeds.
- Current limitation: no kinodynamics, speed limits, merge lanes, pedestrians,
  stop signs, or ROS/Nissan adapter yet.

## 15. Current Commands

Fixed-config training:

```bash
intersection-rl train --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on \
  --steps 100000 \
  --checkpoint checkpoints/week6_fixed.npz
```

Curriculum training:

```bash
intersection-rl train --curriculum \
  --curriculum-min-lanes 2 --curriculum-max-lanes 5 \
  --curriculum-min-cars 5 --curriculum-max-cars 64 \
  --steps 100000 \
  --checkpoint checkpoints/week6_curriculum.npz
```

Evaluation:

```bash
intersection-rl evaluate checkpoints/week6_curriculum_best.npz \
  --lanes 5 --cars 64 \
  --left-signal protected --right-on-red on \
  --episodes 100
```

Visual simulation:

```bash
intersection-rl simulate --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on
```

Test suite:

```bash
pytest
```
