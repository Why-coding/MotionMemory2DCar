from __future__ import annotations

import csv
from dataclasses import dataclass, replace
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.distributions import Normal

from intersection_rl.config import PPOConfig


class SharedActorCritic(nn.Module):
    """Shared PyTorch MLP with a Gaussian continuous-action policy."""

    min_log_std = -2.5
    max_log_std = -0.8

    def __init__(
        self,
        observation_size: int,
        hidden_size: int,
        action_size: int = 2,
        seed: int = 7,
    ) -> None:
        super().__init__()
        torch.manual_seed(seed)
        self.observation_size = observation_size
        self.hidden_size = hidden_size
        self.action_size = action_size
        self.policy_body = nn.Sequential(
            nn.Linear(observation_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh(),
        )
        self.policy_head = nn.Linear(hidden_size, action_size)
        self.value_head = nn.Linear(hidden_size, 1)
        self.log_std = nn.Parameter(torch.full((action_size,), -1.0))
        self._init_weights()

    def _init_weights(self) -> None:
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.orthogonal_(module.weight, gain=np.sqrt(2.0))
                nn.init.zeros_(module.bias)
        nn.init.orthogonal_(self.policy_head.weight, gain=0.01)
        nn.init.zeros_(self.policy_head.bias)
        with torch.no_grad():
            self.policy_head.bias[0] = 0.35
        nn.init.orthogonal_(self.value_head.weight, gain=1.0)
        nn.init.zeros_(self.value_head.bias)

    @property
    def device(self) -> torch.device:
        return next(self.parameters()).device

    def _tensor(self, array: np.ndarray) -> torch.Tensor:
        return torch.as_tensor(array, dtype=torch.float32, device=self.device)

    def _forward_tensor(self, observations: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        features = self.policy_body(observations)
        mean = torch.tanh(self.policy_head(features))
        values = self.value_head(features).squeeze(-1)
        return mean, values

    def forward(self, observations: np.ndarray) -> tuple[np.ndarray, np.ndarray, tuple[()]]:
        with torch.no_grad():
            mean, values = self._forward_tensor(self._tensor(observations))
        return mean.cpu().numpy(), values.cpu().numpy(), ()

    def distribution(self, observations: torch.Tensor) -> tuple[Normal, torch.Tensor, torch.Tensor]:
        mean, values = self._forward_tensor(observations)
        log_std = torch.clamp(self.log_std, self.min_log_std, self.max_log_std)
        std = torch.exp(log_std).expand_as(mean)
        return Normal(mean, std), mean, values

    def act(
        self,
        observations: np.ndarray,
        rng: np.random.Generator | None = None,
        deterministic: bool = False,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        del rng
        with torch.no_grad():
            obs = self._tensor(observations)
            dist, mean, values = self.distribution(obs)
            actions = mean if deterministic else dist.sample()
            actions = torch.clamp(actions, -1.0, 1.0)
            log_probs = dist.log_prob(actions).sum(dim=-1)
        return (
            actions.cpu().numpy().astype(np.float32),
            log_probs.cpu().numpy().astype(np.float32),
            values.cpu().numpy().astype(np.float32),
        )

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        state = {name: tensor.detach().cpu().numpy() for name, tensor in self.state_dict().items()}
        metadata = {
            "format": np.array("torch_state_npz"),
            "observation_size": np.array(self.observation_size),
            "hidden_size": np.array(self.hidden_size),
            "action_size": np.array(self.action_size),
        }
        np.savez(path, **state, **metadata)

    def load(self, path: str | Path) -> None:
        data = np.load(path, allow_pickle=False)
        keys = set(data.files)
        state = self.state_dict()
        if "policy_body.0.weight" in keys:
            loaded_state = dict(state)
            for name in state:
                if name not in keys:
                    continue
                source = torch.as_tensor(data[name], dtype=state[name].dtype)
                if source.shape == state[name].shape:
                    loaded_state[name] = source
                elif name == "policy_body.0.weight" and source.shape[0] == state[name].shape[0]:
                    target = state[name].clone()
                    width = min(source.shape[1], target.shape[1])
                    target.zero_()
                    target[:, :width] = source[:, :width]
                    loaded_state[name] = target
                else:
                    raise ValueError(
                        f"Checkpoint tensor {name} has incompatible shape {tuple(source.shape)}; "
                        f"expected {tuple(state[name].shape)}"
                    )
            self.load_state_dict(loaded_state)
            return
        old_keys = {"w1", "b1", "w2", "b2", "wp", "bp", "log_std", "wv", "bv"}
        if old_keys.issubset(keys):
            with torch.no_grad():
                old_w1 = torch.as_tensor(data["w1"].T, dtype=torch.float32)
                self.policy_body[0].weight.zero_()
                self.policy_body[0].weight[:, : old_w1.shape[1]].copy_(old_w1)
                self.policy_body[0].bias.copy_(torch.as_tensor(data["b1"], dtype=torch.float32))
                self.policy_body[2].weight.copy_(torch.as_tensor(data["w2"].T, dtype=torch.float32))
                self.policy_body[2].bias.copy_(torch.as_tensor(data["b2"], dtype=torch.float32))
                self.policy_head.weight.copy_(torch.as_tensor(data["wp"].T, dtype=torch.float32))
                self.policy_head.bias.copy_(torch.as_tensor(data["bp"], dtype=torch.float32))
                self.value_head.weight.copy_(torch.as_tensor(data["wv"].T, dtype=torch.float32))
                self.value_head.bias.copy_(torch.as_tensor(data["bv"], dtype=torch.float32))
                self.log_std.copy_(torch.as_tensor(data["log_std"], dtype=torch.float32))
            return
        raise ValueError(f"Unsupported checkpoint format: {path}")


@dataclass(slots=True)
class Rollout:
    observations: np.ndarray
    actions: np.ndarray
    log_probs: np.ndarray
    rewards: np.ndarray
    values: np.ndarray
    dones: np.ndarray
    masks: np.ndarray
    last_values: np.ndarray
    info_metrics: dict[str, float]

    def advantages_and_returns(
        self, gamma: float, gae_lambda: float
    ) -> tuple[np.ndarray, np.ndarray]:
        advantages = np.zeros_like(self.rewards)
        gae = np.zeros(self.rewards.shape[1], dtype=np.float32)
        for time_index in reversed(range(len(self.rewards))):
            next_values = (
                self.last_values
                if time_index == len(self.rewards) - 1
                else self.values[time_index + 1]
            )
            nonterminal = 1.0 - self.dones[time_index]
            delta = (
                self.rewards[time_index]
                + gamma * next_values * nonterminal
                - self.values[time_index]
            )
            gae = delta + gamma * gae_lambda * nonterminal * gae
            gae *= self.masks[time_index]
            advantages[time_index] = gae
        return advantages, advantages + self.values


class PPOTrainer:
    """PPO trainer using one shared continuous PyTorch policy for all vehicle slots."""

    def __init__(self, env, config: PPOConfig) -> None:
        self.env = env
        self.config = config
        self.rng = np.random.default_rng(config.seed)
        torch.manual_seed(config.seed)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = SharedActorCritic(
            env.OBSERVATION_SIZE,
            config.hidden_size,
            env.ACTION_SIZE,
            seed=config.seed,
        ).to(self.device)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=config.learning_rate)
        self.observation, self.info = env.reset(seed=config.seed)

    def collect_rollout(self) -> Rollout:
        storage: dict[str, list[np.ndarray]] = {
            key: []
            for key in (
                "observations",
                "actions",
                "log_probs",
                "rewards",
                "values",
                "dones",
                "masks",
            )
        }
        info_metrics = {
            "completed_clean": 0.0,
            "failed": 0.0,
            "collisions": 0.0,
            "proximity": 0.0,
            "proximity_events": 0.0,
            "red": 0.0,
            "yellow": 0.0,
            "closed_signal": 0.0,
            "left_yield": 0.0,
            "right_yield": 0.0,
            "right_lane": 0.0,
            "lane_drift": 0.0,
            "right_on_red_entries": 0.0,
            "safety_overrides": 0.0,
            "policy_samples": 0.0,
            "env_steps": 0.0,
            "unsafe_requests": 0.0,
            "timeout_failures": 0.0,
            "progress": 0.0,
            "safety_score": 0.0,
        }
        for _ in range(self.config.rollout_steps):
            actions, log_probs, values = self.model.act(self.observation)
            mask = self.info["active_mask"].copy()
            active_count = float(mask.sum())
            next_observation, rewards, terminated, truncated, next_info = self.env.step(actions)
            rewards = np.clip(rewards, -self.config.reward_clip, self.config.reward_clip)
            info_metrics["completed_clean"] += float(next_info.get("completed_delta", 0))
            info_metrics["failed"] += float(next_info.get("failed_delta", 0))
            info_metrics["collisions"] += float(next_info.get("collisions", 0))
            info_metrics["proximity"] += float(next_info.get("proximity_violations", 0))
            info_metrics["proximity_events"] += float(next_info.get("proximity_events", 0))
            info_metrics["red"] += float(next_info.get("red_light_violations", 0))
            info_metrics["yellow"] += float(next_info.get("yellow_light_violations", 0))
            info_metrics["closed_signal"] += float(next_info.get("closed_signal_violations", next_info.get("red_light_violations", 0)))
            info_metrics["left_yield"] += float(next_info.get("left_yield_violations", 0))
            info_metrics["right_yield"] += float(next_info.get("right_yield_violations", 0))
            info_metrics["right_lane"] += float(next_info.get("right_lane_violations", 0))
            info_metrics["lane_drift"] += float(next_info.get("lane_drift_warnings", 0))
            info_metrics["right_on_red_entries"] += float(next_info.get("right_on_red_entries", 0))
            info_metrics["safety_overrides"] += float(next_info.get("safety_overrides", 0))
            info_metrics["policy_samples"] += active_count
            info_metrics["env_steps"] += 1.0
            info_metrics["unsafe_requests"] += float(next_info.get("unsafe_requests", 0))
            info_metrics["timeout_failures"] += float(next_info.get("timeout_failures", 0))
            info_metrics["progress"] += float(next_info.get("progress_delta", 0.0))
            info_metrics["safety_score"] += float(next_info.get("safety_score", 0.0))
            done = terminated or truncated
            storage["observations"].append(self.observation.copy())
            storage["actions"].append(actions)
            storage["log_probs"].append(log_probs)
            storage["rewards"].append(rewards)
            storage["values"].append(values)
            storage["dones"].append(np.full_like(rewards, float(done)))
            storage["masks"].append(mask)
            self.observation, self.info = next_observation, next_info
            if done:
                self.observation, self.info = self.env.reset()

        _, last_values, _ = self.model.forward(self.observation)
        arrays = {key: np.asarray(value) for key, value in storage.items()}
        return Rollout(**arrays, last_values=last_values, info_metrics=info_metrics)

    def update(self, rollout: Rollout) -> dict[str, float]:
        advantages, returns = rollout.advantages_and_returns(
            self.config.gamma, self.config.gae_lambda
        )
        active = rollout.masks.reshape(-1).astype(bool)
        observations = rollout.observations.reshape(-1, rollout.observations.shape[-1])[active]
        actions = rollout.actions.reshape(-1, rollout.actions.shape[-1])[active]
        old_log_probs = rollout.log_probs.reshape(-1)[active]
        advantages = advantages.reshape(-1)[active]
        returns = returns.reshape(-1)[active]
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        obs_t = torch.as_tensor(observations, dtype=torch.float32, device=self.device)
        act_t = torch.as_tensor(actions, dtype=torch.float32, device=self.device)
        old_log_t = torch.as_tensor(old_log_probs, dtype=torch.float32, device=self.device)
        adv_t = torch.as_tensor(advantages, dtype=torch.float32, device=self.device)
        ret_t = torch.as_tensor(returns, dtype=torch.float32, device=self.device)

        indices = np.arange(len(actions))
        metrics: dict[str, float] = {}
        update_count = 0
        stop_update = False
        for _ in range(self.config.update_epochs):
            self.rng.shuffle(indices)
            for start in range(0, len(indices), self.config.minibatch_size):
                batch_np = indices[start : start + self.config.minibatch_size]
                batch = torch.as_tensor(batch_np, dtype=torch.long, device=self.device)
                dist, _, values = self.model.distribution(obs_t[batch])
                log_probs = dist.log_prob(act_t[batch]).sum(dim=-1)
                entropy = dist.entropy().sum(dim=-1).mean()
                ratio = torch.exp(log_probs - old_log_t[batch])
                unclipped = ratio * adv_t[batch]
                clipped = torch.clamp(
                    ratio,
                    1.0 - self.config.clip_ratio,
                    1.0 + self.config.clip_ratio,
                ) * adv_t[batch]
                policy_loss = -torch.min(unclipped, clipped).mean()
                value_loss = 0.5 * torch.mean((values - ret_t[batch]) ** 2)
                loss = (
                    policy_loss
                    + self.config.value_coefficient * value_loss
                    - self.config.entropy_coefficient * entropy
                )
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
                self.optimizer.step()
                with torch.no_grad():
                    self.model.log_std.clamp_(
                        self.model.min_log_std,
                        self.model.max_log_std,
                    )
                approximate_kl = torch.mean(old_log_t[batch] - log_probs).item()
                batch_metrics = {
                    "policy_loss": float(policy_loss.item()),
                    "value_loss": float(value_loss.item()),
                    "entropy": float(entropy.item()),
                    "approximate_kl": float(approximate_kl),
                }
                for key, value in batch_metrics.items():
                    metrics[key] = metrics.get(key, 0.0) + value
                update_count += 1
                if self.config.target_kl > 0.0 and approximate_kl > self.config.target_kl:
                    stop_update = True
                    break
            if stop_update:
                break
        metrics = {key: value / max(update_count, 1) for key, value in metrics.items()}
        active_rewards = rollout.rewards[rollout.masks.astype(bool)]
        metrics["rollout_mean_reward"] = float(active_rewards.mean())
        metrics.update(rollout.info_metrics)
        return metrics

    def _validation_score(self, metrics: dict[str, float]) -> float:
        episodes = max(metrics.get("episodes", float(self.config.validation_episodes)), 1.0)
        cars = max(metrics.get("cars", float(self.config.validation_cars or self.env.config.max_cars)), 1.0)
        total_vehicles = episodes * cars
        completed_pct = 100.0 * metrics.get("completed_clean", 0.0) / total_vehicles
        failed_pct = 100.0 * metrics.get("failed", 0.0) / total_vehicles
        collisions_per_ep = metrics.get("collisions", 0.0) / episodes
        red_per_ep = metrics.get("closed_signal", metrics.get("red", 0.0)) / episodes
        proximity_events_per_ep = metrics.get("proximity_events", 0.0) / episodes
        yield_per_ep = (metrics.get("left_yield", 0.0) + metrics.get("right_yield", 0.0)) / episodes
        unsafe_pct = 100.0 * metrics.get("unsafe_requests", 0.0) / max(metrics.get("active_action_samples", 0.0), 1.0)

        completion_gap = max(0.0, self.config.validation_target_completed_pct - completed_pct)
        collision_excess = max(0.0, collisions_per_ep - self.config.validation_target_collisions_per_ep)
        red_excess = max(0.0, red_per_ep - self.config.validation_target_red_per_ep)
        proximity_excess = max(0.0, proximity_events_per_ep - self.config.validation_target_proximity_events_per_ep)

        return float(
            120.0 * completed_pct
            - 80.0 * failed_pct
            - 1400.0 * completion_gap
            - 1200.0 * collision_excess
            - 900.0 * red_excess
            - 260.0 * proximity_excess
            - 180.0 * collisions_per_ep
            - 90.0 * red_per_ep
            - 22.0 * proximity_events_per_ep
            - 160.0 * yield_per_ep
            - 35.0 * unsafe_pct
            + 0.15 * metrics.get("progress", 0.0) / episodes
        )

    def _stage3_validation_shape(self) -> tuple[int, int]:
        episode = self.env.episode_resets
        env_config = self.env.config
        if episode < env_config.stage3_phase1_episodes:
            return 2, 8
        if episode < env_config.stage3_phase2_episodes:
            return 2, 10
        if episode < env_config.stage3_phase3_episodes:
            return 2, 12
        if episode < env_config.stage3_phase4_episodes:
            return env_config.curriculum_max_lanes, 10
        if episode < env_config.stage3_phase5_episodes:
            return env_config.curriculum_max_lanes, 12
        return env_config.curriculum_max_lanes, 14

    def run_validation(
        self,
        update_index: int,
        safety_shield: bool | None = None,
    ) -> dict[str, float]:
        from intersection_rl.env import IntersectionEnv

        cars = self.config.validation_cars or self.env.config.max_cars
        lanes = self.config.validation_lanes or self.env.config.lanes_per_approach
        allow_right_on_red = self.config.validation_allow_right_on_red
        if (
            self.env.config.curriculum_stage == 3
            and self.env.config.curriculum_progression_enabled
        ):
            lanes, cars = self._stage3_validation_shape()
            allow_right_on_red = True
        shield_enabled = self.config.validation_safety_shield if safety_shield is None else safety_shield
        validation_config = replace(
            self.env.config,
            min_cars=cars,
            max_cars=cars,
            lanes_per_approach=lanes,
            curriculum_enabled=False,
            curriculum_progression_enabled=False,
            protected_left_signal=self.config.validation_protected_left_signal,
            allow_right_on_red=allow_right_on_red,
            safety_filter_enabled=shield_enabled,
            safety_filter_dropout_rate=0.0,
            intersection_reservation_enabled=shield_enabled,
        )
        env = IntersectionEnv(validation_config)
        metrics = {
            "completed_clean": 0.0,
            "failed": 0.0,
            "collisions": 0.0,
            "proximity": 0.0,
            "proximity_events": 0.0,
            "red": 0.0,
            "yellow": 0.0,
            "closed_signal": 0.0,
            "left_yield": 0.0,
            "right_yield": 0.0,
            "safety_overrides": 0.0,
            "unsafe_requests": 0.0,
            "progress": 0.0,
            "env_steps": 0.0,
            "active_action_samples": 0.0,
            "episodes": float(self.config.validation_episodes),
            "cars": float(cars),
        }
        try:
            for episode in range(self.config.validation_episodes):
                observation, info = env.reset(seed=self.config.seed + update_index * 1000 + episode)
                done = False
                while not done:
                    actions, _, _ = self.model.act(observation, deterministic=True)
                    observation, _, terminated, truncated, info = env.step(actions)
                    metrics["collisions"] += float(info.get("collisions", 0))
                    metrics["proximity"] += float(info.get("proximity_violations", 0))
                    metrics["proximity_events"] += float(info.get("proximity_events", 0))
                    metrics["red"] += float(info.get("red_light_violations", 0))
                    metrics["yellow"] += float(info.get("yellow_light_violations", 0))
                    metrics["closed_signal"] += float(info.get("closed_signal_violations", info.get("red_light_violations", 0)))
                    metrics["left_yield"] += float(info.get("left_yield_violations", 0))
                    metrics["right_yield"] += float(info.get("right_yield_violations", 0))
                    metrics["safety_overrides"] += float(info.get("safety_overrides", 0))
                    metrics["unsafe_requests"] += float(info.get("unsafe_requests", 0))
                    metrics["progress"] += float(info.get("progress_delta", 0.0))
                    metrics["env_steps"] += 1.0
                    metrics["active_action_samples"] += float(info.get("active_mask", np.zeros(cars)).sum())
                    done = terminated or truncated
                metrics["completed_clean"] += float(info.get("completed_clean", 0))
                metrics["failed"] += float(info.get("failed_vehicles", 0))
        finally:
            env.close()
        metrics["validation_score"] = self._validation_score(metrics)
        return metrics

    def train(self, checkpoint_path: str | Path) -> SharedActorCritic:
        checkpoint_path = Path(checkpoint_path)
        metrics_path = checkpoint_path.with_name(f"{checkpoint_path.stem}_train_metrics.csv")
        metrics_fields = [
            "update", "steps", "rollout_mean_reward", "policy_loss", "value_loss",
            "entropy", "approximate_kl", "safety_score", "validation_score_off",
            "validation_score_on", "stale_validations", "best_validation_score",
            "completed_clean", "failed", "collisions", "proximity_vehicles",
            "proximity_events", "red", "yellow", "closed_signal", "left_yield", "right_yield", "lane_drift",
            "progress", "safety_overrides", "unsafe_requests", "policy_samples",
            "env_steps", "vehicle_hours", "saved_best", "early_stop",
        ]
        metrics_path.parent.mkdir(parents=True, exist_ok=True)
        with metrics_path.open("w", newline="") as metrics_file:
            csv.DictWriter(metrics_file, fieldnames=metrics_fields).writeheader()
        completed_steps = 0
        total_policy_samples = 0.0
        total_vehicle_hours = 0.0
        update_index = 0
        best_safety_score = -float("inf")
        stale_validations = 0
        validation_controls_best = self.config.validation_interval_updates > 0
        while completed_steps < self.config.total_steps:
            rollout = self.collect_rollout()
            metrics = self.update(rollout)
            completed_steps += self.config.rollout_steps
            total_policy_samples += metrics.get("policy_samples", 0.0)
            total_vehicle_hours += (
                metrics.get("policy_samples", 0.0) * self.env.config.dt / 3600.0
            )
            update_index += 1
            validation_metrics = None
            validation_shield_metrics = None
            selection_score = metrics["safety_score"]
            if self.config.validation_interval_updates > 0 and (
                update_index % self.config.validation_interval_updates == 0
            ):
                validation_metrics = self.run_validation(
                    update_index,
                    safety_shield=self.config.validation_safety_shield,
                )
                selection_score = validation_metrics["validation_score"]
                if self.config.validation_compare_safety_shield:
                    validation_shield_metrics = self.run_validation(
                        update_index,
                        safety_shield=True,
                    )
            should_consider_best = validation_metrics is not None or not validation_controls_best
            stop_training = False
            saved_best = False
            if should_consider_best:
                improved = selection_score > best_safety_score + self.config.validation_min_delta
                if improved:
                    best_safety_score = selection_score
                    stale_validations = 0
                    best_path = checkpoint_path.with_name(
                        f"{checkpoint_path.stem}_best{checkpoint_path.suffix}"
                    )
                    self.model.save(best_path)
                    saved_best = True
                elif validation_metrics is not None and self.config.validation_patience > 0:
                    stale_validations += 1
                    stop_training = stale_validations >= self.config.validation_patience
            if self.config.checkpoint_interval_updates > 0 and (
                update_index % self.config.checkpoint_interval_updates == 0
            ):
                interim_path = checkpoint_path.with_name(
                    f"{checkpoint_path.stem}_update_{update_index:04d}{checkpoint_path.suffix}"
                )
                self.model.save(interim_path)
            validation_text = ""
            if validation_metrics is not None:
                validation_text = f"val_off={validation_metrics['validation_score']:+.1f} stale={stale_validations} "
            if validation_shield_metrics is not None:
                validation_text += f"val_on={validation_shield_metrics['validation_score']:+.1f} "
            print(
                f"update={update_index:04d} steps={completed_steps:07d} "
                f"reward={metrics['rollout_mean_reward']:+.4f} "
                f"policy={metrics['policy_loss']:+.4f} "
                f"value={metrics['value_loss']:.4f} "
                f"entropy={metrics['entropy']:.3f} "
                f"kl={metrics['approximate_kl']:+.5f} "
                f"score={metrics['safety_score']:+.1f} "
                f"{validation_text}"
                f"clean={metrics['completed_clean']:.0f} "
                f"failed={metrics['failed']:.0f} "
                f"coll={metrics['collisions']:.0f} "
                f"prox={metrics['proximity']:.0f}/{metrics.get('proximity_events', 0):.0f} "
                f"red={metrics['red']:.0f} "
                f"yellow={metrics.get('yellow', 0):.0f} "
                f"closed={metrics.get('closed_signal', metrics['red']):.0f} "
                f"yield={metrics['left_yield'] + metrics['right_yield']:.0f} "
                f"drift={metrics.get('lane_drift', 0):.0f} "
                f"progress={metrics['progress']:.1f} "
                f"shield={metrics['safety_overrides']:.0f} "
                f"samples={metrics.get('policy_samples', 0):.0f} "
                f"veh_hr={metrics.get('policy_samples', 0) * self.env.config.dt / 3600.0:.3f}"
            )
            row = {
                "update": update_index,
                "steps": completed_steps,
                "rollout_mean_reward": metrics.get("rollout_mean_reward", 0.0),
                "policy_loss": metrics.get("policy_loss", 0.0),
                "value_loss": metrics.get("value_loss", 0.0),
                "entropy": metrics.get("entropy", 0.0),
                "approximate_kl": metrics.get("approximate_kl", 0.0),
                "safety_score": metrics.get("safety_score", 0.0),
                "validation_score_off": validation_metrics["validation_score"] if validation_metrics is not None else "",
                "validation_score_on": validation_shield_metrics["validation_score"] if validation_shield_metrics is not None else "",
                "stale_validations": stale_validations,
                "best_validation_score": best_safety_score,
                "completed_clean": metrics.get("completed_clean", 0.0),
                "failed": metrics.get("failed", 0.0),
                "collisions": metrics.get("collisions", 0.0),
                "proximity_vehicles": metrics.get("proximity", 0.0),
                "proximity_events": metrics.get("proximity_events", 0.0),
                "red": metrics.get("red", 0.0),
                "yellow": metrics.get("yellow", 0.0),
                "closed_signal": metrics.get("closed_signal", metrics.get("red", 0.0)),
                "left_yield": metrics.get("left_yield", 0.0),
                "right_yield": metrics.get("right_yield", 0.0),
                "lane_drift": metrics.get("lane_drift", 0.0),
                "progress": metrics.get("progress", 0.0),
                "safety_overrides": metrics.get("safety_overrides", 0.0),
                "unsafe_requests": metrics.get("unsafe_requests", 0.0),
                "policy_samples": metrics.get("policy_samples", 0.0),
                "env_steps": metrics.get("env_steps", 0.0),
                "vehicle_hours": metrics.get("policy_samples", 0.0) * self.env.config.dt / 3600.0,
                "saved_best": int(saved_best),
                "early_stop": int(stop_training),
            }
            with metrics_path.open("a", newline="") as metrics_file:
                csv.DictWriter(metrics_file, fieldnames=metrics_fields).writerow(row)
            if stop_training:
                print(
                    f"early_stop update={update_index:04d} best_val={best_safety_score:+.1f} "
                    f"patience={self.config.validation_patience}"
                )
                break
        self.model.save(checkpoint_path)
        print(
            f"training_summary env_steps={completed_steps} "
            f"policy_samples={total_policy_samples:.0f} "
            f"simulated_env_hours={completed_steps * self.env.config.dt / 3600.0:.3f} "
            f"vehicle_hours={total_vehicle_hours:.3f}"
        )
        return self.model
