# Intersection RL No-Shield Curriculum Package

This package contains the latest no-shield curriculum code, selected checkpoints, evaluation results, reports, and Stage 1/Stage 2 graph assets.

Start with `NO_SHIELD_CURRICULUM_REPORT.md` for the current training history, bugs/fixes, commands, metrics, and interpretation.
