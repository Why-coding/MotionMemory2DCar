#!/usr/bin/env python3
from __future__ import annotations

import csv
import math
from pathlib import Path

OUT = Path("graphs/no_shield_stage1_stage2")
OUT.mkdir(parents=True, exist_ok=True)

EVAL_FILES = [
    ("Stage 1A 8-12 cars", Path("results/no_shield_2l8to12_queue_reward_stage1_60s_v1_eval_50ep.csv")),
    ("Stage 1B v2 24-32 cars", Path("results/no_shield_2l24to32_queue_reward_stage1_120s_v2_eval_50ep.csv")),
    ("Stage 1B v3 dense-stop 24-32 cars", Path("results/no_shield_2l24to32_closed_signal_stage1b_120s_v3_eval_50ep.csv")),
]

TRAIN_FILES = [
    ("Stage 1A", Path("checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_train_metrics.csv")),
    ("Stage 1B v2", Path("checkpoints/no_shield_2l24to32_queue_reward_stage1_120s_v2_train_metrics.csv")),
    ("Stage 1B v3", Path("checkpoints/no_shield_2l24to32_closed_signal_stage1b_120s_v3_train_metrics.csv")),
]

COLORS = ["#31688e", "#35b779", "#f28e2b", "#6f4aa8", "#b5bd00", "#8c8c8c"]

def esc(value: object) -> str:
    return str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as fp:
        return list(csv.DictReader(fp))

def val(row: dict[str, str], key: str, default: float = 0.0) -> float:
    raw = row.get(key, "")
    if raw == "":
        return default
    try:
        return float(raw)
    except ValueError:
        return default

def latest_eval_rows() -> list[tuple[str, dict[str, str]]]:
    data = []
    for label, path in EVAL_FILES:
        csv_rows = rows(path)
        if csv_rows:
            data.append((label, csv_rows[-1]))
    return data

def write_eval_summary(data: list[tuple[str, dict[str, str]]]) -> None:
    metrics = [
        ("completed_pct", "Completed %", "%", 100.0),
        ("failed_pct", "Failed %", "%", 100.0),
        ("incomplete_pct", "Incomplete %", "%", 100.0),
        ("collisions_per_ep", "Collisions / ep", "", None),
        ("red_violations_per_ep", "True red / ep", "", None),
        ("yellow_violations_per_ep", "Yellow / ep", "", None),
        ("closed_signal_violations_per_ep", "Closed signal / ep", "", None),
        ("proximity_events_per_ep", "Proximity events / ep", "", None),
    ]
    width, left, top, row_h, group_gap, chart_w = 1180, 310, 74, 34, 20, 710
    height = top + len(data) * (len(metrics) * row_h + group_gap) + 60
    parts = [
        f"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{width}\" height=\"{height}\" viewBox=\"0 0 {width} {height}\">",
        "<rect width=\"100%\" height=\"100%\" fill=\"#ffffff\"/>",
        f"<text x=\"{width/2}\" y=\"34\" text-anchor=\"middle\" font-family=\"Arial\" font-size=\"24\" font-weight=\"700\">No-Shield Stage 1/2 Evaluation Summary</text>",
    ]
    y = top
    for label, row in data:
        parts.append(f"<text x=\"24\" y=\"{y+18}\" font-family=\"Arial\" font-size=\"16\" font-weight=\"700\">{esc(label)}</text>")
        y += 26
        for i, (key, name, suffix, fixed_max) in enumerate(metrics):
            value = val(row, key, val(row, "red_violations_per_ep") if key == "closed_signal_violations_per_ep" else 0.0)
            if fixed_max is None:
                maximum = max(2.0, max(val(r, key, val(r, "red_violations_per_ep") if key == "closed_signal_violations_per_ep" else 0.0) for _, r in data) * 1.10)
            else:
                maximum = fixed_max
            bar_w = chart_w * value / maximum if maximum > 0 else 0.0
            color = COLORS[i % len(COLORS)]
            parts.append(f"<text x=\"48\" y=\"{y+20}\" font-family=\"Arial\" font-size=\"13\">{esc(name)}</text>")
            parts.append(f"<rect x=\"{left}\" y=\"{y+6}\" width=\"{chart_w}\" height=\"20\" fill=\"#edf1f4\"/>")
            parts.append(f"<rect x=\"{left}\" y=\"{y+6}\" width=\"{bar_w:.1f}\" height=\"20\" fill=\"{color}\"/>")
            parts.append(f"<text x=\"{left+bar_w+8:.1f}\" y=\"{y+21}\" font-family=\"Arial\" font-size=\"12\">{value:.2f}{suffix}</text>")
            y += row_h
        y += group_gap
    parts.append("</svg>")
    (OUT / "stage1_stage2_eval_summary.svg").write_text("\\n".join(parts))

def write_outcome_matrix(data: list[tuple[str, dict[str, str]]]) -> None:
    metrics = [
        ("completed_vehicles", "Completed clean", "completed_pct"),
        ("safety_failed_vehicles", "Safety failed", "safety_failed_pct"),
        ("timeout_incomplete_vehicles", "Timeout incomplete", "timeout_incomplete_pct"),
        ("stuck_timeout_vehicles", "Stuck timeout", "stuck_timeout_pct"),
        ("unfinished_timeout_vehicles", "Unfinished timeout", "unfinished_timeout_pct"),
        ("true_incomplete_vehicles", "True incomplete", "incomplete_pct"),
    ]
    width, left, top, row_h, group_gap, chart_w = 1180, 310, 74, 34, 20, 710
    height = top + len(data) * (len(metrics) * row_h + group_gap) + 60
    max_count = max(max(val(r, key) for key, _, _ in metrics) for _, r in data)
    parts = [
        f"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{width}\" height=\"{height}\" viewBox=\"0 0 {width} {height}\">",
        "<rect width=\"100%\" height=\"100%\" fill=\"#ffffff\"/>",
        f"<text x=\"{width/2}\" y=\"34\" text-anchor=\"middle\" font-family=\"Arial\" font-size=\"24\" font-weight=\"700\">No-Shield Stage 1/2 Outcome Matrix</text>",
    ]
    y = top
    for label, row in data:
        total = max(val(row, "total_vehicles", val(row, "episodes") * val(row, "mean_spawned")), 1.0)
        parts.append(f"<text x=\"24\" y=\"{y+18}\" font-family=\"Arial\" font-size=\"16\" font-weight=\"700\">{esc(label)} ({total:.0f} vehicles)</text>")
        y += 26
        for i, (key, name, pct_key) in enumerate(metrics):
            count = val(row, key)
            pct = val(row, pct_key, 100.0 * count / total)
            bar_w = chart_w * count / max_count if max_count > 0 else 0.0
            color = COLORS[i % len(COLORS)]
            parts.append(f"<text x=\"48\" y=\"{y+20}\" font-family=\"Arial\" font-size=\"13\">{esc(name)}</text>")
            parts.append(f"<rect x=\"{left}\" y=\"{y+6}\" width=\"{chart_w}\" height=\"20\" fill=\"#edf1f4\"/>")
            parts.append(f"<rect x=\"{left}\" y=\"{y+6}\" width=\"{bar_w:.1f}\" height=\"20\" fill=\"{color}\"/>")
            parts.append(f"<text x=\"{left+bar_w+8:.1f}\" y=\"{y+21}\" font-family=\"Arial\" font-size=\"12\">{count:.0f} ({pct:.2f}%)</text>")
            y += row_h
        y += group_gap
    parts.append("</svg>")
    (OUT / "stage1_stage2_outcome_matrix.svg").write_text("\\n".join(parts))

def write_line(path: Path, title: str, key: str) -> None:
    series = []
    for name, source in TRAIN_FILES:
        pts = [(val(r, "update"), val(r, key, float("nan"))) for r in rows(source) if r.get(key, "") != ""]
        if pts:
            series.append((name, pts))
    all_points = [p for _, pts in series for p in pts if math.isfinite(p[1])]
    width, height = 1180, 560
    left, right, top, bottom = 80, 40, 70, 70
    chart_w, chart_h = width - left - right, height - top - bottom
    min_x, max_x = min(x for x, _ in all_points), max(x for x, _ in all_points)
    min_y, max_y = min(y for _, y in all_points), max(y for _, y in all_points)
    if min_y == max_y:
        min_y -= 1.0
        max_y += 1.0
    pad = (max_y - min_y) * 0.08
    min_y -= pad
    max_y += pad
    def sx(x: float) -> float:
        return left + (x - min_x) / (max_x - min_x) * chart_w if max_x > min_x else left
    def sy(y: float) -> float:
        return top + chart_h - (y - min_y) / (max_y - min_y) * chart_h
    parts = [
        f"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{width}\" height=\"{height}\" viewBox=\"0 0 {width} {height}\">",
        "<rect width=\"100%\" height=\"100%\" fill=\"#ffffff\"/>",
        f"<text x=\"{width/2}\" y=\"34\" text-anchor=\"middle\" font-family=\"Arial\" font-size=\"24\" font-weight=\"700\">{esc(title)}</text>",
        f"<rect x=\"{left}\" y=\"{top}\" width=\"{chart_w}\" height=\"{chart_h}\" fill=\"#f8fafb\" stroke=\"#c8d0d8\"/>",
    ]
    for i in range(6):
        y_value = min_y + (max_y - min_y) * i / 5
        y = sy(y_value)
        parts.append(f"<line x1=\"{left}\" y1=\"{y:.1f}\" x2=\"{left+chart_w}\" y2=\"{y:.1f}\" stroke=\"#e1e7ec\"/>")
        parts.append(f"<text x=\"{left-8}\" y=\"{y+4:.1f}\" text-anchor=\"end\" font-family=\"Arial\" font-size=\"11\">{y_value:.1f}</text>")
    for i, (name, pts) in enumerate(series):
        color = COLORS[i % len(COLORS)]
        coords = " ".join(f"{sx(x):.1f},{sy(y):.1f}" for x, y in pts if math.isfinite(y))
        parts.append(f"<polyline points=\"{coords}\" fill=\"none\" stroke=\"{color}\" stroke-width=\"2.5\"/>")
        lx = left + 20 + i * 220
        parts.append(f"<rect x=\"{lx}\" y=\"{height-42}\" width=\"18\" height=\"12\" fill=\"{color}\"/>")
        parts.append(f"<text x=\"{lx+24}\" y=\"{height-31}\" font-family=\"Arial\" font-size=\"13\">{esc(name)}</text>")
    parts.append(f"<text x=\"{width/2}\" y=\"{height-12}\" text-anchor=\"middle\" font-family=\"Arial\" font-size=\"12\">Update</text>")
    parts.append("</svg>")
    path.write_text("\\n".join(parts))

def main() -> None:
    data = latest_eval_rows()
    write_eval_summary(data)
    write_outcome_matrix(data)
    write_line(OUT / "stage1_stage2_training_validation_scores.svg", "Stage 1/2 Training Validation Scores", "validation_score_off")
    write_line(OUT / "stage1_stage2_training_safety_scores.svg", "Stage 1/2 Training Safety Scores", "safety_score")
    write_line(OUT / "stage1_stage2_training_closed_signal.svg", "Stage 1/2 Training Closed-Signal Counts", "closed_signal")
    for graph in sorted(OUT.glob("*.svg")):
        print(graph)

if __name__ == "__main__":
    main()
