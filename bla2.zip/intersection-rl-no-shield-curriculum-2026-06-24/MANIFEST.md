# Package Manifest

Package: intersection-rl-no-shield-curriculum-2026-06-24

Updated contents:

- Latest source code: `intersection_rl/`
- Training/evaluation scripts: `scripts/`
- Tests: `tests/`
- Reports: `README.md`, `REPORT.md`, `NO_SHIELD_RL_REPORT.md`, `NO_SHIELD_CURRICULUM_REPORT.md`
- Graphs: `graphs/no_shield_stage1_stage2/`
- Selected checkpoints and metrics:
  - Stage 1A: `checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_best.npz`
  - Stage 1A metrics: `checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_train_metrics.csv`
  - Stage 1B v2: `checkpoints/no_shield_2l24to32_queue_reward_stage1_120s_v2_best.npz`
  - Stage 1B v2 metrics: `checkpoints/no_shield_2l24to32_queue_reward_stage1_120s_v2_train_metrics.csv`
  - Stage 1B v3: `checkpoints/no_shield_2l24to32_closed_signal_stage1b_120s_v3_best.npz`
  - Stage 1B v3 metrics: `checkpoints/no_shield_2l24to32_closed_signal_stage1b_120s_v3_train_metrics.csv`
- Evaluation CSVs:
  - `results/no_shield_2l8to12_queue_reward_stage1_60s_v1_eval_50ep.csv`
  - `results/no_shield_2l24to32_queue_reward_stage1_120s_v2_eval_50ep.csv`
  - `results/no_shield_2l24to32_closed_signal_stage1b_120s_v3_eval_50ep.csv`

New graph files:

- `graphs/no_shield_stage1_stage2/stage1_stage2_eval_summary.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_outcome_matrix.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_validation_scores.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_safety_scores.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_closed_signal.svg`

Latest verified test status: `64 passed, 1 warning`.
