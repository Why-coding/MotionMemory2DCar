# Intersection RL Engineering Report

## 1. Executive Summary

This project builds a lightweight four-way intersection simulator and trains a
shared reinforcement-learning policy for autonomous-driving behavior inside that
simulator. The current implementation covers the Week 5 and Week 6 milestones
from the project plan.

The simulator currently supports:

- One to five incoming lanes per approach.
- Four-way traffic-light-controlled intersection.
- Protected left-turn signal mode or permissive/yielding left-turn mode.
- Right turns on green.
- Optional right turn on red after yielding.
- Right-turn enforcement from the rightmost lane.
- Random outgoing destination lane assignment.
- Continuous acceleration and continuous steering actions.
- Oriented-rectangle collision detection using vehicle length, width, and heading.
- Proximity penalties when cars are too close but not yet overlapping.
- Curriculum training across randomized lane counts, car counts, signal modes,
  right-on-red settings, route choices, destination lanes, and seeds.
- PPO training with final, best, and intermediate checkpoint saving.

The current codebase uses `numpy`, `gymnasium`, `pygame`, and PyTorch. The simulator remains lightweight and local, while PPO training now uses PyTorch autograd, distributions, and Adam optimization instead of the earlier hand-written NumPy backpropagation path. Checkpoints are still stored as `.npz` files for simple packaging.

## 2. Project Goals

The project goal is to create an intersection simulator and train an RL policy
that can learn traffic-rule-compliant behavior. The simulator is built in stages
so that complexity is added only after the policy and environment interface are
understood.

The high-level goals are:

- Build a controllable intersection simulator.
- Model cars, lanes, routes, stop lines, traffic lights, and interactions.
- Define policy observations and actions explicitly.
- Train a shared policy using PPO.
- Add traffic complexity week by week.
- Keep code modular enough to extend toward later project phases such as
  speed limits, merging, pedestrians, stop signs, noise, ROS bag compatibility,
  and simulator deployment.

## 3. Repository Structure

| File | Responsibility |
| --- | --- |
| `intersection_rl/config.py` | Environment and PPO configuration dataclasses. |
| `intersection_rl/env.py` | Main Gymnasium-compatible simulator environment. |
| `intersection_rl/geometry.py` | Road, lane, route, and polyline geometry helpers. |
| `intersection_rl/vehicle.py` | Vehicle state and kinematic update model. |
| `intersection_rl/ppo.py` | Shared Gaussian actor-critic PPO implementation. |
| `intersection_rl/cli.py` | Command-line interface for simulation, training, and evaluation. |
| `intersection_rl/rendering.py` | Pygame renderer for visual simulation. |
| `tests/` | Regression tests for geometry, environment behavior, and PPO numerics. |
| `README.md` | User-facing setup, Docker, and command reference. |
| `REPORT.md` | Formal engineering report and design record. |
| `Dockerfile`, `compose.yaml` | Container execution support. |

## 4. Current Technical Status

Current milestone: Week 6 complete.

Implemented:

- Week 5 base simulator and PPO loop.
- Week 6 lane scaling, turn-signal logic, right-on-red, and lane-following
  behavior.
- Curriculum training across multiple configurations.
- Continuous action policy.
- Rectangle-based collision and proximity penalty.
- Docker packaging.

Not yet implemented:

- Week 7 kinodynamic vehicle model.
- Speed limits and speed-limit rewards.
- Merge lanes and merge-yield behavior.
- Pedestrians, parked vehicles, jaywalking, stop signs, occlusion, ROS bag
  adapter, Nissan simulator deployment.

## 5. Simulator Design

### 5.1 Intersection Layout

The simulator represents a four-way intersection with approaches:

- North (`N`)
- East (`E`)
- South (`S`)
- West (`W`)

Each approach can have one to five incoming lanes. The road geometry uses a
centerline representation for each route. A route is represented by a `Polyline`
object, and each vehicle tracks progress along that polyline.

The route types are:

- `left`
- `straight`
- `right`

### 5.2 Lane Convention

Lanes are indexed from `0` to `lanes_per_approach - 1`.

Current lane-use rules:

- If there is one lane, it can serve left, straight, or right movements.
- Lane `0` is the left/straight lane.
- The rightmost lane is the straight/right lane.
- Intermediate lanes are straight-only.
- Right turns are legal only from the rightmost lane.

This rule was chosen because it matches the Week 6 project requirement for
rightmost-lane right turns while keeping route generation simple and explicit.

### 5.3 Destination Lane Assignment

Each vehicle receives a random valid outgoing destination lane. This was added
because training only one fixed lane-to-lane route would not teach a general
route-following policy.

Rationale:

- If every straight vehicle always exits into the same lane, the policy can
  overfit to one centerline.
- Random destination lanes force the observation to include route and target
  lane information.
- The lateral steering action and lane-centering reward give PPO a way to learn
  lane-following behavior.

### 5.4 Stop Lines

Stop lines are encoded in route geometry as the second route point. Each vehicle
stores `stop_progress`, which is the path-progress value at the stop line.

The policy does not receive raw world coordinates of the stop line. Instead, it
receives normalized distance to the stop line. This is more compact and easier
for a shared policy to learn from across approaches.

### 5.5 Vehicle Model

The current vehicle model is kinematic, not kinodynamic.

Vehicle state includes:

- Route progress.
- Speed.
- Acceleration.
- Lateral offset from route centerline.
- Steering command.
- Active/completed flag.
- Collision flag.
- Route type.
- Origin lane.
- Destination lane.

Vehicle position and heading are sampled from the route polyline. Lateral offset
is applied perpendicular to the route heading. This gives a simple steering
model without requiring full bicycle dynamics yet.

Rationale:

- Week 5 required a basic kinematic model.
- A simple route-progress model is easier to validate than a full dynamic model.
- Later Week 7 work can replace this with a kinodynamic model while preserving
  the high-level observation/reward structure.

## 6. Policy Interface

### 6.1 Multi-Agent Shape

The simulator exposes a fixed slot tensor:

```text
observation: (max_cars, 34)
action:      (max_cars, 2)
reward:      (max_cars,)
```

Each row corresponds to one vehicle slot. Not every slot must be active. The
`active_mask` in `info` tells PPO which slots should contribute to training.

Rationale:

- PPO requires consistent rollout array shapes.
- Curriculum training may vary active car count per episode.
- Fixed slots plus `active_mask` allow one policy to train across different car
  counts without changing tensor shapes.

### 6.2 Observation Vector

Each active vehicle receives a 34-dimensional normalized observation. The original 26 reactive features are followed by 8 predictive conflict and lane-centering features.

| Index/Group | Meaning | Reason |
| --- | --- | --- |
| 0 | Speed normalized by max speed | Required for longitudinal control. |
| 1 | Acceleration normalized by braking limit | Helps policy understand current motion trend. |
| 2 | Distance to stop line normalized by road length | Needed for stopping at lights and turn decisions. |
| 3 | Movement green flag | Tells whether the intended movement currently has green. |
| 4 | Yellow flag for vehicle axis | Helps policy avoid entering late in phase. |
| 5 | Red/no-green proxy | Helps signal compliance. |
| 6 | Front gap normalized by road length | Supports car following and safe distance. |
| 7 | Nearest vehicle distance normalized | Supports interaction awareness beyond same-lane front gap. |
| 8 | Route progress fraction | Helps know whether vehicle is before, inside, or after intersection. |
| 9 | Current lane index normalized | Needed for lane/rule context. |
| 10-12 | Route one-hot: left, straight, right | Defines intended maneuver. |
| 13 | `sin(heading)` | Encodes heading without angle discontinuity. |
| 14 | `cos(heading)` | Encodes heading without angle discontinuity. |
| 15 | Signal phase progress | Provides timing context. |
| 16 | Destination lane normalized | Needed for random destination lane following. |
| 17 | Lateral offset normalized by lane width | Needed for steering/lane centering. |
| 18 | Left-turn conflict flag | Needed for permissive left-turn yielding. |
| 19 | Right-on-red availability flag | Needed for right-on-red decision. |
| 20 | Right-turn conflict flag | Needed for yielding before right-on-red. |
| 21 | Rightmost-lane flag | Needed for right-turn legality. |
| 22 | Front relative speed | Helps detect whether ego is closing on the lead vehicle. |
| 23 | Front time-to-collision | Gives the policy direct safe-following context. |
| 24 | Required stopping-distance ratio | Helps the policy judge whether braking is needed before a stop line. |
| 25 | Movement permitted flag | Combines signal and yield legality into one compact safety feature. |

Important design choice:

The observation avoids absolute world coordinates where possible. Normalized
route-relative features are used because the same policy controls cars from all
approaches and should generalize across directions.

### 6.3 Action Vector

The action for each vehicle is continuous:

```text
action[0] = normalized acceleration in [-1, 1]
action[1] = normalized steering in [-1, 1]
```

Mapping:

- Positive acceleration command maps to `max_acceleration`.
- Negative acceleration command maps to `comfortable_braking`.
- Steering command changes lateral offset from route centerline.

Rationale:

The earlier implementation used discrete accelerate/coast/brake and left/center/right steering. Based on manager feedback, continuous acceleration is more realistic and avoids uncomfortable discrete go/stop behavior. Lateral steering is kept because Week 6 now includes random destination lanes and lane-following behavior.

## 7. Reward Design

The current reward is per vehicle.

| Reward/Penalty | Current Purpose |
| --- | --- |
| Progress reward | Encourages moving through the route. |
| Step penalty | Discourages indefinite blocking. |
| Acceleration penalty | Discourages excessive acceleration/braking. |
| Lateral offset penalty | Encourages lane-center tracking. |
| Steering penalty | Discourages unnecessary steering oscillation. |
| Front-gap penalty | Penalizes following too closely in the same lane. |
| Proximity penalty | Penalizes all-around too-close vehicles before collision. |
| Collision penalty | Large penalty for rectangle overlap. |
| Red-light penalty | Penalizes entering without legal movement permission. |
| Left-yield penalty | Penalizes permissive left turn when opposing straight traffic has priority. |
| Right-yield penalty | Penalizes unsafe right-on-red when conflict exists. |
| Wrong-lane right-turn penalty | Penalizes right turn from non-rightmost lane. |
| Completion bonus | Rewards finishing the route. |

### 7.1 Safe Distance

Safe distance is represented in two ways:

1. Same-lane front gap check:
   ```text
   front_gap < vehicle_length + 2.0
   ```
2. General proximity detection using all active vehicles:
   ```text
   oriented_rectangle_clearance < proximity_clearance
   ```

The second term was added because same-lane front gap alone misses side and
angled near-collisions. It now uses oriented-rectangle clearance instead of
center-distance clearance, so normal adjacent-lane traffic is not incorrectly
penalized just because vehicle centers are close.

### 7.2 Collision Model

Vehicles are modeled as oriented rectangles. Corners are computed from:

- Vehicle center.
- Heading.
- Vehicle length.
- Vehicle width.

Rectangle overlap is checked using separating-axis projection. This detects:

- Front collisions.
- Rear collisions.
- Side collisions.
- Angled overlap.

Rationale:

The original point-distance collision check was too approximate. It could miss
side contacts or over-penalize situations depending on center distance. Rectangle
overlap better represents real vehicle footprint.

## 8. Traffic Signal and Rule Model

### 8.1 Protected Left-Turn Mode

In protected mode, each axis has a left-turn phase followed by a through phase:

```text
NS_LEFT_GREEN -> NS_GREEN -> NS_YELLOW -> EW_LEFT_GREEN -> EW_GREEN -> EW_YELLOW
```

During left phase:

- Left-turning vehicles on the active axis may proceed.
- Through traffic on that axis remains red.

During through phase:

- Straight/right movements may proceed.
- Protected left turns are red.

Rationale:

This matches the requirement that a dedicated left signal should be green first,
then the other signal should be green, and each should be red when the other is
green.

### 8.2 Permissive Left-Turn Mode

In yield mode, left turns share the through green. A left-turning vehicle must
yield if an opposing straight vehicle is close to or inside the intersection.

Conflict check uses:

- Opposing approach.
- Opposing vehicle route equals `straight`.
- Distance to opposing vehicle stop line.
- Opposing vehicle speed.

Rationale:

The left-turning car needs to learn that green does not always mean safe to
proceed. The `left_turn_conflict` observation flag and yield penalty expose this
rule to PPO.

### 8.3 Right Turn On Red

Right-on-red is optional and enabled by default.

A right turn on red is legal only if:

- Right-on-red is enabled.
- Vehicle route is `right`.
- Vehicle is in the rightmost incoming lane.
- The normal movement signal is not already green.
- The phase is not yellow for that axis.
- No conflicting perpendicular or opposing-left traffic is close/inside the
  intersection.

If a vehicle enters right-on-red with conflict, it receives a right-yield
penalty. If it turns right from the wrong lane, it receives a wrong-lane penalty.

## 9. Curriculum Training

### 9.1 Why Curriculum Was Added

A policy trained only on one setting, for example four lanes and 20 cars, can be
executed on a different setting, but it may not behave safely. Generalization
requires exposure to multiple layouts during training.

The curriculum mode solves this by randomizing the active scenario at each
episode reset while keeping PPO tensors fixed.

### 9.2 Curriculum Parameters

CLI example:

```bash
intersection-rl train --curriculum \
  --curriculum-min-lanes 2 --curriculum-max-lanes 5 \
  --curriculum-min-cars 5 --curriculum-max-cars 64 \
  --steps 100000 \
  --checkpoint checkpoints/week6_curriculum.npz
```

Curriculum randomizes:

- Active lane count.
- Active car count.
- Protected/yield left signal mode.
- Right-on-red on/off.
- Random route choices.
- Random destination lanes.
- Initial offsets and seeds.

### 9.3 Fixed Tensor Shape

The environment still has fixed shapes:

```text
observation: (curriculum_max_cars, 34)
action:      (curriculum_max_cars, 2)
```

Inactive vehicle slots are masked out using `active_mask`. This is necessary
because PPO rollout arrays must have stable shapes across updates.

### 9.4 Capacity Handling

If the sampled lane count cannot physically fit the requested maximum car count,
the active car count is capped by road capacity. This prevents invalid episodes
such as too many queued vehicles for a short road.

## 10. PPO Design

### 10.1 Shared Policy

One shared actor-critic network controls all active vehicles. Each active car is
one sample in the PPO update.

Rationale:

- Reduces model size.
- Allows learning a general driving rule rather than a vehicle-specific rule.
- Supports variable active vehicle count through masking.

### 10.2 Continuous Gaussian Actor

The actor outputs a mean action vector. Exploration is done by sampling from a
Gaussian distribution with learned log standard deviation.

The sampled action is clipped to `[-1, 1]` before being sent to the environment.

### 10.3 Checkpointing

Training saves:

- Final checkpoint: exact `--checkpoint` path.
- Best checkpoint: `<name>_best.npz` based on rollout safety score.
- Periodic checkpoint: `<name>_update_XXXX.npz` every configured number of PPO
  updates.

Rationale:

Saving only at the end is risky because RL training can become unstable. The
best checkpoint now uses a safety score instead of reward alone, because a policy
can collect progress reward while still creating collisions, proximity events, or
traffic-rule failures. Intermediate checkpoints allow recovery from earlier safer
policies.

## 11. Validation and Tests

Current test count: 56 passing tests.

Test categories:

- Geometry path construction.
- Route projection.
- Environment reset and step shapes.
- Reproducible seeded resets.
- Episode truncation.
- Rule-based baseline action validity.
- Four-lane and five-lane exact car counts.
- Renderer background output.
- Protected left-turn phase separation.
- Permissive left-turn conflict detection.
- Destination lane randomization.
- Lateral action behavior.
- Right-on-red conflict and disabling behavior.
- Unsafe right-on-red violation counter.
- Right turns only from rightmost lane.
- Rectangle collision detection.
- Proximity violation detection.
- Curriculum randomized episode settings with fixed tensor shapes.
- Curriculum capacity capping.
- Continuous Gaussian PPO actor shapes.
- Short PPO rollout/update finite metrics.

Smoke tests performed during development:

- Visual/render path with `rgb_array` mode.
- Fixed-config PPO training.
- Curriculum PPO training.
- Checkpoint saving for final, best, and update checkpoints.
- Docker build and containerized training/evaluation.

## 12. Week-by-Week Engineering Record

## Week 5: Base Simulator and PPO Policy

### 12.1 Goal

Create the first runnable intersection simulation and train a PPO policy in that
environment.

### 12.2 Implemented Modules

| Module | Week 5 Responsibility |
| --- | --- |
| `env.py` | Base multi-agent intersection environment. |
| `geometry.py` | Four-way route centerlines and stop-line projection. |
| `vehicle.py` | Vehicle state and basic kinematic stepping. |
| `ppo.py` | Initial shared PPO trainer. |
| `rendering.py` | Pygame visualization. |
| `cli.py` | Simulate, train, and evaluate commands. |

### 12.3 Week 5 Environment Features

- Four-way intersection.
- Traffic light phases.
- Stop lines before intersection.
- Initial two-lane assumption.
- 8-12 vehicles by default.
- Left/straight/right route choices.
- Kinematic vehicle progression along route paths.
- Per-vehicle observations, actions, and rewards.

### 12.4 Week 5 Policy Inputs

The first version included motion state, signal state, route type, lane index,
front gap, nearest vehicle distance, route progress, and heading.

### 12.5 Week 5 Policy Outputs

The first version used discrete actions. This was later changed to continuous
actions after feedback that discrete go/coast/stop is not comfortable or
realistic enough.

Current output is continuous acceleration and steering.

### 12.6 Week 5 Rewards

Implemented rewards/penalties:

- Positive progress reward.
- Small time penalty.
- Acceleration penalty.
- Collision penalty.
- Red-light violation penalty.
- Front-gap penalty.
- Completion bonus.

### 12.7 Week 5 Design Rationale

The first simulator was intentionally simple. A full driving simulator can
become too complex before the RL interface is validated. The Week 5 design
prioritized:

- Clear state/action/reward interface.
- Fast training loop.
- Visual inspection.
- Minimal dependencies.
- Easy extension for later weeks.

### 12.8 Week 5 Bugs and Fixes

| Bug / Issue | Cause | Fix |
| --- | --- | --- |
| Image viewer sandbox failed while reading plan images. | Local environment sandbox had `bwrap` networking failure. | Used OCR and local image-processing tools instead. |
| Initial collision penalty repeated every overlapping frame. | Collision was detected every step for the same pair. | Added `_collision_pairs` so each pair collision is counted once. |
| Cars were not centered correctly in lanes. | Outgoing route geometry converged to a single lane. | Added lane-aware outgoing points and destination lane handling. |
| Stop-line rendering span was too wide. | Stop line was drawn across incoming and outgoing lanes. | Restricted stop-line drawing to incoming lane width. |
| Rule-based baseline typo. | Used `vehicle.apach` instead of `vehicle.approach`. | Corrected attribute and added regression test. |
| Slotted `Polyline` cached fields failed. | Dataclass with `slots=True` did not declare cached fields. | Added `_segments`, `_lengths`, and `_cumulative` fields. |

## Week 6: Lane Scaling, Turning Rules, and Curriculum

### 12.9 Goal

Increase simulator realism by supporting more lanes and more detailed turning
rules, then prepare training for multiple configurations.

### 12.10 Implemented Week 6 Features

- Configurable one to five lanes per approach.
- Exact configurable vehicle count.
- Protected left-turn signal mode.
- Permissive left-turn yielding mode.
- Right turns on green.
- Optional right turn on red.
- Right-on-red conflict yielding.
- Right-turn restriction to rightmost lane.
- Random destination lane assignment.
- Continuous acceleration and steering.
- Rectangle collision model.
- Proximity/safe-distance penalty.
- Curriculum training across randomized configurations.
- Best and intermediate checkpoint saving.

### 12.11 Week 6 Policy Inputs Added

Week 6 added or emphasized:

- Destination lane.
- Lateral offset.
- Left-turn conflict flag.
- Right-on-red availability flag.
- Right-turn conflict flag.
- Rightmost-lane flag.

### 12.12 Week 6 Policy Outputs

Current policy output:

```text
continuous acceleration command in [-1, 1]
continuous steering command in [-1, 1]
```

Reason for this choice:

- Continuous acceleration is more realistic than discrete accelerate/coast/brake.
- Steering is needed because vehicles can receive random destination lanes.
- Keeping both controls continuous allows smoother behavior and aligns better
  with later kinodynamic work.

### 12.13 Week 6 Rule Details

Protected left:

- Left arrow green first.
- Through green after left phase.
- Left movement red while through is green.

Permissive left:

- Left shares through green.
- Left yields to opposing straight traffic.

Right-on-red:

- Only if enabled.
- Only from rightmost lane.
- Only if conflicting traffic is clear.
- Penalized if unsafe.

### 12.14 Week 6 Curriculum Rationale

Without curriculum, a model trained on one layout may fail on another. The
curriculum was added to expose the policy to a distribution of scenarios.

The curriculum keeps fixed tensor shapes but randomizes active scenario details.
This preserves PPO compatibility while improving policy generalization.

### 12.15 Week 6 Bugs and Fixes

| Bug / Issue | Cause | Fix |
| --- | --- | --- |
| Training with one config did not guarantee generalization. | PPO tensor shape was fixed to one car count. | Added curriculum with fixed max slots and active masks. |
| Curriculum could sample more cars than road could fit. | Active car count did not consider lane capacity. | Added `_lane_capacity()` and capacity-aware sampling. |
| Rendering originally used base lane count during curriculum. | Renderer referenced static config instead of sampled episode state. | Renderer now uses `episode_lanes_per_approach` and episode modes. |
| Discrete action space conflicted with smooth-control feedback. | Initial PPO actor was categorical. | Replaced actor with Gaussian continuous policy. |
| Old checkpoints became incompatible after action-space change. | Actor output changed from 9 discrete logits to 2 continuous means. | Documented incompatibility; retraining required. |
| Point collision did not represent vehicle footprint. | Collision used center distance. | Added oriented rectangle overlap using vehicle length, width, heading. |
| Safe-distance penalty was too narrow. | Only same-lane front gap was penalized. | Added all-around proximity penalty. |
| Docker zip included stale extracted folder and manager screenshot. | Zip command did not exclude old extracted copy and `PP4.jpeg`. | Rebuilt zip with explicit exclusions. |
| Docker-generated checkpoints were root-owned. | Compose ran container as root. | Added host UID/GID mapping in Compose. |

## Week 7: Planned Kinodynamics, Speed Limits, and Merge Lanes

### 12.16 Goal

Move from basic kinematics toward more realistic driving dynamics and add speed
limit/merge behavior.

### 12.17 Planned Features

- Kinodynamic vehicle model.
- Speed limit per road segment.
- Randomized initial speed, including some vehicles above speed limit.
- Merge lanes on selected approaches.
- Merge-yield logic.
- Jerk/smoothness reward.
- Speed-limit reward/penalty.

### 12.18 Planned Policy Input Additions

- Speed limit value.
- Current speed-limit violation flag or margin.
- Merge lane availability.
- Distance to merge end.
- Nearby vehicles in target lane.
- Acceleration history or jerk estimate.

### 12.19 Planned Reward Additions

- Penalize speeding.
- Penalize high jerk.
- Reward smooth acceleration.
- Penalize unsafe merge.
- Reward yielding to immediate one or two vehicles during merge.

### 12.20 Engineering Risk

The current route-following model assumes each vehicle has a fixed route
centerline. Merge behavior may require dynamic path selection or explicit lane
change state. That should be designed carefully before coding.

## Week 8: Planned Parking Lanes and Pedestrians

### 12.21 Goal

Add static and dynamic obstacles around the intersection.

### 12.22 Planned Features

- Shoulder or parking lanes.
- Parked cars near straight and turning paths.
- Crosswalks.
- Pedestrian crossing behavior.

### 12.23 Planned Policy Input Additions

- Parked-car distance and relative position.
- Crosswalk occupancy.
- Pedestrian position, velocity, and crossing intent.
- Distance to crosswalk.

### 12.24 Planned Reward Additions

- Penalize close passes near parked vehicles.
- Penalize failure to yield to pedestrian.
- Penalize blocking crosswalk.

## Week 9: Planned Jaywalking and Lane Changes

### 12.25 Goal

Add more dynamic, less structured behavior.

### 12.26 Planned Features

- Jaywalking pedestrians.
- Vehicle lane changes.
- Unsafe lane-change detection.
- Lane changes inside intersection detection.

### 12.27 Planned Policy Input Additions

- Adjacent lane occupancy.
- Pedestrian off-crosswalk position.
- Time-to-collision estimate.
- Lane-change permission/constraint flags.

### 12.28 Planned Reward Additions

- Penalize risky lane changes.
- Penalize lane changes inside intersection.
- Reward safe deceleration near pedestrians.
- Penalize hard braking only when avoidable.

## Week 10: Planned Goal-Conditioned Behavior and Cut-In

### 12.29 Goal

Give each vehicle a goal and train goal-conditioned navigation.

### 12.30 Planned Features

- Per-vehicle goal.
- Goal progress reward.
- Necessary lane-change behavior.
- Late lane-change penalty.
- Cut-in scenarios when target lane is full.

### 12.31 Planned Policy Input Additions

- Goal route/lane encoding.
- Distance to goal.
- Required lane-change indicator.
- Target-lane gap estimate.

### 12.32 Planned Reward Additions

- Goal progress.
- Correct final lane/route.
- Penalize last-moment risky lane changes.
- Reward successful safe cut-in.

## Week 11: Planned Unprotected Turns, Stop Signs, Noise, and ROS Bag Format

### 12.33 Goal

Reduce idealized-simulator assumptions.

### 12.34 Planned Features

- Stop-sign-controlled intersections.
- Unprotected turns without traffic lights.
- Sensor noise.
- Occlusions.
- Dropouts.
- ROS bag compatible input/output format.

### 12.35 Planned Policy Input Additions

- Stop-sign distance.
- Stop-sign compliance state.
- Occlusion flags.
- Sensor confidence/noise estimates.

### 12.36 Engineering Risk

Noise and occlusion should not simply randomize observations without a clear
model. The simulator should define what is hidden, delayed, or corrupted and
how that maps to realistic perception limitations.

## Week 12: Planned Nissan Simulator Deployment

### 12.37 Goal

Deploy the trained policy to the Nissan simulator and reduce sim-to-sim gap.

### 12.38 Planned Work

- Adapter from current simulator observation format to Nissan simulator data.
- Policy export/loading path.
- Scenario matching between simulators.
- Sim-to-sim validation metrics.
- Final presentation.

### 12.39 Sim-to-Sim Gap Risks

Current simulator is lightweight and idealized. Differences may include:

- Vehicle dynamics.
- Coordinate frames.
- Time step.
- Road geometry.
- Traffic light encoding.
- Object detection/perception format.
- Collision/contact model.

## 13. Known Limitations

Current limitations:

- Vehicle model is still simple kinematic route-following, not full dynamics.
- PPO implementation is custom PyTorch code, not a mature external RL library such as Stable-Baselines3 or RLlib.
- No explicit jerk term yet.
- No speed limit yet.
- No merge lanes yet.
- No pedestrians or parked vehicles yet.
- No stop signs yet.
- No perception noise/occlusion yet.
- No ROS bag adapter yet.
- No Nissan simulator adapter yet.
- Training quality is not guaranteed by tests; tests validate functionality and
  numerical sanity, not final policy performance.

## 14. Recommended Manager Update Format

For each update, report in this structure:

1. What changed this week.
2. Policy inputs added or changed.
3. Policy outputs added or changed.
4. Reward terms added or changed.
5. Traffic rules modeled.
6. Assumptions made.
7. Bugs found and fixes.
8. Tests/validation run.
9. Current limitations.
10. Next planned work.

Example summary for current state:

- Implemented Week 6 turning rules and curriculum training.
- Policy input is a 26-dimensional per-car vector.
- Policy output is continuous acceleration and steering.
- Collision uses oriented rectangles, not point masses.
- Safe-distance penalty includes same-lane front gap and all-around proximity.
- Curriculum randomizes lanes, car counts, signal modes, right-on-red, routes,
  destination lanes, and seeds.
- Current limitation: no kinodynamics, speed limits, merge lanes, pedestrians,
  stop signs, or ROS/Nissan adapter yet.

## 15. Current Commands

Fixed-config training:

```bash
intersection-rl train --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on \
  --steps 100000 \
  --checkpoint checkpoints/week6_fixed.npz
```

Curriculum training:

```bash
intersection-rl train --curriculum \
  --curriculum-min-lanes 2 --curriculum-max-lanes 5 \
  --curriculum-min-cars 5 --curriculum-max-cars 64 \
  --steps 100000 \
  --checkpoint checkpoints/week6_curriculum.npz
```

Evaluation:

```bash
intersection-rl evaluate checkpoints/week6_curriculum_best.npz \
  --lanes 5 --cars 64 \
  --left-signal protected --right-on-red on \
  --episodes 100
```

Visual simulation:

```bash
intersection-rl simulate --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on
```

Test suite:

```bash
pytest
```


## 16. Week 6 Safety Stabilization Addendum

### 16.1 Training Problems Observed

After switching from discrete actions to continuous acceleration and steering,
fixed-config and curriculum PPO training showed unsafe behavior:

- Value loss often stayed very high, commonly hundreds or more.
- Entropy increased or oscillated instead of staying controlled.
- Reward remained negative and did not reliably improve toward safe behavior.
- Deterministic evaluation still showed red-light violations, collisions, and
  proximity violations after long training.
- Mean completion could look misleading because failed cars were still able to
  continue driving and finish the route.
- The policy learned to accelerate toward closed signals because progress reward
  was dense, while red-light penalties happened only after crossing the stop
  line.

### 16.2 Bugs and Design Issues Fixed

| Issue | Why it hurt training or evaluation | Fix |
| --- | --- | --- |
| Failed vehicles stayed active after collision or traffic-rule failure. | Evaluation could count a failed vehicle as completed later, hiding unsafe behavior. | Failed vehicles are now removed from active control and counted in `failed_vehicles`. |
| Completion metric did not distinguish clean success from failure. | `mean_completed` could look good even when cars violated rules. | Added `completed_clean`, `failed_vehicles`, `completed_delta`, and `failed_delta`. |
| Best checkpoint used reward only. | Reward could improve while safety got worse. | Best checkpoint now uses safety score with penalties for failure, collision, red/yield violations, proximity, and shield overrides. |
| Continuous Gaussian exploration could grow too large. | Large action noise made stop/go control unstable. | Bounded `log_std`, lowered default entropy coefficient, and clipped PPO training rewards. |
| Observation lacked direct safety timing features. | The policy saw front gap but not closing speed, time-to-collision, or stopping requirement. | Observation expanded from 22 to 26 features with front relative speed, TTC, stopping-distance ratio, and movement-permitted flag. |
| Red/yield penalties were delayed. | PPO received progress reward before the final violation penalty, encouraging unsafe approach behavior. | Added dense penalties for unsafe speed/acceleration near closed movements, low TTC, short front gap, and unsafe requests. |
| Full curriculum was too difficult as a first training distribution. | Random 5-lane/64-car scenarios create sparse, noisy safety feedback. | Added staged curriculum presets from easy low-density traffic to full Week 6 randomization. |

### 16.3 Training-Aware Safety Shield

A training-aware safety shield now runs inside `env.step()` before vehicle motion.
The PPO policy still outputs continuous acceleration and steering. If the policy
requests unsafe acceleration near a closed signal, yield conflict, or unsafe
front gap, the environment can override the acceleration to braking. The original
unsafe request is still penalized through reward terms and counted in
`safety_overrides` and `unsafe_requests`.

This is different from hiding mistakes. The rollout is made safer, but PPO still
receives negative feedback for asking for the unsafe action. The shield can be
disabled with:

```bash
intersection-rl train --safety-shield off
intersection-rl evaluate checkpoint.npz --safety-shield off
```

### 16.4 Safety Score

The rollout safety score is used for best-checkpoint selection:

```text
score =
  + 100 * completed_delta
  + 2 * progress_delta
  - 50 * failed_delta
  - 80 * collisions
  - 5 * proximity_violations
  - 40 * red_light_violations
  - 30 * yield_violations
  - 30 * right_lane_violations
  - 0.5 * safety_overrides
```

The score intentionally penalizes safety failures more strongly than progress.
This makes `<checkpoint>_best.npz` better aligned with demo safety than mean
reward alone.

### 16.5 Staged Curriculum

Staged curriculum presets were added so training can start with easier traffic
before full Week 6 randomization:

| Stage | Scenario |
| --- | --- |
| 1 | 1-2 lanes, 4-8 cars, protected left, right-on-red off. |
| 2 | 2 lanes, 8-12 cars, protected left, right-on-red off. |
| 3 | 2-3 lanes, 8-16 cars, protected left, right-on-red randomized. |
| 4 | 3-4 lanes, 12-32 cars, left-signal mode randomized, right-on-red randomized. |
| 5 | 4-5 lanes, 20-64 cars, full Week 6 randomized traffic. |

Example:

```bash
intersection-rl train --curriculum-stage 1 --steps 100000   --checkpoint checkpoints/stage1.npz
```

### 16.6 Remaining Risk

These changes make the training signal more safety-aware, but they do not prove a
high-quality trained policy by themselves. A short sanity run confirmed that the
shield prevents many immediate red-light failures, but a useful demo checkpoint
still needs longer staged training and evaluation. A good trained policy should
show both low violations and low `safety_overrides`; if safety overrides remain
high, the shield is doing too much work and the learned policy still needs more
training or reward tuning.

### 16.7 Proximity Metric Fix and Training Check

The previous proximity metric used center-distance clearance based on each car's half-diagonal. With a 4 m lane width and a vehicle footprint radius of about 2.42 m, normal adjacent-lane cars could be counted as proximity violations. This produced very large proximity counts and corrupted both reward and evaluation.

The proximity detector now uses oriented-rectangle clearance. Collision still uses rectangle overlap; proximity now means non-overlapping rectangles with minimum edge/corner clearance below `proximity_clearance` (0.75 m by default). This avoids penalizing normal side-by-side adjacent-lane traffic while still penalizing near side-swipe and close following cases.

Validation after the fix on 50 rule-based baseline episodes with 2 lanes, 8 cars, protected left, and right-on-red off:

```text
mean_completed=5.84 / 8
mean_failed=2.16
collisions=54
proximity=526
red_violations=0
```

Before the fix, the same baseline produced tens of thousands of proximity events, so the metric is now much more realistic.

A 100,000-step Stage 1 PPO run was also tested after the fix:

```text
checkpoint: checkpoints/stage1_proximity_fixed.npz
final shield-on: mean_completed=0.00, mean_failed=0.96, collisions=24, proximity=5344, red=0
best shield-on:  mean_completed=0.00, mean_failed=0.00, collisions=0,  proximity=0,    red=0
```

The result is not demo-quality. The best checkpoint found a safe but stationary policy: no red violations, no collisions, and no proximity, but also no clean completions. This means the proximity bug is fixed, but the next training issue is reward/curriculum pressure toward route completion. The next iteration should increase progress and clean-completion incentives, add stronger penalties for safe inactivity when movement is permitted, and possibly start with shorter/easier routes before returning to full Stage 1 traffic.


### 16.8 Progress-Aware Demo Safety Fix

The stationary-policy result in Section 16.7 showed that safety-only checkpoint selection was not enough. The next fix changed both reward design and demo safety handling.

Bugs and issues fixed:

| Issue | Why it hurt learning or evaluation | Fix |
| --- | --- | --- |
| Best checkpoint could prefer no movement. | A policy could avoid all safety penalties by parking before the stop line. | Added progress-aware safety score with large clean-completion reward and dense progress term. |
| Reward did not strongly prefer legal movement when traffic was permitted. | Cars could remain very slow near the intersection and still avoid failures. | Added clean-completion bonus, progress reward, permitted-speed reward, permitted-acceleration reward, and idle penalty when movement is legally permitted. |
| Red-light shield could brake too late. | A vehicle close to the stop line could still roll through after the action was applied. | Added a stop-line guard: when the shield is enabled, blocked vehicles are clamped just before the stop line and counted as safety overrides instead of becoming red-light failures. |
| Collision/proximity remained high in demo evaluation. | Red/yield/front-gap filtering does not reserve the shared intersection box. | Added an evaluation/simulation reservation layer that blocks entry when the intersection is occupied or a higher-priority vehicle is about to enter. |
| Reservation made PPO training too conservative. | Training with full reservation produced thousands of shield overrides and almost no clean completions. | PPO training now disables intersection reservation but keeps the red/yield/front-gap stop-line shield; evaluation and simulation keep reservation enabled for demo safety. |
| Proximity risk inside the shield over-constrained training. | Proximity warnings can occur in queues and caused excessive braking. | Removed proximity from the hard shield; proximity remains a reward/evaluation signal. |

Training run after these changes:

~~~bash
intersection-rl train --curriculum-stage 1 --steps 50000 \
  --save-interval-updates 25 \
  --checkpoint checkpoints/stage1_trainable_shield.npz
~~~

The aborted training run with reservation enabled was intentionally stopped because it produced near-zero completions and hundreds to thousands of shield overrides per rollout. After disabling reservation during training, PPO again produced useful progress. The 50,000-step run reached several high-quality rollouts, including clean rollouts with 10 completions, 0 failures, 0 collisions, and 0 red-light violations.

Evaluation of `checkpoints/stage1_trainable_shield.npz` with the demo shield enabled:

~~~text
2 lanes, 4 cars, protected left, right-on-red off, 50 episodes:
mean_completed=3.76 / 4
mean_failed=0.00
collisions=0
proximity=36
red_violations=0
mean_shield=401.08

2 lanes, 8 cars, protected left, right-on-red off, 50 episodes:
mean_completed=5.78 / 8
mean_failed=0.16
collisions=4
proximity=296
red_violations=0
mean_shield=1176.64
~~~

Historical note: this checkpoint was an intermediate improvement, but it is no longer the recommended demo checkpoint. Section 21 documents the later lane-centering, timeout-accounting, shield-hold, and geometric-reservation fixes that produced a clean 8-car controlled demo with 100% completion and zero hard safety violations.


### 16.9 Current Submission Summary

For the Week 6 upload, the important current behavior is:

- PPO remains continuous-action RL with one shared policy for all active cars.
- Training uses red/yield/front-gap shielding and stop-line clamping, but not intersection reservation.
- Evaluation and simulation use the extra reservation layer for demo safety.
- Failed vehicles are removed from active traffic and clean completion is tracked separately from failure.
- Proximity is rectangle-clearance based, fixing the earlier adjacent-lane false positives.
- The latest recommended controlled-demo checkpoint is `checkpoints/demo_8car_lane_centered_finetune_best.npz`.

Main bugs fixed in the final iteration:

| Bug | Final fix |
| --- | --- |
| Proximity counts were enormous because center-distance clearance treated adjacent lanes as too close. | Replaced proximity with oriented-rectangle clearance. |
| Failed cars could continue and later appear completed. | Added failed vehicle state and removed failed vehicles from active control. |
| Best checkpoint could choose parked policies. | Added progress-aware safety score and stronger clean-completion/progress rewards. |
| Red-light shield could brake too late near the stop line. | Added stop-line clamp when shielded movement is not legally permitted. |
| Intersection conflicts were not handled by the safety filter. | Added demo-time geometric intersection reservation. |
| Full reservation during training prevented learning. | Disabled reservation during training while keeping it for evaluation/simulation. |

Recommended demo command:

~~~bash
intersection-rl simulate --policy checkpoints/demo_8car_lane_centered_finetune_best.npz --lanes 2 --cars 8 --left-signal protected --right-on-red off
~~~

This is intentionally a controlled Stage 1 demo, not a claim that the full 5-lane/64-car Week 6 curriculum is solved. Section 21 gives the 50-episode 8-car evaluation: 100% completion, zero failed/incomplete vehicles, zero collisions, zero proximity events, zero red/yield/right-lane violations, and zero lane drift.


## 17. Manager Q&A Reference and Next Work Plan

This section is written as a practical reference for project review questions. It explains why the current system was designed this way, what is solved, what is not solved yet, and how to continue training from one curriculum stage to the next.

### 17.1 Why Use One Shared Policy?

All active vehicles use the same actor-critic network. Each vehicle gets its own observation row, action row, reward, and active mask, but the neural-network weights are shared.

Reasoning:

- A shared policy lets the model learn a general driving rule instead of memorizing behavior for car slot 0, slot 1, etc.
- It supports different vehicle counts because inactive rows are masked and ignored.
- It scales better to curriculum settings where lanes and car counts change between episodes.
- It is closer to a real autonomous-driving controller: the same controller should work for any vehicle given local observations.

Tradeoff: shared policy makes credit assignment harder. A bad rollout can include many cars with different problems, so safety metrics must be tracked per vehicle and aggregated carefully.

### 17.2 Why Continuous Actions?

The Week 6 policy outputs two continuous actions per active vehicle:

- acceleration command in `[-1, 1]`
- steering command in `[-1, 1]`

Acceleration is mapped to braking or acceleration limits, and steering changes lateral offset toward the route center.

Reasoning:

- Continuous control is closer to real vehicle control than a small discrete action list.
- It allows smooth speed adjustment and lane-centering behavior.
- It prepares the project for later kinodynamic and simulator integration work.

Observed problem: after switching from discrete actions, exploration became harder. Random continuous acceleration can easily create red-light violations, collisions, and unstable value targets. This is why bounded `log_std`, reward clipping, dense safety terms, and the training shield were added.

### 17.3 Why Keep a Safety Shield If This Is RL?

Pure RL starts randomly, so early rollouts are unsafe. In a traffic environment, random exploration creates many red-light entries and collisions before PPO receives enough useful feedback. The shield is not replacing RL; it is a training-aware constraint layer.

How it works:

- The policy still outputs acceleration and steering.
- If acceleration would be unsafe near a red/yield stop line or unsafe front gap, the environment can override acceleration to braking.
- The original unsafe request is still counted and penalized.
- The policy therefore receives negative feedback for asking for unsafe behavior.

Why this is acceptable for the demo:

- It prevents visually bad red-light failures during controlled demonstration.
- It makes training data less chaotic.
- It exposes remaining weakness through `safety_overrides`; high override counts mean the learned policy still depends on the shield.

Important limitation: a low collision/red-light count with high shield count does not mean the policy is fully solved. It means the policy plus safety layer works for a controlled demo.

### 17.4 Why Reservation Is Evaluation-Only

The intersection reservation layer prevents a vehicle from entering when another vehicle is inside the intersection or has higher priority to enter. This improved demo safety, but training with this layer enabled made PPO too conservative.

Observed behavior when reservation was enabled during training:

- Very high shield override counts.
- Almost no clean completions.
- Slow or parked traffic near the stop line.
- Poor learning signal because the shield blocked too many exploratory actions.

Final design choice:

- Training keeps red/yield/front-gap shield and stop-line clamp.
- Training disables intersection reservation so cars can still learn progress and completion.
- Evaluation and simulation enable reservation for safer demo behavior.

This is a pragmatic split: train with enough freedom to learn movement, demo with an additional safety guard.

### 17.5 How to Train Curriculum Stage N Then Stage N+1

The CLI now supports warm-starting a training run from a previous checkpoint using `--init-checkpoint`. Use the best or final checkpoint from Stage N as the initial checkpoint for Stage N+1.

Recommended workflow:

~~~bash
# Stage 1: easy low-density protected-left traffic.
intersection-rl train --curriculum-stage 1 --steps 100000   --checkpoint checkpoints/stage1.npz

# Stage 2: warm-start from Stage 1 best checkpoint.
intersection-rl train --curriculum-stage 2 --steps 150000   --init-checkpoint checkpoints/stage1_best.npz   --checkpoint checkpoints/stage2.npz

# Stage 3: introduce more lanes/cars and randomized right-on-red.
intersection-rl train --curriculum-stage 3 --steps 200000   --init-checkpoint checkpoints/stage2_best.npz   --checkpoint checkpoints/stage3.npz

# Stage 4: introduce more density and randomized left-signal mode.
intersection-rl train --curriculum-stage 4 --steps 300000   --init-checkpoint checkpoints/stage3_best.npz   --checkpoint checkpoints/stage4.npz

# Stage 5: full Week 6 randomized traffic.
intersection-rl train --curriculum-stage 5 --steps 500000   --init-checkpoint checkpoints/stage4_best.npz   --checkpoint checkpoints/stage5.npz
~~~

Use evaluation after each stage before moving forward:

~~~bash
intersection-rl evaluate checkpoints/stage2_best.npz   --lanes 2 --cars 8 --left-signal protected --right-on-red off   --episodes 50
~~~

Move to the next stage only when the current stage has acceptable safety and useful throughput. A practical threshold before increasing difficulty is:

- red violations near zero
- collisions near zero in the current stage layout
- failed vehicles low
- completed clean vehicles improving
- shield overrides trending down, not up
- proximity warnings not exploding as density increases

If Stage N+1 gets worse, continue Stage N longer or create an intermediate custom configuration before advancing.

### 17.6 Next Steps for Multi-Lane and Multi-Car Behavior

The current controlled demo works best at low density. Multi-lane and high-car-count behavior needs additional work because the policy still struggles with intersection ordering, close spacing, and throughput under density.

Recommended next steps, in priority order:

1. Train stage-to-stage with warm starts.
   Start from `demo_8car_lane_centered_finetune_best.npz`, then train Stage 2, evaluate, and only then move to Stage 3. Do not jump directly to full random curriculum.

2. Track metrics per scenario, not only averaged curriculum metrics.
   Keep separate evaluation tables for 4 cars, 8 cars, 12 cars, protected left, yield left, right-on-red on/off, and each lane count. Curriculum averages can hide a failure mode.

3. Reduce shield dependence gradually.
   The current 8-car demo has much lower shield use than earlier runs, but shield actions are still present. Add training objectives that penalize repeated overrides more strongly after the policy is already completing routes. The goal is not to remove the shield, but to make the learned policy ask for safer actions before the shield intervenes.

4. Improve intersection ordering.
   The reservation layer is rule-based. For RL learning, add observation features that expose reservation-like state: whether the intersection is occupied, nearest conflicting vehicle distance-to-stop, conflicting vehicle speed, and whether ego has priority. This lets the policy learn the same behavior instead of relying on the demo guard.

5. Improve spawning and spacing for dense traffic.
   High proximity can come from initial queues and early intersection compression. Add larger initial queue spacing for high car counts, minimum spawn clearance checks, and optional staggered release times.

6. Add route-conflict-aware rewards.
   Current proximity/collision penalties are general. Dense intersections need penalties for entering a conflict zone while another route is already occupying or approaching it. This should be dense and before collision, not only after overlap.

7. Add throughput-aware safety score by stage.
   Stage 1 can reward clean completion heavily. Later stages should also measure average delay, stopped time, and queue discharge. Otherwise the policy may become safe but inefficient.

8. Evaluate with shield on and off.
   Shield-on results show demo behavior. Shield-off results show what the policy has actually learned. A mature policy should improve in both, with shield-off red/collision failures decreasing over curriculum stages.

9. Consider staged action-noise reduction.
   The current Gaussian policy explores continuously. Later curriculum stages may need lower `log_std` max or entropy coefficient after the policy has learned basic stopping and yielding.

10. Add automated checkpoint selection using evaluation episodes.
   Current best checkpoint is based on rollout safety score during training. For serious multi-lane work, periodically run deterministic evaluation on fixed validation scenarios and choose the checkpoint by validation safety score.

### 17.7 Current Demo Recommendation

Use the following command for the cleanest controlled visual demo:

~~~bash
intersection-rl simulate --policy checkpoints/demo_8car_lane_centered_finetune_best.npz --lanes 2 --cars 8 --left-signal protected --right-on-red off
~~~

This setting is appropriate because the 50-episode evaluation completed all 8 vehicles in every episode with zero collisions, zero proximity events, zero red-light violations, zero yield violations, zero lane drift, zero failures, and zero incomplete vehicles.

### 17.8 How to Answer Likely Manager Questions

| Question | Short answer |
| --- | --- |
| Why are there still shield overrides? | The policy is not fully independent yet; the shield prevents unsafe actions and logs them. High overrides are a known residual risk and a training target for the next stage. |
| Is this pure RL? | The action policy is RL, but training/evaluation include a safety layer. The layer does not choose normal driving actions; it overrides unsafe acceleration and records penalties. |
| Why not train full 64-car curriculum immediately? | The signal is too noisy and sparse. The policy must first learn stop-line behavior, safe following, and clean completion in easier stages. |
| Why did the earlier proximity metric fail? | It used center-distance clearance based on vehicle half-diagonal, which made adjacent lanes look too close. It now uses exact oriented-rectangle clearance. |
| Why did the best checkpoint sometimes not move? | A safety-only score allowed parking to avoid violations. The score now includes progress and clean completion. |
| Why is 8-car still worse than 4-car? | Dense traffic creates more route conflicts and close spacing. The policy has not yet learned robust intersection ordering for higher density. |
| What proves the final demo setting is safe enough? | In 50 deterministic evaluation episodes at 2 lanes/4 cars/protected-left/right-on-red off, it had zero collisions, zero red-light violations, and zero failed vehicles. |
| What is the next technical milestone? | Stage 2 warm-start training from Stage 1, with validation on 8-12 cars until collisions and proximity drop while completions stay high. |


## 18. Latest Bug Fix Pass: Proximity Responsibility, Red-Light Accounting, Lane Drift, and Training Data Accounting

This pass addressed six issues found during simulation/evaluation review.

### 18.1 Proximity Responsibility

Previous behavior: proximity detection marked both vehicles in a close pair. That was correct for ambiguous side/crossing conflicts, but not for same-lane following. If a rear vehicle drives too close to a front vehicle, the front vehicle did not cause the unsafe spacing.

Current behavior:

- `proximity_events` counts close vehicle pairs.
- `proximity_violations` counts responsible vehicle slots.
- Same approach/lane/route following: only the rear vehicle is marked responsible.
- Crossing/ambiguous conflicts: both vehicles are marked responsible because either vehicle may be contributing to conflict-zone crowding.

This makes the metric more useful: pair count tells how many close interactions happened, while responsible-vehicle count tells how many policy-controlled vehicles should receive penalty.

### 18.2 Red-Light and Right-On-Red Accounting

Red-light violation is counted only when a vehicle crosses its stop line while it does not have legal movement permission.

A vehicle has legal movement permission when:

- its signal movement has green and it is not violating a yield rule, or
- it is making a legal right-on-red entry, from the right lane, not during yellow, and without detected cross-traffic conflict.

Right-on-red is not automatically a red-light violation. The metrics now separate:

- `red_violations`: illegal stop-line crossings on red/no permission.
- `right_on_red_entries`: legal right-on-red entries.
- `right_yield`: right-on-red attempts with conflicting traffic.

With the safety shield on, the stop-line clamp can prevent a red-light violation by holding the vehicle just before the stop line. That is why shield-on evaluation can show zero red violations while shield-off evaluation has many red violations.

### 18.3 Lane Drift and Lateral Offset Fix

Observed bug: during simulation some cars continuously drifted from the lane center and could visually enter adjacent/wrong lanes. The old lateral clamp allowed the vehicle center to move up to `0.75 * lane_width`. With a 4 m lane this was 3 m, which is wider than a lane-safe center offset.

Fix:

- Lateral offset is now clamped to `(lane_width - vehicle_width) / 2 - lane_edge_margin`.
- For the default 4 m lane and 1.8 m vehicle width, this keeps the vehicle center within about 1.0 m of the route center.
- Added lane-drift warnings when a vehicle rides near the lane edge.
- Added stronger lane-centering reward penalty and outward-steering penalty.

This prevents visual lane departure and reduces false proximity caused by lateral drift.

### 18.4 Training Data and Driving-Hour Accounting

Training logs now include rollout sample accounting:

- `samples`: active policy samples in the rollout. One active vehicle controlled for one step counts as one sample.
- `veh_hr`: vehicle-hours represented by that rollout: `samples * dt / 3600`.
- `training_summary env_steps`: number of environment steps collected.
- `training_summary policy_samples`: total active vehicle-action samples.
- `training_summary simulated_env_hours`: wall-clock simulated environment time, not multiplied by active vehicles.
- `training_summary vehicle_hours`: total active vehicle driving/decision hours.

Example calculation from a 15,104-step run:

```text
policy_samples = 66,921
simulated_env_hours = 15,104 * 0.2 / 3600 = 0.839 hours
vehicle_hours = 66,921 * 0.2 / 3600 = 3.718 hours
```

This distinction matters because one environment step can include multiple active vehicles, so vehicle-hours are larger than environment-hours.

### 18.5 Evaluation Percentages

Evaluation output now reports both raw counts and percentages:

- completion, failure, and incomplete percentages over total episode vehicle slots
- shield actions per episode and as a percentage of active action samples
- collision vehicle percentage
- proximity responsible vehicles, pair events, and action percentage
- red-light violation vehicle percentage
- lane-drift action percentage
- unsafe request action percentage
- active action samples and vehicle-hours

This makes results easier to compare across different car counts and episode lengths.

### 18.6 Training-Step Trend Check

A short trend check was run on Stage 1 with 2 lanes, 4 evaluation cars, protected left, and right-on-red off. These were quick checks, not final training runs.

| Training run | Env steps | Active policy samples | Vehicle-hours | Completion | Failures | Collisions | Proximity events | Red violations | Lane-drift action pct |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 5k final | 5,120 | 26,741 | 1.486 | 60.00% | 0.00% | 0 | 9 | 0 | 8.93% |
| 15k final | 15,104 | 66,921 | 3.718 | 93.75% | 0.00% | 0 | 0 | 0 | 19.08% |
| 30k final | 30,208 | 125,987 | 6.999 | 80.00% | 0.00% | 0 | 28 | 0 | 50.19% |

Interpretation:

- More training helped from 5k to 15k: completion improved from 60% to 93.75%, with zero collisions and zero red violations.
- More training did not monotonically improve from 15k to 30k in this quick run: completion dropped and lane drift increased.
- Therefore the trend is not simply "more steps always better." PPO can regress, so checkpoint selection and validation evaluation matter.
- The best practical checkpoint from this quick trend check is the 15k final checkpoint, not the 30k final checkpoint.

### 18.7 Checkpoint Selection Finding

The `_best` checkpoint is still based on rollout safety score, not deterministic validation. Even after correcting lane-drift weighting, `_best` was worse than the final 15k checkpoint in deterministic evaluation. This means rollout metrics are not enough for reliable checkpoint selection.

Next improvement: periodically run deterministic validation scenarios during training and choose the checkpoint by validation score, for example:

```text
validation_score =
  + completion_pct
  - collision_weight * collisions
  - red_weight * red_violations
  - proximity_weight * proximity_events
  - drift_weight * lane_drift_pct
  - shield_weight * shield_action_pct
```

Until that is implemented, evaluate both final and `_best` checkpoints and select the one with better deterministic evaluation results.


## 19. PyTorch PPO Migration

The project originally used a custom NumPy PPO implementation. That was useful for transparency, but it is not the right foundation for production-level continuous-control RL. The trainer has now been migrated to PyTorch.

### 19.1 Why Move Away From Custom NumPy?

Custom NumPy PPO had several limitations:

- Manual gradients are easy to get subtly wrong.
- Adding larger networks, richer losses, or auxiliary heads becomes slow and risky.
- There is no GPU acceleration path.
- Debugging optimizer behavior and tensor shapes is harder.
- Production RL workflows normally use framework autograd, not hand-written backprop.

PyTorch gives automatic differentiation, robust optimizers, easy model extension, and GPU support. This is a better base for a policy that must eventually learn lane centering, yielding, lane-change timing, and dense multi-car interaction.

### 19.2 What Changed Technically

- `SharedActorCritic` is now a `torch.nn.Module`.
- The actor and critic share a two-layer tanh MLP body.
- The actor outputs bounded continuous action means with `tanh`.
- `log_std` remains a learned parameter and is clamped to keep exploration stable.
- PPO loss uses PyTorch distributions and autograd.
- Optimizer is `torch.optim.Adam` with gradient clipping.
- Checkpoints remain `.npz` files for simple submission packaging.
- New `.npz` checkpoints store PyTorch state-dict arrays.
- Old NumPy checkpoints with keys like `w1`, `wp`, `wv`, and `log_std` still load through a compatibility conversion path.

### 19.3 Why Not Remove Steering?

The goal is not to hard-code lane keeping. The desired behavior is:

- If not changing lanes, learn near-zero steering and stay centered.
- If changing lanes is later added, steer during the lane-change maneuver.
- After the lane change, recenter and continue straight.

For Week 6, lane changing is not fully implemented as a discrete maneuver or target-lane state machine. Therefore the current policy still controls steering, but lane-drift penalties and lateral offset limits teach it that unnecessary lateral motion is bad. A future production version should add an explicit lane-change intention/action and target-lane state, so steering is supervised by a clearer maneuver objective.

### 19.4 Verification

After migration:

```text
PPO unit tests: passed
full test suite: passed
short PyTorch training smoke test: passed
new PyTorch checkpoint evaluation: passed
old NumPy checkpoint compatibility evaluation: passed
```

### 19.5 Remaining Production RL Work

PyTorch is necessary but not sufficient. The next production-level steps are:

1. Add predictive collision/yield filtering with future rectangle rollout over a short horizon.
2. Add validation-based checkpoint selection instead of relying only on rollout safety score.
3. Add explicit lane-change state/action if lane changes are required.
4. Add richer observations for conflict-zone occupancy and priority.
5. Increase network capacity only after validation metrics show the current architecture is the bottleneck.
6. Run staged curriculum with warm starts and compare shield-on vs shield-off evaluations.


## 20. Predictive Signals for PPO Learning

The previous observation vector was mostly reactive: current speed, signal state, front gap, nearest vehicle distance, route progress, and rule flags. That tells PPO what is happening now, but not enough about what is likely to happen next. For dense intersections, waiting until current rectangles overlap is too late.

### 20.1 What Was Added

The observation size increased from 26 to 34. The added features are short-horizon predictive signals computed from current vehicle speed, path progress, and rectangle geometry:

- predicted future collision flag
- predicted future proximity flag
- normalized time to nearest predicted conflict
- normalized conflicting vehicle time-to-stop/conflict
- ego priority flag
- intersection occupied flag
- conflicting vehicle approaching flag
- normalized minimum future clearance

The environment now projects vehicles forward over a short horizon using constant-speed path progress and checks future oriented rectangles. These features let PPO see conflict risk before collision/proximity happens.

### 20.2 Why This Helps PPO

The policy should learn behavior such as:

```text
if no conflict and movement permitted: proceed
if predicted conflict and ego has lower priority: slow/yield
if no lane-change objective: steer toward lane center
if near lane edge: steer back toward center
```

Before this change, collision and proximity penalties were delayed. PPO only learned after the vehicles were already too close. Predictive features make the learning signal less sparse and make yielding behavior learnable from state, not only from the safety shield.

### 20.3 Dense Predictive Penalties

The reward now includes soft penalties for predicted future collision and predicted future proximity. These penalties are smaller than real collision/proximity penalties because they are warnings, not final failures. The intent is to shape behavior before hard safety events occur.

### 20.4 Checkpoint Compatibility

Because the observation size changed, a policy trained on the old 26-feature input does not have weights for the new predictive features. The loader handles this safely:

- old NumPy checkpoints are still accepted
- old first-layer weights are copied into the original 26 columns
- new predictive feature input weights are zero-filled during compatibility loading so old behavior is not randomly perturbed

This compatibility is for evaluation and transition only. A production-quality policy should be retrained or fine-tuned with the new 34-feature observation.

### 20.5 Verification

After adding predictive signals:

```text
full test suite: 56 passed
predictive observation regression test: passed
PyTorch PPO smoke train: passed
predictive checkpoint evaluation: passed
old 26-feature checkpoint compatibility evaluation: passed
```


### 20.6 Predictive Feature Computation Optimization

Initial predictive features were correct but expensive because reward and observation paths could request future conflict metrics repeatedly for each active vehicle. The optimized implementation now builds one cached predictive feature matrix per simulator state:

- the cache key uses vehicle id, active flag, progress, speed, and lateral offset
- active vehicle future rectangles are projected once over the configured horizon
- each active vehicle pair is checked once, and both vehicles receive their predictive features from the same pairwise computation
- reward and observation both read from the cached matrix
- the cache is invalidated after each environment step and reset

This keeps the learning signal the same while removing repeated future rollout work. The optimization was verified by the full test suite and by a 512-step Stage 1 smoke run. The smoke run completed quickly and produced 3,584 active policy samples, confirming that the predictive feature path was no longer the runtime bottleneck.

### 20.7 Long Stage 1 Training Run

Command used:

    .venv/bin/intersection-rl train --curriculum-stage 1 --steps 500000 --save-interval-updates 25 --checkpoint checkpoints/stage1_torch_predictive_long.npz

Final training summary:

- environment steps: 500,224
- active policy samples: 2,050,125
- simulated environment hours: 27.790
- simulated vehicle-hours: 113.896
- final checkpoint: checkpoints/stage1_torch_predictive_long.npz
- best safety-score checkpoint: checkpoints/stage1_torch_predictive_long_best.npz

Driving-hour calculation: each active policy sample represents one controlled vehicle for one environment time step. The environment step time is 0.2 seconds, so vehicle-hours = policy_samples * 0.2 / 3600 = 2,050,125 * 0.2 / 3600 = 113.896 vehicle-hours. Environment-hours = env_steps * 0.2 / 3600 = 500,224 * 0.2 / 3600 = 27.790 hours.

Important training observations:

- Early training still had collision-heavy exploration and high shield use.
- Around 200k-280k environment steps, the policy began producing repeated zero-collision batches.
- The strongest training batches reached clean=10, failed=0, collision=0, proximity=0.
- Later in training, Gaussian entropy collapsed very low/negative, showing that exploration became almost deterministic. This is not automatically wrong for a Gaussian policy, but it means final checkpoints can over-specialize and should be evaluated against the saved best checkpoint.
- Red-light and yield violations stayed at zero throughout the long run, showing that the safety-aware training and predictive stop/yield signals are working for traffic-law compliance.

Fixed 2-lane/8-car protected-left, right-on-red-off evaluation over 50 episodes:

Final checkpoint:

- mean_completed: 6.38 / 8 (79.75%)
- mean_failed: 0.00 (0.00%)
- mean_incomplete: 1.62 (20.25%)
- collisions: 0 total
- red violations: 0
- left/right yield violations: 0
- proximity vehicles/events: 412 vehicles, 206 pair events
- shield actions: 48,639 (65.51% of active action samples)
- lane drift actions: 16,177 (21.79% of active action samples)

Best safety-score checkpoint:

- mean_completed: 5.80 / 8 (72.50%)
- mean_failed: 0.04 (0.50%)
- mean_incomplete: 2.16 (27.00%)
- collisions: 1 total over 50 episodes
- red violations: 0
- left/right yield violations: 0
- proximity vehicles/events: 390 vehicles, 195 pair events
- shield actions: 49,053 (63.52% of active action samples)
- lane drift actions: 17,369 (22.49% of active action samples)

Conclusion: the optimized predictive features and long Stage 1 training substantially improved traffic-law safety and removed evaluation collisions in the final checkpoint, but the policy is still not fully demo-polished. The main remaining gaps are incomplete vehicles, high proximity counts, high shield intervention, and lane drift. The next fix should target validation-based checkpoint scoring, stronger clean-completion reward relative to proximity/idling, entropy/log-std scheduling to avoid late collapse, and explicit lane-centering or lane-change state so steering does not drift during normal driving.


## 21. Lane Drift, Proximity, Incomplete Vehicles, and Shield-Use Fix

### 21.1 Problem Observed

After the long Stage 1 predictive-feature run, the 2-lane/8-car demo was safe for red-light and yield rules but still not demo-quality. Evaluation showed incomplete vehicles, high shield use, many proximity events, and visible lane drift. Several of these were environment/interface bugs that made the policy look worse than it was.

Observed pre-fix 50-episode result for `checkpoints/demo_8car_lane_centered_finetune_best.npz` in the 2-lane/8-car protected-left, right-on-red-off setting:

```text
mean_completed=6.46 / 8
mean_failed=1.54
mean_incomplete=0.00 after timeout accounting, but these were stuck/timeout failures
collisions=0
proximity_vehicles=0 after lane-centering test fix
red_violations=0
lane_drift=0 after lane-centering test fix
shield_action_pct=24.73
unsafe_action_pct=22.87
```

Before lane centering was added, the same policy showed lane drift and proximity because vehicles could slowly slide away from the lane center.

### 21.2 Root Causes

| Symptom | Root Cause | Why It Hurt Learning/Evaluation |
| --- | --- | --- |
| Lane drift while driving straight | `Vehicle.step()` integrated lateral offset directly from any nonzero steering command. Tiny steering bias accumulated every frame. | A car inside a lane could slowly leave the lane even when no lane change was intended, creating false proximity and bad simulation. |
| High proximity counts | Lane drift and earlier clearance logic placed vehicle rectangles too close even when traffic should have been lane-centered. | Proximity warnings polluted reward/evaluation and made safe policies look unsafe. |
| Incomplete vehicles | Active vehicles at episode timeout were previously easy to report as incomplete rather than explicit stuck failures. | Evaluation hid the real problem: some cars were timing out instead of finishing. |
| High shield use | The shield counted repeated holds for already-stopped vehicles, and reservation could block for non-conflicting intersection traffic. | A stopped car waiting safely at a red/reservation condition looked like continuous shield intervention. |
| Collision regression after simple reservation relaxation | The first conflict-aware reservation check used a broad route heuristic. Some geometric merge/cross conflicts were classified as non-conflicting. | Completion improved, but collisions appeared, proving the heuristic was too permissive. |

### 21.3 Fixes Implemented

1. Lane-centering vehicle dynamics.
   The vehicle model now adds a centering steering term when the vehicle has lateral offset. Outward steering near the lane edge is damped. PPO can still steer for lane/destination tracking, but a straight-driving car naturally returns to the route centerline instead of drifting forever.

2. Timeout failures are explicit.
   If the episode reaches `max_steps`, remaining active vehicles are marked failed, deactivated, and penalized with `timeout_failure_penalty`. Evaluation now reports stuck vehicles as failures instead of leaving them ambiguous as incomplete.

3. Stopped-vehicle shield hold is not over-counted.
   When a vehicle is already stopped under an unsafe/red/reservation condition, the shield can hold zero acceleration without counting a new override every frame. Overrides still count when the policy asks to accelerate unsafely.

4. Geometric reservation conflict detection.
   Evaluation/simulation reservation no longer blocks for every active vehicle inside or near the intersection. It samples the actual generated route footprints as oriented rectangles and only treats two vehicles as reservation-conflicting if their future route footprints overlap or come inside the clearance threshold. The result is less unnecessary waiting without allowing merge/cross conflicts.

5. Cached route-conflict checks.
   Geometric route conflict checks are cached by route descriptor. This keeps the more accurate reservation and predictive logic practical during tests, evaluation, and simulation.

6. CLI episode horizon control.
   `--episode-seconds` is now available through simulate, train, and evaluate. This separates true stuck behavior from an episode horizon that is simply too short.

### 21.4 Verification

Regression tests after the fixes:

```text
56 passed, 1 warning
```

The route-dependent tests were updated so manually edited test vehicles rebuild their route paths before geometric conflict checks are evaluated.

### 21.5 Demo Evaluation After Fix

Recommended checkpoint:

```text
checkpoints/demo_8car_lane_centered_finetune_best.npz
```

Command:

```bash
.venv/bin/intersection-rl evaluate checkpoints/demo_8car_lane_centered_finetune_best.npz   --lanes 2 --cars 8 --left-signal protected --right-on-red off   --episodes 50 --episode-seconds 60
```

Result:

```text
episodes=50
mean_reward=399.74
mean_completed=8.00 completed_pct=100.00
mean_failed=0.00 failed_pct=0.00
mean_incomplete=0.00 incomplete_pct=0.00
mean_shield=114.20
shield_actions=5710 shield_action_pct=10.84
collisions=0 collisions_per_ep=0.00 collision_vehicle_pct=0.00
proximity_vehicles=0 proximity_events=0 proximity_action_pct=0.00
red_violations=0 red_vehicle_pct=0.00
left_yield=0 right_yield=0 right_lane=0
lane_drift=0 lane_drift_action_pct=0.00
unsafe_requests=4398 unsafe_action_pct=8.35
active_action_samples=52667 env_steps=10531 vehicle_hours=2.926
```

This is the first clean 8-car controlled demo result: every vehicle completed, no vehicle failed, no vehicle was incomplete, and all safety violation counters stayed at zero.

### 21.6 Horizon Check

The same checkpoint was evaluated with 60, 90, and 120 second episode horizons after the geometric reservation fix. The 20-episode results were identical because all episodes finished before 60 seconds:

```text
mean_completed=8.00 / 8
mean_failed=0.00
mean_incomplete=0.00
collisions=0
proximity=0
red_violations=0
lane_drift=0
shield_action_pct=11.01
```

This means the previous incomplete/stuck behavior was not solved by increasing time. It was solved by lane centering, better shield accounting, and correct reservation conflict logic.

### 21.7 Fine-Tune Check

A short fine-tune was run after the environment fix:

```bash
.venv/bin/intersection-rl train --lanes 2 --cars 8   --left-signal protected --right-on-red off --steps 50000   --save-interval-updates 25   --init-checkpoint checkpoints/demo_8car_lane_centered_finetune_best.npz   --checkpoint checkpoints/demo_8car_lane_centered_geometric_finetune.npz
```

Training summary:

```text
env_steps=50176
policy_samples=267551
simulated_env_hours=2.788
vehicle_hours=14.864
```

Evaluation of the fine-tuned final checkpoint stayed safe but had higher shield use:

```text
mean_completed=8.00 / 8
collisions=0
proximity=0
red_violations=0
lane_drift=0
shield_action_pct=13.48
```

Evaluation of the fine-tuned best checkpoint stayed safe and had higher reward, but still did not beat the recommended checkpoint on shield percentage:

```text
mean_completed=8.00 / 8
collisions=0
proximity=0
red_violations=0
lane_drift=0
shield_action_pct=11.23
```

Decision: use `checkpoints/demo_8car_lane_centered_finetune_best.npz` for the demo because it has the lowest measured shield dependence among the clean 8-car checkpoints.

### 21.8 What This Means

The controlled 2-lane/8-car Stage 1 demo is now clean. This does not mean the full Week 6 problem is solved for all lane counts and 64 cars. It means the environment bugs that blocked the demo were fixed, and the current policy plus safety layer can demonstrate safe, complete behavior in the intended controlled setting.

For Stage 2 and higher-density training, the next steps are:

1. Warm-start Stage 2 from the recommended Stage 1 checkpoint.
2. Evaluate shield-on and shield-off after each stage.
3. Track `completed_pct`, `failed_pct`, `proximity_events`, `lane_drift_action_pct`, `shield_action_pct`, and `unsafe_action_pct`.
4. Do not move to Stage N+1 until Stage N has high completion, zero or near-zero hard safety violations, and shield use trending down.
5. For multi-lane/multi-car behavior, keep geometric reservation in evaluation, but expose its state through observations so PPO can learn to anticipate priority instead of depending on the shield.

## 22. From-Scratch Stage 1 Collapse Fix

### 22.1 Problem Reproduced

A fresh Stage 1 run was started from scratch with the command:

```bash
.venv/bin/intersection-rl train --curriculum-stage 1 --steps 500000 \
  --save-interval-updates 25 \
  --checkpoint checkpoints/stage1_current_from_scratch.npz
```

The run reproduced the failure observed on a second desktop. By about 89,600 environment steps, the policy was clearly stuck:

- clean completions were almost always zero
- most episodes ended with timeout failures
- collisions, proximity, red violations, yield violations, and lane drift stayed near zero
- progress was tiny
- entropy collapsed early
- evaluation of the saved best checkpoint produced `mean_completed=0.00`, `mean_failed=8.00`, and no hard violations

This proved the issue was not stale cache data. The policy had found a local optimum: do almost nothing, avoid obvious violations, then time out.

### 22.2 Root Causes

| Cause | Effect |
| --- | --- |
| Stage 1 started directly with 4-8 cars and 1-2 lanes. | From random initialization, the policy had to learn stop-line behavior, movement, yielding, and spacing at the same time. |
| Safety score penalized hard violations more clearly than it rewarded early clean movement. | A stationary or very slow policy could look safer than a moving exploratory policy. |
| Legal-movement reward was too weak. | When the signal was green and no yield/front-gap conflict existed, the policy did not receive enough dense reward for actually moving. |
| Continuous Gaussian exploration was still too wide for from-scratch stop/go learning. | Noisy acceleration made early traffic unstable, while later entropy collapse could lock in the bad timeout behavior. |
| Initial policy bias was neutral. | A brand-new policy had no prior tendency to move when legal, so it could converge toward coasting/stopping. |

### 22.3 Fixes Implemented

1. Progressive Stage 1 ramp.
   Stage 1 now starts easier before returning to normal Stage 1 randomization: 2 active cars first, then 4 active cars, then the normal 1-2 lane / 4-8 car Stage 1 distribution.

2. Fixed-shape curriculum implementation.
   The environment keeps `config.max_cars` fixed and uses episode-local sampled counts for active vehicles. This preserves stable PPO observation/action tensor shapes during the progressive ramp.

3. Stronger legal movement reward.
   When movement is legally permitted and front gap is safe, the reward gives more dense credit for speed and positive acceleration. If a vehicle stays almost stopped when it is allowed to move, it receives a stronger idle penalty.

4. Stronger clean-completion and timeout pressure.
   The clean completion bonus and timeout failure penalty were increased so PPO sees a clearer difference between finishing legally and waiting safely until timeout.

5. More conservative exploration.
   PPO maximum `log_std` was lowered and the default entropy coefficient was reduced. This limits excessive random acceleration in continuous control while still allowing exploration.

6. Initial acceleration bias.
   New policies initialize the acceleration mean with a small positive bias. This does not hard-code driving; it only makes early exploration include legal forward progress more often.

7. Safety score shield penalty increased.
   Safety overrides now reduce best-checkpoint score more strongly, so checkpoint selection prefers policies that ask for safe actions themselves.

8. Timeout failures in training logs.
   Rollout logs now print timeout failures separately. This makes the zero-completion timeout local optimum visible during training.

### 22.4 Verification

Full regression suite after the implementation:

```text
56 passed, 1 warning
```

The first proof run after adding the ramp immediately produced clean completions, but it exposed a tensor-shape bug because the initial implementation mutated `config.max_cars` during training. After replacing that with episode-local sampled counts, the proof run completed.

Final proof command:

```bash
.venv/bin/intersection-rl train --curriculum-stage 1 --steps 80000 \
  --save-interval-updates 25 \
  --checkpoint checkpoints/stage1_progressive_fix_probe3.npz
```

Training summary:

```text
env_steps=80128
policy_samples=206698
simulated_env_hours=4.452
vehicle_hours=11.483
```

Deterministic evaluation of the final checkpoint on the controlled 2-lane/8-car protected-left, right-on-red-off setting:

```text
episodes=30
mean_reward=379.31
mean_completed=8.00 completed_pct=100.00
mean_failed=0.00 failed_pct=0.00
mean_incomplete=0.00 incomplete_pct=0.00
mean_shield=164.77
shield_actions=4943 shield_action_pct=15.51
collisions=0 collisions_per_ep=0.00 collision_vehicle_pct=0.00
proximity_vehicles=0 proximity_events=0 proximity_action_pct=0.00
red_violations=0 red_vehicle_pct=0.00
left_yield=0 right_yield=0 right_lane=0
lane_drift=0 lane_drift_action_pct=0.00
unsafe_requests=4137 unsafe_action_pct=12.98
active_action_samples=31865 env_steps=6382 vehicle_hours=1.770
```

The `_best` checkpoint from the same run was also safe but slightly less complete:

```text
mean_completed=7.87 / 8
mean_failed=0.13
collisions=0
proximity_events=0
red_violations=0
lane_drift=0
shield_action_pct=15.35
```

Decision: for this proof run, the final checkpoint was better than the rollout-score `_best` checkpoint. This reinforces the recommendation to evaluate both final and `_best` checkpoints deterministically after every training run.

### 22.5 What To Run On A New Computer

On a new machine with no prior checkpoints, start with Stage 1 from scratch:

```bash
.venv/bin/intersection-rl train --curriculum-stage 1 --steps 500000 \
  --save-interval-updates 25 \
  --checkpoint checkpoints/stage1.npz
```

Then evaluate both final and best:

```bash
.venv/bin/intersection-rl evaluate checkpoints/stage1.npz \
  --lanes 2 --cars 8 --left-signal protected --right-on-red off \
  --episodes 50 --episode-seconds 60

.venv/bin/intersection-rl evaluate checkpoints/stage1_best.npz \
  --lanes 2 --cars 8 --left-signal protected --right-on-red off \
  --episodes 50 --episode-seconds 60
```

Warm-start Stage 2 from whichever checkpoint has the better deterministic safety/completion result:

```bash
.venv/bin/intersection-rl train --curriculum-stage 2 --steps 200000 \
  --init-checkpoint checkpoints/stage1.npz \
  --checkpoint checkpoints/stage2.npz
```

Use `_best` instead of final only if deterministic evaluation proves it is better. Rollout-score best checkpoints can still lose to final checkpoints in deterministic validation.

## 17. Latest Stage 1-3 Training Update (2026-06-23)

This section records the latest reproducible training and evaluation state after
switching back to 4 m lanes, removing lateral noise, forcing vehicles to stay on
route/lane center, adding CSV logging for training/evaluation, and adding Stage
3 right-on-red curriculum support.

### 17.1 Current Checkpoints Used

Only the following checkpoints are part of the latest staged run and should be
used for the current Week 6 package:

| Stage | Checkpoint | Role |
| --- | --- | --- |
| Stage 1 | `checkpoints/stage1_lane4_centered_v4_best.npz` | Fresh Stage 1 best checkpoint, used to initialize Stage 2. |
| Stage 2 | `checkpoints/stage2_lane4_centered_v4_best.npz` | Fresh Stage 2 best checkpoint, used to initialize Stage 3. |
| Stage 3 | `checkpoints/stage3_lane4_centered_v6_best.npz` | Latest Stage 3 best checkpoint after the right-on-red curriculum changes. |

Training metrics are saved in:

- `checkpoints/stage1_lane4_centered_v4_train_metrics.csv`
- `checkpoints/stage2_lane4_centered_v4_train_metrics.csv`
- `checkpoints/stage3_lane4_centered_v6_train_metrics.csv`

Evaluation metrics are saved in:

- `results/evaluations.csv`

### 17.2 Latest Evaluation Results

All results below use deterministic policy evaluation over 50 episodes. The most
important numbers are shield-off because they show what the learned policy can do
without safety intervention.

| Stage / Setting | Shield | Completed | Collisions / ep | Red / ep | Proximity events / ep | Notes |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| Stage 1, 2 lanes / 8 cars, right-on-red off | off | 86.25% | 0.48 | 0.14 | 3.98 | Meets the current demo threshold. |
| Stage 1, 2 lanes / 8 cars, right-on-red off | on | 83.50% | 0.00 | 0.00 | 0.00 | Shield removes unsafe events but slightly reduces throughput. |
| Stage 2, 2 lanes / 12 cars, right-on-red off | off | 71.50% | 1.36 | 0.42 | 15.04 | Below completion target and proximity is too high. |
| Stage 2, 2 lanes / 12 cars, right-on-red off | on | 60.17% | 0.12 | 0.00 | 35.08 | Shield reduces collision/red events but causes more waiting and proximity/timeout pressure. |
| Stage 3, 2 lanes / 12 cars, right-on-red on | off | 71.83% | 1.40 | 0.34 | 7.86 | Close on safety thresholds, still below 75% completion. |
| Stage 3, 2 lanes / 12 cars, right-on-red on | on | 60.17% | 0.12 | 0.00 | 29.80 | Safer but slower; throughput drops. |
| Stage 3, 3 lanes / 10 cars, right-on-red on | off | 69.80% | 1.50 | 0.00 | 4.74 | Collision rate is at the target boundary, completion is low. |
| Stage 3, 3 lanes / 10 cars, right-on-red on | on | 77.20% | 0.02 | 0.00 | 0.02 | This is the best Stage 3 shield-on result. |
| Stage 3, 3 lanes / 14 cars, right-on-red on | off | 68.00% | 1.76 | 0.50 | 29.08 | Hard setting is not demo-ready. |
| Stage 3, 3 lanes / 14 cars, right-on-red on | on | 56.00% | 0.18 | 0.00 | 12.48 | Shield prevents many safety failures but throughput collapses. |

Interpretation:

- `right_on_red_entries` counts legal right-on-red entries, not violations.
- Right-on-red yield failures are counted separately as `right_yield`.
- In the latest Stage 3 results, right-on-red is being exercised, but the main
  remaining issues are low completion, collisions, proximity pressure, and
  timeout/waiting behavior under shield intervention.

### 17.3 Latest Bugs, Causes, and Fixes

#### Lane-width regression

A previous experiment increased `lane_width` from 4 m to 5 m. This degraded
performance because the geometry changed the route spacing and conflict/proximity
relationships relative to the policy and reward balance learned under 4 m lanes.
The policy was not simply seeing a wider road; it was seeing shifted lane centers,
turn arcs, stop-line spacing, and interaction geometry.

Fix:

- Restored `EnvConfig.lane_width = 4.0`.
- Reduced `proximity_clearance` to 0.65 m for the 4 m lane geometry.

#### Lateral drift and off-center visualization

Cars appeared slightly left/right aligned and sometimes seemed to merge or vanish
near the start. The root cause was lateral noise/steering interacting with route
geometry and failure deactivation. Failed vehicles were removed from active
control and were previously skipped by the renderer, which looked like vehicles
vanishing.

Fix:

- Set `initial_lateral_noise = 0.0`.
- Disabled lateral motion in `Vehicle.step()` so vehicles remain on route center.
- Updated rendering so failed/collided inactive vehicles remain visible in red.
- Reduced rendered vehicle size with a visual scale while leaving physical
  collision geometry unchanged.

#### Stage 1/Stage 2 checkpoint selection

Training rollouts can improve and then collapse later in the same run. Earlier
best-checkpoint handling could select noisy rollout metrics instead of stable
shield-off validation.

Fix:

- Stage 1 and Stage 2 now save `_best` from validation checkpoints.
- Stage 2 uses shield-off validation for checkpoint selection and also logs
  shield-on validation.
- Training writes per-update metrics CSV files for graphing.

#### Stage 2 instability

Stage 2 initially jumped too abruptly from 8 to 12 cars and could collapse into
poor progress or timeout-heavy behavior. The weak Stage 2 base is still a major
reason Stage 3 does not reach the completion target.

Fix:

- Stage 2 curriculum now ramps 8 -> 10 -> 11 -> 12 cars.
- Stage 2 uses lower learning rate, fewer PPO epochs, smaller PPO clip ratio,
  target-KL early stopping, shield dropout, and stronger timeout/progress reward
  pressure.

Remaining issue:

- Stage 2 shield-off completion is still only 71.50%, below the 75% target.
  Stage 3 inherits this weakness.

#### Stage 3 immediate collapse

The first Stage 3 implementation enabled right-on-red and expanded immediately to
2-3 lanes / 8-16 cars. Validation also tested the hardest Stage 3 case too early.
This caused early stopping before the curriculum had time to mature.

Fix:

- Stage 3 now uses a six-phase curriculum:
  1. 2 lanes / 8 cars / right-on-red on
  2. 2 lanes / 10 cars / right-on-red on
  3. 2 lanes / 12 cars / right-on-red on
  4. 3 lanes / 10 cars / right-on-red on
  5. 3 lanes / 12 cars / right-on-red on
  6. 3 lanes / 14 cars / right-on-red on
- Stage 3 validation is phase-aware, so early stopping compares against the
  current curriculum difficulty rather than the final hard case.
- Stage 3 route sampling is biased toward right turns with
  `stage3_right_turn_probability = 0.45` so right-on-red appears more often.

Remaining issue:

- The latest Stage 3 best checkpoint still early-stopped at update 25, with the
  best validation at update 5. The easier right-on-red settings improved, but the
  hard 3-lane / 14-car setting is still below target.

#### Shield-on completion lower than shield-off

Some shield-on evaluations complete fewer vehicles than shield-off. This is not a
logging error. The shield prevents unsafe entries and collisions, but when the
policy repeatedly requests unsafe acceleration, the shield brakes/holds vehicles.
That improves safety metrics but increases waiting, queues, proximity exposure,
and timeout failures.

Fix attempted:

- Added shield dropout during Stage 2 and Stage 3 training so the policy sees
  some shield-off consequences.
- Added unsafe-request penalties and validation logging.

Remaining issue:

- The learned policy still depends too much on shield intervention in harder
  scenarios.

### 17.4 Graph Generation

A standard-library graph script is included at:

```bash
scripts/generate_graphs.py
```

Run from the project root:

```bash
python scripts/generate_graphs.py \
  --eval-csv results/evaluations.csv \
  --metrics-dir checkpoints \
  --out-dir graphs
```

It generates SVG figures for:

- Per-stage evaluation summaries.
- Combined shield-off stage comparison.
- Training reward, safety score, and shield-off validation score curves.

### 17.5 Current Recommendation

Do not move to Stage 4 yet. The next engineering target should be improving
Stage 2 and Stage 3 completion without increasing collision/proximity failures.
The most likely useful changes are:

- Improve timeout/blocked-traffic handling so the policy learns to keep traffic
  moving without shield intervention.
- Add a validation target that explicitly penalizes failed/timeout vehicles in
  addition to collision/red/proximity metrics.
- Increase Stage 3 patience only after Stage 2 reliably exceeds 75% shield-off
  completion.
- Consider training Stage 2 longer or with more stable reward shaping before
  re-running Stage 3.


## 18. Open Simulator Issues To Address Before Further Training

The following issues were observed during visual inspection of trained policies and should be treated as open simulator/training mechanics work. They are documented here so they are not lost while the new no-shield experiment is explored.

1. Queue movement at green is unrealistic. If three cars are in one lane, the first car may cross at green while the second waits near its initial spawn point instead of rolling forward continuously behind the lead vehicle.
2. Red-light stopping is unrealistic. Cars can stop in place when the light turns red; expected behavior is that the lead car stops before the stop line and following cars stop at safe spacing behind it.
3. Episode-end accounting is too harsh. Vehicles that do not reach the destination by timeout are currently marked as failed, while a separate incomplete state may be more accurate for reporting.
4. Some cars are stuck at initialization or are spawned close enough to create immediate collision/proximity problems.
5. The signal model needs a stronger yellow/all-red design. Desired behavior: red means stop, green means go, yellow means brake if still behind the stop line and continue safely if already crossed. Proposed timing was red 5 s, yellow 2 s, green 5 s, plus a 2 s all-red pause before the next green.
6. Lane mapping through the intersection needs tightening. Cars should not change lanes inside the intersection; left turns should map lane-to-lane, straight should map to the corresponding straight lane, and lane changes should only be allowed after clearing the intersection.
7. Some cars are too slow or start too late, reducing throughput and causing timeout failures.
8. Protected-left movement should be strict: left turns should use leftmost-to-leftmost lane behavior.
9. Training and validation are slow per update, so further optimization is needed before large curriculum runs.

These issues are separate from the safety-shield discussion. The new no-shield experiment intentionally avoids shield intervention, but it still inherits these simulator mechanics until they are fixed in the core environment.
