# No-Shield RL Curriculum Report - June 24, 2026

## Scope

This report documents the current no-safety-shield curriculum branch for `intersection_rl`. The manager direction is to avoid hard-coded safety action overrides and make PPO learn red-light stopping, queueing, front-gap behavior, proximity avoidance, collision avoidance, protected-left movement, and later right-on-red yield behavior from simulator dynamics and rewards.

The safety shield code still exists for comparison, but the no-shield scripts disable it:

- `safety_filter_enabled=False`
- `intersection_reservation_enabled=False`
- `safety_override_penalty=0.0`
- `unsafe_acceleration_penalty=0.0`
- evaluation shield actions remain `0`

## Current Curriculum Plan

1. Stage 1A: 2 lanes, 8-12 total cars, protected left, right-on-red off, 60s episodes.
2. Stage 1B: 2 lanes, 3-4 cars per lane, 24-32 total cars, protected left, right-on-red off, 120s episodes.
3. Stage 2A: right-on-red on, small/easy, many safe right-on-red examples.
4. Stage 2B: right-on-red on, explicit cross-traffic/yield examples.
5. Stage 2C: right-on-red on, 10-12 cars.
6. Stage 3: right-on-red on, 16-24+ cars.

Right-on-red should not be retried at high density until Stage 1B closed-signal stopping is reliable.

## Implemented Changes

### No-Shield Training Scripts

- `scripts/train_no_shield_rl.py`: protected-left, right-on-red-off no-shield training/evaluation. Now supports `--min-cars`, `--max-cars`, and `--validation-cars`.
- `scripts/train_no_shield_ror_stage.py`: right-on-red no-shield training/evaluation. Includes spawned-process parallel validation workers.

### Strict Lane Mapping

Strict lane mapping is enabled in staged no-shield training:

- left turn: leftmost lane to leftmost lane
- straight: same lane to same lane
- right turn: rightmost lane to rightmost lane

For protected-left no-right-turn stages, right turns are disabled with `right_turns_enabled=False`.

### Lane Centering And No Lateral Noise

No-shield scripts use zero initial lateral noise. The current `Vehicle.step()` resets lateral offset to zero each step, so vehicles remain lane-centered and no longer drift visually.

### Spawn Queue Fixes

Vehicle spawn is queue-based behind the stop line:

- first car starts about `spawn_lead_gap = 16m` before the stop line
- following cars use `spawn_queue_gap = 11.5m`, also respecting `vehicle_length + minimum_front_gap`

This removed the earlier random spawn merges and immediate spawn collisions.

### Outcome Matrix

Evaluation now separates:

- completed vehicles
- safety failed vehicles
- timeout incomplete vehicles
- stuck timeout vehicles
- unfinished timeout vehicles
- true incomplete vehicles

The environment still marks timeout vehicles as failed internally, but evaluation splits them into timeout/stuck/unfinished categories.

### Runtime Optimizations

Optimized predictive and proximity checks:

- skip non-conflicting routes
- skip exact same-lane future polygon checks
- require near-intersection relevance
- require time-to-conflict overlap
- use center-distance gate before polygon clearance
- use center-distance gate before proximity rectangle clearance

This made 50-episode evaluations practical again, but 32-car validation is still slow in `train_no_shield_rl.py` because it is serial.

### Legal Stall Tracking

Vehicle state now tracks:

- `legal_stall_seconds`: nearly stopped while movement is legally allowed and front gap is clear
- `blocked_stall_seconds`: stopped while blocked by signal/front/conflict

This supports better stuck classification and reward shaping.

### Queue-To-Stop-Line Reward

Closed-signal queue shaping was added. On red/yellow/closed signal, if front gap is clear:

- slow forward progress toward stop line is rewarded
- stopping about `1m-4m` before stop line is rewarded
- stopping too far back with clear lane is penalized
- entering too close to/beyond stop line is penalized
- overspeed approaching a closed stop line is penalized

This is reward shaping only. No hard action correction is applied.

### Right-On-Red Reward Correction

Legal right-on-red reward is applied only when the entry is not a right-yield violation. Illegal red/closed-signal crossing now uses `red_light_violation_penalty = 16.0`.

## Yellow Signal Handling

Yellow is treated as a closed signal for vehicles still before the stop line.

- before stop line during yellow: should brake/stop
- already crossed before yellow/red: may continue through
- crossing stop line during yellow: counted as `yellow_light_violations`
- crossing stop line during true red: counted as `red_light_violations`
- `closed_signal_violations` is the combined red + yellow count used for closed-signal target tracking

This split is important for interpreting results: true red violations and yellow entries are now reported separately in training and evaluation.

## Bugs / Issues And Fixes

### Safety Shield Defeated Pure RL Goal

Problem: shield overrode unsafe acceleration with braking/holding.

Fix: no-shield scripts disable shield and reservation so PPO actions are never replaced.

### Cars Left-Aligned / Lane Changes In Intersection

Problem: visual lane-center and mapping issues.

Fix: strict mapping, zero lateral noise, and centered vehicle dynamics.

### Spawn Merges / Immediate Collisions

Problem: vehicles spawned too close or overlapped.

Fix: queue-style spawn spacing behind stop line.

### Failed Metric Hid Timeout/Stuck

Problem: timeouts were counted as failures only.

Fix: eval matrix splits safety failure, timeout incomplete, stuck timeout, unfinished timeout.

### Full Eval Too Slow

Problem: high-density evals spent too much time on all-pairs polygon checks.

Fix: center-distance gates and predictive route/time gates.

### Right-On-Red Did Not Learn At High Density

Problem: high-density right-on-red stages either avoided right-on-red or increased illegal red crossings.

Cause: jump from 8-car protected-left to 16-24 car right-on-red was too large; right-on-red examples were noisy and mixed with high conflict pressure.

Fix so far: staged curriculum plan and legal-only right-on-red reward. More work needed in Stage 2A/2B.

### Cars Stopped Too Early On Red/Yellow

Problem: policy could stop in place far from stop line.

Cause: old reward mainly taught not crossing the stop line, not queueing toward it.

Fix: queue-to-stop-line reward shaping.

## Results

### Baseline No-Shield 2L/8 Strict Spawn

Checkpoint: `checkpoints/no_shield_2l8_strict_spawn_v1_best.npz`

Earlier 50-episode eval:

- completed: `100.00%`
- failed: `0.00%`
- collisions: `0`
- red violations: `0`
- proximity events: `0`

This was the initial checkpoint for early right-on-red attempts.

### Failed Right-On-Red v1

Checkpoint: `checkpoints/no_shield_2l_ror_120s_parallel_v1_best.npz`

10-episode eval:

- completed: `70.00%`
- failed: `30.00%`
- collisions: `0.40 / episode`
- red violations: `2.00 / episode`
- proximity events: `1.30 / episode`
- right-on-red entries: `0.00 / episode`
- timeout incomplete: `16.67%`
- stuck timeout vehicles: `35`

### Failed Right-On-Red v2

Checkpoint: `checkpoints/no_shield_2l_ror_120s_parallel_v2_best.npz`

50-episode eval:

- completed: `63.02%`
- failed: `36.98%`
- collisions: `0.20 / episode`
- red violations: `5.04 / episode`
- proximity events: `3.76 / episode`
- right-on-red entries: `0.32 / episode`

### Failed Right-On-Red v3

Checkpoint: `checkpoints/no_shield_2l_ror_120s_parallel_v3_best.npz`

50-episode eval:

- completed: `72.68%`
- failed: `27.32%`
- safety failed: `18.93%`
- timeout incomplete: `8.38%`
- stuck timeout: `8.19%`
- collisions: `0.44 / episode`
- red violations: `2.96 / episode`
- proximity events: `1.36 / episode`
- right-on-red entries: `0.00 / episode`

### Stage 1A: 2L / 8-12 Cars / Protected Left / ROR Off / 60s

Training command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py train \
  --steps 250000 \
  --episode-seconds 60 \
  --min-cars 8 \
  --max-cars 12 \
  --validation-cars 12 \
  --validation-episodes 20 \
  --checkpoint checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1.npz
```

Training:

- early stopped at update `120`
- best validation at update `40`
- checkpoint: `checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_best.npz`
- metrics: `checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_train_metrics.csv`

Evaluation command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py evaluate \
  checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_best.npz \
  --episodes 50 \
  --episode-seconds 60 \
  --min-cars 8 \
  --max-cars 12 \
  --output-csv results/no_shield_2l8to12_queue_reward_stage1_60s_v1_eval_50ep.csv
```

50-episode eval:

- mean spawned: `10.10`
- total vehicles: `505`
- completed: `87.92%`
- failed: `12.08%`
- collisions: `0.12 / episode`
- red/closed-signal violations: `0.98 / episode`
- proximity events: `0.24 / episode`
- timeout incomplete: `0`
- stuck timeout: `0`
- shield actions: `0`

Interpretation: good protected-left no-shield stage.

### Stage 1B: 2L / 3-4 Cars Per Lane / 24-32 Cars / Protected Left / ROR Off / 120s

First command used 20 validation episodes but was interrupted during slow update-40 validation. Restarted with 8 validation episodes.

Restart command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py train \
  --steps 250000 \
  --episode-seconds 120 \
  --min-cars 24 \
  --max-cars 32 \
  --validation-cars 32 \
  --validation-episodes 8 \
  --checkpoint checkpoints/no_shield_2l24to32_queue_reward_stage1_120s_v2.npz \
  --init-checkpoint checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_best.npz
```

Training:

- initialized from Stage 1A best checkpoint
- early stopped at update `150`
- best validation at update `70`
- checkpoint: `checkpoints/no_shield_2l24to32_queue_reward_stage1_120s_v2_best.npz`
- metrics: `checkpoints/no_shield_2l24to32_queue_reward_stage1_120s_v2_train_metrics.csv`

Evaluation command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py evaluate \
  checkpoints/no_shield_2l24to32_queue_reward_stage1_120s_v2_best.npz \
  --episodes 50 \
  --episode-seconds 120 \
  --min-cars 24 \
  --max-cars 32 \
  --output-csv results/no_shield_2l24to32_queue_reward_stage1_120s_v2_eval_50ep.csv
```

50-episode eval:

- mean spawned: `28.28`
- total vehicles: `1414`
- completed: `73.55%`
- failed: `26.45%`
- collisions: `0.66 / episode`
- red/closed-signal violations: `6.16 / episode`
- proximity events: `2.74 / episode`
- timeout incomplete: `0`
- stuck timeout: `0`
- shield actions: `0`

Interpretation: completion is close to target and collisions/proximity/stuck are acceptable, but closed-signal violations are too high. Do not move to right-on-red yet.

## Current Test Status

After current changes:

```text
63 passed, 1 warning
```

The warning is from pygame/pkg_resources deprecation.

## Recommended Next Work

Before additional right-on-red training:

1. Strengthen closed-signal stopping for dense 24-32 car traffic.
2. Add separate yellow vs red violation counters or rename the metric to closed-signal violations.
3. Add parallel validation to `scripts/train_no_shield_rl.py`; 32-car validation is currently too slow.
4. Consider an intermediate density step between 12 and 32 cars, such as 12-16, 16-24, then 24-32.
5. Re-evaluate Stage 1B after closed-signal fix before enabling right-on-red.

## Package Contents

The package includes:

- current source code in `intersection_rl/`
- current training/evaluation scripts in `scripts/`
- tests in `tests/`
- README and reports
- selected no-shield checkpoints and training metrics
- selected no-shield evaluation CSVs
- graph-generation script and existing SVG graphs
- package manifest

## Latest Stage 1/2 Graph And Stage 1B v3 Update

After strengthening dense closed-signal stopping and adding parallel validation, Stage 1B was retrained as v3.

Training command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py train \
  --steps 250000 \
  --episode-seconds 120 \
  --min-cars 24 \
  --max-cars 32 \
  --validation-cars 32 \
  --validation-episodes 8 \
  --validation-workers 4 \
  --closed-signal-profile dense \
  --checkpoint checkpoints/no_shield_2l24to32_closed_signal_stage1b_120s_v3.npz \
  --init-checkpoint checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_best.npz
```

Training result:

- initialized from Stage 1A best checkpoint
- early stopped at update `180`
- best validation checkpoint selected at update `100`
- checkpoint: `checkpoints/no_shield_2l24to32_closed_signal_stage1b_120s_v3_best.npz`
- metrics: `checkpoints/no_shield_2l24to32_closed_signal_stage1b_120s_v3_train_metrics.csv`

Evaluation command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py evaluate \
  checkpoints/no_shield_2l24to32_closed_signal_stage1b_120s_v3_best.npz \
  --episodes 50 \
  --episode-seconds 120 \
  --min-cars 24 \
  --max-cars 32 \
  --closed-signal-profile dense \
  --output-csv results/no_shield_2l24to32_closed_signal_stage1b_120s_v3_eval_50ep.csv
```

50-episode eval:

- mean spawned: `28.28`
- total vehicles: `1414`
- completed: `72.35%`
- failed: `27.65%`
- incomplete: `0.00%`
- safety failed: `27.44%`
- timeout incomplete vehicles: `3`
- stuck timeout vehicles: `3`
- unfinished timeout vehicles: `0`
- collisions: `2.48 / episode`
- proximity events: `13.82 / episode`
- true red violations: `2.72 / episode`
- yellow violations: `0.08 / episode`
- closed-signal violations: `2.80 / episode`
- shield actions: `0`

Interpretation: v3 reduced closed-signal violations compared with Stage 1B v2 (`6.16 / episode` to `2.80 / episode`), but collisions and proximity worsened (`0.66` to `2.48` collisions/episode and `2.74` to `13.82` proximity events/episode). This checkpoint is useful evidence for the graph/report, but it is not a better demo checkpoint than v2. Do not move to right-on-red yet.

Yellow signal handling is now split in metrics:

- `red_light_violations`: true red stop-line entries
- `yellow_light_violations`: yellow stop-line entries
- `closed_signal_violations`: red + yellow, used for closed-signal target tracking

Generated graph files:

- `graphs/no_shield_stage1_stage2/stage1_stage2_eval_summary.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_outcome_matrix.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_validation_scores.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_safety_scores.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_closed_signal.svg`

Current test status after these code changes:

```text
64 passed, 1 warning
```

## Latest Randomized-Signal Curriculum Update - June 24, 2026

Randomized initial signal phase was added through `randomize_initial_signal_phase=True` in closed-signal reward profiles. This prevents the policy from relying on the fixed episode start phase and forces it to observe the signal state. The fixed-start Stage 1A result was strong, but random signal starts exposed a real weakness: the policy had learned timing regularity instead of fully robust red/yellow stopping.

### Stage 1B v4: Dense-Balanced 16-24 Cars From Stage 1A

Training command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py train \
  --steps 180000 \
  --episode-seconds 120 \
  --min-cars 16 \
  --max-cars 24 \
  --validation-cars 24 \
  --validation-episodes 8 \
  --validation-workers 4 \
  --closed-signal-profile dense_balanced \
  --checkpoint checkpoints/no_shield_2l16to24_dense_balanced_stage1b_mid_120s_v4.npz \
  --init-checkpoint checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_best.npz
```

Evaluation command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py evaluate \
  checkpoints/no_shield_2l16to24_dense_balanced_stage1b_mid_120s_v4_best.npz \
  --episodes 50 \
  --episode-seconds 120 \
  --min-cars 16 \
  --max-cars 24 \
  --closed-signal-profile dense_balanced \
  --output-csv results/no_shield_2l16to24_dense_balanced_stage1b_mid_120s_v4_eval_50ep.csv
```

50-episode eval:

- mean spawned: `20.28`
- completed: `76.13%`
- failed: `23.87%`
- incomplete: `0.00%`
- collisions: `0.14 / episode`
- proximity events: `0.56 / episode`
- true red violations: `4.48 / episode`
- yellow violations: `0.08 / episode`
- closed-signal violations: `4.56 / episode`
- shield actions: `0`

Interpretation: good completion/collision/proximity for 16-24 cars, but red/closed-signal violations are still too high.

### Stage 1B v5: Randomized-Signal Drill 16-24 Cars From Stage 1A

Training command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py train \
  --steps 180000 \
  --episode-seconds 120 \
  --min-cars 16 \
  --max-cars 24 \
  --validation-cars 24 \
  --validation-episodes 8 \
  --validation-workers 4 \
  --closed-signal-profile dense_balanced_signal \
  --checkpoint checkpoints/no_shield_2l16to24_signal_drill_from_stage1a_120s_v5.npz \
  --init-checkpoint checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_best.npz
```

Evaluation command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py evaluate \
  checkpoints/no_shield_2l16to24_signal_drill_from_stage1a_120s_v5_best.npz \
  --episodes 50 \
  --episode-seconds 120 \
  --min-cars 16 \
  --max-cars 24 \
  --closed-signal-profile dense_balanced_signal \
  --output-csv results/no_shield_2l16to24_signal_drill_from_stage1a_120s_v5_eval_50ep.csv
```

50-episode eval:

- completed: `64.86%`
- failed: `35.14%`
- incomplete: `0.00%`
- collisions: `0.22 / episode`
- proximity events: `11.78 / episode`
- true red violations: `5.00 / episode`
- yellow violations: `1.70 / episode`
- closed-signal violations: `6.70 / episode`
- shield actions: `0`

Interpretation: direct randomized-signal drilling from fixed-start Stage 1A made performance worse. The curriculum jump was still too hard.

### Stage 1R: Randomized-Signal 8-12 Cars From Scratch

Training command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py train \
  --steps 160000 \
  --episode-seconds 90 \
  --min-cars 8 \
  --max-cars 12 \
  --validation-cars 12 \
  --validation-episodes 20 \
  --validation-workers 4 \
  --closed-signal-profile dense_balanced_signal \
  --learning-rate 0.00015 \
  --update-epochs 4 \
  --target-kl 0.01 \
  --validation-patience 8 \
  --checkpoint checkpoints/no_shield_2l8to12_signal_random_from_scratch_90s_1r_v1.npz
```

Evaluation command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py evaluate \
  checkpoints/no_shield_2l8to12_signal_random_from_scratch_90s_1r_v1_best.npz \
  --episodes 50 \
  --episode-seconds 90 \
  --min-cars 8 \
  --max-cars 12 \
  --closed-signal-profile dense_balanced_signal \
  --output-csv results/no_shield_2l8to12_signal_random_from_scratch_90s_1r_v1_eval_50ep.csv
```

50-episode eval:

- completed: `21.40%`
- failed: `78.60%`
- incomplete: `0.00%`
- collisions: `0.44 / episode`
- proximity events: `1.92 / episode`
- true red violations: `6.32 / episode`
- yellow violations: `0.88 / episode`
- closed-signal violations: `7.20 / episode`
- shield actions: `0`

Interpretation: the scratch 8-12 randomized-signal run collapsed into poor signal behavior and low completion. More data did not automatically improve the policy because PPO can move into a conservative or unsafe local optimum when reward terms conflict.

### Stage 1R Easy: Randomized-Signal 4-6 Cars From Scratch

Training command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py train \
  --steps 160000 \
  --episode-seconds 60 \
  --min-cars 4 \
  --max-cars 6 \
  --validation-cars 6 \
  --validation-episodes 20 \
  --validation-workers 4 \
  --closed-signal-profile signal_easy_progress \
  --learning-rate 0.00015 \
  --update-epochs 4 \
  --target-kl 0.01 \
  --validation-patience 8 \
  --checkpoint checkpoints/no_shield_2l4to6_signal_easy_progress_60s_1r_v1.npz
```

Training result:

- early stopped at update `140`
- best validation checkpoint selected at update `60`
- checkpoint: `checkpoints/no_shield_2l4to6_signal_easy_progress_60s_1r_v1_best.npz`
- metrics: `checkpoints/no_shield_2l4to6_signal_easy_progress_60s_1r_v1_train_metrics.csv`

Evaluation command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py evaluate \
  checkpoints/no_shield_2l4to6_signal_easy_progress_60s_1r_v1_best.npz \
  --episodes 50 \
  --episode-seconds 60 \
  --min-cars 4 \
  --max-cars 6 \
  --closed-signal-profile signal_easy_progress \
  --output-csv results/no_shield_2l4to6_signal_easy_progress_60s_1r_v1_eval_50ep.csv
```

50-episode eval:

- mean spawned: `5.12`
- total vehicles: `256`
- completed: `44.14%`
- failed: `55.86%`
- incomplete: `0.00%`
- safety failed: `13.28%`
- timeout incomplete vehicles: `109` (`42.58%`)
- stuck timeout vehicles: `92` (`35.94%`)
- unfinished timeout vehicles: `17` (`6.64%`)
- collisions: `0.00 / episode`
- proximity events: `0.00 / episode`
- true red violations: `0.40 / episode`
- yellow violations: `0.28 / episode`
- closed-signal violations: `0.68 / episode`
- shield actions: `0`

90-second diagnostic eval did not improve completion: completion stayed `44.14%`, while closed-signal violations increased to `1.44 / episode`. This means the failure is not simply episode length; the policy learned to wait too much and many vehicles time out/stuck.

Interpretation: the easy randomized run solved collisions, proximity, and most red/yellow behavior, but completion is far below target. The next fix should rebalance progress/green movement versus closed-signal caution rather than just training longer.

## Graph Generation Commands

Regenerate the current no-shield Stage 1/Stage 1B/randomized-signal comparison graphs from saved CSV files:

```bash
.venv/bin/python scripts/generate_stage1_stage2_graphs.py
```

This writes:

- `graphs/no_shield_stage1_stage2/stage1_stage2_eval_summary.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_outcome_matrix.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_validation_scores.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_safety_scores.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_closed_signal.svg`

Regenerate the older shield-on/shield-off stage graphs, if those CSVs are present:

```bash
.venv/bin/python scripts/generate_graphs.py --results-dir results --checkpoints-dir checkpoints --output-dir graphs
```

The current package includes the regenerated no-shield SVGs and all CSV/checkpoint inputs needed for the latest no-shield graphs.

## Current Recommendation

Do not move to right-on-red yet. The current bottleneck is randomized-signal protected-left behavior without the safety shield. The next training change should keep the 4-6 or 6-8 car randomized-signal setup and make legal green progress/completion stronger while preventing the policy from avoiding motion. Once completion is above target on randomized signals, scale back toward 8-12 cars and then 16-24 cars.
