# Intersection RL No-Shield Curriculum Package

This package contains the latest no-shield curriculum code, selected checkpoints, evaluation results, reports, and graph assets.

Start with `NO_SHIELD_CURRICULUM_REPORT.md` for the current training history, bugs/fixes, commands, metrics, and interpretation.

Regenerate the latest no-shield comparison graphs with:

```bash
.venv/bin/python scripts/generate_stage1_stage2_graphs.py
```

The latest added experiments are Stage 1B v4/v5 and Stage 1R randomized-signal runs. The current bottleneck is low completion under randomized signal starts without the safety shield.
