# Package Manifest

Package: `intersection-rl-no-shield-curriculum-2026-06-24`

Updated: June 24, 2026

## Contents

- Latest source code: `intersection_rl/`
- Training/evaluation scripts: `scripts/`
- Tests: `tests/`
- Reports: `README.md`, `REPORT.md`, `NO_SHIELD_RL_REPORT.md`, `NO_SHIELD_CURRICULUM_REPORT.md`
- Graphs: `graphs/no_shield_stage1_stage2/`

## Selected Checkpoints And Training Metrics

- Stage 1A fixed-start 8-12 cars:
  - `checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_best.npz`
  - `checkpoints/no_shield_2l8to12_queue_reward_stage1_60s_v1_train_metrics.csv`
- Stage 1B v2 fixed-start 24-32 cars:
  - `checkpoints/no_shield_2l24to32_queue_reward_stage1_120s_v2_best.npz`
  - `checkpoints/no_shield_2l24to32_queue_reward_stage1_120s_v2_train_metrics.csv`
- Stage 1B v3 dense-stop 24-32 cars:
  - `checkpoints/no_shield_2l24to32_closed_signal_stage1b_120s_v3_best.npz`
  - `checkpoints/no_shield_2l24to32_closed_signal_stage1b_120s_v3_train_metrics.csv`
- Stage 1B v4 dense-balanced 16-24 cars:
  - `checkpoints/no_shield_2l16to24_dense_balanced_stage1b_mid_120s_v4_best.npz`
  - `checkpoints/no_shield_2l16to24_dense_balanced_stage1b_mid_120s_v4_train_metrics.csv`
- Stage 1B v5 randomized-signal drill 16-24 cars:
  - `checkpoints/no_shield_2l16to24_signal_drill_from_stage1a_120s_v5_best.npz`
  - `checkpoints/no_shield_2l16to24_signal_drill_from_stage1a_120s_v5_train_metrics.csv`
- Stage 1R randomized-signal 8-12 cars from scratch:
  - `checkpoints/no_shield_2l8to12_signal_random_from_scratch_90s_1r_v1_best.npz`
  - `checkpoints/no_shield_2l8to12_signal_random_from_scratch_90s_1r_v1_train_metrics.csv`
- Stage 1R easy randomized-signal 4-6 cars from scratch:
  - `checkpoints/no_shield_2l4to6_signal_easy_progress_60s_1r_v1_best.npz`
  - `checkpoints/no_shield_2l4to6_signal_easy_progress_60s_1r_v1_train_metrics.csv`

## Evaluation CSVs

- `results/no_shield_2l8to12_queue_reward_stage1_60s_v1_eval_50ep.csv`
- `results/no_shield_2l24to32_queue_reward_stage1_120s_v2_eval_50ep.csv`
- `results/no_shield_2l24to32_closed_signal_stage1b_120s_v3_eval_50ep.csv`
- `results/no_shield_2l16to24_dense_balanced_stage1b_mid_120s_v4_eval_50ep.csv`
- `results/no_shield_2l16to24_signal_drill_from_stage1a_120s_v5_eval_50ep.csv`
- `results/no_shield_2l8to12_signal_random_from_scratch_90s_1r_v1_eval_50ep.csv`
- `results/no_shield_2l4to6_signal_easy_progress_60s_1r_v1_eval_50ep.csv`
- `results/no_shield_2l4to6_signal_easy_progress_90s_1r_v1_eval_50ep.csv`

## Graph Files

- `graphs/no_shield_stage1_stage2/stage1_stage2_eval_summary.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_outcome_matrix.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_validation_scores.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_safety_scores.svg`
- `graphs/no_shield_stage1_stage2/stage1_stage2_training_closed_signal.svg`

## Graph Generation Commands

Regenerate current no-shield graphs from saved CSVs:

```bash
.venv/bin/python scripts/generate_stage1_stage2_graphs.py
```

Regenerate older shield-on/shield-off graphs if the corresponding CSVs are present:

```bash
.venv/bin/python scripts/generate_graphs.py --results-dir results --checkpoints-dir checkpoints --output-dir graphs
```

Latest verified test status: `64 passed, 1 warning`.
