#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

STAGE_POLICIES = {
    "stage1": "stage1_lane4_centered_v4_best.npz",
    "stage2": "stage2_lane4_centered_v4_best.npz",
    "stage3": "stage3_lane4_centered_v6_best.npz",
}
TRAINING_FILES = {
    "stage1": "stage1_lane4_centered_v4_train_metrics.csv",
    "stage2": "stage2_lane4_centered_v4_train_metrics.csv",
    "stage3": "stage3_lane4_centered_v6_train_metrics.csv",
}
NO_SHIELD_TRAINING_FILE = "no_shield_2l8_protected_train_metrics.csv"
EVAL_METRICS = [
    ("completed_pct", "Completed %", "%"),
    ("collisions_per_ep", "Collisions / ep", ""),
    ("red_violations_per_ep", "Red violations / ep", ""),
    ("proximity_events_per_ep", "Proximity events / ep", ""),
]
TRAIN_METRICS = [
    ("rollout_mean_reward", "Mean reward"),
    ("safety_score", "Safety score"),
    ("validation_score_off", "Validation score off"),
]


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="") as file:
        return list(csv.DictReader(file))


def as_float(row: dict[str, str], key: str, default: float = 0.0) -> float:
    value = row.get(key, "")
    if value == "":
        return default
    try:
        return float(value)
    except ValueError:
        return default


def esc(text: object) -> str:
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def write_bar_svg(path: Path, title: str, groups: list[tuple[str, dict[str, float]]], metrics=EVAL_METRICS) -> None:
    width = 980
    row_h = 88
    top = 80
    left = 220
    chart_w = 650
    height = top + len(groups) * len(metrics) * row_h + 70
    colors = {"off": "#31688e", "on": "#35b779"}
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        f'<text x="{width/2}" y="36" text-anchor="middle" font-family="Arial" font-size="24" font-weight="700">{esc(title)}</text>',
    ]
    y = top
    for group, values in groups:
        parts.append(f'<text x="20" y="{y + 24}" font-family="Arial" font-size="16" font-weight="700">{esc(group)}</text>')
        for key, label, suffix in metrics:
            off = values.get(f"{key}:off")
            on = values.get(f"{key}:on")
            vals = [v for v in (off, on) if v is not None]
            max_val = max(vals + [1.0])
            if key == "completed_pct":
                max_val = 100.0
            elif max_val < 2.0 and "per_ep" in key:
                max_val = 2.0
            parts.append(f'<text x="40" y="{y + 52}" font-family="Arial" font-size="13">{esc(label)}</text>')
            for idx, mode in enumerate(("off", "on")):
                val = off if mode == "off" else on
                if val is None:
                    continue
                bar_y = y + 18 + idx * 26
                bar_w = 0 if max_val <= 0 else min(chart_w, chart_w * val / max_val)
                parts.append(f'<rect x="{left}" y="{bar_y}" width="{chart_w}" height="18" fill="#edf1f4"/>')
                parts.append(f'<rect x="{left}" y="{bar_y}" width="{bar_w:.1f}" height="18" fill="{colors[mode]}"/>')
                parts.append(f'<text x="{left - 38}" y="{bar_y + 14}" font-family="Arial" font-size="12" text-anchor="end">{mode}</text>')
                parts.append(f'<text x="{left + bar_w + 8:.1f}" y="{bar_y + 14}" font-family="Arial" font-size="12">{val:.2f}{suffix}</text>')
            y += row_h
    parts.append('</svg>')
    path.write_text("\n".join(parts))


def write_line_svg(path: Path, title: str, series: list[tuple[str, list[tuple[float, float]]]]) -> None:
    width, height = 980, 520
    left, right, top, bottom = 80, 30, 70, 70
    chart_w = width - left - right
    chart_h = height - top - bottom
    points = [p for _, pts in series for p in pts if math.isfinite(p[1])]
    if not points:
        path.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"><text x="20" y="40">No data for {esc(title)}</text></svg>')
        return
    min_x = min(p[0] for p in points)
    max_x = max(p[0] for p in points)
    min_y = min(p[1] for p in points)
    max_y = max(p[1] for p in points)
    if min_x == max_x:
        max_x += 1.0
    if min_y == max_y:
        min_y -= 1.0
        max_y += 1.0
    pad_y = (max_y - min_y) * 0.08
    min_y -= pad_y
    max_y += pad_y
    colors = ["#31688e", "#35b779", "#fde725", "#443983"]

    def sx(x: float) -> float:
        return left + (x - min_x) / (max_x - min_x) * chart_w

    def sy(y: float) -> float:
        return top + chart_h - (y - min_y) / (max_y - min_y) * chart_h

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        f'<text x="{width/2}" y="36" text-anchor="middle" font-family="Arial" font-size="24" font-weight="700">{esc(title)}</text>',
        f'<rect x="{left}" y="{top}" width="{chart_w}" height="{chart_h}" fill="#f8fafb" stroke="#c8d0d8"/>',
    ]
    for i in range(6):
        y_val = min_y + (max_y - min_y) * i / 5
        y = sy(y_val)
        parts.append(f'<line x1="{left}" y1="{y:.1f}" x2="{left + chart_w}" y2="{y:.1f}" stroke="#e1e7ec"/>')
        parts.append(f'<text x="{left - 8}" y="{y + 4:.1f}" text-anchor="end" font-family="Arial" font-size="11">{y_val:.1f}</text>')
    for idx, (name, pts) in enumerate(series):
        clean = [(x, y) for x, y in pts if math.isfinite(y)]
        if not clean:
            continue
        color = colors[idx % len(colors)]
        coords = " ".join(f"{sx(x):.1f},{sy(y):.1f}" for x, y in clean)
        parts.append(f'<polyline points="{coords}" fill="none" stroke="{color}" stroke-width="2.5"/>')
        lx = left + 15 + idx * 210
        parts.append(f'<rect x="{lx}" y="{height - 42}" width="18" height="12" fill="{color}"/>')
        parts.append(f'<text x="{lx + 24}" y="{height - 31}" font-family="Arial" font-size="13">{esc(name)}</text>')
    parts.append(f'<text x="{width/2}" y="{height - 12}" text-anchor="middle" font-family="Arial" font-size="12">Update</text>')
    parts.append('</svg>')
    path.write_text("\n".join(parts))


def latest_rows_by_stage(rows: list[dict[str, str]]) -> dict[str, dict[str, dict[str, float]]]:
    selected: dict[str, dict[str, dict[str, float]]] = {}
    for stage, policy_name in STAGE_POLICIES.items():
        stage_rows = [r for r in rows if r.get("policy", "").endswith(policy_name)]
        by_label: dict[str, dict[str, float]] = {}
        for r in stage_rows:
            mode = r.get("safety_shield", "off")
            label = f'{r.get("lanes")}L/{r.get("cars")} cars'
            by_label[f"{label}:{mode}"] = {metric: as_float(r, metric) for metric, _, _ in EVAL_METRICS}
        selected[stage] = by_label
    return selected


def make_eval_graphs(eval_csv: Path, out_dir: Path) -> None:
    rows = read_csv(eval_csv)
    out_dir.mkdir(parents=True, exist_ok=True)
    selected = latest_rows_by_stage(rows)
    combined_groups = []
    for stage, rows_by_label in selected.items():
        labels = sorted({k.rsplit(":", 1)[0] for k in rows_by_label})
        groups = []
        for label in labels:
            values = {}
            for mode in ("off", "on"):
                metrics = rows_by_label.get(f"{label}:{mode}", {})
                for metric, _, _ in EVAL_METRICS:
                    if metric in metrics:
                        values[f"{metric}:{mode}"] = metrics[metric]
            groups.append((label, values))
            off_metrics = rows_by_label.get(f"{label}:off")
            if off_metrics:
                combined_groups.append((f"{stage} {label}", {f"{m}:off": off_metrics[m] for m, _, _ in EVAL_METRICS if m in off_metrics}))
        if groups:
            write_bar_svg(out_dir / f"eval_{stage}.svg", f"{stage.upper()} Evaluation", groups)
    if combined_groups:
        write_bar_svg(out_dir / "eval_all_stages_shield_off.svg", "All Stages Shield-Off Evaluation", combined_groups)



def write_matrix_svg(path: Path, title: str, rows: list[tuple[str, float, float]]) -> None:
    width = 980
    row_h = 46
    top = 82
    left = 270
    chart_w = 560
    height = top + row_h * len(rows) + 70
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        f'<text x="{width/2}" y="36" text-anchor="middle" font-family="Arial" font-size="24" font-weight="700">{esc(title)}</text>',
        f'<text x="{left}" y="64" font-family="Arial" font-size="12" font-weight="700">Vehicles</text>',
        f'<text x="{left + chart_w + 24}" y="64" font-family="Arial" font-size="12" font-weight="700">Pct</text>',
    ]
    max_count = max([count for _, count, _ in rows] + [1.0])
    colors = ["#31688e", "#440154", "#f28e2b", "#b5bd00", "#8c8c8c"]
    for idx, (label, count, pct) in enumerate(rows):
        y = top + idx * row_h
        bar_w = chart_w * count / max_count if max_count > 0 else 0.0
        color = colors[idx % len(colors)]
        parts.append(f'<text x="24" y="{y + 24}" font-family="Arial" font-size="14">{esc(label)}</text>')
        parts.append(f'<rect x="{left}" y="{y + 8}" width="{chart_w}" height="22" fill="#edf1f4"/>')
        parts.append(f'<rect x="{left}" y="{y + 8}" width="{bar_w:.1f}" height="22" fill="{color}"/>')
        parts.append(f'<text x="{left + bar_w + 8:.1f}" y="{y + 24}" font-family="Arial" font-size="13">{count:.0f}</text>')
        parts.append(f'<text x="{left + chart_w + 24}" y="{y + 24}" font-family="Arial" font-size="13">{pct:.2f}%</text>')
    parts.append('</svg>')
    path.write_text("\n".join(parts))


def latest_row(rows: list[dict[str, str]]) -> dict[str, str] | None:
    return rows[-1] if rows else None


def make_no_shield_graphs(
    metrics_dir: Path,
    eval_csv: Path,
    out_dir: Path,
    training_csv: Path | None = None,
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    metrics_path = training_csv if training_csv is not None else metrics_dir / NO_SHIELD_TRAINING_FILE
    rows = read_csv(metrics_path)
    if rows:
        outcome_series = []
        for key, label in [
            ("completed_clean", "Completed"),
            ("failed", "Failed"),
            ("red", "Red violations"),
            ("collisions", "Collisions"),
            ("proximity_events", "Proximity events"),
        ]:
            pts = [(as_float(r, "update"), as_float(r, key, float("nan"))) for r in rows]
            outcome_series.append((label, pts))
        write_line_svg(
            out_dir / "no_shield_training_outcomes.svg",
            "No-Shield Training Outcomes: Improvement Then Collapse",
            outcome_series,
        )
        score_series = []
        for key, label in [
            ("safety_score", "Rollout safety score"),
            ("validation_score_off", "Validation score"),
            ("best_validation_score", "Best validation score"),
        ]:
            pts = [
                (as_float(r, "update"), as_float(r, key, float("nan")))
                for r in rows
                if r.get(key, "") != ""
            ]
            if pts:
                score_series.append((label, pts))
        write_line_svg(
            out_dir / "no_shield_training_scores.svg",
            "No-Shield Training Scores: Best Window And Collapse",
            score_series,
        )
    eval_rows = read_csv(eval_csv)
    row = latest_row(eval_rows)
    if row:
        episodes = as_float(row, "episodes", 1.0)
        cars = as_float(row, "cars", 8.0)
        total = max(episodes * cars, 1.0)
        completed = as_float(row, "completed_vehicles", as_float(row, "mean_completed") * episodes)
        safety_failed = as_float(row, "safety_failed_vehicles", as_float(row, "mean_failed") * episodes)
        timeout = as_float(row, "timeout_incomplete_vehicles", 0.0)
        true_incomplete = as_float(row, "true_incomplete_vehicles", as_float(row, "mean_incomplete") * episodes)
        stuck = as_float(row, "stuck_timeout_vehicles", 0.0)
        unfinished = as_float(row, "unfinished_timeout_vehicles", 0.0)
        matrix_rows = [
            ("Completed clean", completed, 100.0 * completed / total),
            ("Safety failed", safety_failed, 100.0 * safety_failed / total),
            ("Timeout / not finished", timeout, 100.0 * timeout / total),
            ("Timeout stuck", stuck, 100.0 * stuck / total),
            ("Timeout still moving", unfinished, 100.0 * unfinished / total),
            ("Still active incomplete", true_incomplete, 100.0 * true_incomplete / total),
        ]
        write_matrix_svg(
            out_dir / "no_shield_outcome_matrix.svg",
            "No-Shield Evaluation Outcome Matrix",
            matrix_rows,
        )


def make_training_graphs(metrics_dir: Path, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    for stage, filename in TRAINING_FILES.items():
        rows = read_csv(metrics_dir / filename)
        if not rows:
            continue
        for metric, title in TRAIN_METRICS:
            pts = [(as_float(r, "update"), as_float(r, metric, float("nan"))) for r in rows if r.get(metric, "") != ""]
            write_line_svg(out_dir / f"training_{stage}_{metric}.svg", f"{stage.upper()} {title}", [(stage, pts)])
    for metric, title in TRAIN_METRICS:
        series = []
        for stage, filename in TRAINING_FILES.items():
            rows = read_csv(metrics_dir / filename)
            pts = [(as_float(r, "update"), as_float(r, metric, float("nan"))) for r in rows if r.get(metric, "") != ""]
            if pts:
                series.append((stage, pts))
        if series:
            write_line_svg(out_dir / f"training_all_{metric}.svg", f"All Stages {title}", series)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate SVG graphs from Intersection RL evaluation and training CSV files.")
    parser.add_argument("--eval-csv", type=Path, default=Path("results/evaluations.csv"))
    parser.add_argument("--metrics-dir", type=Path, default=Path("checkpoints"))
    parser.add_argument("--out-dir", type=Path, default=Path("graphs"))
    parser.add_argument("--no-shield-eval-csv", type=Path, default=Path("results/no_shield_2l8_evaluations.csv"))
    parser.add_argument("--no-shield-training-csv", type=Path)
    args = parser.parse_args()
    make_eval_graphs(args.eval_csv, args.out_dir)
    make_training_graphs(args.metrics_dir, args.out_dir)
    make_no_shield_graphs(
        args.metrics_dir,
        args.no_shield_eval_csv,
        args.out_dir,
        args.no_shield_training_csv,
    )
    print(f"graphs written to {args.out_dir}")


if __name__ == "__main__":
    main()
