#!/usr/bin/env python3
"""Train/evaluate the no-shield right-on-red stage.

Scenario: 2 lanes per approach, 2-3 cars per lane across four approaches
(16-24 total cars), protected left, right-on-red enabled, no safety shield.
"""

from __future__ import annotations

import argparse
import csv
import multiprocessing as mp
import os
import tempfile
from concurrent.futures import ProcessPoolExecutor
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from intersection_rl.config import EnvConfig, PPOConfig
from intersection_rl.env import IntersectionEnv
from intersection_rl.ppo import PPOTrainer, SharedActorCritic
from train_no_shield_rl import append_csv_row, load_model


DEFAULT_CHECKPOINT = Path("checkpoints/no_shield_2l_ror_2to3_per_lane.npz")
DEFAULT_EVAL_CSV = Path("results/no_shield_2l_ror_2to3_per_lane_evaluations.csv")
DEFAULT_INIT = Path("checkpoints/no_shield_2l8_strict_spawn_v1_best.npz")


class NoShieldRorEnv(IntersectionEnv):
    pass


def empty_validation_metrics(episodes: int, cars: int) -> dict[str, float]:
    return {
        "completed_clean": 0.0,
        "failed": 0.0,
        "collisions": 0.0,
        "proximity": 0.0,
        "proximity_events": 0.0,
        "red": 0.0,
        "yellow": 0.0,
        "closed_signal": 0.0,
        "left_yield": 0.0,
        "right_yield": 0.0,
        "safety_overrides": 0.0,
        "unsafe_requests": 0.0,
        "progress": 0.0,
        "env_steps": 0.0,
        "active_action_samples": 0.0,
        "episodes": float(episodes),
        "cars": float(cars),
    }


def run_validation_worker(
    validation_config: EnvConfig,
    checkpoint_path: str,
    hidden_size: int,
    seed_base: int,
    episode_indices: list[int],
    total_episodes: int,
    cars: int,
) -> dict[str, float]:
    env = NoShieldRorEnv(validation_config)
    model = load_model(env, Path(checkpoint_path), hidden_size)
    metrics = empty_validation_metrics(total_episodes, cars)
    try:
        for episode in episode_indices:
            observation, info = env.reset(seed=seed_base + episode)
            done = False
            while not done:
                actions, _, _ = model.act(observation, deterministic=True)
                observation, _, terminated, truncated, info = env.step(actions)
                metrics["collisions"] += float(info.get("collisions", 0))
                metrics["proximity"] += float(info.get("proximity_violations", 0))
                metrics["proximity_events"] += float(info.get("proximity_events", 0))
                metrics["red"] += float(info.get("red_light_violations", 0))
                metrics["yellow"] += float(info.get("yellow_light_violations", 0))
                metrics["closed_signal"] += float(info.get("closed_signal_violations", info.get("red_light_violations", 0)))
                metrics["left_yield"] += float(info.get("left_yield_violations", 0))
                metrics["right_yield"] += float(info.get("right_yield_violations", 0))
                metrics["safety_overrides"] += float(info.get("safety_overrides", 0))
                metrics["unsafe_requests"] += float(info.get("unsafe_requests", 0))
                metrics["progress"] += float(info.get("progress_delta", 0.0))
                metrics["env_steps"] += 1.0
                metrics["active_action_samples"] += float(
                    info.get("active_mask", np.zeros(cars)).sum()
                )
                done = terminated or truncated
            metrics["completed_clean"] += float(info.get("completed_clean", 0))
            metrics["failed"] += float(info.get("failed_vehicles", 0))
    finally:
        env.close()
    return metrics


class NoShieldRorTrainer(PPOTrainer):
    def __init__(self, env, config: PPOConfig, validation_workers: int = 1) -> None:
        super().__init__(env, config)
        self.validation_workers = max(1, int(validation_workers))

    @staticmethod
    def _merge_validation_metrics(results: list[dict[str, float]], episodes: int, cars: int) -> dict[str, float]:
        merged = empty_validation_metrics(episodes, cars)
        for result in results:
            for key, value in result.items():
                if key in ("episodes", "cars"):
                    continue
                merged[key] = merged.get(key, 0.0) + float(value)
        return merged

    def run_validation(
        self,
        update_index: int,
        safety_shield: bool | None = None,
    ) -> dict[str, float]:
        cars = self.config.validation_cars or self.env.config.max_cars
        lanes = self.config.validation_lanes or self.env.config.lanes_per_approach
        shield_enabled = (
            self.config.validation_safety_shield
            if safety_shield is None
            else safety_shield
        )
        validation_config = replace(
            self.env.config,
            min_cars=cars,
            max_cars=cars,
            lanes_per_approach=lanes,
            curriculum_enabled=False,
            curriculum_progression_enabled=False,
            protected_left_signal=True,
            allow_right_on_red=True,
            right_turns_enabled=True,
            strict_lane_mapping=True,
            safety_filter_enabled=shield_enabled,
            safety_filter_dropout_rate=0.0,
            intersection_reservation_enabled=False,
            safety_override_penalty=0.0,
            unsafe_acceleration_penalty=0.0,
            initial_lateral_noise=0.0,
        )
        episodes = self.config.validation_episodes
        seed_base = self.config.seed + update_index * 1000
        worker_count = min(self.validation_workers, max(episodes, 1))
        checkpoint_path = Path(tempfile.gettempdir()) / (
            f"ror_validation_{os.getpid()}_{update_index}.npz"
        )
        self.model.save(checkpoint_path)
        try:
            if worker_count == 1:
                results = [
                    run_validation_worker(
                        validation_config,
                        str(checkpoint_path),
                        self.config.hidden_size,
                        seed_base,
                        list(range(episodes)),
                        episodes,
                        cars,
                    )
                ]
            else:
                chunks = [list(range(offset, episodes, worker_count)) for offset in range(worker_count)]
                chunks = [chunk for chunk in chunks if chunk]
                executor = ProcessPoolExecutor(
                    max_workers=worker_count,
                    mp_context=mp.get_context("spawn"),
                )
                futures = [
                    executor.submit(
                        run_validation_worker,
                        validation_config,
                        str(checkpoint_path),
                        self.config.hidden_size,
                        seed_base,
                        chunk,
                        episodes,
                        cars,
                    )
                    for chunk in chunks
                ]
                try:
                    results = [future.result() for future in futures]
                except BaseException:
                    for future in futures:
                        future.cancel()
                    for process in getattr(executor, "_processes", {}).values():
                        process.terminate()
                    executor.shutdown(wait=False, cancel_futures=True)
                    raise
                else:
                    executor.shutdown(wait=True)
        finally:
            checkpoint_path.unlink(missing_ok=True)
        metrics = self._merge_validation_metrics(results, episodes, cars)
        metrics["validation_score"] = self._validation_score(metrics)
        return metrics


def ror_env_config(args: argparse.Namespace) -> EnvConfig:
    return EnvConfig(
        min_cars=args.min_cars,
        max_cars=args.max_cars,
        lanes_per_approach=2,
        protected_left_signal=True,
        allow_right_on_red=True,
        right_turns_enabled=True,
        strict_lane_mapping=True,
        stage3_right_turn_probability=args.right_turn_probability,
        curriculum_stage=3,
        safety_filter_enabled=False,
        safety_filter_dropout_rate=0.0,
        intersection_reservation_enabled=False,
        safety_override_penalty=0.0,
        unsafe_acceleration_penalty=0.0,
        initial_lateral_noise=0.0,
        episode_seconds=args.episode_seconds,
        seed=args.seed,
        curriculum_enabled=False,
        curriculum_progression_enabled=False,
    )


def ppo_config(args: argparse.Namespace) -> PPOConfig:
    return PPOConfig(
        total_steps=args.steps,
        rollout_steps=args.rollout_steps,
        update_epochs=args.update_epochs,
        minibatch_size=args.minibatch_size,
        hidden_size=args.hidden_size,
        learning_rate=args.learning_rate,
        entropy_coefficient=args.entropy_coefficient,
        clip_ratio=args.clip_ratio,
        target_kl=args.target_kl,
        checkpoint_interval_updates=args.save_interval_updates,
        validation_interval_updates=args.validation_interval_updates,
        validation_episodes=args.validation_episodes,
        validation_cars=args.validation_cars,
        validation_lanes=2,
        validation_safety_shield=False,
        validation_compare_safety_shield=False,
        validation_protected_left_signal=True,
        validation_allow_right_on_red=True,
        validation_patience=args.validation_patience,
        validation_min_delta=args.validation_min_delta,
        validation_target_completed_pct=75.0,
        validation_target_collisions_per_ep=1.5,
        validation_target_red_per_ep=2.0,
        validation_target_proximity_events_per_ep=9.0,
        seed=args.seed,
    )


def train(args: argparse.Namespace) -> None:
    if getattr(args, "no_init_checkpoint", False):
        args.init_checkpoint = None
    env = NoShieldRorEnv(ror_env_config(args))
    config = ppo_config(args)
    try:
        trainer = NoShieldRorTrainer(env, config, args.validation_workers)
        if args.init_checkpoint is not None and args.init_checkpoint.exists():
            trainer.model.load(args.init_checkpoint)
            print(f"loaded_init_checkpoint={args.init_checkpoint}")
        trainer.train(args.checkpoint)
    finally:
        env.close()


def evaluate(args: argparse.Namespace) -> None:
    env_config = ror_env_config(args)
    env = NoShieldRorEnv(env_config)
    model = load_model(env, args.policy, args.hidden_size)
    rewards: list[float] = []
    completions: list[int] = []
    failures: list[int] = []
    incomplete: list[int] = []
    spawned_counts: list[int] = []
    timeout_incomplete: list[int] = []
    stuck_timeout: list[int] = []
    unfinished_timeout: list[int] = []
    shields: list[int] = []
    collisions = 0
    red_violations = 0
    yellow_violations = 0
    closed_signal_violations = 0
    left_yield_violations = 0
    right_yield_violations = 0
    right_lane_violations = 0
    right_on_red_entries = 0
    proximity_violations = 0
    proximity_events = 0
    lane_drift_warnings = 0
    unsafe_requests = 0
    legal_stall_vehicle_steps = 0
    max_legal_stall_seconds = 0.0
    active_action_samples = 0
    env_steps = 0
    try:
        for episode in range(args.episodes):
            observation, info = env.reset(seed=args.seed + episode)
            spawned = int(info["active_mask"].sum())
            spawned_counts.append(spawned)
            done = False
            episode_reward = 0.0
            episode_timeout_failures = 0
            while not done:
                active_action_samples += int(info["active_mask"].sum())
                actions, _, _ = model.act(observation, deterministic=True)
                observation, reward, terminated, truncated, info = env.step(actions)
                env_steps += 1
                episode_reward += float(reward.sum())
                collisions += int(info["collisions"])
                proximity_violations += int(info["proximity_violations"])
                proximity_events += int(info.get("proximity_events", 0))
                red_violations += int(info["red_light_violations"])
                yellow_violations += int(info.get("yellow_light_violations", 0))
                closed_signal_violations += int(info.get("closed_signal_violations", info["red_light_violations"]))
                left_yield_violations += int(info["left_yield_violations"])
                right_yield_violations += int(info["right_yield_violations"])
                right_lane_violations += int(info["right_lane_violations"])
                right_on_red_entries += int(info.get("right_on_red_entries", 0))
                lane_drift_warnings += int(info.get("lane_drift_warnings", 0))
                unsafe_requests += int(info.get("unsafe_requests", 0))
                legal_stall_vehicle_steps += int(info.get("legal_stall_vehicles", 0))
                max_legal_stall_seconds = max(
                    max_legal_stall_seconds,
                    float(info.get("max_legal_stall_seconds", 0.0)),
                )
                episode_timeout_failures += int(info.get("timeout_failures", 0))
                done = terminated or truncated
            timeout_candidates = [
                vehicle
                for vehicle in env.vehicles
                if vehicle.failed and not vehicle.collided and not vehicle.crossed_on_red and not vehicle.active
            ]
            if len(timeout_candidates) > episode_timeout_failures:
                timeout_candidates = timeout_candidates[:episode_timeout_failures]
            episode_stuck = 0
            episode_unfinished = 0
            for vehicle in timeout_candidates:
                remaining = max(0.0, vehicle.path.length - vehicle.progress)
                legally_stalled = vehicle.legal_stall_seconds >= env_config.stuck_timeout_seconds
                stopped_with_route_left = (
                    vehicle.speed < 0.5
                    and remaining > env_config.vehicle_length
                )
                if legally_stalled or stopped_with_route_left:
                    episode_stuck += 1
                else:
                    episode_unfinished += 1
            rewards.append(episode_reward)
            completions.append(int(info["completed_clean"]))
            failures.append(int(info["failed_vehicles"]))
            shields.append(int(info["cumulative_safety_overrides"]))
            timeout_incomplete.append(episode_timeout_failures)
            stuck_timeout.append(episode_stuck)
            unfinished_timeout.append(episode_unfinished)
            incomplete.append(max(0, spawned - completions[-1] - failures[-1]))
    finally:
        env.close()

    total_vehicles = max(sum(spawned_counts), 1)
    action_denominator = max(active_action_samples, 1)
    completed_total = sum(completions)
    failed_total = sum(failures)
    timeout_incomplete_total = sum(timeout_incomplete)
    stuck_timeout_total = sum(stuck_timeout)
    unfinished_timeout_total = sum(unfinished_timeout)
    true_incomplete_total = sum(incomplete)
    safety_failed_total = max(0, failed_total - timeout_incomplete_total)
    completed_pct = 100.0 * completed_total / total_vehicles
    failed_pct = 100.0 * failed_total / total_vehicles
    incomplete_pct = 100.0 * true_incomplete_total / total_vehicles
    timeout_incomplete_pct = 100.0 * timeout_incomplete_total / total_vehicles
    safety_failed_pct = 100.0 * safety_failed_total / total_vehicles
    stuck_timeout_pct = 100.0 * stuck_timeout_total / total_vehicles
    unfinished_timeout_pct = 100.0 * unfinished_timeout_total / total_vehicles
    shield_action_pct = 100.0 * sum(shields) / action_denominator
    unsafe_action_pct = 100.0 * unsafe_requests / action_denominator
    vehicle_hours = active_action_samples * env_config.dt / 3600.0

    print(
        f"episodes={args.episodes} mean_reward={np.mean(rewards):.2f} "
        f"mean_spawned={np.mean(spawned_counts):.2f} total_vehicles={total_vehicles} "
        f"mean_completed={np.mean(completions):.2f} completed_pct={completed_pct:.2f} "
        f"mean_failed={np.mean(failures):.2f} failed_pct={failed_pct:.2f} "
        f"mean_incomplete={np.mean(incomplete):.2f} incomplete_pct={incomplete_pct:.2f} "
        f"safety_failed_vehicles={safety_failed_total} safety_failed_pct={safety_failed_pct:.2f} "
        f"timeout_incomplete_vehicles={timeout_incomplete_total} timeout_incomplete_pct={timeout_incomplete_pct:.2f} "
        f"stuck_timeout_vehicles={stuck_timeout_total} stuck_timeout_pct={stuck_timeout_pct:.2f} "
        f"unfinished_timeout_vehicles={unfinished_timeout_total} unfinished_timeout_pct={unfinished_timeout_pct:.2f} "
        f"legal_stall_vehicle_steps={legal_stall_vehicle_steps} max_legal_stall_seconds={max_legal_stall_seconds:.1f} "
        f"shield_actions={sum(shields)} shield_action_pct={shield_action_pct:.2f} "
        f"collisions={collisions} collisions_per_ep={collisions / args.episodes:.2f} "
        f"proximity_vehicles={proximity_violations} proximity_events={proximity_events} "
        f"proximity_events_per_ep={proximity_events / args.episodes:.2f} "
        f"red_violations={red_violations} red_violations_per_ep={red_violations / args.episodes:.2f} "
        f"yellow_violations={yellow_violations} yellow_violations_per_ep={yellow_violations / args.episodes:.2f} "
        f"closed_signal_violations={closed_signal_violations} closed_signal_violations_per_ep={closed_signal_violations / args.episodes:.2f} "
        f"left_yield={left_yield_violations} right_yield={right_yield_violations} "
        f"right_on_red_entries={right_on_red_entries} right_on_red_entries_per_ep={right_on_red_entries / args.episodes:.2f} "
        f"right_lane={right_lane_violations} lane_drift={lane_drift_warnings} "
        f"unsafe_requests={unsafe_requests} unsafe_action_pct={unsafe_action_pct:.2f} "
        f"active_action_samples={active_action_samples} env_steps={env_steps} vehicle_hours={vehicle_hours:.3f}"
    )

    row = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "experiment": "no_shield_2l_ror_2to3_per_lane",
        "policy": str(args.policy),
        "episodes": args.episodes,
        "seed": args.seed,
        "lanes": 2,
        "min_cars": args.min_cars,
        "max_cars": args.max_cars,
        "total_vehicles": total_vehicles,
        "mean_spawned": float(np.mean(spawned_counts)),
        "left_signal": "protected",
        "right_on_red": "on",
        "safety_shield": "off",
        "right_turn_probability": args.right_turn_probability,
        "episode_seconds": args.episode_seconds,
        "mean_reward": float(np.mean(rewards)),
        "mean_completed": float(np.mean(completions)),
        "completed_pct": completed_pct,
        "mean_failed": float(np.mean(failures)),
        "failed_pct": failed_pct,
        "mean_incomplete": float(np.mean(incomplete)),
        "incomplete_pct": incomplete_pct,
        "completed_vehicles": completed_total,
        "safety_failed_vehicles": safety_failed_total,
        "safety_failed_pct": safety_failed_pct,
        "timeout_incomplete_vehicles": timeout_incomplete_total,
        "timeout_incomplete_pct": timeout_incomplete_pct,
        "stuck_timeout_vehicles": stuck_timeout_total,
        "stuck_timeout_pct": stuck_timeout_pct,
        "unfinished_timeout_vehicles": unfinished_timeout_total,
        "unfinished_timeout_pct": unfinished_timeout_pct,
        "true_incomplete_vehicles": true_incomplete_total,
        "legal_stall_vehicle_steps": legal_stall_vehicle_steps,
        "max_legal_stall_seconds": max_legal_stall_seconds,
        "shield_actions": sum(shields),
        "shield_action_pct": shield_action_pct,
        "collisions": collisions,
        "collisions_per_ep": collisions / args.episodes,
        "proximity_vehicles": proximity_violations,
        "proximity_events": proximity_events,
        "proximity_events_per_ep": proximity_events / args.episodes,
        "red_violations": red_violations,
        "red_violations_per_ep": red_violations / args.episodes,
        "yellow_violations": yellow_violations,
        "yellow_violations_per_ep": yellow_violations / args.episodes,
        "closed_signal_violations": closed_signal_violations,
        "closed_signal_violations_per_ep": closed_signal_violations / args.episodes,
        "left_yield": left_yield_violations,
        "right_yield": right_yield_violations,
        "right_on_red_entries": right_on_red_entries,
        "right_on_red_entries_per_ep": right_on_red_entries / args.episodes,
        "right_lane": right_lane_violations,
        "lane_drift": lane_drift_warnings,
        "unsafe_requests": unsafe_requests,
        "unsafe_action_pct": unsafe_action_pct,
        "active_action_samples": active_action_samples,
        "env_steps": env_steps,
        "vehicle_hours": vehicle_hours,
    }
    append_csv_row(args.output_csv, row)
    print(f"logged={args.output_csv}")


def describe(args: argparse.Namespace) -> None:
    print(ror_env_config(args))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="No-shield right-on-red stage: 2 lanes, 16-24 cars.")
    subparsers = parser.add_subparsers(dest="command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--seed", type=int, default=7)
    common.add_argument("--episode-seconds", type=float, default=120.0)
    common.add_argument("--hidden-size", type=int, default=PPOConfig().hidden_size)
    common.add_argument("--min-cars", type=int, default=16)
    common.add_argument("--max-cars", type=int, default=24)
    common.add_argument("--right-turn-probability", type=float, default=0.55)

    train_parser = subparsers.add_parser("train", parents=[common])
    train_parser.add_argument("--steps", type=int, default=250_000)
    train_parser.add_argument("--rollout-steps", type=int, default=PPOConfig().rollout_steps)
    train_parser.add_argument("--update-epochs", type=int, default=PPOConfig().update_epochs)
    train_parser.add_argument("--minibatch-size", type=int, default=PPOConfig().minibatch_size)
    train_parser.add_argument("--learning-rate", type=float, default=2e-4)
    train_parser.add_argument("--entropy-coefficient", type=float, default=PPOConfig().entropy_coefficient)
    train_parser.add_argument("--clip-ratio", type=float, default=PPOConfig().clip_ratio)
    train_parser.add_argument("--target-kl", type=float, default=PPOConfig().target_kl)
    train_parser.add_argument("--save-interval-updates", type=int, default=10)
    train_parser.add_argument("--validation-interval-updates", type=int, default=10)
    train_parser.add_argument("--validation-episodes", type=int, default=10)
    train_parser.add_argument("--validation-cars", type=int, default=24)
    train_parser.add_argument("--validation-patience", type=int, default=8)
    train_parser.add_argument("--validation-min-delta", type=float, default=0.0)
    train_parser.add_argument("--validation-workers", type=int, default=4)
    train_parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CHECKPOINT)
    train_parser.add_argument("--init-checkpoint", type=Path, default=DEFAULT_INIT)
    train_parser.add_argument("--no-init-checkpoint", action="store_true")
    train_parser.set_defaults(func=train)

    eval_parser = subparsers.add_parser("evaluate", parents=[common])
    eval_parser.add_argument("policy", type=Path)
    eval_parser.add_argument("--episodes", type=int, default=50)
    eval_parser.add_argument("--output-csv", type=Path, default=DEFAULT_EVAL_CSV)
    eval_parser.set_defaults(func=evaluate)

    describe_parser = subparsers.add_parser("describe", parents=[common])
    describe_parser.set_defaults(func=describe)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
