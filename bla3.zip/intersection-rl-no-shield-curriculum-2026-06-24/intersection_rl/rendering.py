from __future__ import annotations

import os

import numpy as np

from intersection_rl.config import EnvConfig
from intersection_rl.geometry import APPROACHES, HEADINGS, right_vector, stop_point


class IntersectionRenderer:
    """Pygame renderer kept separate so headless training imports stay light."""

    SIZE = 800
    COLORS = {
        "grass": (173, 216, 230),
        "road": (52, 55, 58),
        "line": (235, 220, 120),
        "lane": (225, 225, 225),
        "stop": (245, 245, 245),
        "car": (50, 145, 235),
        "collision": (220, 55, 55),
        "text": (245, 245, 245),
    }

    def __init__(self, config: EnvConfig, render_mode: str | None) -> None:
        if render_mode == "rgb_array":
            os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        import pygame

        self.pg = pygame
        pygame.init()
        self.config = config
        self.render_mode = render_mode
        self.surface = (
            pygame.display.set_mode((self.SIZE, self.SIZE))
            if render_mode == "human"
            else pygame.Surface((self.SIZE, self.SIZE))
        )
        if render_mode == "human":
            pygame.display.set_caption("Week 5-6 - RL Intersection Simulator")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 25)
        world_extent = config.road_length + config.intersection_half_size + 5
        self.scale = self.SIZE / (2.0 * world_extent)

    def world_to_screen(self, point: np.ndarray) -> tuple[int, int]:
        return (
            round(self.SIZE / 2 + point[0] * self.scale),
            round(self.SIZE / 2 + point[1] * self.scale),
        )

    def render(self, env) -> np.ndarray | None:
        pg = self.pg
        for event in pg.event.get():
            if event.type == pg.QUIT:
                env.close()
                return None

        self.surface.fill(self.COLORS["grass"])
        lane_count = getattr(env, "episode_lanes_per_approach", self.config.lanes_per_approach)
        road_half_width = lane_count * self.config.lane_width
        center = self.SIZE // 2
        road_pixels = round(2.0 * road_half_width * self.scale)
        pg.draw.rect(
            self.surface,
            self.COLORS["road"],
            (0, center - road_pixels // 2, self.SIZE, road_pixels),
        )
        pg.draw.rect(
            self.surface,
            self.COLORS["road"],
            (center - road_pixels // 2, 0, road_pixels, self.SIZE),
        )

        # Week 5: two lanes each side, center dividers, stop lines, and signals.
        pg.draw.line(
            self.surface,
            self.COLORS["line"],
            (0, center),
            (center - road_pixels // 2, center),
            2,
        )
        pg.draw.line(
            self.surface,
            self.COLORS["line"],
            (center + road_pixels // 2, center),
            (self.SIZE, center),
            2,
        )
        pg.draw.line(
            self.surface,
            self.COLORS["line"],
            (center, 0),
            (center, center - road_pixels // 2),
            2,
        )
        pg.draw.line(
            self.surface,
            self.COLORS["line"],
            (center, center + road_pixels // 2),
            (center, self.SIZE),
            2,
        )
        self._draw_lane_markings(env)
        self._draw_stop_lines_and_signals(env)

        for vehicle in env.vehicles:
            if not vehicle.active and not vehicle.failed and not vehicle.collided:
                continue
            position, heading = vehicle.pose()
            self._draw_vehicle(
                position,
                heading,
                vehicle.vehicle_id,
                vehicle.collided or vehicle.failed,
            )

        phase = env._signal_phase()[0]
        label = self.font.render(
            f"{phase}  left={'protected' if env.episode_protected_left_signal else 'yield'}  "
            f"ROR={'on' if env.episode_allow_right_on_red else 'off'}  lanes={env.episode_lanes_per_approach}  "
            f"cars={len(env.vehicles)}  t={env.elapsed_seconds:04.1f}s  "
            f"passed={env.completed_vehicles}",
            True,
            self.COLORS["text"],
        )
        self.surface.blit(label, (12, 12))

        if self.render_mode == "human":
            pg.display.flip()
            self.clock.tick(self.metadata_fps(env))
            return None
        pixels = pg.surfarray.array3d(self.surface)
        return np.transpose(pixels, (1, 0, 2))

    def metadata_fps(self, env) -> int:
        return max(1, round(1.0 / env.config.dt))

    def _draw_dashed_line(
        self, start: tuple[int, int], end: tuple[int, int]
    ) -> None:
        direction = np.asarray(end, dtype=float) - np.asarray(start, dtype=float)
        length = float(np.linalg.norm(direction))
        if length == 0.0:
            return
        unit = direction / length
        for offset in np.arange(0.0, length, 20.0):
            dash_start = np.asarray(start, dtype=float) + unit * offset
            dash_end = np.asarray(start, dtype=float) + unit * min(offset + 11.0, length)
            self.pg.draw.line(
                self.surface, self.COLORS["lane"], dash_start, dash_end, 2
            )

    def _draw_lane_markings(self, env) -> None:
        center = self.SIZE // 2
        intersection_edge = round(self.config.intersection_half_size * self.scale)
        for lane_boundary in range(1, env.episode_lanes_per_approach):
            offset = round(lane_boundary * self.config.lane_width * self.scale)
            for y in (center - offset, center + offset):
                self._draw_dashed_line((0, y), (center - intersection_edge, y))
                self._draw_dashed_line((center + intersection_edge, y), (self.SIZE, y))
            for x in (center - offset, center + offset):
                self._draw_dashed_line((x, 0), (x, center - intersection_edge))
                self._draw_dashed_line((x, center + intersection_edge), (x, self.SIZE))

    def _draw_stop_lines_and_signals(self, env) -> None:
        pg = self.pg
        lane_count = env.episode_lanes_per_approach
        incoming_half_width = lane_count * self.config.lane_width / 2.0
        for approach in APPROACHES:
            heading = HEADINGS[approach]
            lateral = right_vector(heading)
            midpoint = stop_point(
                approach,
                0,
                self.config.lane_width,
                self.config.intersection_half_size,
            ) + lateral * (
                (lane_count - 1)
                * self.config.lane_width
                / 2.0
            )
            first = midpoint - lateral * incoming_half_width
            second = midpoint + lateral * incoming_half_width
            pg.draw.line(
                self.surface,
                self.COLORS["stop"],
                self.world_to_screen(first),
                self.world_to_screen(second),
                4,
            )
            signal_position = midpoint + lateral * (incoming_half_width + 2.0)
            through_color = (
                (40, 210, 80)
                if env._has_green(approach, "straight")
                else (220, 50, 50)
            )
            pg.draw.circle(
                self.surface,
                through_color,
                self.world_to_screen(signal_position),
                7,
            )
            if self.config.protected_left_signal:
                left_position = signal_position - heading * 3.0
                left_color = (
                    (40, 210, 80)
                    if env._has_green(approach, "left")
                    else (220, 50, 50)
                )
                left_screen = self.world_to_screen(left_position)
                pg.draw.circle(self.surface, left_color, left_screen, 7)
                left_label = self.font.render("L", True, self.COLORS["text"])
                self.surface.blit(
                    left_label, left_label.get_rect(center=left_screen)
                )

    def _draw_vehicle(
        self,
        position: np.ndarray,
        heading: float,
        vehicle_id: int,
        collided: bool,
    ) -> None:
        pg = self.pg
        visual_scale = 0.9
        length = max(8, round(self.config.vehicle_length * self.scale * visual_scale))
        width = max(5, round(self.config.vehicle_width * self.scale * visual_scale))
        car = pg.Surface((length, width), pg.SRCALPHA)
        color = self.COLORS["collision"] if collided else self.COLORS["car"]
        pg.draw.rect(car, color, (0, 0, length, width), border_radius=2)
        text = self.font.render(str(vehicle_id), True, (255, 255, 255))
        car.blit(text, text.get_rect(center=(length // 2, width // 2)))
        rotated = pg.transform.rotate(car, -np.degrees(heading))
        rect = rotated.get_rect(center=self.world_to_screen(position))
        self.surface.blit(rotated, rect)

    def close(self) -> None:
        self.pg.quit()
