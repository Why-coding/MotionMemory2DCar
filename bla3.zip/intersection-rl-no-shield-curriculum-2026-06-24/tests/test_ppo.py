import numpy as np

from intersection_rl.config import EnvConfig, PPOConfig
from intersection_rl.env import IntersectionEnv
from intersection_rl.ppo import PPOTrainer, SharedActorCritic


def test_actor_critic_shapes_and_continuous_actions():
    observation_size = IntersectionEnv.OBSERVATION_SIZE
    model = SharedActorCritic(observation_size, 32, 2, seed=1)
    observations = np.zeros((7, observation_size), dtype=np.float32)
    mean, values, _ = model.forward(observations)
    actions, log_probs, act_values = model.act(
        observations, np.random.default_rng(1)
    )
    assert mean.shape == (7, 2)
    assert actions.shape == (7, 2)
    assert log_probs.shape == (7,)
    assert values.shape == (7,)
    assert act_values.shape == (7,)
    assert np.all(actions >= -1.0)
    assert np.all(actions <= 1.0)


def test_short_rollout_and_update_are_finite():
    env = IntersectionEnv(
        EnvConfig(min_cars=8, max_cars=8, episode_seconds=2.0, seed=1)
    )
    config = PPOConfig(
        total_steps=8,
        rollout_steps=8,
        update_epochs=1,
        minibatch_size=32,
        hidden_size=16,
        seed=1,
    )
    trainer = PPOTrainer(env, config)
    rollout = trainer.collect_rollout()
    metrics = trainer.update(rollout)
    assert rollout.actions.shape == (8, 8, 2)
    assert all(np.isfinite(value) for value in metrics.values())


def test_validation_score_path_is_finite():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=8,
            max_cars=12,
            lanes_per_approach=2,
            protected_left_signal=True,
            allow_right_on_red=False,
            episode_seconds=1.0,
            seed=2,
        )
    )
    config = PPOConfig(
        total_steps=8,
        rollout_steps=8,
        update_epochs=1,
        minibatch_size=32,
        hidden_size=16,
        validation_episodes=1,
        validation_cars=8,
        validation_lanes=2,
        seed=2,
    )
    trainer = PPOTrainer(env, config)

    metrics = trainer.run_validation(update_index=1)

    assert np.isfinite(metrics["validation_score"])
    assert metrics["env_steps"] > 0
