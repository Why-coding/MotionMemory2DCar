# No-Shield RL Training Report

## Purpose

This experiment is a separate training path for the manager-requested no-safety-shield policy. The goal is to test whether PPO can learn intersection behavior from simulator observations, rewards, and terminal outcomes without hard-rule action overrides.

The existing simulator, PPO trainer, CLI, and safety-shield code remain unchanged. The new entry point is `scripts/train_no_shield_rl.py`.

## Target Scenario

Fixed scenario:

- 2 incoming lanes per approach.
- 8 total cars per episode, not 8 cars per lane or per approach.
- Protected-left signal mode enabled.
- Right-on-red disabled.
- Route sampling limited in the new script to left and straight movements only.
- Lane 0 can sample left or straight.
- Lane 1 samples straight only.
- Safety shield disabled.
- Intersection reservation layer disabled.
- Initial lateral noise disabled.

The important distinction is that the policy action is never replaced by a safety rule. If it accelerates into a red light, follows too closely, or collides, the simulator records the event and applies reward/termination consequences. It does not forcibly brake the vehicle.

## New Files

- `scripts/train_no_shield_rl.py`: isolated no-shield train/evaluate/describe script.
- `NO_SHIELD_RL_REPORT.md`: this report.

The core files under `intersection_rl/` were not changed for this experiment.

## Commands

Describe the fixed experiment configuration:

```bash
.venv/bin/python scripts/train_no_shield_rl.py describe
```

Train from scratch:

```bash
.venv/bin/python scripts/train_no_shield_rl.py train   --steps 250000   --checkpoint checkpoints/no_shield_2l8_protected.npz
```

Evaluate the best checkpoint without a shield:

```bash
.venv/bin/python scripts/train_no_shield_rl.py evaluate   checkpoints/no_shield_2l8_protected_best.npz   --episodes 50
```

Training metrics are written by the existing PPO trainer beside the checkpoint:

- `checkpoints/no_shield_2l8_protected_train_metrics.csv`

Evaluation rows are written to:

- `results/no_shield_2l8_evaluations.csv`

## What Was Removed From Learning

The safety shield previously worked by detecting unsafe requests and replacing the policy acceleration with hold/brake commands in risky states. This can make behavior safer, but it also injects hand-coded driving behavior into the policy rollout.

In this no-shield experiment:

- `safety_filter_enabled=False`
- `safety_filter_dropout_rate=0.0`
- `intersection_reservation_enabled=False`
- `safety_override_penalty=0.0`
- `unsafe_acceleration_penalty=0.0`

The environment may still compute diagnostic unsafe-request counts internally, but those counts do not override actions and do not add reward penalty in this experiment.

## Detection Definitions

### Completion

A vehicle is cleanly completed when it reaches the end of its assigned route path while active and without being marked failed.

Metric fields:

- `completed_clean`: number of cleanly completed vehicles.
- `completed_pct`: clean completions divided by total vehicles evaluated.

### Failure

A vehicle is failed when it is removed because of a collision, red-light violation, yield violation, right-lane violation, or timeout. Current timeout accounting still marks unfinished active vehicles as failed at episode end.

Metric fields:

- `failed_vehicles`
- `failed_pct`
- `timeout_failures` in training metrics

### Collision

Collision detection uses oriented vehicle rectangles. Each vehicle rectangle is built from the route-sampled pose, vehicle length, vehicle width, and heading. Two vehicles collide when their rectangles overlap under separating-axis polygon overlap.

Metric fields:

- `collisions`: close-pair collision events counted per step.
- `collisions_per_ep`: total collisions divided by evaluation episodes.

### Proximity

Proximity detection uses oriented-rectangle clearance, not center distance. If two active, non-colliding vehicle rectangles have edge/corner clearance below `proximity_clearance`, a proximity event is recorded.

For same-lane following, only the rear vehicle is marked responsible. For crossing or side conflicts, both vehicles are marked responsible.

Metric fields:

- `proximity_events`: close vehicle-pair count.
- `proximity_vehicles`: responsible vehicle count.
- `proximity_events_per_ep`: pair events divided by evaluation episodes.

### Front Gap

Front gap is computed only against active vehicles on the same approach and same lane with larger path progress. The nearest such vehicle is treated as the lead vehicle.

The simulator also computes closing speed and time-to-collision:

- `front_gap = lead_progress - ego_progress`
- `front_relative_speed = max(0, ego_speed - lead_speed)`
- `front_ttc = front_gap / front_relative_speed` when closing, otherwise a large safe value

### Red-Light Violation

A red-light violation is recorded when a vehicle crosses its stop line while its movement does not have green permission. In this experiment, right-on-red is disabled, so a right turn cannot legally enter on red.

Metric fields:

- `red_violations`
- `red_violations_per_ep`

### Protected-Left Permission

Protected-left mode gives left turns a dedicated left-green phase. A left-turn vehicle is permitted only during the protected left phase for its axis. Straight vehicles are permitted during the regular green phase for their axis.

Because the new experiment uses protected-left mode, permissive left-turn yield conflicts are not the main learning target.

### Lane Drift

Lane drift warnings are based on lateral offset from the assigned route center. Current vehicle motion has lateral movement disabled in the core code, and the no-shield script spawns with zero lateral offset, so this should stay near zero unless the core dynamics are changed later.

## Reward and Penalty Terms Used

The script reuses the current environment reward. The important terms are:

### Positive rewards

- Route progress reward: rewards forward progress along the assigned path.
- Permitted movement speed reward: rewards moving when the signal and front gap allow motion.
- Permitted acceleration reward: rewards acceleration when movement is permitted and spacing is safe.
- Clean completion bonus: large reward when a vehicle finishes its route cleanly.

### Red-light and stopping penalties

Before the stop line, if the movement is not green, the reward penalizes speed and positive acceleration. It also penalizes insufficient stopping margin, especially close to the stop line.

If the vehicle actually crosses illegally, it receives the red-light violation penalty and is failed.

### Front-gap penalties

The reward penalizes unsafe same-lane following:

- Close gap below `vehicle_length + 2.0`.
- Gap below `minimum_front_gap`.
- Time-to-collision below `ttc_warning_seconds`.
- Stronger penalty below `ttc_critical_seconds`.

### Proximity penalties

If a vehicle is responsible for a proximity event, it receives a proximity penalty. This is separate from collision and exists to teach margin before overlap.

### Predictive conflict penalties

The environment projects vehicles forward over a short horizon and computes predicted collision/proximity features. These are reward-shaping signals, not action overrides. They penalize likely future conflict before the collision actually happens.

### Collision and rule penalties

Hard failure events receive penalties:

- Collision.
- Red-light violation.
- Left-yield violation.
- Right-yield violation.
- Right-lane violation.

For this no-shield target, right-on-red and right turns are disabled in the new route sampler, so right-yield and right-lane failures should not be central.

### Idle and timeout penalties

When movement is permitted and the front gap is safe, very low speed is penalized. Vehicles still active at episode timeout are failed and receive the timeout failure penalty.

## Acceptance Target For This Experiment

For the first no-shield target, evaluate deterministic policy over 50 episodes and aim for:

- `completed_pct >= 75%`
- `collisions_per_ep < 1.5`
- `red_violations_per_ep <= 2.0`
- `proximity_events_per_ep <= 9.0`
- `shield_actions = 0`

The last condition is required because this experiment is only meaningful if no action override happens.

## Current Limitations To Remember

This experiment does not fix known simulator mechanics. It isolates no-shield learning first. The existing limitations still affect training quality:

- Queue movement can be unrealistic at green.
- Red-light queue stopping can freeze vehicles in place instead of forming a realistic stopped queue.
- Timeout vehicles are still counted as failures, not incomplete.
- Spawn spacing can still create bad initial interactions in harder settings.
- Yellow/all-red clearance timing is not redesigned here.
- Lane-to-lane mapping through the intersection is still broad because the base route builder allows random destination lanes.
- Some policies may learn slow or late-start behavior if completion pressure is not strong enough.
- Training and validation speed still depends on the current Python simulator loop.

## Next Technical Questions

If this no-shield run does not learn the target behavior, the next fixes should still avoid action overrides. Good candidates are:

- Improve spawn spacing and queue state generation.
- Fix timeout/incomplete accounting.
- Add realistic queue discharge and car-following dynamics.
- Add yellow/all-red signal timing.
- Add route/lane mapping constraints for leftmost-to-leftmost protected turns and straight lane continuity.
- Tune reward magnitudes after the simulator mechanics are cleaner.


## Strict Mapping And Spawn Fix Retrain

After visual inspection, the simulator was updated so the training and visual simulation use the same stricter mechanics:

- Strict lane mapping is enabled in the core environment.
- In multi-lane mode, lane 0 is left-turn only.
- The rightmost lane is straight/right in the general simulator.
- The no-shield 2-lane experiment disables right-turn route sampling, so lane 1 is straight only.
- Left turns map to destination lane 0.
- Straight movements preserve the same lane index.
- Right turns map to the rightmost destination lane when right turns are enabled.
- Spawn placement now uses a fixed lead gap before the stop line and a larger queue gap.
- Vehicles on red/no-green start stopped instead of rolling toward a red stop line at reset.
- Vehicles with green at reset receive a small initial speed.

This fixes the observed visual problems where a car in the left lane could wait during protected-left and then go straight on normal green, where cars appeared too close to the stop line at red, and where vehicles appeared to change destination lanes through/after the intersection.

Fresh retrain command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py train   --steps 250000   --checkpoint checkpoints/no_shield_2l8_strict_spawn_v1.npz
```

Training stopped early at update 100. The best validation checkpoint was saved at:

- `checkpoints/no_shield_2l8_strict_spawn_v1_best.npz`

Evaluation command:

```bash
.venv/bin/python scripts/train_no_shield_rl.py evaluate   checkpoints/no_shield_2l8_strict_spawn_v1_best.npz   --episodes 50   --output-csv results/no_shield_2l8_strict_spawn_evaluations.csv
```

Latest 50-episode shield-off result:

| Metric | Value |
| --- | ---: |
| completed_pct | 100.00 |
| mean_completed | 8.00 / 8 |
| failed_pct | 0.00 |
| collisions_per_ep | 0.00 |
| red_violations_per_ep | 0.00 |
| proximity_events_per_ep | 0.00 |
| shield_actions | 0 |
| timeout_incomplete_vehicles | 0 |
| stuck_timeout_vehicles | 0 |
| unfinished_timeout_vehicles | 0 |

The current best visual simulation command is:

```bash
.venv/bin/python scripts/train_no_shield_rl.py simulate   checkpoints/no_shield_2l8_strict_spawn_v1_best.npz   --episodes 20
```

Use this script instead of the generic `intersection-rl simulate` command for this experiment, because it disables right-turn route sampling and uses the same strict no-shield environment as training/evaluation.
