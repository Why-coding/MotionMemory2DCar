# Intersection RL Generalized - Pure RL Red/Green Behavior Work

This folder contains the generalized intersection RL redesign. The current active target is a pure runtime RL policy for safe protected-left intersection driving without a safety shield or runtime action correction.

Current status as of 2026-07-07:

- Selected protected red/green checkpoint: `checkpoints/protected_redgreen_generalized_v1_selected.npz`.
- Protected-left and straight red-to-green release are trained with one generalized next-release curriculum, not separate route-specific release rules.
- Yellow remains excluded, right-on-red remains disabled, and runtime control remains pure policy output.
- Final 60-episode evaluations across 2/3/4 lanes show about 93% completion, zero stuck/moving timeouts, zero collisions, and zero proximity events.
- Red violations are not zero yet, but are much lower than the failed release-only models and no longer cause the stuck-release failure mode.
- Generated result graphs are in `graphs/protected_redgreen_generalized_v1/`.

## Current Handoff - 2026-07-07

### What we are doing now

We paused right-on-red work because two pure-RL right-on-red curriculum runs stayed safe but never produced actual right-on-red entries. Before returning to right-on-red, the current focus is red queue behavior: vehicles should stop close to the stop line on red, followers should queue behind the lead vehicle with safe spacing, and the same policy should still discharge normally when the signal turns green.

Green discharge is preserved by keeping protected red/green replay and green_queue_discharge in the red-queue curriculum. Any red-queue checkpoint must still be re-evaluated on protected redgreen before it is used for a demo.

### Checkpoint Roles

| Checkpoint | Use | Status |
| --- | --- | --- |
| checkpoints/protected_redgreen_generalized_v1_selected.npz | Demo checkpoint for protected-left red/green, no yellow, no right-on-red | Best/current selected checkpoint. Use this for protected red/green demo. |
| checkpoints/red_queue_v4_far_recover_40k_best.npz | Experimental red-queue fine-tune candidate | Not demo-selected yet. It reduced stopped-too-far behavior compared with earlier red-queue attempts, but front-gap/queue spacing is still not solved and it needs full eval plus redgreen retention eval. |

Deleted/removed from the clean folder: failed right-on-red checkpoints, older red-queue checkpoints, stale train metrics CSVs, stale eval CSVs, old logs, and old zip archives. The documentation records the important results so the folder stays readable.

### Current Best Protected Red/Green Result

Using checkpoints/protected_redgreen_generalized_v1_selected.npz:

- 2 lanes / 8 cars / 60s: completed about 93.54%, collisions 0, proximity 0, stuck/moving timeout 0, red violations about 0.52/ep.
- 3 lanes / 12 cars / 60s: completed about 93.06%, collisions 0, proximity 0, stuck/moving timeout 0, red violations about 0.83/ep.
- 4 lanes / 16 cars / 60s: completed about 93.33%, collisions 0, proximity 0, stuck/moving timeout 0, red violations about 1.07/ep.

Simulator rollouts for this checkpoint remain in results/simulator_rollouts/ and show 8/8, 12/12, and 16/16 completion in the saved demo seeds.

### Right-On-Red Status

Right-on-red is not solved. Both attempted checkpoints were deleted from the clean folder because eval showed right_on_red_entries_per_ep=0.0; the policy waited for green. The next right-on-red attempt should be a behavior-discovery drill, not just longer training.

### Red Queue Status

Baseline red-queue eval of checkpoints/protected_redgreen_generalized_v1_selected.npz showed poor queue behavior in pure red drills: many red crossings, very high front-gap violations, and many cars stopped too far from the stop line.

Red-queue v4 added a focused red_queue curriculum, red-queue validation mode, stronger stop-line approach shaping, and green queue discharge replay. It is experimental only. Best observed validation snapshot was update 5, with red/proximity improved and stopped-too-far lower than earlier v3, but front-gap violations remained high.

Next technical step: continue red queue from a cleaned reward setup that directly balances three targets together: no red crossing, close stop-line placement, and safe follower gap. After that, run protected redgreen retention eval to confirm queue discharge on green still works.

## Main Goal

Train one shared policy that controls all vehicles using ego-centric graph observations. The policy should learn safe road behavior from simulation rewards plus auxiliary training losses, not from runtime rules.

Target behaviors:

- move promptly on legal green
- stop before the stop line on red
- preserve strict lane mapping
- keep vehicles centered in lanes
- avoid collisions
- maintain safe proximity and front gap
- avoid stuck vehicles and unnecessary waiting
- complete protected-left and straight routes
- generalize across 2, 3, and 4 lanes per approach

Current narrowed target:

- protected-left only
- straight and left routes only
- right-on-red disabled
- yellow postponed until red is reliable
- no lane changes
- no lateral spawn noise
- red/green behavior trained after a green-only checkpoint

## Runtime Purity Rule

The runtime policy is still pure policy control:

- no safety shield
- no hard action override
- no rule module that clamps acceleration
- no runtime collision avoidance controller
- no runtime red-light braking controller

The actor outputs continuous actions directly:

```text
action[0] = normalized longitudinal acceleration/braking
action[1] = normalized steering
```

The auxiliary intent head and physics-derived action target are training losses only. They do not choose or overwrite the action during simulation/evaluation.

## Folder Layout

```text
intersection-rl_generalized/
  README.md                         This file.
  REPORT.md                         Fresh technical report and experiment history.
  MANIFEST.md                       Deliverable inventory.
  pyproject.toml                    Editable package metadata.
  requirements.txt                  Runtime Python requirements.
  Dockerfile, compose.yaml          Container files copied from the deliverable structure.
  intersection_rl/                  Source package for the generalized implementation.
  scripts/train_graph_multitask.py  Main train/evaluate CLI.
  scripts/generate_graphs.py        Graph generation helper.
  checkpoints/                      Saved model checkpoints kept for current handoff.
  results/                          Simulator rollout media and summaries kept for demo review.
  graphs/                           Generated plots.
  tests/                            Regression tests.
```

## Core Files

- `intersection_rl/env.py`: simulator, dynamics, signal phase, rewards, collision/proximity/front-gap detection, completion/failure bookkeeping, and diagnostics.
- `intersection_rl/config.py`: vehicle geometry, signal timing, reward weights, PPO hyperparameters, auxiliary action-target constants, and validation targets.
- `intersection_rl/graph_observation.py`: ego-centric graph observation encoder.
- `intersection_rl/graph_ppo.py`: graph actor-critic, PPO rollout/update logic, parallel rollout workers, auxiliary losses, KL regularization, validation, and checkpoint saving.
- `intersection_rl/multitask.py`: scenario task families and multi-task environment wrapper.
- `scripts/train_graph_multitask.py`: train/evaluate CLI and behavior-stage presets.

## Simulator Setup

Current generalized work uses:

- lanes per approach sampled from 2, 3, or 4 depending on task
- total cars per episode, not per lane and not per approach
- straight and protected-left routes
- strict lane mapping
- no lane changing
- no right turns and no right-on-red
- no lateral spawn noise
- safety filter disabled
- intersection reservation disabled

A training episode samples a task family. The task sets lane range, car range, episode length, signal mode, spawn filter, lead gap, queue gap, and closed-signal spawn speed.

## Signal Handling

Current red/green training avoids yellow. The simulator still supports yellow, but the latest red-learning step intentionally removes yellow from the task so we can debug red stopping first.

The red behavior tasks use a stable green phase for one axis and spawn vehicles that face the closed/red side. This gives red-facing cars a closed signal without accidentally entering yellow during short behavior drills.

## Observation Design

For each active vehicle, `GraphObserver.encode(env)` builds:

```text
ego:       [max_cars, ego_size]
nodes:     [max_cars, max_nodes, node_size]
edges:     [max_cars, max_nodes, edge_size]
node_mask: [max_cars, max_nodes]
```

Each vehicle gets its own graph. The graph contains all active vehicle nodes plus a lane/map context node and a traffic-signal context node.

Ego features include normalized speed, acceleration, distance to stop line, crossed-stop-line flag, stopping distance estimate, route progress, lateral offset, lane index, destination lane, lane count, active vehicle count, current visible signal state, movement-permitted flag, protected-left flag, right-on-red flag, route one-hot, front gap, front relative speed, front TTC proxy, front-too-close flag, and inside-intersection flag.

Other-vehicle nodes include observable relative position, relative speed, other speed, other acceleration, heading delta, same-lane/same-approach/same-axis flags, possible geometric conflict from position/approach relationship, inside-intersection flag, and lane position. We removed hidden route-conflict caching from the observation direction because the ego should not receive another vehicle's private route answer.

Edge features encode self edge, same-lane front/back, adjacent lane, same approach, possible conflict geometry, other inside intersection, relative distance, relative forward distance, observed TTC proxy, and front-gap risk.

## Model Architecture

The current model is `GraphActorCritic`.

Architecture flow:

1. Encode ego features with linear + layer norm + tanh.
2. Encode vehicle/context nodes with linear + layer norm + tanh.
3. Encode edges with linear + layer norm + tanh.
4. Apply edge-conditioned graph attention blocks.
5. Pass ego readout through a shared body MLP.
6. Produce actor mean, critic value, and auxiliary intent logits.

Main modules:

```text
ego_encoder
node_encoder
edge_encoder
attention_layers
body
acceleration_head
steering_head
value_head
intent_head
log_std
```

The attention block uses ego as the query over graph nodes. Edge features affect keys, values, and attention bias, so the ego can focus on relevant cars, lane context, and signal context.

The current actor has independent direct output heads:

```text
action[0] mean = tanh(acceleration_head(features))
action[1] mean = tanh(steering_head(features))
```

The auxiliary intent head predicts:

```text
0 = stop
1 = hold
2 = go
3 = yield
```

This prediction is diagnostic/training-only. Evaluation still applies the continuous actor action.

Old checkpoints made before `actor_head=separate_accel_steer_v1` used `policy_head` and `mode_policy_head`. They are incompatible with the current code and should not be used for initialization.

## Training Dataflow

One PPO update:

1. Main process copies model weights to rollout workers.
2. Each worker creates a `MultiTaskIntersectionEnv`.
3. Each worker samples task families and collects `rollout_steps` simulator steps.
4. At each step, graph observations are encoded, continuous actions are sampled, the environment steps, and rewards/diagnostics are stored.
5. Workers return `GraphRollout` batches.
6. The main trainer concatenates active-vehicle samples.
7. GAE computes advantages and returns.
8. Advantages are normalized by phase/intent when enabled.
9. Minibatches are phase-balanced when enabled.
10. PPO optimizes actor, critic, auxiliary intent loss, auxiliary action-target loss, and optional reference KL.
11. Validation runs deterministic evaluation on fixed scenarios.
12. Checkpoints and metrics CSV rows are saved.

## Loss Components

The training loss contains:

```text
policy_loss
+ value_coefficient * value_loss
+ intent_loss_weight * intent_loss
+ intent_action_loss_coefficient * intent_action_loss
+ reference_kl_coefficient * reference_kl_loss
+ reference_kl_all_coefficient * reference_kl_all_loss
- entropy_coefficient * entropy
```

Important details:

- `policy_loss`: clipped PPO objective.
- `value_loss`: critic regression.
- `intent_loss`: stop/hold/go/yield cross entropy.
- `intent_action_loss`: actor-mean penalty toward a smooth continuous acceleration target.
- `reference_kl_loss`: anti-forgetting loss against an older checkpoint.
- `entropy`: exploration bonus.

## Auxiliary Intent And Action Target

The auxiliary head helps the network represent tactical state. It does not act as a controller.

The physics-derived action target gives a continuous acceleration target for training. For red-before-stop samples, the target is a speed profile:

1. Far from stop line: creep forward slowly.
2. Approaching stop line: brake according to stopping distance.
3. Inside stop window: target zero speed.

Core red target intuition:

```text
available_distance = distance_to_stop - stop_margin
required_decel = brake_safety * speed^2 / (2 * available_distance)
safe_stop_speed = sqrt(2 * comfortable_braking * available_distance / brake_safety)
red_desired_speed = min(red_crawl_speed, safe_stop_speed)
red_target_accel = (red_desired_speed - speed) / time_constant
```

This is still not a runtime rule because it is only a training loss on the actor mean.

Current constants in `PPOConfig`:

```text
physics_action_target_road_length = 65.0
physics_action_target_max_speed = 13.4
physics_action_target_max_acceleration = 2.5
physics_action_target_comfortable_braking = 4.0
physics_action_target_stop_margin = 3.0
physics_action_target_brake_safety_factor = 1.25
physics_action_target_red_crawl_speed = 3.0
physics_action_target_green_speed = 8.0
physics_action_target_time_constant = 1.0
```

## Green Checkpoint Assessment

Current trusted green checkpoint for the separate acceleration/steering actor:

```text
checkpoints/behavior_green_separate_head_v1_300k.npz
```

Representative deterministic evaluations, 50 episodes each:

```text
2 lanes, 4 cars, green, 60s:
  completed_pct = 100.0
  failed_pct = 0.0
  incomplete_pct = 0.0
  collisions_per_ep = 0.0
  proximity_events_per_ep = 0.0
  red_violations_per_ep = 0.0

2 lanes, 4 cars, green, one car per green lane, 60s:
  completed_pct = 100.0
  failed_pct = 0.0
  incomplete_pct = 0.0
  collisions_per_ep = 0.0
  proximity_events_per_ep = 0.0

3 lanes, 6 cars, green, 60s:
  completed_pct = 92.0
  failed_pct = 8.0
  incomplete_pct = 0.0
  collisions_per_ep = 0.24
  proximity_events_per_ep = 6.46

4 lanes, 8 cars, green, 60s:
  completed_pct = 91.0
  failed_pct = 9.0
  incomplete_pct = 0.0
  collisions_per_ep = 0.36
  proximity_events_per_ep = 5.28
```

Conclusion: the new green checkpoint is a cleaner 2-lane movement baseline than the earlier intent-blended actor. It is not a final safe-driving policy. The next red training should use this checkpoint as init/reference, but 3/4-lane conflict handling also needs more work.

## Latest Training Command

Fresh separate-head green run:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage green   --checkpoint checkpoints/behavior_green_separate_head_v1_300k.npz   --steps 300000   --rollout-steps 256   --rollout-workers 12   --validation-workers 8   --validation-interval 5   --validation-episodes 8   --checkpoint-interval 0   --max-cars 50   --learning-rate 8e-6   --target-kl 0.003   --reward-clip 320
```

Key implementation note: green behavior-stage validation now uses feasible green scenarios `2:4:60`, `3:6:60`, and `4:8:60`. The first attempt used dense default validation and failed because green-only spawn mode cannot fit 24 cars into the simple green reset.



## 2026-07-02 Simplified Red/Green Reward Update

The current red/green experiment intentionally stops trying to teach smooth braking first. The simulator still does not hard-stop cars and there is still no safety shield or runtime action override. The change is only in the training objective.

New red objective:

```text
red before stop line: do not receive generic progress reward
red in legal stop window: reward legal stop position and holding
red stopped far upstream: penalize being stopped too far from the line
red moving toward stop window: reward approach progress
red crossing stop line: keep the large terminal violation penalty
```

New green objective remains:

```text
green progress/completion: reward
green stuck before stop line: penalize idle/stall behavior
green collision/proximity/front-gap issues: penalize
```

Important implementation changes:

- Red and redgreen stages no longer auto-enable the auxiliary action-target loss. Default `--intent-action-loss-coefficient` remains `0.0`.
- `closed_signal_accel_penalty` is now `0.0`.
- `closed_signal_target_speed_penalty` is now `0.0`.
- The small global acceleration magnitude penalty is skipped while a car is before a closed signal.
- Red reward now focuses on stop-line outcome, not a required deceleration profile.

Recommended next experiment:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage redgreen   --init-checkpoint checkpoints/behavior_green_separate_head_v1_300k.npz   --reference-checkpoint checkpoints/behavior_green_separate_head_v1_300k.npz   --checkpoint checkpoints/behavior_redgreen_simplified_v1_300k.npz   --steps 300000   --rollout-steps 256   --rollout-workers 12   --validation-workers 8   --validation-interval 5   --validation-episodes 8   --checkpoint-interval 0   --max-cars 50   --learning-rate 8e-6   --target-kl 0.003   --reward-clip 320   --reference-kl-coefficient 0.03   --reference-kl-all-coefficient 0.0   --reference-kl-green-only
```



## 2026-07-02 Red Stop Velocity Reward Update

The 200k mixed red/green run showed a specific failure: deterministic stop-label action stayed near zero, and red-facing cars still had positive velocity when they reached the stop line. The next reward-only fix focuses on velocity, not acceleration style.

Implemented reward-only changes:

```text
red stop window:
  reward legal stop-window position
  strongly penalize nonzero speed
  reward speed below 0.25 m/s

red far before stop line:
  allow approach progress
  penalize stopping far upstream
  penalize overspeed while approaching the stop zone

red too close / past legal stop window:
  penalize margin error
  strongly penalize speed
```

This still does not add an auxiliary action target, safety shield, hard stop, or runtime controller. The policy must still learn the action from reward.



## 2026-07-02 Stop-Window-Only Red And Strong Green Movement Reward

The red reward was simplified again after discussion: we do not care about approach overspeed or smooth braking in this phase. The only red outcome that matters is stopping in the legal stop window before the line.

Current red reward logic:

```text
red crossing stop line -> huge failure penalty
red inside stop window + speed near 0 -> strong reward
red inside stop window + speed > 0 -> strong penalty
red stopped far before stop window -> penalty
red moving toward stop window -> reward
red approach overspeed outside stop window -> no penalty
```

Current green reward logic:

```text
green progress -> reward
green completion -> large reward
green speed near 0 before stop line -> large penalty
green very slow before stop line -> penalty
green no progress before stop line -> large penalty
```

This is still reward-only RL: no safety shield, no hard stop, no auxiliary action target, and no runtime controller.

## Red/Green Experiments

### v2: Direct Brake Target

Checkpoint family:

```text
checkpoints/behavior_redgreen_v2_direct_brake_300k_*.npz
```

Changes:

- red-before-stop samples used direct required-deceleration target
- green checkpoint loaded as init and reference

Representative update 40 eval:

```text
green, 2 lanes, 4 cars:
  completed_pct = 100.0
  failed_pct = 0.0
  collisions_per_ep = 0.0
  proximity_events_per_ep = 1.15
  closed_signal_violations_per_ep = 0.0

red, 2 lanes, 4 cars:
  completed_pct = 17.5
  failed_pct = 82.5
  red_violations_per_ep = 3.1
  closed_signal_violations_per_ep = 3.3

mixed, 2 lanes, 4 cars:
  completed_pct = 36.25
  failed_pct = 63.75
  red_violations_per_ep = 2.25
  yellow_violations_per_ep = 0.3
  closed_signal_violations_per_ep = 2.55
```

Interpretation: green stayed solved, but red stopping failed badly. Collision/proximity were not the main failure cause.

### v3: Profile Brake Target

Checkpoint family:

```text
checkpoints/behavior_redgreen_v3_profile_brake_300k_*.npz
```

Changes:

- red target became creep-far / brake-near / hold-at-line profile
- redgreen timing fixed to avoid yellow contamination
- red action samples weighted more strongly

Observed result:

- red failures improved in rollout windows around updates 30-45
- validation stayed very negative
- later updates drifted and became worse

Important bug found: anti-forgetting KL was applied against the green-only reference on red samples, which pulled red behavior back toward the old wrong policy.

### v4: Green-Only KL

Checkpoint family:

```text
checkpoints/behavior_redgreen_v4_green_kl_300k_*.npz
```

Changes:

- added `reference_kl_green_only`
- anti-forgetting KL is applied only on legal green/go samples
- red stop samples are no longer forced to match the old green-only checkpoint

Command used:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage redgreen   --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --checkpoint checkpoints/behavior_redgreen_v4_green_kl_300k.npz   --steps 300000   --rollout-steps 256   --rollout-workers 12   --safety-replay-workers 6   --validation-workers 8   --validation-interval 10   --validation-episodes 8   --validation-scenarios 2:4:60 3:6:60 4:8:60   --checkpoint-interval 10   --max-cars 50   --learning-rate 4e-6   --target-kl 0.0012   --reward-clip 320   --reference-kl-coefficient 0.03   --reference-kl-all-coefficient 0.0   --reference-kl-green-only   2>&1 | tee results/behavior_redgreen_v4_green_kl_300k_train.log
```

Observed pattern:

```text
updates 1-20: red failures often 100-250 per rollout batch
updates 28-44: red failures often 19-50 with zero collision/proximity
updates 48-59: red failures rose again; collision/proximity appeared in some batches
```

Selected log points:

```text
update 29: clean=77 failed=19 red=19 coll=0 prox=0
update 31: clean=80 failed=23 red=23 coll=0 prox=0
update 36: clean=63 failed=20 red=20 coll=0 prox=0
update 44: clean=85 failed=21 red=21 coll=0 prox=0
update 55: clean=82 failed=170 red=170 coll=0 prox=22
update 57: clean=88 failed=88 red=86 coll=1 prox=5
```

Interpretation: green-only KL is the right direction, but the policy still does not validate robustly. It learns a useful transient red behavior and then drifts.

## Bugs And Issues Faced

1. Safety shield conflicted with the new goal. Earlier shielded policies were safer, but runtime rule correction beats the purpose of learning the behavior naturally. Generalized work disables the shield.
2. Lane width changes broke old distributions. Moving from 4 m to 5 m changed geometry, proximity, and trained-policy assumptions.
3. Spawn/lateral issues caused visual off-center cars or close initial placement. Current work uses no lateral noise and strict lane mapping.
4. Cars stopped in place behind red instead of queuing to the stop line. Current rewards/targets now penalize far upstream stopping and teach slow approach plus stop-window hold.
5. Green discharge became too conservative after adding stop behavior. Current green replay and green-only KL protect green movement.
6. Yellow contaminated red-only experiments. Current redgreen timing avoids yellow until red is solved.
7. Anti-forgetting KL was initially applied to red samples against a green-only reference. Fixed by adding green-only KL.
8. Rollout looked good but validation stayed bad. This means the behavior is seed/lane fragile and cannot be trusted from rollout metrics alone.
9. Training learns then forgets. Red failures drop in a window and later rise again, probably from PPO drift, competing objectives, unstable value scale, and insufficient checkpoint selection focused on red.

## What We Tried

- old staged PPO with safety shield
- removed runtime safety shield for generalized work
- graph/entity observation redesign
- graph attention actor-critic
- multi-task scenario sampling
- parallel rollout workers
- parallel evaluation workers
- failure-cause metrics
- incomplete/stuck/moving-timeout metrics
- auxiliary intent head
- detached intent loss by default
- phase advantage normalization
- phase-balanced minibatches
- green-only behavior training
- direct red braking target
- red speed-profile target
- no-yellow redgreen timing
- green-only anti-forgetting KL
- stopping bad training tails instead of trusting final checkpoints

## Current Interpretation

The model can learn simple green discharge. It can begin to learn red stopping when the signal is clear, but red stopping is not stable yet. The core current issue is not collision or proximity; it is closed-signal discipline and training stability while adding red to a green checkpoint.

The next direction should be:

1. Make red-only training/evaluation narrower until red is solved.
2. Save/evaluate every 5-10 updates during the good window.
3. Use green-only KL only on green/go samples.
4. Reduce mixed redgreen weight until red eval is strong.
5. Add checkpoint selection based on red eval, not broad mixed validation.
6. Once red eval is stable, mix red+green with a fixed ratio.
7. Only then reintroduce yellow.
8. Only after yellow, increase density and add right-on-red.

## Commands

Run tests:

```bash
cd intersection-rl_generalized
../.venv/bin/python -m pytest tests
```

Evaluate green checkpoint:

```bash
cd intersection-rl_generalized
../.venv/bin/python scripts/train_graph_multitask.py evaluate   checkpoints/behavior_green_v3_300k_best.npz   --lanes 2   --cars 4   --episode-seconds 60   --episodes 50   --eval-workers 8   --eval-mode green   --output-csv results/eval_green_v3_2l_4c_60s.csv
```

Evaluate a redgreen checkpoint on green/red/mixed:

```bash
cd intersection-rl_generalized
for mode in green red mixed; do
  ../.venv/bin/python scripts/train_graph_multitask.py evaluate     checkpoints/behavior_redgreen_v4_green_kl_300k_update_0040.npz     --lanes 2     --cars 4     --episode-seconds 60     --episodes 50     --eval-workers 8     --eval-mode "$mode"     --output-csv "results/eval_behavior_redgreen_v4_update_0040_${mode}_2l4c60.csv"
done
```

Current redgreen training command pattern:

```bash
cd intersection-rl_generalized
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage redgreen   --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --checkpoint checkpoints/behavior_redgreen_next.npz   --steps 300000   --rollout-steps 256   --rollout-workers 12   --safety-replay-workers 6   --validation-workers 8   --validation-interval 10   --validation-episodes 8   --validation-scenarios 2:4:60 3:6:60 4:8:60   --checkpoint-interval 10   --max-cars 50   --learning-rate 4e-6   --target-kl 0.0012   --reward-clip 320   --reference-kl-coefficient 0.03   --reference-kl-all-coefficient 0.0   --reference-kl-green-only   2>&1 | tee results/behavior_redgreen_next_train.log
```

## How To Read Training Logs

Example:

```text
update=0036 reward=+0.2900 clean=63 failed=20 coll=0 prox=0 red=20 yellow=0 closed=20
```

Meanings:

- `clean`: completed vehicles in the rollout batch
- `failed`: failed vehicles in the rollout batch
- `coll`: collision count/flags in rollout metrics
- `prox`: proximity events/violations
- `red`: red-light violations
- `yellow`: yellow-light violations
- `closed`: red + yellow closed-signal violations
- `phase_stop/hold/go/yield`: labeled active samples for phase diagnostics

Rollout logs are trend indicators only. Deterministic evaluation is required before trusting a checkpoint.

## What Not To Claim Yet

Do not claim the project has solved safe driving. Current true statement:

- green-only simple behavior is strong
- red stopping is partially learned but unstable
- final protected-left safe-driving policy is not achieved yet
- yellow and right-on-red are not ready
- dense multi-lane robustness is not ready

## Update 2026-07-01: Red-Only Stage Implementation

After the v4 redgreen run showed transient red learning followed by drift, a new `red` behavior stage was implemented. This stage is intentionally narrower than `redgreen`.

What changed:

- Added `--behavior-stage red` to `scripts/train_graph_multitask.py`.
- Red stage training tasks are now only:
  - `red_stop_basic`
  - `red_brake_basic`
  - `red_creep_release_basic`
- Red stage excludes:
  - green replay tasks
  - mixed redgreen tasks
  - yellow tasks
  - right-on-red
  - dense traffic tasks
- Red stage keeps 2/3/4 lane sampling through those task definitions.
- Red stage defaults `intent_action_loss_coefficient` to `0.35`.
- Red stage automatically enables `reference_kl_green_only` when using a reference checkpoint.
- Red stage defaults validation to red-mode validation through `validation_eval_mode = "red"`.
- Red stage changes validation interval from 10 to 5 when the user did not override it.
- Red stage changes default validation scenarios from broad mixed scenarios to:
  - `2:4:60`
  - `3:6:60`
  - `4:8:60`
- Added `--validation-eval-mode {standard,green,red,mixed}` so checkpoint selection can use red-focused validation instead of standard random-signal validation.
- Validation workers can now run behavior-mode validation tasks using `MultiTaskIntersectionEnv`, matching the eval-mode logic.
- `scripts/train_graph_multitask.py` now forces its local `intersection_rl` package path onto `sys.path` before importing. This avoids accidentally importing the root installed package instead of the generalized package copy.
- Added `validation_eval_mode` to `PPOConfig` in both package copies.

Why this change was needed:

The previous redgreen stage mixed too many objectives too early. It could reduce red failures for a short window, but validation stayed poor and later training drifted. The new red stage isolates the red stopping behavior so `_best` checkpoints are selected by red-stop validation, not broad mixed validation.

Smoke test command used:

```bash
cd intersection-rl_generalized
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage red \
  --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz \
  --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz \
  --checkpoint /tmp/behavior_red_stage_smoke.npz \
  --steps 8 \
  --rollout-steps 8 \
  --rollout-workers 1 \
  --validation-workers 1 \
  --validation-interval 1 \
  --validation-episodes 1 \
  --validation-scenarios 2:4:60 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 1e-6 \
  --target-kl 0.001 \
  --reward-clip 320
```

Smoke result:

```text
update=0001 steps=0000008 rollouts=1 rw=1 vw=1 reward=-25.2291 val=-140780.9437 clean=0 failed=0 coll=0 prox=0 red=0 yellow=0 closed=0 phase_stop=32 phase_go=0 samples=32
```

Interpretation of smoke result:

- The command executed successfully.
- Red-stage rollout sampled stop-phase data only (`phase_stop=32`, `phase_go=0`).
- Red-mode validation executed and produced a validation score.
- This was not a training-quality run; it was only a code-path smoke test.

Regression tests after the implementation:

```text
64 passed, 1 warning
```

Recommended next training command:

```bash
cd intersection-rl_generalized
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage red \
  --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz \
  --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz \
  --checkpoint checkpoints/behavior_red_v1_redonly_150k.npz \
  --steps 150000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 5 \
  --max-cars 50 \
  --learning-rate 4e-6 \
  --target-kl 0.0012 \
  --reward-clip 320 \
  --reference-kl-coefficient 0.03 \
  --reference-kl-all-coefficient 0.0 \
  --reference-kl-green-only \
  2>&1 | tee results/behavior_red_v1_redonly_150k_train.log
```

Expected purpose of the next run:

- Check whether red stopping can become stable before mixing green/red again.
- Use `_best` from red-mode validation, not broad validation.
- Stop manually if red failures fall and then begin drifting upward again.

## 2026-07-01 Red-Only v2 Fixes

Reason for this version:

- Red-only drills intentionally place vehicles on a closed signal, so completion is not a valid success target for that drill. A vehicle that stops correctly will not complete until the light changes.
- The previous red-only v1 run showed temporary rollout improvement but deterministic evaluation still failed. The model usually either crossed the red line or stopped too far from the stop line.
- The previous red validation score still penalized lack of completion, which made `_best` checkpoint selection misleading for a red-stop drill.

Implemented changes:

- Added `closed_signal_approach_speed_gain` to `EnvConfig` for reward-side red approach speed shaping.
- Added `physics_action_target_red_approach_gain` to `PPOConfig` for auxiliary continuous action-target shaping.
- Changed red braking target from mostly constant crawl speed to a distance-proportional speed profile. The desired red speed now decreases as the car approaches the stop target instead of staying too high until very close to the line.
- Strengthened reward-side closed-signal speed shaping so cars are rewarded for controlled approach and braking, not for fast progress near the stop line.
- Added red-specific validation scoring when `--validation-eval-mode red` is active. Red validation now prioritizes no closed-signal crossing, low collision/proximity, reasonable stop position, and low front-gap violations instead of completion percentage.
- Added `red_drill_safe_pct` to evaluation CSV output. This is the percentage of spawned cars that did not create a red/yellow closed-signal crossing in a red drill.

Verification:

```bash
../.venv/bin/python -m py_compile scripts/train_graph_multitask.py intersection_rl/graph_ppo.py intersection_rl/config.py intersection_rl/env.py
../.venv/bin/python -m pytest -q
```

Result:

```text
64 passed, 1 warning
```

Next training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage red   --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --checkpoint checkpoints/behavior_red_v2_profile_200k.npz   --steps 200000   --rollout-steps 256   --rollout-workers 12   --validation-workers 8   --validation-interval 5   --validation-episodes 8   --checkpoint-interval 1   --max-cars 50   --learning-rate 4e-6   --target-kl 0.0012   --reward-clip 320   --reference-kl-coefficient 0.03   --reference-kl-all-coefficient 0.0   --reference-kl-green-only
```

Checkpoint interval is now `1` because v1 had a short rollout window around updates 46-47 but no exact checkpoint was saved there.

## 2026-07-01 Red-Only v2 Result And v3 Plan

Red-only v2 completed 66 updates / 202,752 sampled steps.

Useful rollout window:

- update 39: 20 rollout red crossings, 0 collisions, 0 proximity events
- update 47: 18 rollout red crossings, 0 collisions, 0 proximity events

Deterministic evaluation showed the rollout window did not transfer to the actor mean:

```text
behavior_red_v2_profile_200k_best, red eval 2 lanes / 4 cars / 60s / 30 episodes
completed_pct=0.0
failed_pct=100.0
red_violations_per_ep=2.93
closed_signal_violations_per_ep=2.93
red_drill_safe_pct=26.67
collisions_per_ep=0.0
proximity_events_per_ep=0.0
queue_stop_position_error_avg=5.92
```

Additional action diagnostic on the v2 best checkpoint:

```text
action_stop_label_mean=-0.057
action_stop_label_brake_share=0.979
action_hold_label_mean=-0.057
```

Interpretation:

- The policy often predicts a braking/holding tactical state, but the deterministic continuous action is almost neutral, not a real brake.
- Stochastic rollout samples sometimes brake enough to reduce red crossings, but deterministic evaluation uses the actor mean and still crosses red.
- Therefore the next fix is not collision/proximity reward. The next fix is stronger continuous action-target learning for red-stop samples.

Implemented after v2:

- Added deterministic action diagnostics to evaluation CSV:
  - `action_longitudinal_mean`
  - `action_brake_share`
  - `action_stop_label_mean`
  - `action_stop_label_brake_share`
  - `action_hold_label_mean`
  - `action_hold_label_brake_share`
  - `action_go_label_mean`
  - `action_go_label_brake_share`

Next v3 training change:

- Keep runtime policy pure: no hard brake, no action override, no safety shield.
- Keep red-only drill from green checkpoint.
- Increase `--intent-action-loss-coefficient` from the old red value `0.35` to `3.0` so the actor mean is directly pulled toward the smooth braking target.
- Use checkpoint interval `1` again.
- Evaluate deterministic red behavior immediately after training.

Planned v3 command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage red   --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --checkpoint checkpoints/behavior_red_v3_strong_action_120k.npz   --steps 120000   --rollout-steps 256   --rollout-workers 12   --validation-workers 8   --validation-interval 5   --validation-episodes 8   --checkpoint-interval 1   --max-cars 50   --learning-rate 8e-6   --target-kl 0.0012   --reward-clip 320   --intent-action-loss-coefficient 3.0   --reference-kl-coefficient 0.03   --reference-kl-all-coefficient 0.0   --reference-kl-green-only
```

## 2026-07-01 Red-Only v3-v7 Training Outcome

After v2 failed deterministic red evaluation, several focused red-only runs were executed from the green baseline checkpoint:

- `behavior_red_v3_strong_action_120k`: increased action-target loss to `3.0`.
- `behavior_red_v4_conservative_brake_100k`: added conservative red target profile controls.
- `behavior_red_v5_min_brake_80k`: added a training-only minimum braking target when above the red stop profile.
- `behavior_red_v6_low_value_80k`: reduced value loss coefficient and increased gradient clipping norm so value gradients would not dominate the actor/action-target loss.
- `behavior_red_v7_action_dominant_50k`: made the action-target loss dominant as a diagnostic run.

All runs kept runtime control pure policy output:

- no safety shield
- no hard brake override
- no red-light controller
- no action clamp

New CLI controls added during this iteration:

```text
--red-target-crawl-speed
--red-target-approach-gain
--red-target-stop-margin
--red-target-brake-safety
--red-target-min-brake
--closed-signal-approach-speed-gain
--value-coefficient
--max-grad-norm
```

New evaluation diagnostics added:

```text
action_longitudinal_mean
action_brake_share
action_stop_label_mean
action_stop_label_brake_share
action_hold_label_mean
action_hold_label_brake_share
action_go_label_mean
action_go_label_brake_share
red_drill_safe_pct
```

Summary CSV:

```text
results/red_v2_to_v7_deterministic_summary.csv
```

Best deterministic red result found in this iteration:

```text
checkpoint=checkpoints/behavior_red_v6_low_value_80k_update_0027.npz
red_violations_per_ep=2.53
closed_signal_violations_per_ep=2.53
red_drill_safe_pct=36.67
collisions_per_ep=0.00
proximity_events_per_ep=0.00
action_stop_label_mean=-0.092
action_stop_label_brake_share=0.999
```

This is still not acceptable as a solved red-stop policy. It means about 2.5 of 4 red-facing cars still cross the red line in deterministic red evaluation.

Important finding:

- Rollout metrics sometimes looked strong, for example v4 update 25 had only 2 red crossings in the stochastic rollout batch.
- Deterministic evaluation remained poor because the actor mean stayed near neutral braking.
- Across v2-v7, `action_stop_label_mean` mostly stayed between about `-0.04` and `-0.09`.
- That is too weak to stop cars that spawn 10-30 m before the stop line at 2-6 m/s.

Interpretation:

The current actor head is the bottleneck. Reward shaping, auxiliary action targets, lower value loss, larger gradient norm, and stronger target coefficients improved stochastic rollout windows but did not make the deterministic actor mean produce enough braking. The residual plus intent-blended action head appears to damp the longitudinal output around small negative values.

Next required engineering fix:

1. Redesign the actor output head, not the simulator rules.
2. Keep the graph-attention encoder and critic.
3. Replace the current blended residual/mode action output with a clearer longitudinal control head, for example:
   - one direct longitudinal mean head trained by PPO and action-target loss
   - one steering mean head kept separate
   - optional mode-conditioned residual added only after the direct longitudinal head
4. Add evaluation that reports initial red-state deterministic action at reset, not only episode averages.
5. Retrain green baseline if the actor-head tensor shapes change.
6. Then repeat red-only training.
7. Only after deterministic red stopping works, mix green/red and then reintroduce yellow.

Verification after code changes:

```bash
../.venv/bin/python -m py_compile scripts/train_graph_multitask.py intersection_rl/graph_ppo.py intersection_rl/config.py intersection_rl/env.py
../.venv/bin/python -m pytest -q
```

Result:

```text
64 passed, 1 warning
```

## 2026-07-01 Separate Acceleration/Steering Actor Update

Implemented architecture change:

- Replaced the old residual + intent-blended action output with two direct actor heads:
  - `acceleration_head(features) -> tanh -> action[0]`
  - `steering_head(features) -> tanh -> action[1]`
- The graph attention encoder, shared body, value head, and diagnostic intent head remain.
- Intent prediction no longer controls or blends the action path.
- Training CLI default for `--intent-loss-coefficient` is now `0.0` for this architecture.
- Intent labels are still reported for diagnostics/evaluation, but they are not trained by default and do not choose the action.

Checkpoint compatibility:

- New checkpoints include `actor_head=separate_accel_steer_v1` metadata.
- Loading old checkpoints with `policy_head` / `mode_policy_head` now raises a clear error.
- Because the actor-head tensor names changed, old checkpoints cannot be used as initialization for the new architecture.
- The next real training run must start from scratch with the separate acceleration/steering actor.

Checkpoint cleanup before packaging:

- Deleted all `*_update_*.npz` checkpoints.
- Kept only final checkpoints, `_best` checkpoints, metrics CSV files, and checkpoint README.
- The remaining old checkpoints are retained only as historical experiment records. They are not compatible with the new actor-head architecture.

Verification:

```bash
../.venv/bin/python -m pytest -q
```

Result:

```text
64 passed, 1 warning
```

Immediate next training command direction:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage green   --checkpoint checkpoints/behavior_green_separate_head_v1_300k.npz   --steps 300000   --rollout-steps 256   --rollout-workers 12   --validation-workers 8   --validation-interval 5   --validation-episodes 8   --checkpoint-interval 0   --max-cars 50   --learning-rate 8e-6   --target-kl 0.003   --reward-clip 320
```

After green is stable, red-only training should use the new green checkpoint as both init and reference checkpoint.



## 2026-07-02 Redgreen Stop-Window v2 200k Result

Training command used 12 rollout workers, 8 validation workers, `--checkpoint-interval 0`, and mixed 2/3/4-lane redgreen tasks with 1-car-per-lane plus light 2-cars-per-lane exposure.

Result: do not extend this checkpoint to 1M. The reward-only stop-window version learned to reduce red violations in rollout, but deterministic evaluation exposed two bad failure modes.

Final checkpoint:

```text
2 lanes / 8 cars:  completed_pct=25.0, failed_pct=75.0, stuck_timeout_pct=73.5, red_violations_per_ep=0.12
3 lanes / 12 cars: completed_pct=33.33, failed_pct=66.67, stuck_timeout_pct=65.33, red_violations_per_ep=0.16
4 lanes / 16 cars: completed_pct=37.5, failed_pct=62.5, stuck_timeout_pct=61.25, red_violations_per_ep=0.20
```

Best checkpoint:

```text
2 lanes / 8 cars:  completed_pct=25.0, failed_pct=75.0, stuck_timeout_pct=28.5, red_violations_per_ep=3.72
3 lanes / 12 cars: completed_pct=33.33, failed_pct=66.67, stuck_timeout_pct=25.67, red_violations_per_ep=4.92
4 lanes / 16 cars: completed_pct=37.5, failed_pct=62.5, stuck_timeout_pct=23.25, red_violations_per_ep=6.28
```

Interpretation:

- Final checkpoint nearly eliminates red crossings but does so by becoming too conservative/stuck.
- Best checkpoint moves more than final but still has too many red violations.
- Deterministic stop-label action is still near zero and never crosses the brake-share threshold.
- The current reward-only design is not balanced enough: it can trade red violations against green movement, but it does not learn both at once.

Next fix direction:

- Do not train this run to 1M.
- Add stronger positive green discharge/completion pressure or revise validation score to punish stuck timeout more directly.
- Consider a phase-balanced validation score/checkpoint selector that requires both red safety and green completion.
- If reward-only still cannot make stop-label action negative, the next non-runtime option is a training-only auxiliary action target.

## 2026-07-06 Redgreen Balanced v3 Implementation

Reason:

The previous redgreen stop-window v2 run exposed a bad tradeoff: the final checkpoint had low red violations but became too conservative and stuck, while the `_best` checkpoint moved more but still violated red too often. That means checkpoint selection and reward balance were allowing one behavior to improve while the other regressed.

Implemented changes:

- Redgreen behavior-stage training now uses only one-car-per-lane tasks at first:
  - `redgreen_1_per_lane_2l`: 2 lanes per approach, 8 total cars.
  - `redgreen_1_per_lane_3l`: 3 lanes per approach, 12 total cars.
  - `redgreen_1_per_lane_4l`: 4 lanes per approach, 16 total cars.
- Two-cars-per-lane tasks are intentionally delayed until the basic red/green rule is stable.
- `--behavior-stage redgreen` can now run from scratch without a reference checkpoint. If a reference checkpoint is supplied, reference KL is still available, but the scratch run remains pure RL from environment reward/outcome.
- Redgreen validation now evaluates the same one-car-per-lane densities: `2:8:60`, `3:12:60`, and `4:16:60`.
- Added a redgreen-specific validation score. A `_best` checkpoint must now satisfy the combined objective: completion, closed-signal safety, and low stuck timeout. A checkpoint that avoids red violations by never moving should no longer win validation.
- Strengthened green movement rewards and penalties:
  - higher progress reward
  - higher legal speed reward
  - higher clean completion bonus
  - stronger zero-speed, slow-speed, and no-progress penalties under green
  - stronger legal stall penalties
- Reduced passive red-stop reward dominance:
  - lower closed-signal hold reward
  - lower stopped-in-window reward
  - lower stop-position reward
- Red crossing penalties remain strong. This change does not weaken red-light safety; it reduces the incentive to become permanently stopped.

Runtime purity:

No safety shield, hard stop, behavior cloning, or runtime action correction was added. The policy still outputs continuous acceleration and steering actions. Yellow behavior is still ignored for this phase.

Next training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --checkpoint checkpoints/redgreen_balanced_v3_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 8e-6 \
  --target-kl 0.003 \
  --reward-clip 320
```

Decision rule during training:

- If red violations do not start dropping by about update 40, stop and revise red reward geometry.
- If green completion or stuck timeout is still bad by about update 70, stop and revise green movement reward or validation sampling.
- Do not extend to 1M unless both red safety and green completion improve together.

Evaluation commands after training:

```bash
../.venv/bin/python scripts/train_graph_multitask.py evaluate \
  checkpoints/redgreen_balanced_v3_200k_best.npz \
  --lanes 2 --cars 8 --episode-seconds 60 --episodes 50 \
  --eval-mode redgreen --eval-workers 8 \
  --output-csv results/eval_redgreen_balanced_v3_best_2l_8c.csv

../.venv/bin/python scripts/train_graph_multitask.py evaluate \
  checkpoints/redgreen_balanced_v3_200k_best.npz \
  --lanes 3 --cars 12 --episode-seconds 60 --episodes 50 \
  --eval-mode redgreen --eval-workers 8 \
  --output-csv results/eval_redgreen_balanced_v3_best_3l_12c.csv

../.venv/bin/python scripts/train_graph_multitask.py evaluate \
  checkpoints/redgreen_balanced_v3_200k_best.npz \
  --lanes 4 --cars 16 --episode-seconds 60 --episodes 50 \
  --eval-mode redgreen --eval-workers 8 \
  --output-csv results/eval_redgreen_balanced_v3_best_4l_16c.csv
```

Separate green sanity evaluation:

```bash
../.venv/bin/python scripts/train_graph_multitask.py evaluate \
  checkpoints/redgreen_balanced_v3_200k_best.npz \
  --lanes 2 --cars 8 --episode-seconds 60 --episodes 50 \
  --eval-mode green --eval-workers 8 \
  --output-csv results/eval_redgreen_balanced_v3_best_green_2l_8c.csv
```

Verification after implementation:

```text
../.venv/bin/python -m py_compile intersection_rl/config.py intersection_rl/graph_ppo.py scripts/train_graph_multitask.py
../.venv/bin/python -m pytest -q
64 passed, 1 warning
```

## 2026-07-06 Redgreen Balanced v4 Initialization Fix

Reason:

The v3 redgreen run failed on the easiest deterministic 2-lane/8-car evaluation. The `_best` checkpoint had 25% completion and 4.64 red violations per episode. The final checkpoint reduced red violations to 1.32 per episode but had 58.5% stuck timeout. Diagnostics showed the same action-level problem in both checkpoints: stop/hold-labeled samples had near-zero longitudinal action and `action_stop_label_brake_share = 0.0`. The policy was not discovering negative acceleration for red stopping.

Root cause found:

The separate acceleration actor was initialized with a positive bias of `0.30`, and the longitudinal policy std was initialized near `exp(-1.8) ~= 0.165`. In a mixed red/green scratch run this starts the policy as "go everywhere" and gives very little early braking exploration. PPO then receives many red failures but few useful negative-acceleration samples to reinforce.

Implemented v4 changes:

- Removed the positive acceleration-head bias. Scratch policy now starts with neutral longitudinal mean.
- Increased initial longitudinal exploration by changing `log_std` from `[-1.8, -1.8]` to `[-1.2, -1.8]`; steering exploration remains unchanged.
- Increased `red_light_violation_penalty` from `320` to `420`.
- Increased stop-window speed penalty from `12` to `18`.
- Increased stopped-in-window reward from `1.0` to `1.5`.

What did not change:

- No safety shield.
- No action correction.
- No behavior cloning.
- No supervised action target.
- Yellow is still ignored for this phase.
- Runtime remains pure continuous-action PPO.

Next run:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --checkpoint checkpoints/redgreen_balanced_v4_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 8e-6 \
  --target-kl 0.003 \
  --reward-clip 320
```

Verification:

```text
../.venv/bin/python -m py_compile intersection_rl/config.py intersection_rl/graph_ppo.py scripts/train_graph_multitask.py
../.venv/bin/python -m pytest -q
64 passed, 1 warning
```

## 2026-07-06 Redgreen Balanced v5 Initialization Fix

Reason:

The v4 run fixed the extreme red-violation problem but overcorrected into almost no green movement. Through update 20, clean completions stayed near 0-5 vehicles per update, so the run was stopped and its interrupted checkpoint/metrics were deleted.

v5 change:

- Keep larger longitudinal exploration, but reduce the overconservative start:
  - longitudinal `log_std`: `-1.0`
  - steering `log_std`: `-1.8`
  - acceleration-head bias: `0.15`
- This gives the policy a small go prior for green discharge while still sampling braking often enough for red-stop learning.
- Red reward weights from v4 remain: red crossing penalty `420`, stop-window speed penalty `18`, stopped-in-window reward `1.5`.

Why this is still pure RL:

The initialization only changes the starting distribution of the continuous actor. It does not force an action, override unsafe actions, or provide supervised labels as training targets. The policy must still learn from reward and episode outcomes.

Expected signal:

Compared with v3, red failures should drop earlier because braking samples are common. Compared with v4, clean completions should be much higher because the actor no longer starts neutral/stopped.

## 2026-07-06 Redgreen Balanced v6 Full-Cycle Signal Fix

Reason:

The v5 run showed a strong clue: red failures dropped, but completion plateaued around 40-60 rollout completions and validation became stale. Inspection found a structural training mismatch. The redgreen task families were using `signal_mode="green"`. In `MultiTaskIntersectionEnv`, that extends one green phase for the whole episode. Therefore, vehicles spawned on the opposite approaches saw red for the entire episode, learned to stop, and never received a later green phase to discharge. High completion was impossible for those vehicles.

Implemented fix:

- Changed all redgreen task families from fixed-green signal mode to full-cycle randomized signal mode:
  - `redgreen_mixed_basic`
  - `redgreen_1_per_lane_2l`
  - `redgreen_1_per_lane_3l`
  - `redgreen_1_per_lane_4l`
  - `redgreen_2_per_lane_2l`
  - `redgreen_2_per_lane_3l`
  - `redgreen_2_per_lane_4l`
- The current redgreen stage still trains only the one-car-per-lane tasks, but those tasks now include real signal phase changes during the episode.

Why this matters:

The previous task setup could teach stop-on-red but not release-on-green for initially red-facing vehicles. Full-cycle signal training is required for the policy to learn the complete behavior:

```text
red before stop line -> stop before line
later green -> accelerate and complete
current green -> move and complete
```

Runtime purity:

This remains pure RL. No safety shield, hard stop, behavior cloning, or action override was added. The simulator now exposes the correct traffic-light dynamics during training.

Expected signal in v6:

- Go samples should increase relative to v5 because initially red vehicles can later become green.
- Completion should not be structurally capped by fixed-red approaches.
- Red violations should still trend down because v5 initialization/reward settings are retained.

## 2026-07-06 Redgreen No-Yellow Structural Fix

Reason:

Green-only training learned movement, and red-only training learned stopping, but mixed redgreen training failed because the mixed setup was not clean enough:

- The original redgreen tasks used fixed `green` signal mode, which left the opposite approaches red for the whole episode. Those vehicles could learn to stop, but they never received a later green to release and complete.
- Switching those tasks to the existing `random` signal mode fixed phase cycling, but it also introduced yellow phases. Yellow was not part of the current target and added extra failure noise.

Implemented changes:

- Added true no-yellow support to the simulator signal phase logic. If `signal_yellow_seconds == 0.0`, `_signal_phase()` switches directly between protected-left/green phases and never returns a yellow phase.
- Added a redgreen task mode in `MultiTaskIntersectionEnv`:
  - signal cycles normally between NS and EW approaches
  - protected-left phases remain enabled
  - yellow duration is forced to `0.0`
  - initial signal phase is randomized
- Updated redgreen scenario tasks to use `signal_mode="redgreen"` instead of `random` or fixed `green`.
- Updated redgreen evaluation and validation to use the no-yellow redgreen mode.
- Updated redgreen stage training mix to include focused drills plus mixed release examples:
  - `green_basic`
  - `green_queue_basic`
  - `red_brake_basic`
  - `red_creep_release_basic`
  - `redgreen_1_per_lane_2l`
  - `redgreen_1_per_lane_3l`
  - `redgreen_1_per_lane_4l`

Current target behavior:

```text
green -> move and complete
red/non-green before stop line -> stop before stop line
red now, later green -> release and complete
```

What was removed/cleaned:

- Deleted failed redgreen v2/v3 checkpoints, metrics, logs, and eval CSV files.
- Interrupted v4/v5/v6 failed artifacts had already been removed.
- Yellow support remains in the simulator for future phases, but it is no longer used by the current redgreen stage.

Verification:

```text
redgreen smoke check phases: [EW_GREEN, EW_LEFT_GREEN, NS_GREEN, NS_LEFT_GREEN]
signal_yellow_seconds: 0.0
../.venv/bin/python -m pytest -q
64 passed, 1 warning
```

Next training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --checkpoint checkpoints/redgreen_no_yellow_v1_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 8e-6 \
  --target-kl 0.003 \
  --reward-clip 320
```

Decision rule:

- Continue only if closed-signal violations trend down and clean completions stay alive.
- Stop early if the policy again learns only stopping or only moving.

## 2026-07-06 Redgreen No-Yellow v1 200k Result

Training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --checkpoint checkpoints/redgreen_no_yellow_v1_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 8e-6 \
  --target-kl 0.003 \
  --reward-clip 320
```

Training result:

- Training completed at update 66 / 202,752 collected steps.
- Yellow violations stayed at zero, confirming the no-yellow redgreen mode is active.
- Red violations dropped strongly during rollout.
- Final rollout was promising: `clean=87`, `failed=9`, `red=3`, `yellow=0`, `coll=3`, `prox=13`.
- Validation still selected an earlier checkpoint and remained stale later, so validation scoring may still be too conservative about green release.

Deterministic evaluation, final checkpoint:

```text
2 lanes / 8 cars / 60s / 50 episodes
completed_pct=45.25
failed_pct=54.75
incomplete_pct=46.50
stuck_timeout_pct=30.50
moving_timeout_pct=16.00
collisions_per_ep=0.00
proximity_events_per_ep=0.00
red_violations_per_ep=0.66
yellow_violations_per_ep=0.00
```

```text
3 lanes / 12 cars / 60s / 30 episodes
completed_pct=58.89
failed_pct=41.11
incomplete_pct=31.67
stuck_timeout_pct=20.56
moving_timeout_pct=11.11
collisions_per_ep=0.03
proximity_events_per_ep=0.00
red_violations_per_ep=1.07
yellow_violations_per_ep=0.00
```

```text
4 lanes / 16 cars / 60s / 30 episodes
completed_pct=66.25
failed_pct=33.75
incomplete_pct=23.96
stuck_timeout_pct=15.63
moving_timeout_pct=8.33
collisions_per_ep=0.00
proximity_events_per_ep=0.00
red_violations_per_ep=1.57
yellow_violations_per_ep=0.00
```

Best checkpoint on 2 lanes / 8 cars:

```text
completed_pct=45.75
failed_pct=54.25
incomplete_pct=47.00
stuck_timeout_pct=31.00
moving_timeout_pct=16.00
collisions_per_ep=0.00
proximity_events_per_ep=0.00
red_violations_per_ep=0.58
yellow_violations_per_ep=0.00
```

Interpretation:

This is a meaningful improvement over the earlier mixed runs:

- Red stopping is now learned well enough for the current target range.
- Yellow has been removed from this phase correctly.
- Collision and proximity behavior are clean in deterministic eval.
- The remaining major failure is not red or collision. It is green release / completion after stopping.

Diagnostic evidence:

- `lead_green_start_delay_seconds_per_ep` is high, roughly 35-40 seconds.
- `green_stopped_too_far_events_per_ep` is very high.
- Most incomplete vehicles are stuck timeouts rather than moving timeouts.
- Stop-label action has learned braking: `action_stop_label_brake_share=1.0`.
- Go-label action is positive, but many vehicles still fail to release strongly enough after waiting.

Next fix direction:

Do not change back to yellow or right-on-red. The next version should target green release after red stop:

- Add/strengthen reward for acceleration and progress immediately after a stopped red-facing vehicle receives green.
- Penalize stopped-too-far under green more directly.
- Add a focused no-yellow `redgreen_release_drill` task: cars start stopped before red, then receive green within the episode and must complete.
- Update validation score to value completion recovery after red stop, not only red safety.

## 2026-07-06 Green Release Reward v2 Implementation

Reason:

The no-yellow redgreen v1 checkpoint learned red stopping and kept collision/proximity clean, but completion stayed low because vehicles often stayed stopped or moved too slowly after green became available. Deterministic evaluation showed high green-release delay, many green stopped-too-far events, and high stuck timeout.

Implemented changes:

- Strengthened green movement reward:
  - `permitted_speed_reward`: `0.80 -> 1.10`
  - `permitted_acceleration_reward`: `0.35 -> 0.55`
  - `green_queue_progress_reward`: `1.30 -> 2.40`
  - `green_queue_acceleration_reward`: `0.24 -> 0.70`
- Strengthened green stopped/slow/no-progress penalties:
  - `green_zero_speed_penalty`: `22.0 -> 35.0`
  - `green_slow_speed_penalty`: `8.0 -> 14.0`
  - `green_no_progress_penalty`: `14.0 -> 24.0`
  - `permitted_idle_penalty`: `3.0 -> 5.5`
  - `legal_stall_penalty`: `3.0 -> 5.0`
  - `legal_stall_time_penalty`: `1.0 -> 2.0`
  - `green_queue_idle_penalty`: `3.20 -> 5.50`
  - `green_queue_stall_time_penalty`: `1.50 -> 2.50`
  - `green_queue_stopped_far_penalty`: `2.4 -> 7.0`
- Added explicit green-release terms:
  - `green_release_progress_reward = 3.0`
  - `green_release_acceleration_reward = 1.2`
  - `green_release_delay_penalty = 2.5`
  - `green_release_stopped_far_penalty = 6.0`
- In the reward function, if movement is legally permitted, the front gap is clear, and the vehicle is stopped/slow or has accumulated legal stall time:
  - reward progress more strongly
  - reward positive acceleration more strongly
  - penalize every timestep of green release delay after a short grace period
  - penalize being stopped/slow far before the stop line
- Added focused no-yellow `redgreen_release_drill` task:
  - vehicles spawn on currently closed approaches
  - signal changes to their green shortly afterward
  - intended behavior is stop/wait briefly, then accelerate and complete
- Added `redgreen_release_drill` to the redgreen behavior-stage training mix.
- Strengthened redgreen validation score against green delay/stuck behavior:
  - stronger completion weighting
  - stronger timeout/stuck penalties
  - stronger penalties for `queue_discharge_delay_seconds`, `green_stuck_events`, and `green_stopped_too_far_events`

Runtime purity:

This is still pure RL at runtime. No safety shield, no action override, no hard stop/go rule, and no behavior cloning were added. These are reward/task/validation changes only.

Verification:

```text
redgreen_release_drill smoke test:
signal_yellow_seconds=0.0
phases include no YELLOW phase

../.venv/bin/python -m pytest -q
64 passed, 1 warning
```

Next training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --checkpoint checkpoints/redgreen_release_v2_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 8e-6 \
  --target-kl 0.003 \
  --reward-clip 320
```

Decision rule:

The key metrics to watch are `completed`, `stuck_timeout_pct`, `lead_green_start_delay_seconds_per_ep`, `green_stopped_too_far_events_per_ep`, and red violations. Red was already acceptable in v1; v2 should primarily improve release/completion without losing red safety.

## 2026-07-06 Release v2/v3 Attempt Reverted

What happened:

After the no-yellow v1 checkpoint, we tried to improve completion by adding stronger green-release penalties/rewards and a focused `redgreen_release_drill`. The goal was correct: reduce green-start delay and stuck timeout. However, the first two attempts made mixed learning worse.

Observed during interrupted v2/v3 runs:

- Red violations stopped improving at the rate seen in no-yellow v1.
- Completion did not improve.
- The extra release pressure competed with red-stop learning too early.
- The policy did not reach the useful v1 pattern where red drops into low double digits while completion remains alive.

Decision:

The failed v2/v3 run artifacts were deleted, and the active code was reverted to the best-known no-yellow v1 baseline:

- no active `redgreen_release_drill`
- no active `green_release_*` reward fields
- green reward weights restored to the v1 values
- redgreen validation score restored to v1 weighting
- no-yellow redgreen signal mode remains active and is still the correct baseline

Current best baseline:

```text
checkpoint: checkpoints/redgreen_no_yellow_v1_200k.npz
2 lanes / 8 cars: completed=45.25%, red=0.66/ep, collision=0.00/ep, proximity=0.00/ep
3 lanes / 12 cars: completed=58.89%, red=1.07/ep, collision=0.03/ep, proximity=0.00/ep
4 lanes / 16 cars: completed=66.25%, red=1.57/ep, collision=0.00/ep, proximity=0.00/ep
```

Updated conclusion:

The next improvement should not add a heavy release drill into the full redgreen mix from scratch. A better next step is either:

- train from the no-yellow v1 checkpoint with a very small release-focused fine-tune, or
- add phase scheduling inside the same run so red-stop learning is established first, then release pressure is introduced gradually.

Verification after reverting active code:

```text
../.venv/bin/python -m pytest -q
64 passed, 1 warning
```



## 2026-07-07 Protected Red/Green Generalized v1 Selected

Selected checkpoint:

```text
checkpoints/protected_redgreen_generalized_v1_selected.npz
```

This run fixed the earlier route-specific release problem by replacing the left-only release drill with a generalized `redgreen_next_release` task. The task samples vehicles waiting on whichever movement will receive green next, covering both straight release after protected-left and protected-left release after straight green. The policy is still pure RL at runtime: no safety shield, no red-light controller, no action override, no behavior cloning.

Training source:

```text
init/reference checkpoint: checkpoints/protected_green_v1_scratch_200k_best.npz
run checkpoint: checkpoints/redgreen_generalized_from_green_v1_120k.npz
selected copy: checkpoints/protected_redgreen_generalized_v1_selected.npz
```

Final 60-episode evaluation:

| Scenario | Completed | Red violations / ep | Stuck timeout | Moving timeout | Collisions / ep | Proximity / ep |
|---|---:|---:|---:|---:|---:|---:|
| 2 lanes / 8 cars / 60s | 93.54% | 0.52 | 0.00% | 0.00% | 0.00 | 0.00 |
| 3 lanes / 12 cars / 60s | 93.06% | 0.83 | 0.00% | 0.00% | 0.00 | 0.00 |
| 4 lanes / 16 cars / 60s | 93.33% | 1.07 | 0.00% | 0.00% | 0.00 | 0.00 |

Evaluation CSVs:

```text
results/eval_redgreen_generalized_from_green_v1_final_2l8c60.csv
results/eval_redgreen_generalized_from_green_v1_final_3l12c60.csv
results/eval_redgreen_generalized_from_green_v1_final_4l16c60.csv
```

Graphs:

```text
graphs/protected_redgreen_generalized_v1/final_eval_metrics.png
graphs/protected_redgreen_generalized_v1/baseline_comparison.png
graphs/protected_redgreen_generalized_v1/training_trend.png
```

Important packaging note: `redgreen_generalized_from_green_v1_120k_best.npz` was deleted because validation selected an earlier checkpoint that evaluated badly. Use the selected final checkpoint above.
