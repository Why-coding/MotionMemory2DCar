# Manifest - Current Clean Handoff

Date: 2026-07-07

## Kept Checkpoints

- checkpoints/protected_redgreen_generalized_v1_selected.npz - selected demo checkpoint for protected-left red/green. Use this for the protected redgreen demo.
- checkpoints/red_queue_v4_far_recover_40k_best.npz - experimental red-queue candidate. Not demo-selected; needs more queue-spacing work and redgreen retention eval.

## Kept Demo Media

- results/simulator_rollouts/protected_redgreen_generalized_v1_2l8c_seed130/rollout.gif
- results/simulator_rollouts/protected_redgreen_generalized_v1_3l12c_seed131/rollout.gif
- results/simulator_rollouts/protected_redgreen_generalized_v1_4l16c_seed132/rollout.gif

The matching PNG frames and summary.txt files are kept with each rollout. CSV traces were removed during cleanup.

## Kept Graphs

- graphs/protected_redgreen_generalized_v1/baseline_comparison.png
- graphs/protected_redgreen_generalized_v1/final_eval_metrics.png
- graphs/protected_redgreen_generalized_v1/training_trend.png

## Removed From Clean Handoff

Removed failed/obsolete checkpoints, train metric CSVs, eval CSVs, old logs, right-on-red failed checkpoints, older red-queue attempts, and stale zip archives.

## Current Work

Right-on-red is postponed. Current technical focus is red queue behavior: stop close to the red stop line, maintain safe follower gaps, and preserve green discharge through redgreen replay.
