from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from intersection_rl.geometry import ROUTES


@dataclass(frozen=True, slots=True)
class GraphObservationSpec:
    """Shape metadata for the road-agent graph observation."""

    ego_size: int = 27
    node_size: int = 24
    edge_size: int = 22
    max_vehicle_nodes: int = 18

    @property
    def max_nodes(self) -> int:
        return self.max_vehicle_nodes + 2

    @property
    def lane_context_index(self) -> int:
        return self.max_vehicle_nodes

    @property
    def signal_context_index(self) -> int:
        return self.max_vehicle_nodes + 1


class GraphObserver:
    """Build realistic ego-centric road-agent graph observations.

    The graph is built separately for each controlled ego vehicle. Each ego
    graph contains all active vehicle slots plus two non-vehicle context nodes:
    one lane/route/map context node and one traffic-signal context node.

    No exact time-to-green or future signal timing is exposed. The policy sees
    current signal state, map/legal context, ego state, and observed nearby
    agent states.
    """

    def __init__(self, max_vehicle_nodes: int = 18) -> None:
        self.spec = GraphObservationSpec(max_vehicle_nodes=max_vehicle_nodes)

    def encode(self, env) -> dict[str, np.ndarray]:
        max_cars = env.config.max_cars
        if max_cars > self.spec.max_vehicle_nodes:
            raise ValueError(
                f"GraphObserver max_vehicle_nodes={self.spec.max_vehicle_nodes} "
                f"is smaller than env max_cars={max_cars}"
            )
        ego = np.zeros((max_cars, self.spec.ego_size), dtype=np.float32)
        nodes = np.zeros((max_cars, self.spec.max_nodes, self.spec.node_size), dtype=np.float32)
        edges = np.zeros((max_cars, self.spec.max_nodes, self.spec.edge_size), dtype=np.float32)
        node_mask = np.zeros((max_cars, self.spec.max_nodes), dtype=np.float32)
        active_mask = np.zeros(max_cars, dtype=np.float32)
        phase, _ = env._signal_phase()
        active = [vehicle for vehicle in env.vehicles if vehicle.active]

        for vehicle in active:
            vehicle_id = vehicle.vehicle_id
            active_mask[vehicle_id] = 1.0
            ego[vehicle_id] = self._ego_features(env, vehicle, phase, len(active))
            for other in active:
                node_index = other.vehicle_id
                nodes[vehicle_id, node_index] = self._vehicle_node_features(env, vehicle, other)
                edges[vehicle_id, node_index] = self._edge_features(env, vehicle, other)
                node_mask[vehicle_id, node_index] = 1.0
            lane_index = self.spec.lane_context_index
            signal_index = self.spec.signal_context_index
            nodes[vehicle_id, lane_index] = self._lane_context_node(env, vehicle)
            edges[vehicle_id, lane_index] = self._lane_context_edge(env, vehicle)
            node_mask[vehicle_id, lane_index] = 1.0
            nodes[vehicle_id, signal_index] = self._signal_context_node(env, vehicle, phase)
            edges[vehicle_id, signal_index] = self._signal_context_edge(env, vehicle, phase)
            node_mask[vehicle_id, signal_index] = 1.0

        return {
            "ego": np.clip(ego, -1.0, 1.0),
            "nodes": np.clip(nodes, -1.0, 1.0),
            "edges": np.clip(edges, -1.0, 1.0),
            "node_mask": node_mask,
            "active_mask": active_mask,
        }

    def _ego_features(self, env, vehicle, phase: str, active_count: int) -> np.ndarray:
        distance_to_stop = vehicle.stop_progress - vehicle.progress
        front_gap, front_relative_speed, front_ttc = env._front_vehicle_metrics(vehicle)
        green = env._movement_has_green(vehicle)
        yellow = self._ego_axis_yellow(vehicle, phase)
        closed = not green and not yellow
        movement_permitted = env._movement_permitted(vehicle)
        lateral_limit = max(env._max_lateral_offset(), 1e-3)
        lane_scale = max(1, env.episode_lanes_per_approach - 1)
        route_one_hot = [float(vehicle.route == route) for route in ROUTES]
        values = [
            vehicle.speed / max(env.config.max_speed, 1e-3),
            vehicle.acceleration / max(env.config.comfortable_braking, 1e-3),
            np.clip(distance_to_stop / env.config.road_length, -1.0, 1.0),
            float(distance_to_stop <= 0.0),
            np.clip(env._stopping_distance(vehicle) / env.config.road_length, 0.0, 1.0),
            np.clip(vehicle.progress / max(vehicle.path.length, 1e-3), 0.0, 1.0),
            np.clip(vehicle.lateral_offset / lateral_limit, -1.0, 1.0),
            vehicle.lane / lane_scale,
            vehicle.destination_lane / lane_scale,
            env.episode_lanes_per_approach / 5.0,
            active_count / max(env.config.max_cars, 1),
            float(green),
            float(yellow),
            float(closed),
            float(movement_permitted),
            float(env.episode_protected_left_signal),
            float(env.episode_allow_right_on_red),
            float(env._can_turn_right_on_red(vehicle)),
            float(env._is_rightmost_lane(vehicle)),
            *route_one_hot,
            np.clip(front_gap / env.config.road_length, 0.0, 1.0),
            np.clip(front_relative_speed / max(env.config.max_speed, 1e-3), -1.0, 1.0),
            np.clip(front_ttc / 10.0, 0.0, 1.0),
            float(front_gap < env.config.minimum_front_gap),
            float(env._inside_intersection(vehicle)),
        ]
        return np.asarray(values, dtype=np.float32)

    def _vehicle_node_features(self, env, ego_vehicle, other) -> np.ndarray:
        ego_position, ego_heading = ego_vehicle.pose()
        other_position, other_heading = other.pose()
        forward = np.array([np.cos(ego_heading), np.sin(ego_heading)])
        right = np.array([-np.sin(ego_heading), np.cos(ego_heading)])
        delta = other_position - ego_position
        rel_forward = float(np.dot(delta, forward))
        rel_right = float(np.dot(delta, right))
        distance = float(np.linalg.norm(delta))
        heading_delta = np.arctan2(
            np.sin(other_heading - ego_heading),
            np.cos(other_heading - ego_heading),
        )
        other_distance_to_stop = other.stop_progress - other.progress
        same_lane = ego_vehicle.approach == other.approach and ego_vehicle.lane == other.lane
        same_approach = ego_vehicle.approach == other.approach
        same_axis = self._axis(ego_vehicle.approach) == self._axis(other.approach)
        opposite_approach = self._opposite_approach(ego_vehicle.approach) == other.approach
        crossing_axis = not same_axis
        other_leftmost = other.lane == 0
        other_rightmost = other.lane == env.episode_lanes_per_approach - 1
        values = [
            np.clip(rel_forward / env.config.road_length, -1.0, 1.0),
            np.clip(rel_right / env.config.road_length, -1.0, 1.0),
            np.clip(distance / env.config.road_length, 0.0, 1.0),
            np.clip((other.speed - ego_vehicle.speed) / max(env.config.max_speed, 1e-3), -1.0, 1.0),
            other.speed / max(env.config.max_speed, 1e-3),
            other.acceleration / max(env.config.comfortable_braking, 1e-3),
            np.sin(heading_delta),
            np.cos(heading_delta),
            float(rel_forward >= 0.0),
            float(same_lane),
            float(same_approach),
            float(same_axis),
            float(crossing_axis or opposite_approach),
            np.clip(other_distance_to_stop / env.config.road_length, -1.0, 1.0),
            float(other_distance_to_stop <= 0.0),
            float(self._visible_lane_green(env, other)),
            float(env._inside_intersection(other)),
            other.lane / max(1, env.episode_lanes_per_approach - 1),
            0.0,
            float(other_leftmost),
            float(other_rightmost),
            float(not other_leftmost and not other_rightmost),
            float(other.vehicle_id == ego_vehicle.vehicle_id),
            1.0,
        ]
        return np.asarray(values, dtype=np.float32)

    def _edge_features(self, env, ego_vehicle, other) -> np.ndarray:
        ego_position, ego_heading = ego_vehicle.pose()
        other_position, _ = other.pose()
        forward = np.array([np.cos(ego_heading), np.sin(ego_heading)])
        delta = other_position - ego_position
        rel_forward = float(np.dot(delta, forward))
        distance = float(np.linalg.norm(delta))
        same_lane = ego_vehicle.approach == other.approach and ego_vehicle.lane == other.lane
        same_approach = ego_vehicle.approach == other.approach
        adjacent_lane = same_approach and abs(ego_vehicle.lane - other.lane) == 1
        same_axis = self._axis(ego_vehicle.approach) == self._axis(other.approach)
        opposite_approach = self._opposite_approach(ego_vehicle.approach) == other.approach
        potential_conflict = (not same_axis) or opposite_approach
        ego_distance_to_stop = ego_vehicle.stop_progress - ego_vehicle.progress
        other_distance_to_stop = other.stop_progress - other.progress
        same_lane_front = same_lane and other.progress > ego_vehicle.progress
        same_lane_behind = same_lane and other.progress < ego_vehicle.progress
        closing_speed = max(0.0, ego_vehicle.speed - other.speed) if same_lane_front else 0.0
        observed_ttc = distance / max(closing_speed, 0.1) if closing_speed > 0.0 else 10.0
        values = [
            float(other.vehicle_id == ego_vehicle.vehicle_id),
            float(same_lane_front),
            float(same_lane_behind),
            float(same_lane),
            float(adjacent_lane),
            float(same_approach),
            float(potential_conflict),
            float(env._inside_intersection(other)),
            float(rel_forward >= 0.0),
            float(other_distance_to_stop <= 0.0),
            float(self._visible_lane_green(env, other)),
            float(abs(ego_distance_to_stop) < env.config.conflict_lookahead_distance),
            float(abs(other_distance_to_stop) < env.config.conflict_lookahead_distance),
            np.clip(distance / env.config.road_length, 0.0, 1.0),
            np.clip(rel_forward / env.config.road_length, -1.0, 1.0),
            np.clip((other.speed - ego_vehicle.speed) / max(env.config.max_speed, 1e-3), -1.0, 1.0),
            np.clip(observed_ttc / 10.0, 0.0, 1.0),
            float(distance < env.config.minimum_front_gap),
            0.0,
            0.0,
            0.0,
            1.0,
        ]
        return np.asarray(values, dtype=np.float32)

    def _lane_context_node(self, env, vehicle) -> np.ndarray:
        distance_to_stop = vehicle.stop_progress - vehicle.progress
        values = [
            env.episode_lanes_per_approach / 5.0,
            vehicle.lane / max(1, env.episode_lanes_per_approach - 1),
            vehicle.destination_lane / max(1, env.episode_lanes_per_approach - 1),
            float(vehicle.route == "left"),
            float(vehicle.route == "straight"),
            float(vehicle.route == "right"),
            np.clip(distance_to_stop / env.config.road_length, -1.0, 1.0),
            np.clip(vehicle.progress / max(vehicle.path.length, 1e-3), 0.0, 1.0),
            float(env._is_rightmost_lane(vehicle)),
            float(env.episode_protected_left_signal),
            float(env.episode_allow_right_on_red),
            float(env.config.strict_lane_mapping),
            env.config.lane_width / 6.0,
            env.config.vehicle_length / 8.0,
            env.config.vehicle_width / 3.0,
            env.config.minimum_front_gap / 15.0,
            env.config.proximity_clearance / 3.0,
            env.config.max_speed / 20.0,
            0.0,
            0.0,
            0.0,
            1.0,
            0.0,
            1.0,
        ]
        return np.asarray(values, dtype=np.float32)

    def _signal_context_node(self, env, vehicle, phase: str) -> np.ndarray:
        green = env._movement_has_green(vehicle)
        yellow = self._ego_axis_yellow(vehicle, phase)
        closed = not green and not yellow
        values = [
            float(green),
            float(yellow),
            float(closed),
            float(env._movement_permitted(vehicle)),
            float(env._can_turn_right_on_red(vehicle)),
            float(env.episode_protected_left_signal),
            float(env.episode_allow_right_on_red),
            float(vehicle.route == "left"),
            float(vehicle.route == "straight"),
            float(vehicle.route == "right"),
            float(vehicle.stop_progress - vehicle.progress <= 0.0),
            np.clip((vehicle.stop_progress - vehicle.progress) / env.config.road_length, -1.0, 1.0),
            vehicle.speed / max(env.config.max_speed, 1e-3),
            env.config.signal_green_seconds / 20.0,
            env.config.signal_yellow_seconds / 10.0,
            env.config.left_signal_green_seconds / 10.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            1.0,
            1.0,
        ]
        return np.asarray(values, dtype=np.float32)

    def _lane_context_edge(self, env, vehicle) -> np.ndarray:
        return np.asarray(
            [0.0] * 18 + [1.0, 0.0, float(env.config.strict_lane_mapping), 1.0],
            dtype=np.float32,
        )

    def _signal_context_edge(self, env, vehicle, phase: str) -> np.ndarray:
        green = env._movement_has_green(vehicle)
        yellow = self._ego_axis_yellow(vehicle, phase)
        closed = not green and not yellow
        signal_relevant = float(
            vehicle.stop_progress - vehicle.progress < env.config.queue_approach_distance
        )
        return np.asarray(
            [0.0] * 18 + [0.0, 1.0, signal_relevant, float(closed or yellow)],
            dtype=np.float32,
        )

    @staticmethod
    def _ego_axis_yellow(vehicle, phase: str) -> bool:
        axis = "NS" if vehicle.approach in ("N", "S") else "EW"
        return phase == f"{axis}_YELLOW"

    @staticmethod
    def _axis(approach: str) -> str:
        return "NS" if approach in ("N", "S") else "EW"

    @staticmethod
    def _opposite_approach(approach: str) -> str:
        return {"N": "S", "S": "N", "E": "W", "W": "E"}[approach]

    @staticmethod
    def _visible_lane_green(env, vehicle) -> bool:
        if env.episode_protected_left_signal and vehicle.lane == 0:
            return env._has_green(vehicle.approach, "left")
        return env._has_green(vehicle.approach, "straight")
