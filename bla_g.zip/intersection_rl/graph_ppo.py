from __future__ import annotations

import csv
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, replace
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.distributions import Normal, kl_divergence
import torch.nn.functional as F

from intersection_rl.config import PPOConfig
from intersection_rl.graph_observation import GraphObserver


class GraphAttentionBlock(nn.Module):
    """One ego-readout graph-attention block with typed edge conditioning."""

    def __init__(self, hidden_size: int) -> None:
        super().__init__()
        self.query = nn.Linear(hidden_size, hidden_size)
        self.key = nn.Linear(hidden_size, hidden_size)
        self.value = nn.Linear(hidden_size, hidden_size)
        self.edge_key = nn.Linear(hidden_size, hidden_size)
        self.edge_value = nn.Linear(hidden_size, hidden_size)
        self.edge_bias = nn.Linear(hidden_size, 1)
        self.update = nn.Sequential(
            nn.Linear(2 * hidden_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, hidden_size),
        )
        self.norm = nn.LayerNorm(hidden_size)

    def forward(
        self,
        ego: torch.Tensor,
        nodes: torch.Tensor,
        edges: torch.Tensor,
        node_mask: torch.Tensor,
    ) -> torch.Tensor:
        query = self.query(ego).unsqueeze(1)
        keys = self.key(nodes) + self.edge_key(edges)
        values = self.value(nodes) + self.edge_value(edges)
        scores = (query * keys).sum(dim=-1) / np.sqrt(float(ego.shape[-1]))
        scores = scores + self.edge_bias(edges).squeeze(-1)
        valid = node_mask > 0.5
        scores = scores.masked_fill(~valid, -1.0e9)
        weights = torch.softmax(scores, dim=-1)
        weights = torch.where(valid, weights, torch.zeros_like(weights))
        weights = weights / torch.clamp(weights.sum(dim=-1, keepdim=True), min=1.0e-6)
        context = torch.sum(weights.unsqueeze(-1) * values, dim=1)
        return self.norm(ego + self.update(torch.cat((ego, context), dim=-1)))


class GraphActorCritic(nn.Module):
    """Typed road-agent graph attention actor-critic.

    Each controlled vehicle receives one ego-centric graph. The graph contains
    all active vehicle nodes plus lane/map and signal context nodes. Edge
    features encode same-lane, front/back, adjacent-lane, observable
    interaction geometry, signal, and context relationships.
    """

    min_log_std = -2.5
    max_log_std = -0.8

    def __init__(
        self,
        ego_size: int,
        node_size: int,
        edge_size: int,
        max_nodes: int,
        hidden_size: int = 128,
        action_size: int = 2,
        layers: int = 2,
        seed: int = 7,
    ) -> None:
        super().__init__()
        torch.manual_seed(seed)
        self.ego_size = ego_size
        self.node_size = node_size
        self.edge_size = edge_size
        self.max_nodes = max_nodes
        self.hidden_size = hidden_size
        self.action_size = action_size
        self.intent_size = 4
        self.layers = layers
        self.ego_encoder = nn.Sequential(
            nn.Linear(ego_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.Tanh(),
        )
        self.node_encoder = nn.Sequential(
            nn.Linear(node_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.Tanh(),
        )
        self.edge_encoder = nn.Sequential(
            nn.Linear(edge_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.Tanh(),
        )
        self.attention_layers = nn.ModuleList(
            GraphAttentionBlock(hidden_size) for _ in range(layers)
        )
        self.body = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh(),
        )
        if action_size != 2:
            raise ValueError("GraphActorCritic expects [longitudinal, steering] actions")
        self.acceleration_head = nn.Linear(hidden_size, 1)
        self.steering_head = nn.Linear(hidden_size, 1)
        self.value_head = nn.Linear(hidden_size, 1)
        self.intent_head = nn.Linear(hidden_size, self.intent_size)
        self.log_std = nn.Parameter(torch.tensor([-1.0, -1.8], dtype=torch.float32))
        self._init_weights()

    def _init_weights(self) -> None:
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.orthogonal_(module.weight, gain=np.sqrt(2.0))
                nn.init.zeros_(module.bias)
        nn.init.orthogonal_(self.acceleration_head.weight, gain=0.01)
        nn.init.zeros_(self.acceleration_head.bias)
        nn.init.orthogonal_(self.steering_head.weight, gain=0.01)
        nn.init.zeros_(self.steering_head.bias)
        with torch.no_grad():
            self.acceleration_head.bias[0] = 0.15
        nn.init.orthogonal_(self.value_head.weight, gain=1.0)
        nn.init.zeros_(self.value_head.bias)
        nn.init.orthogonal_(self.intent_head.weight, gain=0.01)
        nn.init.zeros_(self.intent_head.bias)
        with torch.no_grad():
            self.intent_head.bias[0] = 0.25
            self.intent_head.bias[2] = 0.35

    @property
    def device(self) -> torch.device:
        return next(self.parameters()).device

    def _tensor(self, array: np.ndarray) -> torch.Tensor:
        return torch.as_tensor(array, dtype=torch.float32, device=self.device)

    def _forward_tensor(
        self,
        ego: torch.Tensor,
        nodes: torch.Tensor,
        edges: torch.Tensor,
        node_mask: torch.Tensor,
        detach_intent_features: bool = False,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        ego_features = self.ego_encoder(ego)
        node_features = self.node_encoder(nodes)
        edge_features = self.edge_encoder(edges)
        for layer in self.attention_layers:
            ego_features = layer(ego_features, node_features, edge_features, node_mask)
        features = self.body(ego_features)
        intent_features = features.detach() if detach_intent_features else features
        intent_logits = self.intent_head(intent_features)
        acceleration_mean = torch.tanh(self.acceleration_head(features))
        steering_mean = torch.tanh(self.steering_head(features))
        mean = torch.cat((acceleration_mean, steering_mean), dim=-1)
        values = self.value_head(features).squeeze(-1)
        return mean, values, intent_logits

    def forward(self, observation: dict[str, np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
        with torch.no_grad():
            mean, values, _ = self._forward_tensor(
                self._tensor(observation["ego"]),
                self._tensor(observation["nodes"]),
                self._tensor(observation["edges"]),
                self._tensor(observation["node_mask"]),
            )
        return mean.cpu().numpy(), values.cpu().numpy()

    def distribution(
        self,
        ego: torch.Tensor,
        nodes: torch.Tensor,
        edges: torch.Tensor,
        node_mask: torch.Tensor,
        detach_intent_features: bool = False,
    ) -> tuple[Normal, torch.Tensor, torch.Tensor, torch.Tensor]:
        mean, values, intent_logits = self._forward_tensor(
            ego, nodes, edges, node_mask, detach_intent_features=detach_intent_features
        )
        log_std = torch.clamp(self.log_std, self.min_log_std, self.max_log_std)
        std = torch.exp(log_std).expand_as(mean)
        return Normal(mean, std), mean, values, intent_logits

    def act(
        self,
        observation: dict[str, np.ndarray],
        deterministic: bool = False,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        with torch.no_grad():
            ego = self._tensor(observation["ego"])
            nodes = self._tensor(observation["nodes"])
            edges = self._tensor(observation["edges"])
            node_mask = self._tensor(observation["node_mask"])
            dist, mean, values, _ = self.distribution(ego, nodes, edges, node_mask)
            actions = mean if deterministic else dist.sample()
            actions = torch.clamp(actions, -1.0, 1.0)
            log_probs = dist.log_prob(actions).sum(dim=-1)
        return (
            actions.cpu().numpy().astype(np.float32),
            log_probs.cpu().numpy().astype(np.float32),
            values.cpu().numpy().astype(np.float32),
        )

    def predict_intents(self, observation: dict[str, np.ndarray]) -> np.ndarray:
        with torch.no_grad():
            _, _, intent_logits = self._forward_tensor(
                self._tensor(observation["ego"]),
                self._tensor(observation["nodes"]),
                self._tensor(observation["edges"]),
                self._tensor(observation["node_mask"]),
            )
        return torch.argmax(intent_logits, dim=-1).cpu().numpy().astype(np.int64)

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        state = {name: tensor.detach().cpu().numpy() for name, tensor in self.state_dict().items()}
        metadata = {
            "format": np.array("graph_attention_torch_state_npz"),
            "ego_size": np.array(self.ego_size),
            "node_size": np.array(self.node_size),
            "edge_size": np.array(self.edge_size),
            "max_nodes": np.array(self.max_nodes),
            "hidden_size": np.array(self.hidden_size),
            "action_size": np.array(self.action_size),
            "intent_size": np.array(self.intent_size),
            "layers": np.array(self.layers),
            "actor_head": np.array("separate_accel_steer_v1"),
        }
        np.savez(path, **state, **metadata)

    def load(self, path: str | Path) -> None:
        data = np.load(path, allow_pickle=False)
        expected_actor_head = "separate_accel_steer_v1"
        if "actor_head" in data.files:
            actor_head = str(data["actor_head"])
            if actor_head != expected_actor_head:
                raise ValueError(
                    f"Checkpoint actor_head={actor_head!r}; expected {expected_actor_head!r}. "
                    "Retrain from scratch after the actor-head redesign."
                )
        elif "policy_head.weight" in data.files or "mode_policy_head.weight" in data.files:
            raise ValueError(
                "Checkpoint uses the old intent-blended actor head. "
                "Retrain from scratch with the separate acceleration/steering actor."
            )
        state = self.state_dict()
        loaded_state = dict(state)
        for name in state:
            if name not in data.files:
                continue
            source = torch.as_tensor(data[name], dtype=state[name].dtype)
            if source.shape != state[name].shape:
                raise ValueError(
                    f"Checkpoint tensor {name} has shape {tuple(source.shape)}; "
                    f"expected {tuple(state[name].shape)}"
                )
            loaded_state[name] = source
        self.load_state_dict(loaded_state)


@dataclass(slots=True)
class GraphRollout:
    ego: np.ndarray
    nodes: np.ndarray
    edges: np.ndarray
    node_mask: np.ndarray
    actions: np.ndarray
    log_probs: np.ndarray
    rewards: np.ndarray
    values: np.ndarray
    dones: np.ndarray
    masks: np.ndarray
    intent_labels: np.ndarray
    last_values: np.ndarray
    info_metrics: dict[str, float]

    def advantages_and_returns(
        self, gamma: float, gae_lambda: float
    ) -> tuple[np.ndarray, np.ndarray]:
        advantages = np.zeros_like(self.rewards)
        gae = np.zeros(self.rewards.shape[1], dtype=np.float32)
        for time_index in reversed(range(len(self.rewards))):
            next_values = (
                self.last_values
                if time_index == len(self.rewards) - 1
                else self.values[time_index + 1]
            )
            nonterminal = 1.0 - self.dones[time_index]
            delta = (
                self.rewards[time_index]
                + gamma * next_values * nonterminal
                - self.values[time_index]
            )
            gae = delta + gamma * gae_lambda * nonterminal * gae
            gae *= self.masks[time_index]
            advantages[time_index] = gae
        return advantages, advantages + self.values



def _model_state_numpy(model: GraphActorCritic) -> dict[str, np.ndarray]:
    return {name: tensor.detach().cpu().numpy() for name, tensor in model.state_dict().items()}


def _load_state_numpy(model: GraphActorCritic, state_np: dict[str, np.ndarray]) -> None:
    state = model.state_dict()
    loaded_state = dict(state)
    for name, tensor in state.items():
        if name in state_np:
            loaded_state[name] = torch.as_tensor(state_np[name], dtype=tensor.dtype)
    model.load_state_dict(loaded_state)


def _collect_graph_rollout_worker(payload: dict) -> GraphRollout:
    from intersection_rl.multitask import MultiTaskIntersectionEnv

    torch.set_num_threads(1)
    env_config = replace(payload["env_config"], seed=payload["seed"])
    env = MultiTaskIntersectionEnv(env_config, tasks=payload["tasks"])
    observer = GraphObserver(max_vehicle_nodes=payload["max_vehicle_nodes"])
    model = GraphActorCritic(
        payload["ego_size"],
        payload["node_size"],
        payload["edge_size"],
        payload["max_nodes"],
        hidden_size=payload["hidden_size"],
        action_size=payload["action_size"],
        layers=payload["layers"],
        seed=payload["seed"],
    )
    _load_state_numpy(model, payload["model_state"])
    model.eval()
    reset_options = {"task_name": payload["task_name"]} if payload.get("task_name") else None
    _, info = env.reset(seed=payload["seed"], options=reset_options)
    observation = observer.encode(env)
    storage: dict[str, list[np.ndarray]] = {
        key: []
        for key in (
            "ego", "nodes", "edges", "node_mask", "actions",
            "log_probs", "rewards", "values", "dones", "masks", "intent_labels",
        )
    }
    info_metrics = GraphPPOTrainer._empty_metrics()
    try:
        for _ in range(payload["rollout_steps"]):
            actions, log_probs, values = model.act(observation)
            mask = info["active_mask"].copy()
            active_count = float(mask.sum())
            _, rewards, terminated, truncated, next_info = env.step(actions)
            rewards = np.clip(rewards, -payload["reward_clip"], payload["reward_clip"])
            GraphPPOTrainer._accumulate_step_metrics(info_metrics, next_info, active_count)
            done = terminated or truncated
            storage["ego"].append(observation["ego"].copy())
            storage["nodes"].append(observation["nodes"].copy())
            storage["edges"].append(observation["edges"].copy())
            storage["node_mask"].append(observation["node_mask"].copy())
            storage["actions"].append(actions)
            storage["log_probs"].append(log_probs)
            storage["rewards"].append(rewards)
            storage["values"].append(values)
            storage["dones"].append(np.full_like(rewards, float(done)))
            storage["masks"].append(mask)
            storage["intent_labels"].append(info.get("intent_labels", np.full_like(mask, -1, dtype=np.int64)).copy())
            info = next_info
            observation = observer.encode(env)
            if done:
                _, info = env.reset(options=reset_options)
                observation = observer.encode(env)
        _, last_values = model.forward(observation)
    finally:
        env.close()
    arrays = {key: np.asarray(value) for key, value in storage.items()}
    return GraphRollout(**arrays, last_values=last_values, info_metrics=info_metrics)



def _run_graph_validation_worker(payload: dict) -> dict[str, float]:
    from intersection_rl.env import IntersectionEnv
    from intersection_rl.multitask import MultiTaskIntersectionEnv, ScenarioTask

    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass

    validation_config = replace(
        payload["env_config"],
        min_cars=1,
        max_cars=payload["max_cars"],
        lanes_per_approach=payload["lanes"],
        episode_seconds=payload["episode_seconds"],
        curriculum_enabled=False,
        curriculum_progression_enabled=False,
        protected_left_signal=True,
        allow_right_on_red=False,
        right_turns_enabled=False,
        strict_lane_mapping=True,
        initial_lateral_noise=0.0,
        randomize_initial_signal_phase=True,
        safety_filter_enabled=False,
        safety_filter_dropout_rate=0.0,
        intersection_reservation_enabled=False,
    )
    eval_mode = payload.get("validation_eval_mode", "standard")
    allow_ror = False
    right_turns = False
    if eval_mode in {"green", "left_green", "left_release", "right_on_red", "red", "red_queue", "mixed", "redgreen"}:
        if eval_mode == "red":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 10.0, 30.0
            speed_min, speed_max = 2.0, 6.0
            permitted_only = False
        elif eval_mode == "red_queue":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 6.0, 12.0
            speed_min, speed_max = 0.0, 2.5
            permitted_only = False
        elif eval_mode == "mixed":
            signal_mode = "green"
            spawn_filter = "all"
            lead_min, lead_max = 18.0, 42.0
            speed_min, speed_max = 0.0, 1.0
            permitted_only = False
        elif eval_mode == "right_on_red":
            signal_mode = "right_on_red"
            spawn_filter = "right_red_conflict"
            lead_min, lead_max = 8.0, 24.0
            speed_min, speed_max = 0.0, 2.5
            permitted_only = False
            allow_ror = True
            right_turns = True
        elif eval_mode == "redgreen":
            signal_mode = "redgreen"
            spawn_filter = "all"
            lead_min, lead_max = 10.0, 32.0
            speed_min, speed_max = 0.0, 2.0
            permitted_only = False
        elif eval_mode == "left_green":
            signal_mode = "left_green"
            spawn_filter = "green"
            lead_min, lead_max = 4.5, 18.0
            speed_min, speed_max = 0.0, 0.0
            permitted_only = True
        elif eval_mode == "left_release":
            signal_mode = "left_release"
            spawn_filter = "next_left_release"
            lead_min, lead_max = 10.0, 22.0
            speed_min, speed_max = 2.0, 5.0
            permitted_only = False
        else:
            signal_mode = "green"
            spawn_filter = "green"
            lead_min, lead_max = 6.0, 24.0
            speed_min, speed_max = 0.0, 0.0
            permitted_only = True
        task = ScenarioTask(
            f"validation_{eval_mode}",
            payload["lanes"],
            payload["lanes"],
            payload["cars"],
            payload["cars"],
            payload["episode_seconds"],
            payload["episode_seconds"],
            1.0,
            signal_mode,
            lead_min,
            lead_max,
            12.0,
            14.0,
            speed_min,
            speed_max,
            permitted_only,
            spawn_filter,
            None,
            None,
            allow_ror,
            right_turns,
        )
        env = MultiTaskIntersectionEnv(validation_config, tasks=(task,))
    else:
        env = IntersectionEnv(validation_config)
    observer = GraphObserver(max_vehicle_nodes=payload["max_vehicle_nodes"])
    model = GraphActorCritic(
        payload["ego_size"],
        payload["node_size"],
        payload["edge_size"],
        payload["max_nodes"],
        hidden_size=payload["hidden_size"],
        action_size=payload["action_size"],
        layers=payload["layers"],
        seed=payload["seed"],
    )
    _load_state_numpy(model, payload["model_state"])
    model.eval()
    metrics = GraphPPOTrainer._empty_metrics()
    try:
        for episode in range(payload["episode_start"], payload["episode_stop"]):
            env.reset(
                seed=payload["base_seed"] + episode,
                options={"vehicle_count": payload["cars"]},
            )
            observation = observer.encode(env)
            info = env._get_info(np.zeros(env.config.max_cars, dtype=np.float32))
            done = False
            while not done:
                predicted_intents = model.predict_intents(observation)
                GraphPPOTrainer._accumulate_intent_metrics(
                    metrics,
                    info.get("intent_labels", np.full(env.config.max_cars, -1, dtype=np.int64)),
                    predicted_intents,
                    info.get("active_mask", np.zeros(env.config.max_cars, dtype=np.float32)),
                )
                actions, _, _ = model.act(observation, deterministic=True)
                _, _, terminated, truncated, info = env.step(actions)
                GraphPPOTrainer._accumulate_step_metrics(
                    metrics,
                    info,
                    float(info.get("active_mask", np.zeros(payload["cars"])).sum()),
                )
                observation = observer.encode(env)
                done = terminated or truncated
    finally:
        env.close()
    metrics["episodes"] = float(payload["episode_stop"] - payload["episode_start"])
    metrics["cars"] = float(payload["cars"])
    metrics["lanes"] = float(payload["lanes"])
    return metrics


class GraphPPOTrainer:
    """PPO trainer for the final typed graph-attention shared policy."""

    def __init__(
        self,
        env,
        config: PPOConfig,
        observer: GraphObserver,
        layers: int = 2,
        rollout_workers: int = 1,
        validation_workers: int = 1,
    ) -> None:
        self.env = env
        self.config = config
        self.observer = observer
        self.rollout_workers = max(1, int(rollout_workers))
        self.validation_workers = max(1, int(validation_workers))
        self.rng = np.random.default_rng(config.seed)
        torch.manual_seed(config.seed)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        spec = observer.spec
        self.model = GraphActorCritic(
            spec.ego_size,
            spec.node_size,
            spec.edge_size,
            spec.max_nodes,
            hidden_size=config.hidden_size,
            layers=layers,
            seed=config.seed,
        ).to(self.device)
        self.reference_model: GraphActorCritic | None = None
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=config.learning_rate)
        _, self.info = env.reset(seed=config.seed)
        self.observation = observer.encode(env)

    def load_reference_policy(self, checkpoint_path: str | Path) -> None:
        spec = self.observer.spec
        reference = GraphActorCritic(
            spec.ego_size,
            spec.node_size,
            spec.edge_size,
            spec.max_nodes,
            hidden_size=self.config.hidden_size,
            layers=self.model.layers,
            seed=self.config.seed,
        ).to(self.device)
        reference.load(checkpoint_path)
        reference.eval()
        for parameter in reference.parameters():
            parameter.requires_grad_(False)
        self.reference_model = reference

    def collect_rollout(self) -> GraphRollout:
        storage: dict[str, list[np.ndarray]] = {
            key: []
            for key in (
                "ego", "nodes", "edges", "node_mask", "actions",
                "log_probs", "rewards", "values", "dones", "masks", "intent_labels",
            )
        }
        info_metrics = self._empty_metrics()
        for _ in range(self.config.rollout_steps):
            actions, log_probs, values = self.model.act(self.observation)
            mask = self.info["active_mask"].copy()
            active_count = float(mask.sum())
            _, rewards, terminated, truncated, next_info = self.env.step(actions)
            rewards = np.clip(rewards, -self.config.reward_clip, self.config.reward_clip)
            self._accumulate_step_metrics(info_metrics, next_info, active_count)
            done = terminated or truncated
            storage["ego"].append(self.observation["ego"].copy())
            storage["nodes"].append(self.observation["nodes"].copy())
            storage["edges"].append(self.observation["edges"].copy())
            storage["node_mask"].append(self.observation["node_mask"].copy())
            storage["actions"].append(actions)
            storage["log_probs"].append(log_probs)
            storage["rewards"].append(rewards)
            storage["values"].append(values)
            storage["dones"].append(np.full_like(rewards, float(done)))
            storage["masks"].append(mask)
            storage["intent_labels"].append(self.info.get("intent_labels", np.full_like(mask, -1, dtype=np.int64)).copy())
            self.info = next_info
            self.observation = self.observer.encode(self.env)
            if done:
                _, self.info = self.env.reset()
                self.observation = self.observer.encode(self.env)
        _, last_values = self.model.forward(self.observation)
        arrays = {key: np.asarray(value) for key, value in storage.items()}
        return GraphRollout(**arrays, last_values=last_values, info_metrics=info_metrics)


    def _scheduled_tasks(self, update_index: int):
        tasks = tuple(getattr(self.env, "tasks", ()))
        if not tasks:
            return tasks
        if self.config.task_phase1_updates > 0 and update_index <= self.config.task_phase1_updates:
            names = {
                'green_basic',
                'green_queue_basic',
            }
            return tuple(task for task in tasks if task.name in names)
        if self.config.task_phase2_updates > 0 and update_index <= self.config.task_phase2_updates:
            names = {
                'green_basic',
                'green_queue_basic',
                'red_stop_basic',
                'yellow_stop_basic',
                'red_heavy',
                'yellow_stop_drill',
                'dense_queue_stop',
                'green_queue_discharge',
                'sparse_mixed',
                'medium_mixed',
                'protected_left_heavy',
            }
            return tuple(task for task in tasks if task.name in names)
        return tasks

    def collect_rollouts(self, update_index: int = 1) -> list[GraphRollout]:
        if self.rollout_workers <= 1:
            return [self.collect_rollout()]
        spec = self.observer.spec
        state_np = _model_state_numpy(self.model)
        seeds = self.rng.integers(1, 2**31 - 1, size=self.rollout_workers, dtype=np.int64)
        tasks = self._scheduled_tasks(update_index)
        scheduled_names = {task.name for task in tasks}
        safety_tasks = tuple(
            task_name for task_name in self.config.safety_replay_tasks if task_name in scheduled_names
        )
        safety_workers = min(max(0, int(self.config.safety_replay_workers)), self.rollout_workers)
        payloads = [
            {
                "env_config": replace(self.env.config, seed=int(seed)),
                "tasks": tasks,
                "max_vehicle_nodes": spec.max_vehicle_nodes,
                "ego_size": spec.ego_size,
                "node_size": spec.node_size,
                "edge_size": spec.edge_size,
                "max_nodes": spec.max_nodes,
                "hidden_size": self.model.hidden_size,
                "action_size": self.model.action_size,
                "layers": self.model.layers,
                "model_state": state_np,
                "rollout_steps": self.config.rollout_steps,
                "reward_clip": self.config.reward_clip,
                "seed": int(seed),
                "task_name": (
                    safety_tasks[index % len(safety_tasks)]
                    if index < safety_workers and len(safety_tasks) > 0
                    else None
                ),
            }
            for index, seed in enumerate(seeds)
        ]
        with ProcessPoolExecutor(max_workers=self.rollout_workers) as executor:
            return list(executor.map(_collect_graph_rollout_worker, payloads))

    @staticmethod
    def _normalize_array(values: np.ndarray) -> np.ndarray:
        return (values - values.mean()) / (values.std() + 1e-8)

    def _normalize_advantages_by_phase(
        self, advantages: np.ndarray, intent_labels: np.ndarray
    ) -> np.ndarray:
        normalized = np.empty_like(advantages, dtype=np.float32)
        fallback = self._normalize_array(advantages).astype(np.float32)
        normalized[:] = fallback
        for label in range(self.model.intent_size):
            mask = intent_labels == label
            if int(mask.sum()) >= 2:
                normalized[mask] = self._normalize_array(advantages[mask]).astype(np.float32)
        return normalized

    def _minibatch_indices(
        self, indices: np.ndarray, intent_labels: np.ndarray
    ) -> list[np.ndarray]:
        if not self.config.phase_balanced_minibatches:
            shuffled = indices.copy()
            self.rng.shuffle(shuffled)
            return [
                shuffled[start : start + self.config.minibatch_size]
                for start in range(0, len(shuffled), self.config.minibatch_size)
            ]

        groups: list[np.ndarray] = []
        for label in range(self.model.intent_size):
            group = indices[intent_labels[indices] == label]
            if len(group) > 0:
                group = group.copy()
                self.rng.shuffle(group)
                groups.append(group)
        unknown = indices[intent_labels[indices] < 0]
        if len(unknown) > 0:
            unknown = unknown.copy()
            self.rng.shuffle(unknown)
            groups.append(unknown)
        if not groups:
            shuffled = indices.copy()
            self.rng.shuffle(shuffled)
            return [
                shuffled[start : start + self.config.minibatch_size]
                for start in range(0, len(shuffled), self.config.minibatch_size)
            ]

        positions = [0 for _ in groups]
        batches: list[np.ndarray] = []
        total_remaining = sum(len(group) for group in groups)
        while total_remaining > 0:
            active = [i for i, group in enumerate(groups) if positions[i] < len(group)]
            quota = max(1, self.config.minibatch_size // max(len(active), 1))
            batch_parts: list[np.ndarray] = []
            for group_index in active:
                group = groups[group_index]
                start = positions[group_index]
                stop = min(len(group), start + quota)
                if stop > start:
                    batch_parts.append(group[start:stop])
                    taken = stop - start
                    positions[group_index] = stop
                    total_remaining -= taken
            while sum(len(part) for part in batch_parts) < self.config.minibatch_size:
                active = [i for i, group in enumerate(groups) if positions[i] < len(group)]
                if not active:
                    break
                for group_index in active:
                    if sum(len(part) for part in batch_parts) >= self.config.minibatch_size:
                        break
                    group = groups[group_index]
                    start = positions[group_index]
                    batch_parts.append(group[start : start + 1])
                    positions[group_index] = start + 1
                    total_remaining -= 1
            batch = np.concatenate(batch_parts, axis=0)
            self.rng.shuffle(batch)
            batches.append(batch)
        return batches

    def update(self, rollout: GraphRollout | list[GraphRollout], update_index: int = 1) -> dict[str, float]:
        rollouts = rollout if isinstance(rollout, list) else [rollout]
        ego_parts: list[np.ndarray] = []
        node_parts: list[np.ndarray] = []
        edge_parts: list[np.ndarray] = []
        node_mask_parts: list[np.ndarray] = []
        action_parts: list[np.ndarray] = []
        log_prob_parts: list[np.ndarray] = []
        advantage_parts: list[np.ndarray] = []
        return_parts: list[np.ndarray] = []
        reward_parts: list[np.ndarray] = []
        intent_parts: list[np.ndarray] = []
        info_metrics = self._empty_metrics()

        for item in rollouts:
            advantages, returns = item.advantages_and_returns(
                self.config.gamma, self.config.gae_lambda
            )
            active = item.masks.reshape(-1).astype(bool)
            if not np.any(active):
                continue
            ego_parts.append(item.ego.reshape(-1, item.ego.shape[-1])[active])
            node_parts.append(item.nodes.reshape(-1, item.nodes.shape[-2], item.nodes.shape[-1])[active])
            edge_parts.append(item.edges.reshape(-1, item.edges.shape[-2], item.edges.shape[-1])[active])
            node_mask_parts.append(item.node_mask.reshape(-1, item.node_mask.shape[-1])[active])
            action_parts.append(item.actions.reshape(-1, item.actions.shape[-1])[active])
            log_prob_parts.append(item.log_probs.reshape(-1)[active])
            advantage_parts.append(advantages.reshape(-1)[active])
            return_parts.append(returns.reshape(-1)[active])
            reward_parts.append(item.rewards.reshape(-1)[active])
            intent_parts.append(item.intent_labels.reshape(-1)[active])
            for key, value in item.info_metrics.items():
                info_metrics[key] = info_metrics.get(key, 0.0) + float(value)

        if not action_parts:
            metrics = self._empty_metrics()
            metrics["rollout_mean_reward"] = 0.0
            return metrics

        ego = np.concatenate(ego_parts, axis=0)
        nodes = np.concatenate(node_parts, axis=0)
        edges = np.concatenate(edge_parts, axis=0)
        node_mask = np.concatenate(node_mask_parts, axis=0)
        actions = np.concatenate(action_parts, axis=0)
        old_log_probs = np.concatenate(log_prob_parts, axis=0)
        advantages = np.concatenate(advantage_parts, axis=0)
        returns = np.concatenate(return_parts, axis=0)
        intent_labels = np.concatenate(intent_parts, axis=0).astype(np.int64)
        if self.config.phase_advantage_normalization:
            advantages = self._normalize_advantages_by_phase(advantages, intent_labels)
        else:
            advantages = self._normalize_array(advantages)

        ego_t = torch.as_tensor(ego, dtype=torch.float32, device=self.device)
        nodes_t = torch.as_tensor(nodes, dtype=torch.float32, device=self.device)
        edges_t = torch.as_tensor(edges, dtype=torch.float32, device=self.device)
        node_mask_t = torch.as_tensor(node_mask, dtype=torch.float32, device=self.device)
        act_t = torch.as_tensor(actions, dtype=torch.float32, device=self.device)
        old_log_t = torch.as_tensor(old_log_probs, dtype=torch.float32, device=self.device)
        adv_t = torch.as_tensor(advantages, dtype=torch.float32, device=self.device)
        ret_t = torch.as_tensor(returns, dtype=torch.float32, device=self.device)
        intent_t = torch.as_tensor(intent_labels, dtype=torch.long, device=self.device)

        indices = np.arange(len(actions))
        intent_loss_weight = self._intent_loss_weight(update_index)
        metrics: dict[str, float] = {
            "intent_loss_weight": intent_loss_weight,
            "intent_detached": float(self.config.intent_detach_shared),
            "reference_kl_weight": float(self.config.reference_kl_coefficient),
            "reference_kl_green_only": float(self.config.reference_kl_green_only),
            "phase_adv_norm": float(self.config.phase_advantage_normalization),
            "phase_balanced_mb": float(self.config.phase_balanced_minibatches),
            "safety_replay_workers": float(self.config.safety_replay_workers),
        }
        for label, name in enumerate(("stop", "hold", "go", "yield")):
            metrics[f"phase_samples_{name}"] = float(np.sum(intent_labels == label))
        update_count = 0
        stop_update = False
        for _ in range(self.config.update_epochs):
            batches = self._minibatch_indices(indices, intent_labels)
            for batch_np in batches:
                batch = torch.as_tensor(batch_np, dtype=torch.long, device=self.device)
                dist, _, values, intent_logits = self.model.distribution(
                    ego_t[batch],
                    nodes_t[batch],
                    edges_t[batch],
                    node_mask_t[batch],
                    detach_intent_features=self.config.intent_detach_shared,
                )
                log_probs = dist.log_prob(act_t[batch]).sum(dim=-1)
                entropy = dist.entropy().sum(dim=-1).mean()
                ratio = torch.exp(log_probs - old_log_t[batch])
                unclipped = ratio * adv_t[batch]
                clipped = torch.clamp(
                    ratio,
                    1.0 - self.config.clip_ratio,
                    1.0 + self.config.clip_ratio,
                ) * adv_t[batch]
                policy_loss = -torch.min(unclipped, clipped).mean()
                value_loss = 0.5 * torch.mean((values - ret_t[batch]) ** 2)
                reference_kl_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                reference_kl_all_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                reference_kl_samples = torch.zeros((), dtype=torch.float32, device=self.device)
                if self.reference_model is not None and self.config.reference_kl_coefficient > 0.0:
                    with torch.no_grad():
                        reference_dist, _, _, _ = self.reference_model.distribution(
                            ego_t[batch],
                            nodes_t[batch],
                            edges_t[batch],
                            node_mask_t[batch],
                        )
                    sample_kl = kl_divergence(dist, reference_dist).sum(dim=-1)
                    if self.config.reference_kl_green_only:
                        ego_for_kl = ego_t[batch]
                        green_context = (ego_for_kl[:, 11] > 0.5) & (ego_for_kl[:, 14] > 0.5)
                        critical = (intent_t[batch] == 2) & green_context
                        all_labeled = critical
                    elif self.config.reference_kl_stop_hold_only:
                        critical = (intent_t[batch] == 0) | (intent_t[batch] == 1)
                        all_labeled = intent_t[batch] >= 0
                    else:
                        critical = intent_t[batch] >= 0
                        all_labeled = critical
                    if all_labeled.any():
                        reference_kl_all_loss = sample_kl[all_labeled].mean()
                    if critical.any():
                        reference_kl_loss = sample_kl[critical].mean()
                        reference_kl_samples = critical.float().sum()
                valid_intent = intent_t[batch] >= 0
                if valid_intent.any():
                    valid_labels = intent_t[batch][valid_intent]
                    class_counts = torch.bincount(valid_labels, minlength=self.model.intent_size).float()
                    class_weights = valid_labels.numel() / (self.model.intent_size * class_counts.clamp_min(1.0))
                    class_floor = torch.tensor([0.60, 1.0, 1.2, 1.2], dtype=torch.float32, device=self.device)
                    class_ceiling = torch.tensor([1.3, 2.5, 2.5, 2.5], dtype=torch.float32, device=self.device)
                    class_weights = torch.minimum(torch.maximum(class_weights.to(self.device), class_floor), class_ceiling)
                    intent_loss = F.cross_entropy(
                        intent_logits[valid_intent],
                        valid_labels,
                        weight=class_weights,
                    )
                    intent_pred = torch.argmax(intent_logits[valid_intent], dim=-1)
                    intent_accuracy = (intent_pred == valid_labels).float().mean()
                else:
                    intent_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                    intent_accuracy = torch.zeros((), dtype=torch.float32, device=self.device)
                intent_action_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                action_valid = intent_t[batch] >= 0
                if self.config.intent_action_loss_coefficient > 0.0 and action_valid.any():
                    action_mean = dist.mean[:, 0]
                    labels = intent_t[batch]
                    ego_batch = ego_t[batch]
                    speed = torch.clamp(
                        ego_batch[:, 0] * self.config.physics_action_target_max_speed,
                        min=0.0,
                    )
                    distance_to_stop = ego_batch[:, 2] * self.config.physics_action_target_road_length
                    green = ego_batch[:, 11] > 0.5
                    closed = ego_batch[:, 13] > 0.5
                    movement_permitted = ego_batch[:, 14] > 0.5
                    front_too_close = ego_batch[:, 25] > 0.5
                    before_stop_line = distance_to_stop > 0.0
                    front_clear = ~front_too_close

                    time_constant = max(float(self.config.physics_action_target_time_constant), 1e-3)
                    max_accel = max(float(self.config.physics_action_target_max_acceleration), 1e-3)
                    comfortable_braking = max(float(self.config.physics_action_target_comfortable_braking), 1e-3)
                    stop_margin = max(float(self.config.physics_action_target_stop_margin), 0.0)
                    brake_safety = max(float(self.config.physics_action_target_brake_safety_factor), 1.0)
                    green_speed = max(float(self.config.physics_action_target_green_speed), 0.0)
                    red_crawl_speed = max(float(self.config.physics_action_target_red_crawl_speed), 0.0)
                    red_approach_gain = max(float(self.config.physics_action_target_red_approach_gain), 0.0)
                    red_min_brake = max(float(self.config.physics_action_target_red_min_brake_accel), 0.0)

                    target_stop_distance = torch.full_like(speed, stop_margin)
                    available_distance = torch.clamp(distance_to_stop - target_stop_distance, min=0.0)
                    decel_distance = torch.clamp(available_distance, min=0.25)
                    required_decel = brake_safety * speed.square() / (2.0 * decel_distance)
                    safe_stop_speed = torch.sqrt(
                        torch.clamp(
                            2.0 * comfortable_braking * available_distance / brake_safety,
                            min=0.0,
                        )
                    )
                    profile_speed = red_approach_gain * available_distance
                    red_desired_speed = torch.minimum(
                        torch.full_like(speed, red_crawl_speed),
                        safe_stop_speed,
                    )
                    red_desired_speed = torch.minimum(red_desired_speed, profile_speed)
                    red_desired_speed = torch.where(
                        distance_to_stop <= target_stop_distance + 1.0,
                        torch.zeros_like(red_desired_speed),
                        red_desired_speed,
                    )
                    red_target_accel = torch.clamp(
                        (red_desired_speed - speed) / time_constant,
                        min=-comfortable_braking,
                        max=max_accel,
                    )
                    too_fast_for_stop = speed > safe_stop_speed + 0.1
                    red_target_accel = torch.where(
                        too_fast_for_stop,
                        -torch.clamp(required_decel, min=0.0, max=comfortable_braking),
                        red_target_accel,
                    )
                    if red_min_brake > 0.0:
                        profile_brake_needed = (
                            closed
                            & before_stop_line
                            & (distance_to_stop < 45.0)
                            & (speed > red_desired_speed + 0.05)
                        )
                        min_brake_accel = torch.full_like(red_target_accel, -red_min_brake)
                        red_target_accel = torch.where(
                            profile_brake_needed,
                            torch.minimum(red_target_accel, min_brake_accel),
                            red_target_accel,
                        )
                    green_target_accel = torch.clamp(
                        (torch.full_like(speed, green_speed) - speed) / time_constant,
                        min=-comfortable_braking,
                        max=max_accel,
                    )
                    hold_target_accel = torch.clamp(-0.6 * speed / time_constant, min=-comfortable_braking, max=0.0)
                    yield_target_accel = torch.clamp(-1.0 * speed / time_constant, min=-comfortable_braking, max=0.0)

                    target_accel = torch.zeros_like(action_mean)
                    target_accel = torch.where(labels == 0, red_target_accel, target_accel)
                    target_accel = torch.where(labels == 1, hold_target_accel, target_accel)
                    target_accel = torch.where(labels == 2, green_target_accel, target_accel)
                    target_accel = torch.where(labels == 3, yield_target_accel, target_accel)

                    legal_green_clear = movement_permitted & green & front_clear
                    green_blocked = movement_permitted & green & front_too_close & before_stop_line
                    red_before_stop = closed & before_stop_line
                    target_accel = torch.where(legal_green_clear, green_target_accel, target_accel)
                    target_accel = torch.where(green_blocked, hold_target_accel, target_accel)
                    target_accel = torch.where(red_before_stop, red_target_accel, target_accel)

                    action_target = torch.where(
                        target_accel >= 0.0,
                        target_accel / max_accel,
                        target_accel / comfortable_braking,
                    )
                    action_target = torch.clamp(action_target, -1.0, 1.0)

                    action_weight = torch.ones_like(action_mean)
                    action_weight = torch.where(labels == 0, torch.full_like(action_weight, 4.0), action_weight)
                    action_weight = torch.where(labels == 2, torch.full_like(action_weight, 1.5), action_weight)
                    action_weight = torch.where(labels == 1, torch.full_like(action_weight, 1.8), action_weight)
                    action_weight = torch.where(labels == 3, torch.full_like(action_weight, 2.0), action_weight)
                    action_weight = torch.where(legal_green_clear, torch.full_like(action_weight, 2.0), action_weight)
                    action_weight = torch.where(green_blocked, torch.full_like(action_weight, 2.5), action_weight)
                    action_weight = torch.where(red_before_stop, torch.full_like(action_weight, 10.0), action_weight)

                    action_error = (action_mean - action_target) ** 2
                    intent_action_loss = (action_error[action_valid] * action_weight[action_valid]).mean()
                loss = (
                    policy_loss
                    + self.config.value_coefficient * value_loss
                    + intent_loss_weight * intent_loss
                    + self.config.intent_action_loss_coefficient * intent_action_loss
                    + self.config.reference_kl_coefficient * reference_kl_loss
                    + self.config.reference_kl_all_coefficient * reference_kl_all_loss
                    - self.config.entropy_coefficient * entropy
                )
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
                self.optimizer.step()
                with torch.no_grad():
                    self.model.log_std.clamp_(self.model.min_log_std, self.model.max_log_std)
                approximate_kl = torch.mean(old_log_t[batch] - log_probs).item()
                for key, value in {
                    "policy_loss": float(policy_loss.item()),
                    "value_loss": float(value_loss.item()),
                    "entropy": float(entropy.item()),
                    "intent_loss": float(intent_loss.item()),
                    "intent_accuracy": float(intent_accuracy.item()),
                    "intent_action_loss": float(intent_action_loss.item()),
                    "reference_kl": float(reference_kl_loss.item()),
                    "reference_kl_all": float(reference_kl_all_loss.item()),
                    "reference_kl_samples": float(reference_kl_samples.item()),
                    "approximate_kl": float(approximate_kl),
                }.items():
                    metrics[key] = metrics.get(key, 0.0) + value
                update_count += 1
                if self.config.target_kl > 0.0 and approximate_kl > self.config.target_kl:
                    stop_update = True
                    break
            if stop_update:
                break
        averaged = {
            key: value / max(update_count, 1)
            for key, value in metrics.items()
            if key not in (
                "intent_loss_weight",
                "intent_detached",
                "reference_kl_weight",
                "phase_adv_norm",
                "phase_balanced_mb",
                "safety_replay_workers",
                "phase_samples_stop",
                "phase_samples_hold",
                "phase_samples_go",
                "phase_samples_yield",
            )
        }
        metrics = {
            "intent_loss_weight": intent_loss_weight,
            "intent_detached": float(self.config.intent_detach_shared),
            "reference_kl_weight": float(self.config.reference_kl_coefficient),
            "reference_kl_green_only": float(self.config.reference_kl_green_only),
            "phase_adv_norm": float(self.config.phase_advantage_normalization),
            "phase_balanced_mb": float(self.config.phase_balanced_minibatches),
            "safety_replay_workers": float(self.config.safety_replay_workers),
            "phase_samples_stop": float(np.sum(intent_labels == 0)),
            "phase_samples_hold": float(np.sum(intent_labels == 1)),
            "phase_samples_go": float(np.sum(intent_labels == 2)),
            "phase_samples_yield": float(np.sum(intent_labels == 3)),
            **averaged,
        }
        active_rewards = np.concatenate(reward_parts, axis=0)
        metrics["rollout_mean_reward"] = float(active_rewards.mean())
        metrics.update(info_metrics)
        return metrics

    def _intent_loss_weight(self, update_index: int) -> float:
        target = max(0.0, float(self.config.intent_loss_coefficient))
        warmup = max(0, int(self.config.intent_loss_warmup_updates))
        ramp = max(0, int(self.config.intent_loss_ramp_updates))
        if target <= 0.0:
            return 0.0
        if update_index <= warmup:
            return 0.0
        if ramp <= 0:
            return target
        progress = min(1.0, max(0.0, (update_index - warmup) / float(ramp)))
        return target * progress

    def run_validation(
        self,
        update_index: int,
        lanes: int,
        cars: int,
        episode_seconds: float,
        episodes: int,
    ) -> dict[str, float]:
        workers = max(1, min(self.validation_workers, episodes))
        if workers <= 1:
            payload = self._validation_payload(update_index, lanes, cars, episode_seconds, 0, episodes)
            metrics = _run_graph_validation_worker(payload)
        else:
            payloads = []
            for worker_index in range(workers):
                start = worker_index * episodes // workers
                stop = (worker_index + 1) * episodes // workers
                if start == stop:
                    continue
                payloads.append(
                    self._validation_payload(update_index, lanes, cars, episode_seconds, start, stop)
                )
            with ProcessPoolExecutor(max_workers=workers) as executor:
                metrics = self._merge_metrics(list(executor.map(_run_graph_validation_worker, payloads)))
            metrics["episodes"] = float(episodes)
            metrics["cars"] = float(cars)
            metrics["lanes"] = float(lanes)
        metrics["validation_score"] = self._validation_score(metrics)
        return metrics

    def _validation_payload(
        self,
        update_index: int,
        lanes: int,
        cars: int,
        episode_seconds: float,
        episode_start: int,
        episode_stop: int,
    ) -> dict:
        spec = self.observer.spec
        return {
            "env_config": replace(self.env.config),
            "max_cars": self.env.config.max_cars,
            "max_vehicle_nodes": spec.max_vehicle_nodes,
            "ego_size": spec.ego_size,
            "node_size": spec.node_size,
            "edge_size": spec.edge_size,
            "max_nodes": spec.max_nodes,
            "hidden_size": self.model.hidden_size,
            "action_size": self.model.action_size,
            "layers": self.model.layers,
            "model_state": _model_state_numpy(self.model),
            "seed": self.config.seed,
            "base_seed": self.config.seed + update_index * 1000,
            "lanes": lanes,
            "cars": cars,
            "episode_seconds": episode_seconds,
            "episode_start": episode_start,
            "episode_stop": episode_stop,
            "validation_eval_mode": self.config.validation_eval_mode,
        }

    @staticmethod
    def _merge_metrics(items: list[dict[str, float]]) -> dict[str, float]:
        metrics = GraphPPOTrainer._empty_metrics()
        for item in items:
            for key, value in item.items():
                if key in ("episodes", "cars", "lanes", "validation_score"):
                    continue
                metrics[key] = metrics.get(key, 0.0) + float(value)
        return metrics

    def train(
        self,
        checkpoint_path: str | Path,
        validation_scenarios: tuple[tuple[int, int, float], ...] = (
            (2, 8, 60.0),
            (2, 24, 120.0),
            (3, 24, 120.0),
            (3, 36, 150.0),
            (4, 30, 150.0),
            (4, 50, 150.0),
        ),
    ) -> GraphActorCritic:
        checkpoint_path = Path(checkpoint_path)
        metrics_path = checkpoint_path.with_name(f"{checkpoint_path.stem}_train_metrics.csv")
        fields = [
            "update", "steps", "rollout_workers", "validation_workers", "rollout_mean_reward", "policy_loss", "value_loss",
            "entropy", "intent_loss", "intent_loss_weight", "intent_detached", "intent_accuracy", "intent_action_loss", "intent_eval_accuracy",
            "reference_kl", "reference_kl_weight", "reference_kl_samples", "phase_adv_norm", "phase_balanced_mb", "phase_samples_stop", "phase_samples_hold", "phase_samples_go", "phase_samples_yield", "safety_replay_workers", "rollout_guard_stop", "approximate_kl", "validation_score", "stale_validations",
            "best_validation_score", "completed_clean", "failed", "timeouts", "stuck_timeouts", "non_timeout_failed", "collisions",
            "proximity_events", "red", "yellow", "closed_signal",
            "failed_by_red", "failed_by_yellow", "failed_by_collision", "failed_by_left_yield",
            "failed_by_right_yield", "right_yield", "failed_by_lane_violation", "front_gap_violations",
            "queue_stop_position_error_sum", "queue_stop_position_samples", "queue_stop_position_error_avg",
            "cars_stopped_too_far_from_stop_line", "lead_green_start_delay_seconds",
            "follower_green_start_delay_seconds", "queue_discharge_delay_seconds",
            "lead_green_stuck_events", "follower_green_stuck_events", "green_stopped_too_far_events",
            "queue_red_crossings", "progress", "policy_samples", "env_steps", "vehicle_hours", "saved_best", "early_stop",
        ]
        checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
        with metrics_path.open("w", newline="") as metrics_file:
            csv.DictWriter(metrics_file, fieldnames=fields).writeheader()
        completed_steps = 0
        update_index = 0
        best_score = -float("inf")
        stale = 0
        while completed_steps < self.config.total_steps:
            rollouts = self.collect_rollouts(update_index=update_index + 1)
            metrics = self.update(rollouts, update_index=update_index + 1)
            completed_steps += self.config.rollout_steps * len(rollouts)
            update_index += 1
            validation_score = ""
            selection_score = None
            if self.config.validation_interval_updates > 0 and update_index % self.config.validation_interval_updates == 0:
                validation_runs = [
                    self.run_validation(update_index, lanes, cars, seconds, self.config.validation_episodes)
                    for lanes, cars, seconds in validation_scenarios
                ]
                selection_score = float(np.mean([item["validation_score"] for item in validation_runs]))
                validation_score = selection_score
            elif self.config.validation_interval_updates <= 0:
                selection_score = metrics["safety_score"]
            improved = selection_score is not None and selection_score > best_score + self.config.validation_min_delta
            saved_best = False
            early_stop = False
            rollout_guard_stop = (
                self.config.rollout_closed_signal_stop_threshold > 0.0
                and update_index > self.config.rollout_guard_warmup_updates
                and metrics.get("closed_signal", 0.0) > self.config.rollout_closed_signal_stop_threshold
            )
            if improved:
                best_score = selection_score
                stale = 0
                self.model.save(
                    checkpoint_path.with_name(f"{checkpoint_path.stem}_best{checkpoint_path.suffix}")
                )
                saved_best = True
            elif validation_score != "" and self.config.validation_patience > 0:
                stale += 1
                early_stop = stale >= self.config.validation_patience
            if rollout_guard_stop:
                early_stop = True
            if self.config.checkpoint_interval_updates > 0 and update_index % self.config.checkpoint_interval_updates == 0:
                self.model.save(
                    checkpoint_path.with_name(
                        f"{checkpoint_path.stem}_update_{update_index:04d}{checkpoint_path.suffix}"
                    )
                )
            print(
                f"update={update_index:04d} steps={completed_steps:07d} "
                f"rollouts={len(rollouts)} rw={self.rollout_workers} vw={self.validation_workers} "
                f"reward={metrics['rollout_mean_reward']:+.4f} "
                f"policy={metrics.get('policy_loss', 0.0):+.4f} "
                f"value={metrics.get('value_loss', 0.0):.4f} "
                f"entropy={metrics.get('entropy', 0.0):.3f} "
                f"intent_loss={metrics.get('intent_loss', 0.0):.3f} "
                f"intent_w={metrics.get('intent_loss_weight', 0.0):.4f} "
                f"intent_detach={int(metrics.get('intent_detached', 0.0))} "
                f"intent_acc={metrics.get('intent_accuracy', 0.0):.3f} "
                f"intent_action={metrics.get('intent_action_loss', 0.0):.3f} "
                f"ref_kl={metrics.get('reference_kl', 0.0):.5f} "
                f"kl={metrics.get('approximate_kl', 0.0):+.5f} "
                f"val={validation_score if validation_score != '' else ''} "
                f"stale={stale} clean={metrics['completed_clean']:.0f} "
                f"failed={metrics['failed']:.0f} timeout={metrics.get('timeouts', 0.0):.0f} stuck={metrics.get('stuck_timeouts', 0.0):.0f} coll={metrics['collisions']:.0f} "
                f"prox={metrics['proximity_events']:.0f} red={metrics['red']:.0f} "
                f"yellow={metrics['yellow']:.0f} closed={metrics['closed_signal']:.0f} "
                f"guard={int(rollout_guard_stop)} "
                f"phase_stop={metrics.get('phase_samples_stop', 0.0):.0f} "
                f"phase_hold={metrics.get('phase_samples_hold', 0.0):.0f} "
                f"phase_go={metrics.get('phase_samples_go', 0.0):.0f} "
                f"phase_yield={metrics.get('phase_samples_yield', 0.0):.0f} "
                f"samples={metrics['policy_samples']:.0f}"
            )
            row = {
                "update": update_index,
                "steps": completed_steps,
                "rollout_workers": len(rollouts),
                "validation_workers": self.validation_workers,
                "rollout_mean_reward": metrics.get("rollout_mean_reward", 0.0),
                "policy_loss": metrics.get("policy_loss", 0.0),
                "value_loss": metrics.get("value_loss", 0.0),
                "entropy": metrics.get("entropy", 0.0),
                "intent_loss": metrics.get("intent_loss", 0.0),
                "intent_loss_weight": metrics.get("intent_loss_weight", 0.0),
                "intent_detached": metrics.get("intent_detached", 0.0),
                "intent_accuracy": metrics.get("intent_accuracy", 0.0),
                "intent_eval_accuracy": metrics.get("intent_correct", 0.0) / max(metrics.get("intent_total", 0.0), 1.0),
                "reference_kl": metrics.get("reference_kl", 0.0),
                "reference_kl_weight": metrics.get("reference_kl_weight", 0.0),
                "reference_kl_samples": metrics.get("reference_kl_samples", 0.0),
                "phase_adv_norm": metrics.get("phase_adv_norm", 0.0),
                "phase_balanced_mb": metrics.get("phase_balanced_mb", 0.0),
                "phase_samples_stop": metrics.get("phase_samples_stop", 0.0),
                "phase_samples_hold": metrics.get("phase_samples_hold", 0.0),
                "phase_samples_go": metrics.get("phase_samples_go", 0.0),
                "phase_samples_yield": metrics.get("phase_samples_yield", 0.0),
                "safety_replay_workers": metrics.get("safety_replay_workers", 0.0),
                "rollout_guard_stop": int(rollout_guard_stop),
                "approximate_kl": metrics.get("approximate_kl", 0.0),
                "validation_score": validation_score,
                "stale_validations": stale,
                "best_validation_score": best_score,
                "completed_clean": metrics.get("completed_clean", 0.0),
                "failed": metrics.get("failed", 0.0),
                "timeouts": metrics.get("timeouts", 0.0),
                "stuck_timeouts": metrics.get("stuck_timeouts", 0.0),
                "non_timeout_failed": max(0.0, metrics.get("failed", 0.0) - metrics.get("timeouts", 0.0)),
                "collisions": metrics.get("collisions", 0.0),
                "proximity_events": metrics.get("proximity_events", 0.0),
                "red": metrics.get("red", 0.0),
                "yellow": metrics.get("yellow", 0.0),
                "closed_signal": metrics.get("closed_signal", 0.0),
                "failed_by_red": metrics.get("failed_by_red", 0.0),
                "failed_by_yellow": metrics.get("failed_by_yellow", 0.0),
                "failed_by_collision": metrics.get("failed_by_collision", 0.0),
                "failed_by_left_yield": metrics.get("failed_by_left_yield", 0.0),
                "failed_by_right_yield": metrics.get("failed_by_right_yield", 0.0),
                "right_yield": metrics.get("right_yield", 0.0),
                "failed_by_lane_violation": metrics.get("failed_by_lane_violation", 0.0),
                "front_gap_violations": metrics.get("front_gap_violations", 0.0),
                "queue_stop_position_error_sum": metrics.get("queue_stop_position_error_sum", 0.0),
                "queue_stop_position_samples": metrics.get("queue_stop_position_samples", 0.0),
                "queue_stop_position_error_avg": metrics.get("queue_stop_position_error_sum", 0.0) / max(metrics.get("queue_stop_position_samples", 0.0), 1.0),
                "cars_stopped_too_far_from_stop_line": metrics.get("cars_stopped_too_far_from_stop_line", 0.0),
                "lead_green_start_delay_seconds": metrics.get("lead_green_start_delay_seconds", 0.0),
                "follower_green_start_delay_seconds": metrics.get("follower_green_start_delay_seconds", 0.0),
                "queue_discharge_delay_seconds": metrics.get("queue_discharge_delay_seconds", 0.0),
                "lead_green_stuck_events": metrics.get("lead_green_stuck_events", 0.0),
                "follower_green_stuck_events": metrics.get("follower_green_stuck_events", 0.0),
                "green_stopped_too_far_events": metrics.get("green_stopped_too_far_events", 0.0),
                "queue_red_crossings": metrics.get("queue_red_crossings", 0.0),
                "progress": metrics.get("progress", 0.0),
                "policy_samples": metrics.get("policy_samples", 0.0),
                "env_steps": metrics.get("env_steps", 0.0),
                "vehicle_hours": metrics.get("policy_samples", 0.0) * self.env.config.dt / 3600.0,
                "saved_best": int(saved_best),
                "early_stop": int(early_stop),
            }
            with metrics_path.open("a", newline="") as metrics_file:
                csv.DictWriter(metrics_file, fieldnames=fields).writerow(row)
            if early_stop:
                print(f"early_stop update={update_index:04d} best_val={best_score:+.1f}")
                break
        self.model.save(checkpoint_path)
        return self.model

    @staticmethod
    def _empty_metrics() -> dict[str, float]:
        return {
            "completed_clean": 0.0,
            "failed": 0.0,
            "timeouts": 0.0,
            "stuck_timeouts": 0.0,
            "collisions": 0.0,
            "proximity": 0.0,
            "proximity_events": 0.0,
            "red": 0.0,
            "yellow": 0.0,
            "closed_signal": 0.0,
            "failed_by_red": 0.0,
            "failed_by_yellow": 0.0,
            "failed_by_collision": 0.0,
            "failed_by_left_yield": 0.0,
            "failed_by_right_yield": 0.0,
            "failed_by_lane_violation": 0.0,
            "front_gap_violations": 0.0,
            "queue_stop_position_error_sum": 0.0,
            "queue_stop_position_samples": 0.0,
            "cars_stopped_too_far_from_stop_line": 0.0,
            "lead_green_start_delay_seconds": 0.0,
            "follower_green_start_delay_seconds": 0.0,
            "queue_discharge_delay_seconds": 0.0,
            "lead_green_stuck_events": 0.0,
            "follower_green_stuck_events": 0.0,
            "green_stopped_too_far_events": 0.0,
            "queue_red_crossings": 0.0,
            "intent_total": 0.0,
            "intent_correct": 0.0,
            "intent_label_stop": 0.0,
            "intent_pred_stop": 0.0,
            "intent_correct_stop": 0.0,
            "intent_label_hold": 0.0,
            "intent_pred_hold": 0.0,
            "intent_correct_hold": 0.0,
            "intent_label_go": 0.0,
            "intent_pred_go": 0.0,
            "intent_correct_go": 0.0,
            "intent_label_yield": 0.0,
            "intent_pred_yield": 0.0,
            "intent_correct_yield": 0.0,
            "left_yield": 0.0,
            "right_yield": 0.0,
            "right_on_red_entries": 0.0,
            "progress": 0.0,
            "policy_samples": 0.0,
            "env_steps": 0.0,
            "unsafe_requests": 0.0,
            "safety_score": 0.0,
        }

    @staticmethod
    def _accumulate_step_metrics(metrics: dict[str, float], info: dict, active_count: float) -> None:
        metrics["completed_clean"] += float(info.get("completed_delta", 0))
        metrics["failed"] += float(info.get("failed_delta", 0))
        metrics["timeouts"] += float(info.get("timeout_failures", 0))
        metrics["stuck_timeouts"] += float(info.get("stuck_timeout_failures", 0))
        metrics["collisions"] += float(info.get("collisions", 0))
        metrics["proximity"] += float(info.get("proximity_violations", 0))
        metrics["proximity_events"] += float(info.get("proximity_events", 0))
        metrics["red"] += float(info.get("red_light_violations", 0))
        metrics["yellow"] += float(info.get("yellow_light_violations", 0))
        metrics["closed_signal"] += float(
            info.get("closed_signal_violations", info.get("red_light_violations", 0))
        )
        for key in (
            "failed_by_red",
            "failed_by_yellow",
            "failed_by_collision",
            "failed_by_left_yield",
            "failed_by_right_yield",
            "failed_by_lane_violation",
            "front_gap_violations",
            "queue_stop_position_error_sum",
            "queue_stop_position_samples",
            "cars_stopped_too_far_from_stop_line",
            "lead_green_start_delay_seconds",
            "follower_green_start_delay_seconds",
            "queue_discharge_delay_seconds",
            "lead_green_stuck_events",
            "follower_green_stuck_events",
            "green_stopped_too_far_events",
            "queue_red_crossings",
        ):
            metrics[key] += float(info.get(key, 0.0))
        metrics["left_yield"] += float(info.get("left_yield_violations", 0))
        metrics["right_yield"] += float(info.get("right_yield_violations", 0))
        metrics["right_on_red_entries"] += float(info.get("right_on_red_entries", 0))
        metrics["progress"] += float(info.get("progress_delta", 0.0))
        metrics["policy_samples"] += active_count
        metrics["env_steps"] += 1.0
        metrics["unsafe_requests"] += float(info.get("unsafe_requests", 0))
        metrics["safety_score"] += float(info.get("safety_score", 0.0))


    @staticmethod
    def _accumulate_intent_metrics(
        metrics: dict[str, float],
        labels: np.ndarray,
        predictions: np.ndarray,
        active_mask: np.ndarray,
    ) -> None:
        labels = np.asarray(labels, dtype=np.int64)
        predictions = np.asarray(predictions, dtype=np.int64)
        active = np.asarray(active_mask, dtype=np.float32) > 0.5
        valid = active & (labels >= 0)
        if not np.any(valid):
            return
        valid_labels = labels[valid]
        valid_predictions = predictions[valid]
        correct = valid_labels == valid_predictions
        metrics["intent_total"] += float(valid_labels.size)
        metrics["intent_correct"] += float(correct.sum())
        for index, name in enumerate(("stop", "hold", "go", "yield")):
            label_mask = valid_labels == index
            pred_mask = valid_predictions == index
            metrics[f"intent_label_{name}"] += float(label_mask.sum())
            metrics[f"intent_pred_{name}"] += float(pred_mask.sum())
            metrics[f"intent_correct_{name}"] += float((label_mask & correct).sum())

    def _validation_score(self, metrics: dict[str, float]) -> float:
        episodes = max(metrics.get("episodes", 1.0), 1.0)
        cars = max(metrics.get("cars", 1.0), 1.0)
        total_vehicles = episodes * cars
        completed_pct = 100.0 * metrics.get("completed_clean", 0.0) / total_vehicles
        failed = metrics.get("failed", 0.0)
        timeouts = metrics.get("timeouts", 0.0)
        stuck_timeouts = metrics.get("stuck_timeouts", 0.0)
        non_timeout_failed_pct = 100.0 * max(0.0, failed - timeouts) / total_vehicles
        timeout_pct = 100.0 * timeouts / total_vehicles
        stuck_timeout_pct = 100.0 * stuck_timeouts / total_vehicles
        collisions_per_ep = metrics.get("collisions", 0.0) / episodes
        closed_per_ep = metrics.get("closed_signal", 0.0) / episodes
        proximity_per_ep = metrics.get("proximity_events", 0.0) / episodes
        front_gap_per_ep = metrics.get("front_gap_violations", 0.0) / episodes
        queue_delay_per_ep = metrics.get("queue_discharge_delay_seconds", 0.0) / episodes
        queue_stop_error_avg = metrics.get("queue_stop_position_error_sum", 0.0) / max(
            metrics.get("queue_stop_position_samples", 0.0), 1.0
        )
        stopped_too_far_per_ep = metrics.get("cars_stopped_too_far_from_stop_line", 0.0) / episodes
        green_stuck_per_ep = (
            metrics.get("lead_green_stuck_events", 0.0)
            + metrics.get("follower_green_stuck_events", 0.0)
        ) / episodes
        green_stopped_far_per_ep = metrics.get("green_stopped_too_far_events", 0.0) / episodes
        completion_gap = max(0.0, self.config.validation_target_completed_pct - completed_pct)
        collision_excess = max(0.0, collisions_per_ep - self.config.validation_target_collisions_per_ep)
        red_excess = max(0.0, closed_per_ep - self.config.validation_target_red_per_ep)
        proximity_excess = max(0.0, proximity_per_ep - self.config.validation_target_proximity_events_per_ep)
        if self.config.validation_eval_mode == "redgreen":
            closed_signal = metrics.get("closed_signal", 0.0)
            red_safe_pct = 100.0 * max(0.0, total_vehicles - closed_signal) / total_vehicles
            redgreen_balance_pct = min(completed_pct, red_safe_pct, 100.0 - stuck_timeout_pct)
            return float(
                260.0 * redgreen_balance_pct
                + 110.0 * completed_pct
                + 85.0 * red_safe_pct
                - 260.0 * non_timeout_failed_pct
                - 240.0 * timeout_pct
                - 340.0 * stuck_timeout_pct
                - 1700.0 * completion_gap
                - 2400.0 * collision_excess
                - 1250.0 * red_excess
                - 550.0 * proximity_excess
                - 420.0 * collisions_per_ep
                - 140.0 * closed_per_ep
                - 50.0 * proximity_per_ep
                - 55.0 * front_gap_per_ep
                - 7.0 * queue_delay_per_ep
                - 45.0 * queue_stop_error_avg
                - 18.0 * stopped_too_far_per_ep
                - 35.0 * green_stuck_per_ep
                - 30.0 * green_stopped_far_per_ep
            )
        if self.config.validation_eval_mode == "right_on_red":
            right_yield_per_ep = metrics.get("right_yield", 0.0) / episodes
            right_on_red_entries_per_ep = metrics.get("right_on_red_entries", 0.0) / episodes
            closed_safe_pct = 100.0 * max(0.0, total_vehicles - metrics.get("closed_signal", 0.0)) / total_vehicles
            yield_safe_pct = 100.0 * max(0.0, total_vehicles - metrics.get("right_yield", 0.0)) / total_vehicles
            balance_pct = min(completed_pct, closed_safe_pct, yield_safe_pct, 100.0 - stuck_timeout_pct)
            return float(
                230.0 * balance_pct
                + 120.0 * completed_pct
                + 70.0 * yield_safe_pct
                + 850.0 * right_on_red_entries_per_ep
                - 260.0 * non_timeout_failed_pct
                - 240.0 * timeout_pct
                - 300.0 * stuck_timeout_pct
                - 1600.0 * completion_gap
                - 2400.0 * collision_excess
                - 1200.0 * red_excess
                - 650.0 * proximity_excess
                - 650.0 * right_yield_per_ep
                - 420.0 * collisions_per_ep
                - 120.0 * closed_per_ep
                - 70.0 * proximity_per_ep
                - 80.0 * front_gap_per_ep
                - 8.0 * queue_delay_per_ep
                - 35.0 * green_stuck_per_ep
            )
        if self.config.validation_eval_mode == "red_queue":
            red_safe_pct = 100.0 * max(0.0, total_vehicles - metrics.get("closed_signal", 0.0)) / total_vehicles
            return float(
                300.0 * red_safe_pct
                - 2600.0 * closed_per_ep
                - 2200.0 * collisions_per_ep
                - 800.0 * proximity_per_ep
                - 110.0 * queue_stop_error_avg
                - 28.0 * stopped_too_far_per_ep
                - 35.0 * front_gap_per_ep
            )
        if self.config.validation_eval_mode == "red":
            red_safe_pct = 100.0 * max(0.0, total_vehicles - metrics.get("closed_signal", 0.0)) / total_vehicles
            return float(
                220.0 * red_safe_pct
                - 2200.0 * closed_per_ep
                - 1800.0 * collisions_per_ep
                - 700.0 * proximity_per_ep
                - 95.0 * queue_stop_error_avg
                - 20.0 * stopped_too_far_per_ep
                - 25.0 * front_gap_per_ep
            )
        return float(
            150.0 * completed_pct
            - 180.0 * non_timeout_failed_pct
            - 130.0 * timeout_pct
            - 170.0 * stuck_timeout_pct
            - 1600.0 * completion_gap
            - 1900.0 * collision_excess
            - 950.0 * red_excess
            - 480.0 * proximity_excess
            - 340.0 * collisions_per_ep
            - 95.0 * closed_per_ep
            - 44.0 * proximity_per_ep
            - 35.0 * front_gap_per_ep
            - 5.0 * queue_delay_per_ep
            - 60.0 * queue_stop_error_avg
            - 12.0 * stopped_too_far_per_ep
            - 7.5 * green_stuck_per_ep
            - 10.0 * green_stopped_far_per_ep
        )
