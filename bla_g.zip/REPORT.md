# Fresh Technical Report: Generalized Pure-RL Intersection Policy

Date: 2026-07-07

Project folder:

```text
/home/dd/Desktop/AV Internship/PP/intersection-rl_generalized
```

This report replaces the older report for the current generalized pure-RL direction. It records the current architecture, training setup, observations, action space, dataflow, reward/auxiliary training logic, experiments, known bugs, attempted fixes, current results, and the next technical direction.

## Current Handoff - 2026-07-07

### What we are doing now

We paused right-on-red work because two pure-RL right-on-red curriculum runs stayed safe but never produced actual right-on-red entries. Before returning to right-on-red, the current focus is red queue behavior: vehicles should stop close to the stop line on red, followers should queue behind the lead vehicle with safe spacing, and the same policy should still discharge normally when the signal turns green.

Green discharge is preserved by keeping protected red/green replay and green_queue_discharge in the red-queue curriculum. Any red-queue checkpoint must still be re-evaluated on protected redgreen before it is used for a demo.

### Checkpoint Roles

| Checkpoint | Use | Status |
| --- | --- | --- |
| checkpoints/protected_redgreen_generalized_v1_selected.npz | Demo checkpoint for protected-left red/green, no yellow, no right-on-red | Best/current selected checkpoint. Use this for protected red/green demo. |
| checkpoints/red_queue_v4_far_recover_40k_best.npz | Experimental red-queue fine-tune candidate | Not demo-selected yet. It reduced stopped-too-far behavior compared with earlier red-queue attempts, but front-gap/queue spacing is still not solved and it needs full eval plus redgreen retention eval. |

Deleted/removed from the clean folder: failed right-on-red checkpoints, older red-queue checkpoints, stale train metrics CSVs, stale eval CSVs, old logs, and old zip archives. The documentation records the important results so the folder stays readable.

### Current Best Protected Red/Green Result

Using checkpoints/protected_redgreen_generalized_v1_selected.npz:

- 2 lanes / 8 cars / 60s: completed about 93.54%, collisions 0, proximity 0, stuck/moving timeout 0, red violations about 0.52/ep.
- 3 lanes / 12 cars / 60s: completed about 93.06%, collisions 0, proximity 0, stuck/moving timeout 0, red violations about 0.83/ep.
- 4 lanes / 16 cars / 60s: completed about 93.33%, collisions 0, proximity 0, stuck/moving timeout 0, red violations about 1.07/ep.

Simulator rollouts for this checkpoint remain in results/simulator_rollouts/ and show 8/8, 12/12, and 16/16 completion in the saved demo seeds.

### Right-On-Red Status

Right-on-red is not solved. Both attempted checkpoints were deleted from the clean folder because eval showed right_on_red_entries_per_ep=0.0; the policy waited for green. The next right-on-red attempt should be a behavior-discovery drill, not just longer training.

### Red Queue Status

Baseline red-queue eval of checkpoints/protected_redgreen_generalized_v1_selected.npz showed poor queue behavior in pure red drills: many red crossings, very high front-gap violations, and many cars stopped too far from the stop line.

Red-queue v4 added a focused red_queue curriculum, red-queue validation mode, stronger stop-line approach shaping, and green queue discharge replay. It is experimental only. Best observed validation snapshot was update 5, with red/proximity improved and stopped-too-far lower than earlier v3, but front-gap violations remained high.

Next technical step: continue red queue from a cleaned reward setup that directly balances three targets together: no red crossing, close stop-line placement, and safe follower gap. After that, run protected redgreen retention eval to confirm queue discharge on green still works.

## 1. Executive Summary

The project is moving from a staged, safety-shield-assisted PPO policy toward a generalized policy that learns intersection behavior from simulation. The current implementation uses one shared graph-attention actor-critic policy for all vehicles. Runtime action correction is disabled.

Current status:

- The selected protected redgreen checkpoint is demo-ready for protected-left red/green without yellow or right-on-red.
- Protected redgreen discharge is the strongest current behavior and should use checkpoints/protected_redgreen_generalized_v1_selected.npz.
- Right-on-red is not solved; attempted checkpoints were removed because they produced zero right-on-red entries.
- Red queue behavior is the active experimental work. The latest red-queue checkpoint is not demo-selected because follower spacing and stop-line placement still need work.
- Yellow remains intentionally excluded from the current phase.

Most important current conclusion:

Use the selected protected redgreen checkpoint for any near-term demo. Continue red-queue work separately, then run protected redgreen retention evaluation before replacing the selected checkpoint.

## 2. Project Objective

The final objective is an autonomous intersection RL policy that can drive vehicles through protected-left intersections with realistic behavior:

- move on legal green
- brake smoothly before red stop line
- queue correctly near the stop line
- maintain front gap
- avoid proximity warnings
- avoid collisions
- avoid stuck cars
- keep vehicles centered in lanes
- complete routes efficiently
- eventually handle yellow, right-on-red, 3/4 lanes, and dense traffic

The manager direction is that the behavior should be learned by the policy rather than enforced by a runtime safety shield.

## 3. Current Scope

Current active scope is intentionally narrower than the final objective:

- protected-left enabled
- straight and left routes only
- right turns disabled
- right-on-red disabled
- yellow postponed
- no lane changes
- no lateral spawn noise
- strict lane mapping
- lanes sampled from 2, 3, and 4 in generalized tasks
- current red/green behavior learned after green behavior

The reason for narrowing is practical: red stopping is still not solved even in small 4-car behavior drills. Adding yellow, right-on-red, dense traffic, or additional turning behavior now would mix too many failure causes and make debugging harder.

## 4. Runtime Policy Purity

The current generalized implementation has no runtime safety shield.

Disabled at runtime:

- safety action override
- red-light hard brake controller
- conflict reservation controller
- proximity action clamp
- queue-following action correction
- rule-based collision avoidance

The policy directly outputs continuous action values. The environment applies them through vehicle dynamics.

Important distinction:

The project now uses auxiliary training signals, but these are not runtime rules. The auxiliary intent head and physics-derived action target influence gradient updates during training. They do not override the model action during rollout/evaluation.

## 5. Repository Structure

```text
intersection-rl_generalized/
  README.md                         Current command and technical reference.
  REPORT.md                         This fresh technical report.
  MANIFEST.md                       Deliverable inventory.
  pyproject.toml                    Package metadata.
  requirements.txt                  Python requirements.
  Dockerfile, compose.yaml          Container files.
  intersection_rl/                  Main source package.
  scripts/train_graph_multitask.py  Train/evaluate CLI.
  scripts/generate_graphs.py        Graph generation helper.
  checkpoints/                      Current handoff checkpoints only.
  results/                          Simulator rollout media and summaries.
  graphs/                           Generated figures.
  tests/                            Regression tests.
```

Main implementation files:

```text
intersection_rl/env.py
intersection_rl/config.py
intersection_rl/graph_observation.py
intersection_rl/graph_ppo.py
intersection_rl/multitask.py
scripts/train_graph_multitask.py
```

## 6. Simulator And Environment

The environment simulates an intersection with vehicles, lanes, signal phases, stop lines, route progress, and collision/proximity checks.

Current generalized settings:

- lanes per approach: sampled by task, generally 2 to 4
- vehicle count: total vehicles per episode, not per lane and not per approach
- route set: straight and protected-left for current work
- strict lane mapping: enabled
- lateral noise: zero
- safety filter: disabled
- intersection reservation: disabled
- right-on-red: disabled

Vehicle status categories:

- completed cleanly
- failed by red violation
- failed by yellow violation
- failed by collision
- failed by yield/lane violation when applicable
- timeout/incomplete
- stuck timeout
- moving timeout

## 7. Signal Logic

The simulator supports green, yellow, and closed/red phases. In the current red/green experiments, yellow is deliberately avoided.

Why yellow is postponed:

- Yellow has conditional behavior: if behind stop line, brake; if already crossed, clear intersection.
- Red stopping is simpler and still not robust.
- Training yellow before red is solved adds another conditional behavior and makes failure analysis harder.

Current red task strategy:

- keep one axis in a stable green phase
- spawn vehicles facing the closed/red side
- train those vehicles to approach slowly and stop before the stop line

This avoids accidental yellow contamination in red-only behavior drills.

## 8. Observation Architecture

Observation is generated by `GraphObserver`.

Each controlled vehicle receives an ego-centric graph:

```text
ego:       [max_cars, ego_size]
nodes:     [max_cars, max_nodes, node_size]
edges:     [max_cars, max_nodes, edge_size]
node_mask: [max_cars, max_nodes]
```

Each ego graph contains:

- all active vehicles as vehicle nodes
- one lane/map context node
- one signal context node

### 8.1 Ego Features

The ego feature vector includes normalized current state and local context:

- speed
- acceleration
- distance to stop line
- crossed-stop-line flag
- stopping distance estimate
- route progress
- lateral offset
- current lane
- destination lane
- lanes per approach
- active vehicle count
- current green flag
- current yellow flag
- current closed/red flag
- movement-permitted flag
- protected-left flag
- right-on-red flag
- can-turn-right-on-red flag
- route one-hot encoding
- front gap
- front relative speed
- front time-to-collision proxy
- front-too-close flag
- inside-intersection flag

The policy does not receive hidden future signal timing.

### 8.2 Vehicle Node Features

Other vehicle nodes include observable relationship information:

- relative forward distance
- relative lateral distance
- Euclidean distance
- relative speed
- other vehicle speed
- other vehicle acceleration
- relative heading
- whether other vehicle is in front
- same lane flag
- same approach flag
- same axis flag
- possible crossing/conflict geometry
- other distance to stop line
- other crossed-stop-line flag
- visible lane green flag
- other inside-intersection flag
- other lane index
- leftmost/rightmost/middle lane indicators
- self-node flag

We intentionally avoid giving the ego a hidden route oracle for other vehicles. The observation is closer to what a real vehicle could infer from perception, map context, and traffic light state.

### 8.3 Edge Features

Edges encode pairwise relationship and interaction geometry:

- self edge
- same-lane front/back
- same lane
- adjacent lane
- same approach
- potential conflict based on observed geometry
- other inside intersection
- relative distance
- relative forward distance
- observed TTC proxy
- front-gap risk

## 9. Action Space

The actor outputs continuous actions:

```text
action[0] = normalized acceleration/braking in [-1, 1]
action[1] = normalized steering in [-1, 1]
```

Interpretation:

- positive longitudinal action means accelerate
- negative longitudinal action means brake
- zero means coast/hold depending on speed and dynamics

Current behavior target still wants continuous braking, not discrete brake/accelerate commands.

## 10. Model Architecture

The current model is `GraphActorCritic` in `intersection_rl/graph_ppo.py`.

Architecture:

1. Ego encoder: linear layer, layer norm, tanh.
2. Node encoder: linear layer, layer norm, tanh.
3. Edge encoder: linear layer, layer norm, tanh.
4. Graph attention blocks.
5. Shared body MLP.
6. Policy/value/intent heads.

Main modules:

```text
ego_encoder
node_encoder
edge_encoder
attention_layers
body
policy_head
mode_policy_head
value_head
intent_head
log_std
```

The graph attention block uses the ego embedding as query over graph nodes. Edge features modify keys, values, and attention bias. This lets the ego attend differently to front vehicles, cross traffic, lane context, and signal context.

### 10.1 Actor Head

The actor combines two branches:

- residual policy branch
- intent-mode policy branch

Current combination:

```text
mean = tanh(0.35 * residual_logits + 0.65 * blended_mode_logits)
```

The action distribution is Gaussian with learned log standard deviation. During training, actions are sampled. During evaluation, deterministic actor mean is used.

### 10.2 Critic

The critic value head predicts a scalar value for PPO advantage/return estimation.

### 10.3 Auxiliary Intent Head

The intent head predicts:

```text
0 = stop
1 = hold
2 = go
3 = yield
```

This is used for:

- auxiliary cross-entropy training
- phase-balanced minibatches
- phase advantage normalization
- diagnostics
- mode-policy blending inside the neural network

It is not a runtime rule.

## 11. Training Dataflow

One PPO update proceeds as follows:

1. Main trainer holds the current model.
2. Current model weights are copied to rollout workers.
3. Each worker creates a `MultiTaskIntersectionEnv`.
4. Each worker samples a task family.
5. The observer encodes graph observations.
6. The actor samples continuous actions.
7. The environment applies actions and advances dynamics.
8. Rewards, dones, masks, intent labels, and diagnostics are stored.
9. Workers return rollout batches.
10. Main trainer concatenates active vehicle samples.
11. GAE computes advantages and returns.
12. Advantages are normalized, optionally per phase/intent.
13. PPO minibatches are built, optionally phase-balanced.
14. Model updates optimize PPO, value, intent, action-target, and KL losses.
15. Validation runs periodically.
16. Checkpoints and metrics are saved.

Parallelism:

- rollout collection uses process workers
- evaluation can use process workers
- PyTorch update uses GPU if available
- workers use CPU copies of the policy

## 12. PPO Losses

Current loss:

```text
policy_loss
+ value_coefficient * value_loss
+ intent_loss_weight * intent_loss
+ intent_action_loss_coefficient * intent_action_loss
+ reference_kl_coefficient * reference_kl_loss
+ reference_kl_all_coefficient * reference_kl_all_loss
- entropy_coefficient * entropy
```

Meaning:

- `policy_loss`: clipped PPO objective
- `value_loss`: critic regression
- `intent_loss`: auxiliary stop/hold/go/yield classification
- `intent_action_loss`: smooth continuous action target loss
- `reference_kl_loss`: anti-forgetting against old policy
- `entropy`: exploration pressure

## 13. Auxiliary Action Target

We added a physics-derived action target because reward-only PPO struggled to learn continuous braking from sparse red violations.

For red-before-stop samples:

```text
available_distance = distance_to_stop - stop_margin
required_decel = brake_safety * speed^2 / (2 * available_distance)
safe_stop_speed = sqrt(2 * comfortable_braking * available_distance / brake_safety)
red_desired_speed = min(red_crawl_speed, safe_stop_speed)
red_target_accel = (red_desired_speed - speed) / time_constant
```

Behavior intuition:

- If far from the line, do not stop immediately; creep forward slowly.
- If approaching too fast for the remaining distance, brake.
- If inside the stop window, target zero speed.

This target is only used as a loss on the actor mean. It does not clamp the runtime action.

Current constants:

```text
physics_action_target_road_length = 65.0
physics_action_target_max_speed = 13.4
physics_action_target_max_acceleration = 2.5
physics_action_target_comfortable_braking = 4.0
physics_action_target_stop_margin = 3.0
physics_action_target_brake_safety_factor = 1.25
physics_action_target_red_crawl_speed = 3.0
physics_action_target_green_speed = 8.0
physics_action_target_time_constant = 1.0
```

## 14. Green-Only Checkpoint Analysis

Checkpoint:

```text
checkpoints/behavior_green_v3_300k_best.npz
```

Simple green results:

```text
2 lanes, 4 cars, green, 60s:
  completed_pct = 100.0
  failed_pct = 0.0
  collisions_per_ep = 0.0
  proximity_events_per_ep = 0.6
  red_violations_per_ep = 0.0

3 lanes, 4 cars, green, 60s:
  completed_pct = 100.0
  failed_pct = 0.0
  collisions_per_ep = 0.0
  proximity_events_per_ep = 0.0

4 lanes, 4 cars, green, 60s:
  completed_pct = 100.0
  failed_pct = 0.0
  collisions_per_ep = 0.0
  proximity_events_per_ep = 0.0
```

Stress checks:

```text
3 lanes, 6 cars, one per green lane:
  completed_pct = 88.0
  failed_pct = 12.0
  collisions_per_ep = 0.36
  proximity_events_per_ep = 3.0

4 lanes, 8 cars, one per green lane:
  completed_pct = 91.5
  failed_pct = 8.5
  collisions_per_ep = 0.34
  proximity_events_per_ep = 3.22
```

Assessment:

The green checkpoint is good as an initialization checkpoint for simple green discharge. It is not a final safe-driving policy because it still has failures under multi-lane stress, collisions/proximity in stress scenarios, and no red stopping behavior.

## 15. Red/Green Experiments

### 15.1 v2: Direct Brake Target

Checkpoint family:

```text
behavior_redgreen_v2_direct_brake_300k
```

Main idea:

- Use green checkpoint as initialization.
- Add red-before-stop action target based on required deceleration.

Representative deterministic eval for update 40:

```text
green, 2 lanes, 4 cars:
  completed_pct = 100.0
  failed_pct = 0.0
  collisions_per_ep = 0.0
  proximity_events_per_ep = 1.15
  closed_signal_violations_per_ep = 0.0

red, 2 lanes, 4 cars:
  completed_pct = 17.5
  failed_pct = 82.5
  red_violations_per_ep = 3.1
  closed_signal_violations_per_ep = 3.3

mixed, 2 lanes, 4 cars:
  completed_pct = 36.25
  failed_pct = 63.75
  red_violations_per_ep = 2.25
  yellow_violations_per_ep = 0.3
  closed_signal_violations_per_ep = 2.55
```

Conclusion:

Direct braking preserved green but did not solve red. The model often failed by red crossing, not by collision or proximity.

### 15.2 v3: Profile Brake Target

Checkpoint family:

```text
behavior_redgreen_v3_profile_brake_300k
```

Main changes:

- Red target changed from direct brake to speed profile.
- Far from stop line: creep.
- Near stop line: brake.
- Stop window: hold.
- Red/green timing fixed to remove yellow contamination.

Observed:

- Red failures improved in rollout around updates 30-45.
- Validation remained very negative.
- Later updates drifted.

Important bug discovered:

Anti-forgetting KL was being applied to red stop samples against a green-only reference policy. That pulled the red learner toward the old policy exactly where the old policy was wrong.

### 15.3 v4: Green-Only KL

Checkpoint family:

```text
behavior_redgreen_v4_green_kl_300k
```

Main change:

- Added `reference_kl_green_only`.
- Reference KL now protects legal green/go samples only.
- Red stop samples are no longer forced to match the old green-only checkpoint.

Command used:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage redgreen   --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --checkpoint checkpoints/behavior_redgreen_v4_green_kl_300k.npz   --steps 300000   --rollout-steps 256   --rollout-workers 12   --safety-replay-workers 6   --validation-workers 8   --validation-interval 10   --validation-episodes 8   --validation-scenarios 2:4:60 3:6:60 4:8:60   --checkpoint-interval 10   --max-cars 50   --learning-rate 4e-6   --target-kl 0.0012   --reward-clip 320   --reference-kl-coefficient 0.03   --reference-kl-all-coefficient 0.0   --reference-kl-green-only   2>&1 | tee results/behavior_redgreen_v4_green_kl_300k_train.log
```

Observed rollout pattern:

```text
updates 1-20: red failures often 100-250 per rollout batch
updates 28-44: red failures often 19-50 with zero collision/proximity
updates 48-59: red failures rose again; collision/proximity appeared in some batches
```

Selected log points:

```text
update 29: clean=77 failed=19 red=19 coll=0 prox=0
update 31: clean=80 failed=23 red=23 coll=0 prox=0
update 36: clean=63 failed=20 red=20 coll=0 prox=0
update 44: clean=85 failed=21 red=21 coll=0 prox=0
update 55: clean=82 failed=170 red=170 coll=0 prox=22
update 57: clean=88 failed=88 red=86 coll=1 prox=5
```

Conclusion:

Green-only KL was a correct fix, but not sufficient. The model still learns red behavior transiently and then loses it.

## 16. Bugs And Issues Faced

### 16.1 Safety Shield Conflict

Earlier policies used safety shielding. That helped metrics but conflicted with the new requirement that the policy learn behavior naturally. The generalized work disables runtime safety filters.

### 16.2 Lane Width Distribution Shift

Changing lane width from 4 m to 5 m changed geometry, proximity, and learned policy distribution. Old checkpoints were not reliable after that geometry change.

### 16.3 Spawn And Centering Issues

Cars sometimes appeared off center or initially too close. Current mitigations:

- no lateral noise
- strict lane mapping
- controlled spawn gaps
- lane center geometry

### 16.4 Stop-In-Place Instead Of Queue-To-Line

Earlier red penalties could reward stopping too early. Fix direction:

- penalize stopping too far upstream
- reward slow approach to stop window
- target creep-far / brake-near / hold-at-line behavior

### 16.5 Green Conservativeness

Adding stop behavior caused the policy to sometimes overgeneralize braking. Fix direction:

- train green first
- keep green replay
- apply reference KL only on green/go contexts

### 16.6 Yellow Contamination

Some red runs accidentally included yellow transitions. Fix direction:

- current redgreen task timing keeps short drills stable and avoids yellow
- yellow is postponed until red is solved

### 16.7 Wrong Anti-Forgetting Context

Applying KL to red samples against the green checkpoint blocked red learning. Fix:

- `reference_kl_green_only`

### 16.8 Rollout/Validation Mismatch

Rollout windows looked promising, but validation stayed poor. Interpretation:

- behavior is not robust across seeds/lane counts
- rollout alone is not enough
- deterministic eval is required

### 16.9 Learning Then Forgetting

The policy learns red partially and then drifts. Likely causes:

- PPO on-policy updates continue pushing after a good window
- red and green objectives still compete
- value scale is unstable due to large penalties
- red checkpoint selection is not yet focused enough
- mixed task distribution may be too hard too early

## 17. What Has Been Tried

Implemented or attempted so far:

- staged PPO with safety shield in old system
- pure runtime RL generalized redesign
- graph/entity observation
- graph attention actor-critic
- multi-task task sampling
- parallel rollout workers
- parallel evaluation workers
- failure-cause metrics
- incomplete/stuck/moving-timeout metrics
- auxiliary intent head
- detached auxiliary intent loss
- phase advantage normalization
- phase-balanced minibatches
- green-only behavior training
- direct red braking target
- red speed-profile target
- no-yellow redgreen timing
- green-only anti-forgetting KL
- stopping bad training tails manually

## 18. Current Technical Diagnosis

The main current issue is closed-signal discipline, not collision avoidance. In the red-only evals, collision and proximity are often near zero while red violations dominate failure.

The green policy is strong enough to use as a movement prior, but it is also a source of bias: it learned to move, not stop. If anti-forgetting is applied to red samples, it prevents red learning.

The policy shows that it can reduce red failures, but the behavior is unstable. This means the training signal is strong enough to move the model, but not yet structured enough to retain the behavior robustly.

## 19. Recommended Next Direction

Recommended next steps:

1. Train a narrower red-only drill until deterministic red eval is good.
2. Select checkpoints using red eval directly, not broad validation.
3. Save/evaluate every 5 updates during the learning window.
4. Keep green-only KL for green/go samples.
5. Temporarily reduce or remove mixed redgreen tasks until red works.
6. After red eval is stable, mix green and red at a controlled ratio.
7. Only then reintroduce yellow.
8. Only after yellow, scale density and add right-on-red.

## 20. Current Claim Boundaries

Do claim:

- the project now has a graph-attention generalized policy architecture
- runtime safety shield is disabled
- green-only simple behavior is strong
- red stopping is partially learned but unstable
- green-only KL fixed an important anti-forgetting bug

Do not claim:

- final safe driving is solved
- red stopping is reliable
- yellow is solved
- dense traffic is solved
- right-on-red is solved
- the green checkpoint is a complete safe-driving policy

## 21. Useful Commands

Run tests:

```bash
cd intersection-rl_generalized
../.venv/bin/python -m pytest tests
```

Evaluate green checkpoint:

```bash
cd intersection-rl_generalized
../.venv/bin/python scripts/train_graph_multitask.py evaluate   checkpoints/behavior_green_v3_300k_best.npz   --lanes 2   --cars 4   --episode-seconds 60   --episodes 50   --eval-workers 8   --eval-mode green   --output-csv results/eval_green_v3_2l_4c_60s.csv
```

Evaluate a redgreen checkpoint:

```bash
cd intersection-rl_generalized
for mode in green red mixed; do
  ../.venv/bin/python scripts/train_graph_multitask.py evaluate     checkpoints/behavior_redgreen_v4_green_kl_300k_update_0040.npz     --lanes 2     --cars 4     --episode-seconds 60     --episodes 50     --eval-workers 8     --eval-mode "$mode"     --output-csv "results/eval_behavior_redgreen_v4_update_0040_${mode}_2l4c60.csv"
done
```

Run current redgreen training pattern:

```bash
cd intersection-rl_generalized
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage redgreen   --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --checkpoint checkpoints/behavior_redgreen_next.npz   --steps 300000   --rollout-steps 256   --rollout-workers 12   --safety-replay-workers 6   --validation-workers 8   --validation-interval 10   --validation-episodes 8   --validation-scenarios 2:4:60 3:6:60 4:8:60   --checkpoint-interval 10   --max-cars 50   --learning-rate 4e-6   --target-kl 0.0012   --reward-clip 320   --reference-kl-coefficient 0.03   --reference-kl-all-coefficient 0.0   --reference-kl-green-only   2>&1 | tee results/behavior_redgreen_next_train.log
```

## 22. Final Current Assessment

The generalized architecture is the right direction for scalability because it uses ego/entity graph observations and one shared policy. The current green checkpoint is a useful base, but not a final policy. Red stopping remains the active unsolved problem. The latest v4 fix corrected a major anti-forgetting mistake, but the training still needs a stricter red-focused checkpoint-selection and curriculum strategy before adding yellow, density, or right-on-red.

## Update 2026-07-01: Red-Only Stage Implementation

After the v4 redgreen run showed transient red learning followed by drift, a new `red` behavior stage was implemented. This stage is intentionally narrower than `redgreen`.

What changed:

- Added `--behavior-stage red` to `scripts/train_graph_multitask.py`.
- Red stage training tasks are now only:
  - `red_stop_basic`
  - `red_brake_basic`
  - `red_creep_release_basic`
- Red stage excludes:
  - green replay tasks
  - mixed redgreen tasks
  - yellow tasks
  - right-on-red
  - dense traffic tasks
- Red stage keeps 2/3/4 lane sampling through those task definitions.
- Red stage defaults `intent_action_loss_coefficient` to `0.35`.
- Red stage automatically enables `reference_kl_green_only` when using a reference checkpoint.
- Red stage defaults validation to red-mode validation through `validation_eval_mode = "red"`.
- Red stage changes validation interval from 10 to 5 when the user did not override it.
- Red stage changes default validation scenarios from broad mixed scenarios to:
  - `2:4:60`
  - `3:6:60`
  - `4:8:60`
- Added `--validation-eval-mode {standard,green,red,mixed}` so checkpoint selection can use red-focused validation instead of standard random-signal validation.
- Validation workers can now run behavior-mode validation tasks using `MultiTaskIntersectionEnv`, matching the eval-mode logic.
- `scripts/train_graph_multitask.py` now forces its local `intersection_rl` package path onto `sys.path` before importing. This avoids accidentally importing the root installed package instead of the generalized package copy.
- Added `validation_eval_mode` to `PPOConfig` in both package copies.

Why this change was needed:

The previous redgreen stage mixed too many objectives too early. It could reduce red failures for a short window, but validation stayed poor and later training drifted. The new red stage isolates the red stopping behavior so `_best` checkpoints are selected by red-stop validation, not broad mixed validation.

Smoke test command used:

```bash
cd intersection-rl_generalized
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage red \
  --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz \
  --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz \
  --checkpoint /tmp/behavior_red_stage_smoke.npz \
  --steps 8 \
  --rollout-steps 8 \
  --rollout-workers 1 \
  --validation-workers 1 \
  --validation-interval 1 \
  --validation-episodes 1 \
  --validation-scenarios 2:4:60 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 1e-6 \
  --target-kl 0.001 \
  --reward-clip 320
```

Smoke result:

```text
update=0001 steps=0000008 rollouts=1 rw=1 vw=1 reward=-25.2291 val=-140780.9437 clean=0 failed=0 coll=0 prox=0 red=0 yellow=0 closed=0 phase_stop=32 phase_go=0 samples=32
```

Interpretation of smoke result:

- The command executed successfully.
- Red-stage rollout sampled stop-phase data only (`phase_stop=32`, `phase_go=0`).
- Red-mode validation executed and produced a validation score.
- This was not a training-quality run; it was only a code-path smoke test.

Regression tests after the implementation:

```text
64 passed, 1 warning
```

Recommended next training command:

```bash
cd intersection-rl_generalized
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage red \
  --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz \
  --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz \
  --checkpoint checkpoints/behavior_red_v1_redonly_150k.npz \
  --steps 150000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 5 \
  --max-cars 50 \
  --learning-rate 4e-6 \
  --target-kl 0.0012 \
  --reward-clip 320 \
  --reference-kl-coefficient 0.03 \
  --reference-kl-all-coefficient 0.0 \
  --reference-kl-green-only \
  2>&1 | tee results/behavior_red_v1_redonly_150k_train.log
```

Expected purpose of the next run:

- Check whether red stopping can become stable before mixing green/red again.
- Use `_best` from red-mode validation, not broad validation.
- Stop manually if red failures fall and then begin drifting upward again.

## 2026-07-01 Red-Only v2 Fixes

Reason for this version:

- Red-only drills intentionally place vehicles on a closed signal, so completion is not a valid success target for that drill. A vehicle that stops correctly will not complete until the light changes.
- The previous red-only v1 run showed temporary rollout improvement but deterministic evaluation still failed. The model usually either crossed the red line or stopped too far from the stop line.
- The previous red validation score still penalized lack of completion, which made `_best` checkpoint selection misleading for a red-stop drill.

Implemented changes:

- Added `closed_signal_approach_speed_gain` to `EnvConfig` for reward-side red approach speed shaping.
- Added `physics_action_target_red_approach_gain` to `PPOConfig` for auxiliary continuous action-target shaping.
- Changed red braking target from mostly constant crawl speed to a distance-proportional speed profile. The desired red speed now decreases as the car approaches the stop target instead of staying too high until very close to the line.
- Strengthened reward-side closed-signal speed shaping so cars are rewarded for controlled approach and braking, not for fast progress near the stop line.
- Added red-specific validation scoring when `--validation-eval-mode red` is active. Red validation now prioritizes no closed-signal crossing, low collision/proximity, reasonable stop position, and low front-gap violations instead of completion percentage.
- Added `red_drill_safe_pct` to evaluation CSV output. This is the percentage of spawned cars that did not create a red/yellow closed-signal crossing in a red drill.

Verification:

```bash
../.venv/bin/python -m py_compile scripts/train_graph_multitask.py intersection_rl/graph_ppo.py intersection_rl/config.py intersection_rl/env.py
../.venv/bin/python -m pytest -q
```

Result:

```text
64 passed, 1 warning
```

Next training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage red   --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --checkpoint checkpoints/behavior_red_v2_profile_200k.npz   --steps 200000   --rollout-steps 256   --rollout-workers 12   --validation-workers 8   --validation-interval 5   --validation-episodes 8   --checkpoint-interval 1   --max-cars 50   --learning-rate 4e-6   --target-kl 0.0012   --reward-clip 320   --reference-kl-coefficient 0.03   --reference-kl-all-coefficient 0.0   --reference-kl-green-only
```

Checkpoint interval is now `1` because v1 had a short rollout window around updates 46-47 but no exact checkpoint was saved there.

## 2026-07-01 Red-Only v2 Result And v3 Plan

Red-only v2 completed 66 updates / 202,752 sampled steps.

Useful rollout window:

- update 39: 20 rollout red crossings, 0 collisions, 0 proximity events
- update 47: 18 rollout red crossings, 0 collisions, 0 proximity events

Deterministic evaluation showed the rollout window did not transfer to the actor mean:

```text
behavior_red_v2_profile_200k_best, red eval 2 lanes / 4 cars / 60s / 30 episodes
completed_pct=0.0
failed_pct=100.0
red_violations_per_ep=2.93
closed_signal_violations_per_ep=2.93
red_drill_safe_pct=26.67
collisions_per_ep=0.0
proximity_events_per_ep=0.0
queue_stop_position_error_avg=5.92
```

Additional action diagnostic on the v2 best checkpoint:

```text
action_stop_label_mean=-0.057
action_stop_label_brake_share=0.979
action_hold_label_mean=-0.057
```

Interpretation:

- The policy often predicts a braking/holding tactical state, but the deterministic continuous action is almost neutral, not a real brake.
- Stochastic rollout samples sometimes brake enough to reduce red crossings, but deterministic evaluation uses the actor mean and still crosses red.
- Therefore the next fix is not collision/proximity reward. The next fix is stronger continuous action-target learning for red-stop samples.

Implemented after v2:

- Added deterministic action diagnostics to evaluation CSV:
  - `action_longitudinal_mean`
  - `action_brake_share`
  - `action_stop_label_mean`
  - `action_stop_label_brake_share`
  - `action_hold_label_mean`
  - `action_hold_label_brake_share`
  - `action_go_label_mean`
  - `action_go_label_brake_share`

Next v3 training change:

- Keep runtime policy pure: no hard brake, no action override, no safety shield.
- Keep red-only drill from green checkpoint.
- Increase `--intent-action-loss-coefficient` from the old red value `0.35` to `3.0` so the actor mean is directly pulled toward the smooth braking target.
- Use checkpoint interval `1` again.
- Evaluate deterministic red behavior immediately after training.

Planned v3 command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage red   --init-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --reference-checkpoint checkpoints/behavior_green_v3_300k_best.npz   --checkpoint checkpoints/behavior_red_v3_strong_action_120k.npz   --steps 120000   --rollout-steps 256   --rollout-workers 12   --validation-workers 8   --validation-interval 5   --validation-episodes 8   --checkpoint-interval 1   --max-cars 50   --learning-rate 8e-6   --target-kl 0.0012   --reward-clip 320   --intent-action-loss-coefficient 3.0   --reference-kl-coefficient 0.03   --reference-kl-all-coefficient 0.0   --reference-kl-green-only
```

## 2026-07-01 Red-Only v3-v7 Training Outcome

After v2 failed deterministic red evaluation, several focused red-only runs were executed from the green baseline checkpoint:

- `behavior_red_v3_strong_action_120k`: increased action-target loss to `3.0`.
- `behavior_red_v4_conservative_brake_100k`: added conservative red target profile controls.
- `behavior_red_v5_min_brake_80k`: added a training-only minimum braking target when above the red stop profile.
- `behavior_red_v6_low_value_80k`: reduced value loss coefficient and increased gradient clipping norm so value gradients would not dominate the actor/action-target loss.
- `behavior_red_v7_action_dominant_50k`: made the action-target loss dominant as a diagnostic run.

All runs kept runtime control pure policy output:

- no safety shield
- no hard brake override
- no red-light controller
- no action clamp

New CLI controls added during this iteration:

```text
--red-target-crawl-speed
--red-target-approach-gain
--red-target-stop-margin
--red-target-brake-safety
--red-target-min-brake
--closed-signal-approach-speed-gain
--value-coefficient
--max-grad-norm
```

New evaluation diagnostics added:

```text
action_longitudinal_mean
action_brake_share
action_stop_label_mean
action_stop_label_brake_share
action_hold_label_mean
action_hold_label_brake_share
action_go_label_mean
action_go_label_brake_share
red_drill_safe_pct
```

Summary CSV:

```text
results/red_v2_to_v7_deterministic_summary.csv
```

Best deterministic red result found in this iteration:

```text
checkpoint=checkpoints/behavior_red_v6_low_value_80k_update_0027.npz
red_violations_per_ep=2.53
closed_signal_violations_per_ep=2.53
red_drill_safe_pct=36.67
collisions_per_ep=0.00
proximity_events_per_ep=0.00
action_stop_label_mean=-0.092
action_stop_label_brake_share=0.999
```

This is still not acceptable as a solved red-stop policy. It means about 2.5 of 4 red-facing cars still cross the red line in deterministic red evaluation.

Important finding:

- Rollout metrics sometimes looked strong, for example v4 update 25 had only 2 red crossings in the stochastic rollout batch.
- Deterministic evaluation remained poor because the actor mean stayed near neutral braking.
- Across v2-v7, `action_stop_label_mean` mostly stayed between about `-0.04` and `-0.09`.
- That is too weak to stop cars that spawn 10-30 m before the stop line at 2-6 m/s.

Interpretation:

The current actor head is the bottleneck. Reward shaping, auxiliary action targets, lower value loss, larger gradient norm, and stronger target coefficients improved stochastic rollout windows but did not make the deterministic actor mean produce enough braking. The residual plus intent-blended action head appears to damp the longitudinal output around small negative values.

Next required engineering fix:

1. Redesign the actor output head, not the simulator rules.
2. Keep the graph-attention encoder and critic.
3. Replace the current blended residual/mode action output with a clearer longitudinal control head, for example:
   - one direct longitudinal mean head trained by PPO and action-target loss
   - one steering mean head kept separate
   - optional mode-conditioned residual added only after the direct longitudinal head
4. Add evaluation that reports initial red-state deterministic action at reset, not only episode averages.
5. Retrain green baseline if the actor-head tensor shapes change.
6. Then repeat red-only training.
7. Only after deterministic red stopping works, mix green/red and then reintroduce yellow.

Verification after code changes:

```bash
../.venv/bin/python -m py_compile scripts/train_graph_multitask.py intersection_rl/graph_ppo.py intersection_rl/config.py intersection_rl/env.py
../.venv/bin/python -m pytest -q
```

Result:

```text
64 passed, 1 warning
```

## 2026-07-01 Separate Acceleration/Steering Actor Update

Implemented architecture change:

- Replaced the old residual + intent-blended action output with two direct actor heads:
  - `acceleration_head(features) -> tanh -> action[0]`
  - `steering_head(features) -> tanh -> action[1]`
- The graph attention encoder, shared body, value head, and diagnostic intent head remain.
- Intent prediction no longer controls or blends the action path.
- Training CLI default for `--intent-loss-coefficient` is now `0.0` for this architecture.
- Intent labels are still reported for diagnostics/evaluation, but they are not trained by default and do not choose the action.

Checkpoint compatibility:

- New checkpoints include `actor_head=separate_accel_steer_v1` metadata.
- Loading old checkpoints with `policy_head` / `mode_policy_head` now raises a clear error.
- Because the actor-head tensor names changed, old checkpoints cannot be used as initialization for the new architecture.
- The next real training run must start from scratch with the separate acceleration/steering actor.

Checkpoint cleanup before packaging:

- Deleted all `*_update_*.npz` checkpoints.
- Kept only final checkpoints, `_best` checkpoints, metrics CSV files, and checkpoint README.
- The remaining old checkpoints are retained only as historical experiment records. They are not compatible with the new actor-head architecture.

Verification:

```bash
../.venv/bin/python -m pytest -q
```

Result:

```text
64 passed, 1 warning
```

Immediate next training command direction:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage green   --checkpoint checkpoints/behavior_green_separate_head_v1_300k.npz   --steps 300000   --rollout-steps 256   --rollout-workers 12   --validation-workers 8   --validation-interval 5   --validation-episodes 8   --checkpoint-interval 0   --max-cars 50   --learning-rate 8e-6   --target-kl 0.003   --reward-clip 320
```

After green is stable, red-only training should use the new green checkpoint as both init and reference checkpoint.



## 2026-07-01 Separate-Head Green Baseline Result

The separate acceleration/steering actor was trained from scratch for green behavior:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train   --behavior-stage green   --checkpoint checkpoints/behavior_green_separate_head_v1_300k.npz   --steps 300000   --rollout-steps 256   --rollout-workers 12   --validation-workers 8   --validation-interval 5   --validation-episodes 8   --checkpoint-interval 0   --max-cars 50   --learning-rate 8e-6   --target-kl 0.003   --reward-clip 320   2>&1 | tee results/behavior_green_separate_head_v1_300k_train.log
```

Implementation fix during this run:

- Green behavior-stage validation originally inherited dense default scenarios such as `2:24:120`. Green-only spawn mode could not fit that many cars in the simple green reset and raised a capacity error.
- Green validation now defaults to feasible movement checks: `2:4:60`, `3:6:60`, and `4:8:60`.

Training outcome:

- The run completed 98 PPO updates / 301,056 sampled steps.
- The final rollout window had no failed cars, no collisions, and no red/yellow/closed-signal events.
- The final checkpoint was slightly better than `_best` on fixed 3/4-lane deterministic evaluation, so the final checkpoint is the preferred green baseline.

Deterministic evaluation results, 50 episodes each:

```text
checkpoint=checkpoints/behavior_green_separate_head_v1_300k.npz

2 lanes, 4 cars, green, 60s:
  completed_pct=100.0
  failed_pct=0.0
  incomplete_pct=0.0
  collisions_per_ep=0.0
  proximity_events_per_ep=0.0
  red_violations_per_ep=0.0
  action_go_label_mean=0.604

2 lanes, 4 cars, green, one car per green lane, 60s:
  completed_pct=100.0
  failed_pct=0.0
  incomplete_pct=0.0
  collisions_per_ep=0.0
  proximity_events_per_ep=0.0

3 lanes, 6 cars, green, 60s:
  completed_pct=92.0
  failed_pct=8.0
  incomplete_pct=0.0
  collisions_per_ep=0.24
  proximity_events_per_ep=6.46
  failed_by_collision_per_ep=0.48
  action_go_label_mean=0.606

4 lanes, 8 cars, green, 60s:
  completed_pct=91.0
  failed_pct=9.0
  incomplete_pct=0.0
  collisions_per_ep=0.36
  proximity_events_per_ep=5.28
  failed_by_collision_per_ep=0.72
  action_go_label_mean=0.606
```

Interpretation:

- The new actor has learned positive continuous acceleration for green movement.
- 2-lane green discharge is solved in the current sanity checks.
- 3/4-lane green movement is not fully solved: remaining failures are collision/proximity related, not signal related.
- This checkpoint is a valid initialization/reference checkpoint for the next red-only training phase, but it should not be presented as a complete safe-driving policy.

Next step:

1. Use `checkpoints/behavior_green_separate_head_v1_300k.npz` as both init and reference checkpoint.
2. Train a red-only stage with green-only KL so red stopping can change while green movement is protected.
3. Evaluate red-only first; do not reintroduce yellow until deterministic red stopping is reliable.
4. After red works, run mixed green/red validation on 2, 3, and 4 lanes before returning to dense traffic.


## 2026-07-02 Simplified Red/Green Reward Update

Reason for this change:

The earlier red-learning attempts tried to teach a smooth braking profile before the model had reliably learned the simpler rule-level behavior. In the current simulator, vehicle dynamics are closer to point-motion kinematics than a high-fidelity kinodynamic car model. Therefore the next experiment should first teach the outcome: red means do not cross the stop line, green means move and complete.

What changed in code:

- `intersection_rl/env.py`: replaced the detailed red speed/deceleration shaping block with outcome-focused closed-signal shaping.
- `intersection_rl/config.py`: set `closed_signal_accel_penalty = 0.0` and `closed_signal_target_speed_penalty = 0.0`.
- `scripts/train_graph_multitask.py`: removed the automatic `0.35` red/redgreen `intent_action_loss_coefficient` default.

New red reward logic:

```text
if closed signal and before stop line:
  remove normal progress reward
  if inside legal stop window:
    reward stop-zone position
    reward holding if speed is near zero
  elif far before stop line:
    penalize stopped/idle far upstream
    reward progress toward stop zone
  elif too close / past legal stop window:
    penalize margin error and speed
if red/yellow stop line is crossed:
  keep large terminal violation penalty
```

What was intentionally removed for this experiment:

- No red acceleration penalty.
- No red target-speed/deceleration penalty.
- No default auxiliary action-target loss for red/redgreen stages.
- No runtime hard stop, no safety shield, and no action override.

Why this is still pure runtime RL:

The simulator does not force the car to stop. The policy still outputs continuous acceleration and steering. The environment only changes rewards and failure labels. If the policy crosses on red, it receives the existing violation penalty and the vehicle fails. If it waits legally near the stop line, it receives reward.

Expected effect:

- The model should have a simpler credit-assignment problem.
- Red behavior is now judged by legal stop-line outcome instead of by matching a hand-designed braking profile.
- Green movement is still protected by progress/completion rewards and green-only KL when using a green reference checkpoint.

Known limitation:

This does not yet teach smooth braking. Once the policy reliably learns red stop-line compliance and green movement, a later phase can reintroduce smoothness or a better kinodynamic model.

Verification after implementation:

```text
../.venv/bin/python -m pytest tests/test_env.py -q
43 passed, 1 warning

../.venv/bin/python -m pytest -q
64 passed, 1 warning
```


## 2026-07-02 Red Stop Velocity Reward Update

Reason:

The first simplified mixed red/green 200k run reduced stochastic rollout red violations, but deterministic evaluation still failed. The final and `_best` checkpoints both had near-zero stop-label acceleration and zero brake share. More importantly, the cars did not reliably reach zero velocity before the stop line.

Key deterministic eval symptom:

```text
action_stop_label_mean ~= 0.0
action_stop_label_brake_share = 0.0
red violations remained high
```

Reward-only fix implemented:

- Added `closed_signal_stop_window_speed_penalty = 12.0`.
- Added `closed_signal_stop_window_zero_speed_reward = 3.0`.
- Added `closed_signal_far_overspeed_penalty = 1.4`.
- Added `closed_signal_far_target_speed = 2.8`.
- In the legal red stop window, reward now strongly penalizes any remaining speed and rewards speed below `0.25 m/s`.
- Far before the stop line, the policy may still move toward the stop zone, but overspeed and far-upstream idling are penalized.
- No auxiliary action target, hard stop, safety shield, or runtime action correction was added.

Expected outcome:

This should test whether reward-only PPO can learn red stopping when the objective explicitly values zero velocity at the stop line, instead of only avoiding red-crossing failure or reducing acceleration.

Verification:

```text
../.venv/bin/python -m pytest -q
64 passed, 1 warning
```


## 2026-07-02 Stop-Window-Only Red And Strong Green Movement Reward

Reason:

The previous reward-only velocity update still included approach-speed shaping before the stop window. For the current simplified simulator objective, that is unnecessary. We only care that a red-facing car reaches the stop window and has velocity near zero there. We do not care whether it approached quickly or stopped suddenly.

Code changes:

- Removed red far-approach overspeed penalty.
- Removed red far-approach target-speed shaping.
- Kept strong stop-window speed penalty.
- Kept strong reward for zero velocity in the stop window.
- Added strong green penalties for stopped/slow/no-progress behavior before the stop line when movement is legally permitted and the front gap is clear.

Current intended behavior:

```text
red -> stop in the stop window before crossing
red far before line -> may move toward stop window
red stopped far before line -> penalized
green -> move and complete
green stopped/slow before stop line -> penalized heavily
```

Runtime purity:

No hard rule forces stopping or movement. The policy still outputs continuous actions. All changes are reward terms only.

Verification:

```text
../.venv/bin/python -m pytest -q
64 passed, 1 warning
```


## 2026-07-02 Redgreen Stop-Window v2 200k Result

Training command used 12 rollout workers, 8 validation workers, `--checkpoint-interval 0`, and mixed 2/3/4-lane redgreen tasks with 1-car-per-lane plus light 2-cars-per-lane exposure.

Result: do not extend this checkpoint to 1M. The reward-only stop-window version learned to reduce red violations in rollout, but deterministic evaluation exposed two bad failure modes.

Final checkpoint:

```text
2 lanes / 8 cars:  completed_pct=25.0, failed_pct=75.0, stuck_timeout_pct=73.5, red_violations_per_ep=0.12
3 lanes / 12 cars: completed_pct=33.33, failed_pct=66.67, stuck_timeout_pct=65.33, red_violations_per_ep=0.16
4 lanes / 16 cars: completed_pct=37.5, failed_pct=62.5, stuck_timeout_pct=61.25, red_violations_per_ep=0.20
```

Best checkpoint:

```text
2 lanes / 8 cars:  completed_pct=25.0, failed_pct=75.0, stuck_timeout_pct=28.5, red_violations_per_ep=3.72
3 lanes / 12 cars: completed_pct=33.33, failed_pct=66.67, stuck_timeout_pct=25.67, red_violations_per_ep=4.92
4 lanes / 16 cars: completed_pct=37.5, failed_pct=62.5, stuck_timeout_pct=23.25, red_violations_per_ep=6.28
```

Interpretation:

- Final checkpoint nearly eliminates red crossings but does so by becoming too conservative/stuck.
- Best checkpoint moves more than final but still has too many red violations.
- Deterministic stop-label action is still near zero and never crosses the brake-share threshold.
- The current reward-only design is not balanced enough: it can trade red violations against green movement, but it does not learn both at once.

Next fix direction:

- Do not train this run to 1M.
- Add stronger positive green discharge/completion pressure or revise validation score to punish stuck timeout more directly.
- Consider a phase-balanced validation score/checkpoint selector that requires both red safety and green completion.
- If reward-only still cannot make stop-label action negative, the next non-runtime option is a training-only auxiliary action target.

## 2026-07-06 Redgreen Balanced v3 Implementation

Reason:

The previous redgreen stop-window v2 run exposed a bad tradeoff: the final checkpoint had low red violations but became too conservative and stuck, while the `_best` checkpoint moved more but still violated red too often. That means checkpoint selection and reward balance were allowing one behavior to improve while the other regressed.

Implemented changes:

- Redgreen behavior-stage training now uses only one-car-per-lane tasks at first:
  - `redgreen_1_per_lane_2l`: 2 lanes per approach, 8 total cars.
  - `redgreen_1_per_lane_3l`: 3 lanes per approach, 12 total cars.
  - `redgreen_1_per_lane_4l`: 4 lanes per approach, 16 total cars.
- Two-cars-per-lane tasks are intentionally delayed until the basic red/green rule is stable.
- `--behavior-stage redgreen` can now run from scratch without a reference checkpoint. If a reference checkpoint is supplied, reference KL is still available, but the scratch run remains pure RL from environment reward/outcome.
- Redgreen validation now evaluates the same one-car-per-lane densities: `2:8:60`, `3:12:60`, and `4:16:60`.
- Added a redgreen-specific validation score. A `_best` checkpoint must now satisfy the combined objective: completion, closed-signal safety, and low stuck timeout. A checkpoint that avoids red violations by never moving should no longer win validation.
- Strengthened green movement rewards and penalties:
  - higher progress reward
  - higher legal speed reward
  - higher clean completion bonus
  - stronger zero-speed, slow-speed, and no-progress penalties under green
  - stronger legal stall penalties
- Reduced passive red-stop reward dominance:
  - lower closed-signal hold reward
  - lower stopped-in-window reward
  - lower stop-position reward
- Red crossing penalties remain strong. This change does not weaken red-light safety; it reduces the incentive to become permanently stopped.

Runtime purity:

No safety shield, hard stop, behavior cloning, or runtime action correction was added. The policy still outputs continuous acceleration and steering actions. Yellow behavior is still ignored for this phase.

Next training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --checkpoint checkpoints/redgreen_balanced_v3_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 8e-6 \
  --target-kl 0.003 \
  --reward-clip 320
```

Decision rule during training:

- If red violations do not start dropping by about update 40, stop and revise red reward geometry.
- If green completion or stuck timeout is still bad by about update 70, stop and revise green movement reward or validation sampling.
- Do not extend to 1M unless both red safety and green completion improve together.

Evaluation commands after training:

```bash
../.venv/bin/python scripts/train_graph_multitask.py evaluate \
  checkpoints/redgreen_balanced_v3_200k_best.npz \
  --lanes 2 --cars 8 --episode-seconds 60 --episodes 50 \
  --eval-mode redgreen --eval-workers 8 \
  --output-csv results/eval_redgreen_balanced_v3_best_2l_8c.csv

../.venv/bin/python scripts/train_graph_multitask.py evaluate \
  checkpoints/redgreen_balanced_v3_200k_best.npz \
  --lanes 3 --cars 12 --episode-seconds 60 --episodes 50 \
  --eval-mode redgreen --eval-workers 8 \
  --output-csv results/eval_redgreen_balanced_v3_best_3l_12c.csv

../.venv/bin/python scripts/train_graph_multitask.py evaluate \
  checkpoints/redgreen_balanced_v3_200k_best.npz \
  --lanes 4 --cars 16 --episode-seconds 60 --episodes 50 \
  --eval-mode redgreen --eval-workers 8 \
  --output-csv results/eval_redgreen_balanced_v3_best_4l_16c.csv
```

Separate green sanity evaluation:

```bash
../.venv/bin/python scripts/train_graph_multitask.py evaluate \
  checkpoints/redgreen_balanced_v3_200k_best.npz \
  --lanes 2 --cars 8 --episode-seconds 60 --episodes 50 \
  --eval-mode green --eval-workers 8 \
  --output-csv results/eval_redgreen_balanced_v3_best_green_2l_8c.csv
```

Verification after implementation:

```text
../.venv/bin/python -m py_compile intersection_rl/config.py intersection_rl/graph_ppo.py scripts/train_graph_multitask.py
../.venv/bin/python -m pytest -q
64 passed, 1 warning
```

## 2026-07-06 Redgreen Balanced v4 Initialization Fix

Reason:

The v3 redgreen run failed on the easiest deterministic 2-lane/8-car evaluation. The `_best` checkpoint had 25% completion and 4.64 red violations per episode. The final checkpoint reduced red violations to 1.32 per episode but had 58.5% stuck timeout. Diagnostics showed the same action-level problem in both checkpoints: stop/hold-labeled samples had near-zero longitudinal action and `action_stop_label_brake_share = 0.0`. The policy was not discovering negative acceleration for red stopping.

Root cause found:

The separate acceleration actor was initialized with a positive bias of `0.30`, and the longitudinal policy std was initialized near `exp(-1.8) ~= 0.165`. In a mixed red/green scratch run this starts the policy as "go everywhere" and gives very little early braking exploration. PPO then receives many red failures but few useful negative-acceleration samples to reinforce.

Implemented v4 changes:

- Removed the positive acceleration-head bias. Scratch policy now starts with neutral longitudinal mean.
- Increased initial longitudinal exploration by changing `log_std` from `[-1.8, -1.8]` to `[-1.2, -1.8]`; steering exploration remains unchanged.
- Increased `red_light_violation_penalty` from `320` to `420`.
- Increased stop-window speed penalty from `12` to `18`.
- Increased stopped-in-window reward from `1.0` to `1.5`.

What did not change:

- No safety shield.
- No action correction.
- No behavior cloning.
- No supervised action target.
- Yellow is still ignored for this phase.
- Runtime remains pure continuous-action PPO.

Next run:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --checkpoint checkpoints/redgreen_balanced_v4_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 8e-6 \
  --target-kl 0.003 \
  --reward-clip 320
```

Verification:

```text
../.venv/bin/python -m py_compile intersection_rl/config.py intersection_rl/graph_ppo.py scripts/train_graph_multitask.py
../.venv/bin/python -m pytest -q
64 passed, 1 warning
```

## 2026-07-06 Redgreen Balanced v5 Initialization Fix

Reason:

The v4 run fixed the extreme red-violation problem but overcorrected into almost no green movement. Through update 20, clean completions stayed near 0-5 vehicles per update, so the run was stopped and its interrupted checkpoint/metrics were deleted.

v5 change:

- Keep larger longitudinal exploration, but reduce the overconservative start:
  - longitudinal `log_std`: `-1.0`
  - steering `log_std`: `-1.8`
  - acceleration-head bias: `0.15`
- This gives the policy a small go prior for green discharge while still sampling braking often enough for red-stop learning.
- Red reward weights from v4 remain: red crossing penalty `420`, stop-window speed penalty `18`, stopped-in-window reward `1.5`.

Why this is still pure RL:

The initialization only changes the starting distribution of the continuous actor. It does not force an action, override unsafe actions, or provide supervised labels as training targets. The policy must still learn from reward and episode outcomes.

Expected signal:

Compared with v3, red failures should drop earlier because braking samples are common. Compared with v4, clean completions should be much higher because the actor no longer starts neutral/stopped.

## 2026-07-06 Redgreen Balanced v6 Full-Cycle Signal Fix

Reason:

The v5 run showed a strong clue: red failures dropped, but completion plateaued around 40-60 rollout completions and validation became stale. Inspection found a structural training mismatch. The redgreen task families were using `signal_mode="green"`. In `MultiTaskIntersectionEnv`, that extends one green phase for the whole episode. Therefore, vehicles spawned on the opposite approaches saw red for the entire episode, learned to stop, and never received a later green phase to discharge. High completion was impossible for those vehicles.

Implemented fix:

- Changed all redgreen task families from fixed-green signal mode to full-cycle randomized signal mode:
  - `redgreen_mixed_basic`
  - `redgreen_1_per_lane_2l`
  - `redgreen_1_per_lane_3l`
  - `redgreen_1_per_lane_4l`
  - `redgreen_2_per_lane_2l`
  - `redgreen_2_per_lane_3l`
  - `redgreen_2_per_lane_4l`
- The current redgreen stage still trains only the one-car-per-lane tasks, but those tasks now include real signal phase changes during the episode.

Why this matters:

The previous task setup could teach stop-on-red but not release-on-green for initially red-facing vehicles. Full-cycle signal training is required for the policy to learn the complete behavior:

```text
red before stop line -> stop before line
later green -> accelerate and complete
current green -> move and complete
```

Runtime purity:

This remains pure RL. No safety shield, hard stop, behavior cloning, or action override was added. The simulator now exposes the correct traffic-light dynamics during training.

Expected signal in v6:

- Go samples should increase relative to v5 because initially red vehicles can later become green.
- Completion should not be structurally capped by fixed-red approaches.
- Red violations should still trend down because v5 initialization/reward settings are retained.

## 2026-07-06 Redgreen No-Yellow Structural Fix

Reason:

Green-only training learned movement, and red-only training learned stopping, but mixed redgreen training failed because the mixed setup was not clean enough:

- The original redgreen tasks used fixed `green` signal mode, which left the opposite approaches red for the whole episode. Those vehicles could learn to stop, but they never received a later green to release and complete.
- Switching those tasks to the existing `random` signal mode fixed phase cycling, but it also introduced yellow phases. Yellow was not part of the current target and added extra failure noise.

Implemented changes:

- Added true no-yellow support to the simulator signal phase logic. If `signal_yellow_seconds == 0.0`, `_signal_phase()` switches directly between protected-left/green phases and never returns a yellow phase.
- Added a redgreen task mode in `MultiTaskIntersectionEnv`:
  - signal cycles normally between NS and EW approaches
  - protected-left phases remain enabled
  - yellow duration is forced to `0.0`
  - initial signal phase is randomized
- Updated redgreen scenario tasks to use `signal_mode="redgreen"` instead of `random` or fixed `green`.
- Updated redgreen evaluation and validation to use the no-yellow redgreen mode.
- Updated redgreen stage training mix to include focused drills plus mixed release examples:
  - `green_basic`
  - `green_queue_basic`
  - `red_brake_basic`
  - `red_creep_release_basic`
  - `redgreen_1_per_lane_2l`
  - `redgreen_1_per_lane_3l`
  - `redgreen_1_per_lane_4l`

Current target behavior:

```text
green -> move and complete
red/non-green before stop line -> stop before stop line
red now, later green -> release and complete
```

What was removed/cleaned:

- Deleted failed redgreen v2/v3 checkpoints, metrics, logs, and eval CSV files.
- Interrupted v4/v5/v6 failed artifacts had already been removed.
- Yellow support remains in the simulator for future phases, but it is no longer used by the current redgreen stage.

Verification:

```text
redgreen smoke check phases: [EW_GREEN, EW_LEFT_GREEN, NS_GREEN, NS_LEFT_GREEN]
signal_yellow_seconds: 0.0
../.venv/bin/python -m pytest -q
64 passed, 1 warning
```

Next training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --checkpoint checkpoints/redgreen_no_yellow_v1_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 8e-6 \
  --target-kl 0.003 \
  --reward-clip 320
```

Decision rule:

- Continue only if closed-signal violations trend down and clean completions stay alive.
- Stop early if the policy again learns only stopping or only moving.

## 2026-07-06 Redgreen No-Yellow v1 200k Result

Training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --checkpoint checkpoints/redgreen_no_yellow_v1_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 8e-6 \
  --target-kl 0.003 \
  --reward-clip 320
```

Training result:

- Training completed at update 66 / 202,752 collected steps.
- Yellow violations stayed at zero, confirming the no-yellow redgreen mode is active.
- Red violations dropped strongly during rollout.
- Final rollout was promising: `clean=87`, `failed=9`, `red=3`, `yellow=0`, `coll=3`, `prox=13`.
- Validation still selected an earlier checkpoint and remained stale later, so validation scoring may still be too conservative about green release.

Deterministic evaluation, final checkpoint:

```text
2 lanes / 8 cars / 60s / 50 episodes
completed_pct=45.25
failed_pct=54.75
incomplete_pct=46.50
stuck_timeout_pct=30.50
moving_timeout_pct=16.00
collisions_per_ep=0.00
proximity_events_per_ep=0.00
red_violations_per_ep=0.66
yellow_violations_per_ep=0.00
```

```text
3 lanes / 12 cars / 60s / 30 episodes
completed_pct=58.89
failed_pct=41.11
incomplete_pct=31.67
stuck_timeout_pct=20.56
moving_timeout_pct=11.11
collisions_per_ep=0.03
proximity_events_per_ep=0.00
red_violations_per_ep=1.07
yellow_violations_per_ep=0.00
```

```text
4 lanes / 16 cars / 60s / 30 episodes
completed_pct=66.25
failed_pct=33.75
incomplete_pct=23.96
stuck_timeout_pct=15.63
moving_timeout_pct=8.33
collisions_per_ep=0.00
proximity_events_per_ep=0.00
red_violations_per_ep=1.57
yellow_violations_per_ep=0.00
```

Best checkpoint on 2 lanes / 8 cars:

```text
completed_pct=45.75
failed_pct=54.25
incomplete_pct=47.00
stuck_timeout_pct=31.00
moving_timeout_pct=16.00
collisions_per_ep=0.00
proximity_events_per_ep=0.00
red_violations_per_ep=0.58
yellow_violations_per_ep=0.00
```

Interpretation:

This is a meaningful improvement over the earlier mixed runs:

- Red stopping is now learned well enough for the current target range.
- Yellow has been removed from this phase correctly.
- Collision and proximity behavior are clean in deterministic eval.
- The remaining major failure is not red or collision. It is green release / completion after stopping.

Diagnostic evidence:

- `lead_green_start_delay_seconds_per_ep` is high, roughly 35-40 seconds.
- `green_stopped_too_far_events_per_ep` is very high.
- Most incomplete vehicles are stuck timeouts rather than moving timeouts.
- Stop-label action has learned braking: `action_stop_label_brake_share=1.0`.
- Go-label action is positive, but many vehicles still fail to release strongly enough after waiting.

Next fix direction:

Do not change back to yellow or right-on-red. The next version should target green release after red stop:

- Add/strengthen reward for acceleration and progress immediately after a stopped red-facing vehicle receives green.
- Penalize stopped-too-far under green more directly.
- Add a focused no-yellow `redgreen_release_drill` task: cars start stopped before red, then receive green within the episode and must complete.
- Update validation score to value completion recovery after red stop, not only red safety.

## 2026-07-06 Green Release Reward v2 Implementation

Reason:

The no-yellow redgreen v1 checkpoint learned red stopping and kept collision/proximity clean, but completion stayed low because vehicles often stayed stopped or moved too slowly after green became available. Deterministic evaluation showed high green-release delay, many green stopped-too-far events, and high stuck timeout.

Implemented changes:

- Strengthened green movement reward:
  - `permitted_speed_reward`: `0.80 -> 1.10`
  - `permitted_acceleration_reward`: `0.35 -> 0.55`
  - `green_queue_progress_reward`: `1.30 -> 2.40`
  - `green_queue_acceleration_reward`: `0.24 -> 0.70`
- Strengthened green stopped/slow/no-progress penalties:
  - `green_zero_speed_penalty`: `22.0 -> 35.0`
  - `green_slow_speed_penalty`: `8.0 -> 14.0`
  - `green_no_progress_penalty`: `14.0 -> 24.0`
  - `permitted_idle_penalty`: `3.0 -> 5.5`
  - `legal_stall_penalty`: `3.0 -> 5.0`
  - `legal_stall_time_penalty`: `1.0 -> 2.0`
  - `green_queue_idle_penalty`: `3.20 -> 5.50`
  - `green_queue_stall_time_penalty`: `1.50 -> 2.50`
  - `green_queue_stopped_far_penalty`: `2.4 -> 7.0`
- Added explicit green-release terms:
  - `green_release_progress_reward = 3.0`
  - `green_release_acceleration_reward = 1.2`
  - `green_release_delay_penalty = 2.5`
  - `green_release_stopped_far_penalty = 6.0`
- In the reward function, if movement is legally permitted, the front gap is clear, and the vehicle is stopped/slow or has accumulated legal stall time:
  - reward progress more strongly
  - reward positive acceleration more strongly
  - penalize every timestep of green release delay after a short grace period
  - penalize being stopped/slow far before the stop line
- Added focused no-yellow `redgreen_release_drill` task:
  - vehicles spawn on currently closed approaches
  - signal changes to their green shortly afterward
  - intended behavior is stop/wait briefly, then accelerate and complete
- Added `redgreen_release_drill` to the redgreen behavior-stage training mix.
- Strengthened redgreen validation score against green delay/stuck behavior:
  - stronger completion weighting
  - stronger timeout/stuck penalties
  - stronger penalties for `queue_discharge_delay_seconds`, `green_stuck_events`, and `green_stopped_too_far_events`

Runtime purity:

This is still pure RL at runtime. No safety shield, no action override, no hard stop/go rule, and no behavior cloning were added. These are reward/task/validation changes only.

Verification:

```text
redgreen_release_drill smoke test:
signal_yellow_seconds=0.0
phases include no YELLOW phase

../.venv/bin/python -m pytest -q
64 passed, 1 warning
```

Next training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --checkpoint checkpoints/redgreen_release_v2_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 8e-6 \
  --target-kl 0.003 \
  --reward-clip 320
```

Decision rule:

The key metrics to watch are `completed`, `stuck_timeout_pct`, `lead_green_start_delay_seconds_per_ep`, `green_stopped_too_far_events_per_ep`, and red violations. Red was already acceptable in v1; v2 should primarily improve release/completion without losing red safety.

## 2026-07-06 Release v2/v3 Attempt Reverted

What happened:

After the no-yellow v1 checkpoint, we tried to improve completion by adding stronger green-release penalties/rewards and a focused `redgreen_release_drill`. The goal was correct: reduce green-start delay and stuck timeout. However, the first two attempts made mixed learning worse.

Observed during interrupted v2/v3 runs:

- Red violations stopped improving at the rate seen in no-yellow v1.
- Completion did not improve.
- The extra release pressure competed with red-stop learning too early.
- The policy did not reach the useful v1 pattern where red drops into low double digits while completion remains alive.

Decision:

The failed v2/v3 run artifacts were deleted, and the active code was reverted to the best-known no-yellow v1 baseline:

- no active `redgreen_release_drill`
- no active `green_release_*` reward fields
- green reward weights restored to the v1 values
- redgreen validation score restored to v1 weighting
- no-yellow redgreen signal mode remains active and is still the correct baseline

Current best baseline:

```text
checkpoint: checkpoints/redgreen_no_yellow_v1_200k.npz
2 lanes / 8 cars: completed=45.25%, red=0.66/ep, collision=0.00/ep, proximity=0.00/ep
3 lanes / 12 cars: completed=58.89%, red=1.07/ep, collision=0.03/ep, proximity=0.00/ep
4 lanes / 16 cars: completed=66.25%, red=1.57/ep, collision=0.00/ep, proximity=0.00/ep
```

Updated conclusion:

The next improvement should not add a heavy release drill into the full redgreen mix from scratch. A better next step is either:

- train from the no-yellow v1 checkpoint with a very small release-focused fine-tune, or
- add phase scheduling inside the same run so red-stop learning is established first, then release pressure is introduced gradually.

Verification after reverting active code:

```text
../.venv/bin/python -m pytest -q
64 passed, 1 warning
```



## 2026-07-07 Protected Red/Green Generalized v1 Selected

Problem addressed:

The previous work separated straight red/green release and protected-left red/green release. That separation helped diagnose the failure, but it was the wrong final training structure. The policy had learned straight green discharge and red stopping, while lane-0 protected-left release remained weak. A left-only release drill improved release but caused too many red violations because it over-trained the policy toward going.

Implementation change:

- Added generalized `redgreen_next_release` scenario task.
- Added `release` signal-time sampling that starts episodes 3-5 seconds before either the next straight green or the next protected-left green.
- Added `next_release` spawn filtering so vehicles are placed on the movement that is currently closed but will receive green next.
- Replaced the route-specific left-release task in the redgreen stage with the generalized next-release task.
- Disabled the route-specific left-green release reward weights for the generalized run, relying on the generic green queue/release rewards plus the generalized task distribution.
- Kept runtime policy purity: no safety shield, no red/green rule controller, no hard action override, no behavior cloning.

Training command:

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --init-checkpoint checkpoints/protected_green_v1_scratch_200k_best.npz \
  --reference-checkpoint checkpoints/protected_green_v1_scratch_200k_best.npz \
  --reference-kl-coefficient 0.03 \
  --reference-kl-all-coefficient 0.0 \
  --reference-kl-green-only \
  --intent-action-loss-coefficient 0.001 \
  --checkpoint checkpoints/redgreen_generalized_from_green_v1_120k.npz \
  --steps 120000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 8 \
  --checkpoint-interval 0 \
  --max-cars 50 \
  --learning-rate 4e-6 \
  --target-kl 0.002 \
  --reward-clip 320
```

Training observation:

The validation-best checkpoint was misleading. Validation selected an earlier update where red behavior was still poor. The final checkpoint at update 40 showed the useful behavior trend: red violations collapsed late in training while clean completions stayed high and stuck timeouts remained zero. The bad validation-best checkpoint was deleted, and the final checkpoint was copied to:

```text
checkpoints/protected_redgreen_generalized_v1_selected.npz
```

Final evaluation, 60 episodes each:

| Scenario | Completed | Failed | Red / ep | Yellow / ep | Stuck timeout | Moving timeout | Collisions / ep | Proximity / ep |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 lanes / 8 cars / 60s | 93.54% | 6.46% | 0.52 | 0.00 | 0.00% | 0.00% | 0.00 | 0.00 |
| 3 lanes / 12 cars / 60s | 93.06% | 6.94% | 0.83 | 0.00 | 0.00% | 0.00% | 0.00 | 0.00 |
| 4 lanes / 16 cars / 60s | 93.33% | 6.67% | 1.07 | 0.00 | 0.00% | 0.00% | 0.00 | 0.00 |

Artifacts:

```text
checkpoints/protected_redgreen_generalized_v1_selected.npz
checkpoints/redgreen_generalized_from_green_v1_120k.npz
checkpoints/redgreen_generalized_from_green_v1_120k_train_metrics.csv
results/eval_redgreen_generalized_from_green_v1_final_2l8c60.csv
results/eval_redgreen_generalized_from_green_v1_final_3l12c60.csv
results/eval_redgreen_generalized_from_green_v1_final_4l16c60.csv
graphs/protected_redgreen_generalized_v1/final_eval_metrics.png
graphs/protected_redgreen_generalized_v1/baseline_comparison.png
graphs/protected_redgreen_generalized_v1/training_trend.png
```

Conclusion:

Protected red/green behavior is now demo-usable across 2, 3, and 4 lanes. Red violations are not zero, so the next phase should avoid aggressive feature expansion until the demo path is verified visually. However, the major blocker from the prior two weeks - release failure and stuck timeouts after green - is resolved in this selected checkpoint.
