from __future__ import annotations

import argparse
import csv
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from intersection_rl.config import EnvConfig, PPOConfig
from intersection_rl.env import IntersectionEnv
from intersection_rl.graph_observation import GraphObserver
from intersection_rl.graph_ppo import GraphActorCritic, GraphPPOTrainer
from intersection_rl.multitask import DEFAULT_TASKS, MultiTaskIntersectionEnv, ScenarioTask


LEGACY_REPLAY_TASKS = ["red_heavy", "yellow_stop_drill", "stop_line_drill", "dense_queue_stop"]
DEFAULT_VALIDATION_SCENARIOS = ["2:8:60", "2:24:120", "3:24:120", "3:36:150", "4:30:150", "4:50:150"]
RED_VALIDATION_SCENARIOS = ["2:4:60", "3:6:60", "4:8:60"]
RED_QUEUE_VALIDATION_SCENARIOS = ["2:8:60", "3:12:60", "4:16:60", "2:16:75", "3:24:75", "4:32:75"]
GREEN_VALIDATION_SCENARIOS = ["2:4:60", "3:6:60", "4:8:60"]
LEFT_GREEN_VALIDATION_SCENARIOS = ["2:4:60", "3:4:60", "4:4:60"]
LEFT_RELEASE_VALIDATION_SCENARIOS = ["2:4:60", "3:4:60", "4:4:60"]
REDGREEN_VALIDATION_SCENARIOS = ["2:8:60", "3:12:60", "4:16:60"]
RIGHT_ON_RED_VALIDATION_SCENARIOS = ["2:8:30", "3:12:30", "4:16:30"]

BEHAVIOR_STAGE_TASKS = {
    "green": [
        "green_basic",
        "green_queue_basic",
    ],
    "protected_green": [
        "green_basic",
        "green_queue_basic",
        "left_green_basic",
        "left_green_queue_basic",
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
    ],
    "red": [
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
    ],
    "red_queue": [
        "red_queue_1_per_lane_2l",
        "red_queue_1_per_lane_3l",
        "red_queue_1_per_lane_4l",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "green_queue_discharge",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "left_release": [
        "left_redgreen_release",
        "left_green_basic",
        "left_green_queue_basic",
    ],
    "right_on_red": [
        "right_on_red_basic",
        "right_on_red_conflict",
        "right_on_red_queue",
        "right_on_red_mixed",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "redgreen": [
        "green_basic",
        "green_queue_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "left_green_basic",
        "left_green_queue_basic",
        "redgreen_next_release",
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "signal": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "yellow_clear_basic",
        "signal_mixed_basic",
    ],
    "queue": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "dense_queue_stop",
        "green_queue_discharge",
        "sparse_mixed",
    ],
    "conflict": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "dense_queue_stop",
        "green_queue_discharge",
        "sparse_mixed",
        "medium_mixed",
        "protected_left_heavy",
    ],
}

BEHAVIOR_STAGE_REPLAY_TASKS = {
    "green": ["green_basic", "green_queue_basic"],
    "protected_green": ["green_basic", "green_queue_basic", "left_green_basic", "left_green_queue_basic", "green_1to2_per_lane_2l", "green_1to2_per_lane_3l", "green_1to2_per_lane_4l"],
    "left_release": ["left_redgreen_release", "left_green_basic", "left_green_queue_basic"],
    "red": [
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
    ],
    "red_queue": [
        "red_queue_1_per_lane_2l",
        "red_queue_1_per_lane_3l",
        "red_queue_1_per_lane_4l",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "green_queue_discharge",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "right_on_red": [
        "right_on_red_basic",
        "right_on_red_conflict",
        "right_on_red_queue",
        "right_on_red_mixed",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "redgreen": [
        "green_basic",
        "green_queue_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "left_green_basic",
        "left_green_queue_basic",
        "redgreen_next_release",
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "signal": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "yellow_clear_basic",
        "signal_mixed_basic",
    ],
    "queue": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "dense_queue_stop",
        "green_queue_discharge",
    ],
    "conflict": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "dense_queue_stop",
        "green_queue_discharge",
        "protected_left_heavy",
    ],
}


def apply_behavior_stage_defaults(args: argparse.Namespace) -> None:
    if args.behavior_stage:
        stage = args.behavior_stage
        if args.training_tasks is None:
            args.training_tasks = BEHAVIOR_STAGE_TASKS[stage]
        if args.safety_replay_tasks is None:
            args.safety_replay_tasks = BEHAVIOR_STAGE_REPLAY_TASKS[stage]
        if stage == "signal" and args.intent_action_loss_coefficient <= 0.0:
            args.intent_action_loss_coefficient = 0.03

        if stage in {"green", "protected_green"}:
            args.validation_eval_mode = "green"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = GREEN_VALIDATION_SCENARIOS

        if stage != "green":
            requires_reference = stage not in {"redgreen", "protected_green"}
            if requires_reference and args.reference_checkpoint is None:
                raise ValueError(
                    f"--behavior-stage {stage} adds a new behavior and requires "
                    "--reference-checkpoint for anti-forgetting KL"
                )
            if args.reference_checkpoint is not None:
                if args.reference_kl_coefficient <= 0.0 and args.reference_kl_all_coefficient <= 0.0:
                    args.reference_kl_coefficient = 0.015
                    args.reference_kl_all_coefficient = 0.005
                args.reference_kl_stop_hold_only = False
                if stage in {"red", "red_queue", "redgreen", "left_release", "right_on_red"}:
                    args.reference_kl_green_only = True

        if stage == "red_queue":
            args.validation_eval_mode = "red_queue"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = RED_QUEUE_VALIDATION_SCENARIOS

        if stage == "right_on_red":
            args.validation_eval_mode = "right_on_red"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = RIGHT_ON_RED_VALIDATION_SCENARIOS

        if stage == "left_release":
            args.validation_eval_mode = "left_release"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = LEFT_RELEASE_VALIDATION_SCENARIOS

        if stage == "protected_green":
            args.validation_eval_mode = "left_green"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = LEFT_GREEN_VALIDATION_SCENARIOS

        if stage == "red":
            args.validation_eval_mode = "red"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = RED_VALIDATION_SCENARIOS

        if stage == "redgreen":
            args.validation_eval_mode = "redgreen"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = REDGREEN_VALIDATION_SCENARIOS
    if args.safety_replay_tasks is None:
        args.safety_replay_tasks = LEGACY_REPLAY_TASKS


def base_env_config(max_cars: int, seed: int, episode_seconds: float) -> EnvConfig:
    return EnvConfig(
        max_cars=max_cars,
        min_cars=1,
        lanes_per_approach=4,
        episode_seconds=episode_seconds,
        protected_left_signal=True,
        allow_right_on_red=False,
        right_turns_enabled=False,
        strict_lane_mapping=True,
        safety_filter_enabled=False,
        intersection_reservation_enabled=False,
        curriculum_enabled=False,
        curriculum_progression_enabled=False,
        randomize_initial_signal_phase=True,
        initial_lateral_noise=0.0,
        seed=seed,
    )


def train(args: argparse.Namespace) -> None:
    apply_behavior_stage_defaults(args)
    observer = GraphObserver(max_vehicle_nodes=args.max_cars)
    tasks = tuple(task for task in DEFAULT_TASKS if task.name in set(args.training_tasks)) if args.training_tasks else DEFAULT_TASKS
    if not tasks:
        raise ValueError("--training-tasks did not match any known task names")
    env_config = base_env_config(args.max_cars, args.seed, 120.0)
    if args.closed_signal_approach_speed_gain is not None:
        env_config.closed_signal_approach_speed_gain = args.closed_signal_approach_speed_gain
    env = MultiTaskIntersectionEnv(env_config, tasks=tasks)
    config = PPOConfig(
        total_steps=args.steps,
        rollout_steps=args.rollout_steps,
        update_epochs=args.update_epochs,
        minibatch_size=args.minibatch_size,
        reward_clip=args.reward_clip,
        hidden_size=args.hidden_size,
        learning_rate=args.learning_rate,
        target_kl=args.target_kl,
        value_coefficient=args.value_coefficient,
        entropy_coefficient=args.entropy_coefficient,
        intent_loss_coefficient=args.intent_loss_coefficient,
        intent_loss_warmup_updates=args.intent_loss_warmup_updates,
        intent_loss_ramp_updates=args.intent_loss_ramp_updates,
        intent_detach_shared=args.intent_detach_shared,
        intent_action_loss_coefficient=args.intent_action_loss_coefficient,
        reference_kl_coefficient=args.reference_kl_coefficient,
        reference_kl_all_coefficient=args.reference_kl_all_coefficient,
        reference_kl_stop_hold_only=args.reference_kl_stop_hold_only,
        reference_kl_green_only=args.reference_kl_green_only,
        phase_advantage_normalization=args.phase_advantage_normalization,
        phase_balanced_minibatches=args.phase_balanced_minibatches,
        safety_replay_workers=args.safety_replay_workers,
        safety_replay_tasks=tuple(args.safety_replay_tasks),
        rollout_closed_signal_stop_threshold=args.rollout_closed_signal_stop_threshold,
        rollout_guard_warmup_updates=args.rollout_guard_warmup_updates,
        task_phase1_updates=args.task_phase1_updates,
        task_phase2_updates=args.task_phase2_updates,
        validation_interval_updates=args.validation_interval,
        validation_episodes=args.validation_episodes,
        validation_patience=args.validation_patience,
        validation_eval_mode=args.validation_eval_mode,
        checkpoint_interval_updates=args.checkpoint_interval,
        seed=args.seed,
    )
    if args.red_target_crawl_speed is not None:
        config.physics_action_target_red_crawl_speed = args.red_target_crawl_speed
    if args.red_target_approach_gain is not None:
        config.physics_action_target_red_approach_gain = args.red_target_approach_gain
    if args.red_target_stop_margin is not None:
        config.physics_action_target_stop_margin = args.red_target_stop_margin
    if args.red_target_brake_safety is not None:
        config.physics_action_target_brake_safety_factor = args.red_target_brake_safety
    if args.red_target_min_brake is not None:
        config.physics_action_target_red_min_brake_accel = args.red_target_min_brake
    config.max_grad_norm = args.max_grad_norm
    trainer = GraphPPOTrainer(
        env,
        config,
        observer,
        layers=args.graph_layers,
        rollout_workers=args.rollout_workers,
        validation_workers=args.validation_workers,
    )
    if args.init_checkpoint:
        trainer.model.load(args.init_checkpoint)
    if args.reference_checkpoint:
        trainer.load_reference_policy(args.reference_checkpoint)
    trainer.train(args.checkpoint, validation_scenarios=parse_validation_scenarios(args.validation_scenarios))


def _empty_eval_totals() -> dict[str, float]:
    return {
        "completed": 0.0,
        "failed": 0.0,
        "timeouts": 0.0,
        "stuck_timeouts": 0.0,
        "collisions": 0.0,
        "proximity_events": 0.0,
        "red": 0.0,
        "yellow": 0.0,
        "closed": 0.0,
        "failed_by_red": 0.0,
        "failed_by_yellow": 0.0,
        "failed_by_collision": 0.0,
        "failed_by_left_yield": 0.0,
        "failed_by_right_yield": 0.0,
        "right_yield": 0.0,
        "right_on_red_entries": 0.0,
        "failed_by_lane_violation": 0.0,
        "front_gap_violations": 0.0,
        "queue_stop_position_error_sum": 0.0,
        "queue_stop_position_samples": 0.0,
        "cars_stopped_too_far_from_stop_line": 0.0,
        "lead_green_start_delay_seconds": 0.0,
        "follower_green_start_delay_seconds": 0.0,
        "queue_discharge_delay_seconds": 0.0,
        "lead_green_stuck_events": 0.0,
        "follower_green_stuck_events": 0.0,
        "green_stopped_too_far_events": 0.0,
        "queue_red_crossings": 0.0,
        "intent_total": 0.0,
        "intent_correct": 0.0,
        "intent_label_stop": 0.0,
        "intent_pred_stop": 0.0,
        "intent_correct_stop": 0.0,
        "intent_label_hold": 0.0,
        "intent_pred_hold": 0.0,
        "intent_correct_hold": 0.0,
        "intent_label_go": 0.0,
        "intent_pred_go": 0.0,
        "intent_correct_go": 0.0,
        "intent_label_yield": 0.0,
        "intent_pred_yield": 0.0,
        "intent_correct_yield": 0.0,
        "intent_true_stop_pred_stop": 0.0,
        "intent_true_stop_pred_hold": 0.0,
        "intent_true_stop_pred_go": 0.0,
        "intent_true_stop_pred_yield": 0.0,
        "intent_true_hold_pred_stop": 0.0,
        "intent_true_hold_pred_hold": 0.0,
        "intent_true_hold_pred_go": 0.0,
        "intent_true_hold_pred_yield": 0.0,
        "intent_true_go_pred_stop": 0.0,
        "intent_true_go_pred_hold": 0.0,
        "intent_true_go_pred_go": 0.0,
        "intent_true_go_pred_yield": 0.0,
        "intent_true_yield_pred_stop": 0.0,
        "intent_true_yield_pred_hold": 0.0,
        "intent_true_yield_pred_go": 0.0,
        "intent_true_yield_pred_yield": 0.0,
        "action_longitudinal_sum": 0.0,
        "action_longitudinal_count": 0.0,
        "action_brake_count": 0.0,
        "action_stop_label_sum": 0.0,
        "action_stop_label_count": 0.0,
        "action_stop_label_brake_count": 0.0,
        "action_hold_label_sum": 0.0,
        "action_hold_label_count": 0.0,
        "action_hold_label_brake_count": 0.0,
        "action_go_label_sum": 0.0,
        "action_go_label_count": 0.0,
        "action_go_label_brake_count": 0.0,
        "spawned": 0.0,
    }


def _accumulate_eval_intents(
    totals: dict[str, float],
    labels,
    predictions,
    active_mask,
) -> None:
    import numpy as np

    labels = np.asarray(labels, dtype=np.int64)
    predictions = np.asarray(predictions, dtype=np.int64)
    active = np.asarray(active_mask, dtype=np.float32) > 0.5
    valid = active & (labels >= 0)
    if not np.any(valid):
        return
    valid_labels = labels[valid]
    valid_predictions = predictions[valid]
    correct = valid_labels == valid_predictions
    totals["intent_total"] += float(valid_labels.size)
    totals["intent_correct"] += float(correct.sum())
    for index, name in enumerate(("stop", "hold", "go", "yield")):
        label_mask = valid_labels == index
        pred_mask = valid_predictions == index
        totals[f"intent_label_{name}"] += float(label_mask.sum())
        totals[f"intent_pred_{name}"] += float(pred_mask.sum())
        totals[f"intent_correct_{name}"] += float((label_mask & correct).sum())
    for true_index, true_name in enumerate(("stop", "hold", "go", "yield")):
        for pred_index, pred_name in enumerate(("stop", "hold", "go", "yield")):
            totals[f"intent_true_{true_name}_pred_{pred_name}"] += float(
                ((valid_labels == true_index) & (valid_predictions == pred_index)).sum()
            )


def _accumulate_eval_actions(
    totals: dict[str, float],
    labels,
    actions,
    active_mask,
) -> None:
    import numpy as np

    labels = np.asarray(labels, dtype=np.int64)
    actions = np.asarray(actions, dtype=np.float32)
    active = np.asarray(active_mask, dtype=np.float32) > 0.5
    valid = active & (labels >= 0)
    if not np.any(valid):
        return
    longitudinal = actions[valid, 0]
    valid_labels = labels[valid]
    totals["action_longitudinal_sum"] += float(longitudinal.sum())
    totals["action_longitudinal_count"] += float(longitudinal.size)
    totals["action_brake_count"] += float((longitudinal < -0.05).sum())
    for index, name in ((0, "stop"), (1, "hold"), (2, "go")):
        mask = valid_labels == index
        if np.any(mask):
            values = longitudinal[mask]
            totals[f"action_{name}_label_sum"] += float(values.sum())
            totals[f"action_{name}_label_count"] += float(values.size)
            totals[f"action_{name}_label_brake_count"] += float((values < -0.05).sum())


def _evaluate_episode_range(payload: dict) -> dict[str, float]:
    import torch

    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass

    observer = GraphObserver(max_vehicle_nodes=payload["max_cars"])
    env_config = base_env_config(
        payload["max_cars"], payload["seed"], payload["episode_seconds"]
    )
    env_config.lanes_per_approach = payload["lanes"]
    if payload.get("eval_mode") in {"green", "left_green", "left_release", "right_on_red", "red", "red_queue", "yellow", "yellow_clear", "mixed", "redgreen"}:
        mode = payload.get("eval_mode")
        offset_min = None
        offset_max = None
        allow_ror = False
        right_turns = False
        if mode == "red":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 10.0, 30.0
            speed_min, speed_max = 2.0, 6.0
            permitted_only = False
        elif mode == "red_queue":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 6.0, 12.0
            speed_min, speed_max = 0.0, 2.5
            permitted_only = False
        elif mode == "yellow":
            signal_mode = "yellow"
            spawn_filter = "yellow"
            lead_min, lead_max = 28.0, 48.0
            speed_min, speed_max = 0.3, 1.2
            permitted_only = False
        elif mode == "yellow_clear":
            signal_mode = "yellow"
            spawn_filter = "yellow"
            lead_min, lead_max = 8.0, 14.0
            speed_min, speed_max = 2.0, 4.0
            permitted_only = False
            offset_min, offset_max = 2.0, 8.0
        elif mode == "mixed":
            signal_mode = "random"
            spawn_filter = "all"
            lead_min, lead_max = 18.0, 42.0
            speed_min, speed_max = 0.0, 1.0
            permitted_only = False
        elif mode == "right_on_red":
            signal_mode = "right_on_red"
            spawn_filter = "right_red_conflict"
            lead_min, lead_max = 8.0, 24.0
            speed_min, speed_max = 0.0, 2.5
            permitted_only = False
            allow_ror = True
            right_turns = True
        elif mode == "redgreen":
            signal_mode = "redgreen"
            spawn_filter = "all"
            lead_min, lead_max = 10.0, 32.0
            speed_min, speed_max = 0.0, 2.0
            permitted_only = False
        elif mode == "left_green":
            signal_mode = "left_green"
            spawn_filter = "green"
            lead_min, lead_max = 4.5, 18.0
            speed_min, speed_max = 0.0, 0.0
            permitted_only = True
        elif mode == "left_release":
            signal_mode = "left_release"
            spawn_filter = "next_left_release"
            lead_min, lead_max = 10.0, 22.0
            speed_min, speed_max = 2.0, 5.0
            permitted_only = False
        else:
            signal_mode = "green"
            spawn_filter = "green"
            lead_min, lead_max = 6.0, 24.0
            speed_min, speed_max = 0.0, 0.0
            permitted_only = True
        task = ScenarioTask(
            f"eval_{mode}",
            payload["lanes"],
            payload["lanes"],
            payload["cars"],
            payload["cars"],
            payload["episode_seconds"],
            payload["episode_seconds"],
            1.0,
            signal_mode,
            lead_min,
            lead_max,
            12.0,
            14.0,
            speed_min,
            speed_max,
            permitted_only,
            spawn_filter,
            offset_min,
            offset_max,
            allow_ror,
            right_turns,
        )
        env = MultiTaskIntersectionEnv(env_config, tasks=(task,))
    else:
        env = IntersectionEnv(env_config)
    spec = observer.spec
    model = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=payload["hidden_size"],
        layers=payload["graph_layers"],
        seed=payload["seed"],
    )
    model.load(payload["checkpoint"])
    model.eval()
    totals = _empty_eval_totals()
    try:
        for episode in range(payload["episode_start"], payload["episode_stop"]):
            _, info = env.reset(seed=payload["seed"] + episode, options={"vehicle_count": payload["cars"]})
            observation = observer.encode(env)
            done = False
            while not done:
                predicted_intents = model.predict_intents(observation)
                _accumulate_eval_intents(
                    totals,
                    info.get("intent_labels", []),
                    predicted_intents,
                    info.get("active_mask", []),
                )
                actions, _, _ = model.act(observation, deterministic=True)
                _accumulate_eval_actions(
                    totals,
                    info.get("intent_labels", []),
                    actions,
                    info.get("active_mask", []),
                )
                _, _, terminated, truncated, info = env.step(actions)
                totals["collisions"] += int(info.get("collisions", 0))
                totals["proximity_events"] += int(info.get("proximity_events", 0))
                totals["red"] += int(info.get("red_light_violations", 0))
                totals["yellow"] += int(info.get("yellow_light_violations", 0))
                totals["closed"] += float(info.get("closed_signal_violations", 0))
                totals["right_yield"] += float(info.get("right_yield_violations", 0))
                totals["right_on_red_entries"] += float(info.get("right_on_red_entries", 0))
                totals["timeouts"] += float(info.get("timeout_failures", 0))
                totals["stuck_timeouts"] += float(info.get("stuck_timeout_failures", 0))
                for key in (
                    "failed_by_red",
                    "failed_by_yellow",
                    "failed_by_collision",
                    "failed_by_left_yield",
                    "failed_by_right_yield",
                    "failed_by_lane_violation",
                    "front_gap_violations",
                    "queue_stop_position_error_sum",
                    "queue_stop_position_samples",
                    "cars_stopped_too_far_from_stop_line",
                    "lead_green_start_delay_seconds",
                    "follower_green_start_delay_seconds",
                    "queue_discharge_delay_seconds",
                    "lead_green_stuck_events",
                    "follower_green_stuck_events",
                    "green_stopped_too_far_events",
                    "queue_red_crossings",
                ):
                    totals[key] += float(info.get(key, 0.0))
                observation = observer.encode(env)
                done = terminated or truncated
            totals["completed"] += float(info.get("completed_clean", 0))
            totals["failed"] += float(info.get("failed_vehicles", 0))
            totals["spawned"] += float(payload["cars"])
    finally:
        env.close()
    return totals


def _merge_eval_totals(items: list[dict[str, float]]) -> dict[str, float]:
    totals = _empty_eval_totals()
    for item in items:
        for key in totals:
            totals[key] += float(item.get(key, 0.0))
    return totals


def _eval_row(args: argparse.Namespace, totals: dict[str, int], eval_workers: int) -> dict[str, float | int | str]:
    return {
        "checkpoint": str(args.checkpoint),
        "episodes": args.episodes,
        "eval_workers": eval_workers,
        "lanes": args.lanes,
        "cars": args.cars,
        "episode_seconds": args.episode_seconds,
        "eval_mode": getattr(args, "eval_mode", "standard"),
        "green_one_car_per_lane": int(getattr(args, "green_one_car_per_lane", False)),
        "completed_pct": 100.0 * totals["completed"] / max(totals["spawned"], 1),
        "failed_pct": 100.0 * totals["failed"] / max(totals["spawned"], 1),
        "non_timeout_failed_pct": 100.0 * max(0, totals["failed"] - totals["timeouts"]) / max(totals["spawned"], 1),
        "incomplete_pct": 100.0 * totals["timeouts"] / max(totals["spawned"], 1),
        "timeout_pct": 100.0 * totals["timeouts"] / max(totals["spawned"], 1),
        "stuck_timeout_pct": 100.0 * totals["stuck_timeouts"] / max(totals["spawned"], 1),
        "moving_timeout_pct": 100.0 * max(0.0, totals["timeouts"] - totals["stuck_timeouts"]) / max(totals["spawned"], 1),
        "stuck_share_of_incomplete_pct": 100.0 * totals["stuck_timeouts"] / max(totals["timeouts"], 1.0),
        "moving_share_of_incomplete_pct": 100.0 * max(0.0, totals["timeouts"] - totals["stuck_timeouts"]) / max(totals["timeouts"], 1.0),
        "timeout_failures_per_ep": totals["timeouts"] / args.episodes,
        "stuck_timeouts_per_ep": totals["stuck_timeouts"] / args.episodes,
        "moving_timeouts_per_ep": max(0.0, totals["timeouts"] - totals["stuck_timeouts"]) / args.episodes,
        "collisions_per_ep": totals["collisions"] / args.episodes,
        "proximity_events_per_ep": totals["proximity_events"] / args.episodes,
        "red_violations_per_ep": totals["red"] / args.episodes,
        "yellow_violations_per_ep": totals["yellow"] / args.episodes,
        "closed_signal_violations_per_ep": totals["closed"] / args.episodes,
        "failed_by_red_per_ep": totals["failed_by_red"] / args.episodes,
        "failed_by_yellow_per_ep": totals["failed_by_yellow"] / args.episodes,
        "failed_by_collision_per_ep": totals["failed_by_collision"] / args.episodes,
        "failed_by_left_yield_per_ep": totals["failed_by_left_yield"] / args.episodes,
        "failed_by_right_yield_per_ep": totals["failed_by_right_yield"] / args.episodes,
        "right_yield_violations_per_ep": totals["right_yield"] / args.episodes,
        "right_on_red_entries_per_ep": totals["right_on_red_entries"] / args.episodes,
        "failed_by_lane_violation_per_ep": totals["failed_by_lane_violation"] / args.episodes,
        "front_gap_violations_per_ep": totals["front_gap_violations"] / args.episodes,
        "queue_stop_position_error_avg": totals["queue_stop_position_error_sum"] / max(totals["queue_stop_position_samples"], 1.0),
        "queue_stop_position_samples_per_ep": totals["queue_stop_position_samples"] / args.episodes,
        "cars_stopped_too_far_from_stop_line_per_ep": totals["cars_stopped_too_far_from_stop_line"] / args.episodes,
        "lead_green_start_delay_seconds_per_ep": totals["lead_green_start_delay_seconds"] / args.episodes,
        "follower_green_start_delay_seconds_per_ep": totals["follower_green_start_delay_seconds"] / args.episodes,
        "queue_discharge_delay_seconds_per_ep": totals["queue_discharge_delay_seconds"] / args.episodes,
        "lead_green_stuck_events_per_ep": totals["lead_green_stuck_events"] / args.episodes,
        "follower_green_stuck_events_per_ep": totals["follower_green_stuck_events"] / args.episodes,
        "green_stopped_too_far_events_per_ep": totals["green_stopped_too_far_events"] / args.episodes,
        "queue_red_crossings_per_ep": totals["queue_red_crossings"] / args.episodes,
        "red_drill_safe_pct": 100.0 * max(0.0, totals["spawned"] - totals["closed"]) / max(totals["spawned"], 1.0),
        "action_longitudinal_mean": totals["action_longitudinal_sum"] / max(totals["action_longitudinal_count"], 1.0),
        "action_brake_share": totals["action_brake_count"] / max(totals["action_longitudinal_count"], 1.0),
        "action_stop_label_mean": totals["action_stop_label_sum"] / max(totals["action_stop_label_count"], 1.0),
        "action_stop_label_brake_share": totals["action_stop_label_brake_count"] / max(totals["action_stop_label_count"], 1.0),
        "action_hold_label_mean": totals["action_hold_label_sum"] / max(totals["action_hold_label_count"], 1.0),
        "action_hold_label_brake_share": totals["action_hold_label_brake_count"] / max(totals["action_hold_label_count"], 1.0),
        "action_go_label_mean": totals["action_go_label_sum"] / max(totals["action_go_label_count"], 1.0),
        "action_go_label_brake_share": totals["action_go_label_brake_count"] / max(totals["action_go_label_count"], 1.0),
        "intent_accuracy": totals["intent_correct"] / max(totals["intent_total"], 1.0),
        "intent_total_per_ep": totals["intent_total"] / args.episodes,
        "intent_label_stop_per_ep": totals["intent_label_stop"] / args.episodes,
        "intent_pred_stop_per_ep": totals["intent_pred_stop"] / args.episodes,
        "intent_recall_stop": totals["intent_correct_stop"] / max(totals["intent_label_stop"], 1.0),
        "intent_label_hold_per_ep": totals["intent_label_hold"] / args.episodes,
        "intent_pred_hold_per_ep": totals["intent_pred_hold"] / args.episodes,
        "intent_recall_hold": totals["intent_correct_hold"] / max(totals["intent_label_hold"], 1.0),
        "intent_label_go_per_ep": totals["intent_label_go"] / args.episodes,
        "intent_pred_go_per_ep": totals["intent_pred_go"] / args.episodes,
        "intent_recall_go": totals["intent_correct_go"] / max(totals["intent_label_go"], 1.0),
        "intent_label_yield_per_ep": totals["intent_label_yield"] / args.episodes,
        "intent_pred_yield_per_ep": totals["intent_pred_yield"] / args.episodes,
        "intent_recall_yield": totals["intent_correct_yield"] / max(totals["intent_label_yield"], 1.0),
        "intent_true_stop_pred_stop_per_ep": totals["intent_true_stop_pred_stop"] / args.episodes,
        "intent_true_stop_pred_hold_per_ep": totals["intent_true_stop_pred_hold"] / args.episodes,
        "intent_true_stop_pred_go_per_ep": totals["intent_true_stop_pred_go"] / args.episodes,
        "intent_true_stop_pred_yield_per_ep": totals["intent_true_stop_pred_yield"] / args.episodes,
        "intent_true_hold_pred_stop_per_ep": totals["intent_true_hold_pred_stop"] / args.episodes,
        "intent_true_hold_pred_hold_per_ep": totals["intent_true_hold_pred_hold"] / args.episodes,
        "intent_true_hold_pred_go_per_ep": totals["intent_true_hold_pred_go"] / args.episodes,
        "intent_true_hold_pred_yield_per_ep": totals["intent_true_hold_pred_yield"] / args.episodes,
        "intent_true_go_pred_stop_per_ep": totals["intent_true_go_pred_stop"] / args.episodes,
        "intent_true_go_pred_hold_per_ep": totals["intent_true_go_pred_hold"] / args.episodes,
        "intent_true_go_pred_go_per_ep": totals["intent_true_go_pred_go"] / args.episodes,
        "intent_true_go_pred_yield_per_ep": totals["intent_true_go_pred_yield"] / args.episodes,
        "intent_true_yield_pred_stop_per_ep": totals["intent_true_yield_pred_stop"] / args.episodes,
        "intent_true_yield_pred_hold_per_ep": totals["intent_true_yield_pred_hold"] / args.episodes,
        "intent_true_yield_pred_go_per_ep": totals["intent_true_yield_pred_go"] / args.episodes,
        "intent_true_yield_pred_yield_per_ep": totals["intent_true_yield_pred_yield"] / args.episodes,
    }


def evaluate(args: argparse.Namespace) -> None:
    if args.green_one_car_per_lane:
        args.eval_mode = "green"
        args.cars = 2 * int(args.lanes)
    eval_workers = max(1, min(int(args.eval_workers), int(args.episodes)))
    payload_base = {
        "checkpoint": str(args.checkpoint),
        "max_cars": args.max_cars,
        "seed": args.seed,
        "episode_seconds": args.episode_seconds,
        "lanes": args.lanes,
        "cars": args.cars,
        "hidden_size": args.hidden_size,
        "graph_layers": args.graph_layers,
        "eval_mode": args.eval_mode,
    }
    if eval_workers == 1:
        totals = _evaluate_episode_range(
            {**payload_base, "episode_start": 0, "episode_stop": args.episodes}
        )
    else:
        payloads = []
        for worker_index in range(eval_workers):
            start = worker_index * args.episodes // eval_workers
            stop = (worker_index + 1) * args.episodes // eval_workers
            if start == stop:
                continue
            payloads.append({**payload_base, "episode_start": start, "episode_stop": stop})
        with ProcessPoolExecutor(max_workers=eval_workers) as executor:
            totals = _merge_eval_totals(list(executor.map(_evaluate_episode_range, payloads)))

    row = _eval_row(args, totals, eval_workers)
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(row))
        writer.writeheader()
        writer.writerow(row)
    print(" ".join(f"{key}={value}" for key, value in row.items()))


def parse_validation_scenarios(values: list[str]) -> tuple[tuple[int, int, float], ...]:
    scenarios: list[tuple[int, int, float]] = []
    for value in values:
        lanes_text, cars_text, seconds_text = value.split(":")
        scenarios.append((int(lanes_text), int(cars_text), float(seconds_text)))
    return tuple(scenarios)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train/evaluate graph-attention multi-task PPO.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    train_parser = subparsers.add_parser("train")
    train_parser.add_argument("--checkpoint", type=Path, default=Path("checkpoints/graph_multitask_v1.npz"))
    train_parser.add_argument("--init-checkpoint", type=Path)
    train_parser.add_argument("--reference-checkpoint", type=Path)
    train_parser.add_argument("--steps", type=int, default=200_000)
    train_parser.add_argument("--rollout-steps", type=int, default=256)
    train_parser.add_argument("--update-epochs", type=int, default=4)
    train_parser.add_argument("--minibatch-size", type=int, default=512)
    train_parser.add_argument("--reward-clip", type=float, default=20.0)
    train_parser.add_argument("--hidden-size", type=int, default=128)
    train_parser.add_argument("--graph-layers", type=int, default=2)
    train_parser.add_argument("--rollout-workers", type=int, default=8)
    train_parser.add_argument("--max-cars", type=int, default=50)
    train_parser.add_argument("--learning-rate", type=float, default=8e-5)
    train_parser.add_argument("--target-kl", type=float, default=0.008)
    train_parser.add_argument("--value-coefficient", type=float, default=0.5, help="Value loss coefficient. Lower values let behavior/action losses dominate focused drills.")
    train_parser.add_argument("--max-grad-norm", type=float, default=0.5, help="Global gradient clipping norm.")
    train_parser.add_argument("--entropy-coefficient", type=float, default=0.0003)
    train_parser.add_argument("--intent-loss-coefficient", type=float, default=0.0, help="Intent classifier loss. Default is 0 for the separate acceleration/steering actor.")
    train_parser.add_argument("--intent-loss-warmup-updates", type=int, default=10)
    train_parser.add_argument("--intent-loss-ramp-updates", type=int, default=30)
    train_parser.add_argument("--intent-action-loss-coefficient", type=float, default=0.0)
    train_parser.add_argument("--reference-kl-coefficient", type=float, default=0.0)
    train_parser.add_argument("--reference-kl-all-coefficient", type=float, default=0.0)
    train_parser.add_argument("--red-target-crawl-speed", type=float, default=None, help="Override the auxiliary red-stop crawl speed target in m/s.")
    train_parser.add_argument("--red-target-approach-gain", type=float, default=None, help="Override the auxiliary red-stop distance-to-target speed gain.")
    train_parser.add_argument("--red-target-stop-margin", type=float, default=None, help="Override the auxiliary target stopping distance before the stop line in meters.")
    train_parser.add_argument("--red-target-brake-safety", type=float, default=None, help="Override the auxiliary red-stop braking safety factor.")
    train_parser.add_argument("--red-target-min-brake", type=float, default=None, help="Minimum auxiliary braking acceleration in m/s^2 when a red-facing car is above the desired stop profile.")
    train_parser.add_argument("--closed-signal-approach-speed-gain", type=float, default=None, help="Override reward-side closed-signal target speed gain.")
    train_parser.add_argument(
        "--behavior-stage",
        choices=sorted(BEHAVIOR_STAGE_TASKS),
        help="Behavior curriculum stage: green, red, red_queue, redgreen, signal, queue, or conflict. Non-green stages require --reference-checkpoint.",
    )
    train_parser.add_argument(
        "--reference-kl-green-only",
        action="store_true",
        help="Apply reference-policy KL only to legal green/go samples. Useful when adding red-stop behavior from a green checkpoint.",
    )
    train_parser.add_argument(
        "--reference-kl-all-labels",
        dest="reference_kl_stop_hold_only",
        action="store_false",
        help="Apply reference-policy KL on all labeled active samples instead of only stop/hold labels.",
    )
    train_parser.set_defaults(reference_kl_stop_hold_only=True, reference_kl_green_only=False)
    train_parser.add_argument("--safety-replay-workers", type=int, default=0)
    train_parser.add_argument("--training-tasks", nargs="+", default=None, help="Optional task names to include in the training distribution.")
    train_parser.add_argument(
        "--safety-replay-tasks",
        nargs="+",
        default=None,
        help="Task names assigned to dedicated behavior replay rollout workers.",
    )
    train_parser.add_argument("--rollout-closed-signal-stop-threshold", type=float, default=0.0)
    train_parser.add_argument("--rollout-guard-warmup-updates", type=int, default=0)
    train_parser.add_argument("--task-phase1-updates", type=int, default=0)
    train_parser.add_argument("--task-phase2-updates", type=int, default=0)
    train_parser.add_argument(
        "--no-phase-advantage-normalization",
        dest="phase_advantage_normalization",
        action="store_false",
        help="Disable per-intent/phase advantage normalization.",
    )
    train_parser.add_argument(
        "--no-phase-balanced-minibatches",
        dest="phase_balanced_minibatches",
        action="store_false",
        help="Disable per-intent/phase balanced PPO minibatches.",
    )
    train_parser.set_defaults(phase_advantage_normalization=True, phase_balanced_minibatches=True)
    train_parser.add_argument(
        "--intent-shared-gradient",
        dest="intent_detach_shared",
        action="store_false",
        help="Allow intent loss to update shared actor/critic features. Default keeps intent loss detached.",
    )
    train_parser.set_defaults(intent_detach_shared=True)
    train_parser.add_argument("--validation-interval", type=int, default=10)
    train_parser.add_argument("--validation-episodes", type=int, default=8)
    train_parser.add_argument("--validation-workers", type=int, default=4)
    train_parser.add_argument("--validation-patience", type=int, default=10)
    train_parser.add_argument("--validation-eval-mode", choices=("standard", "green", "left_green", "left_release", "right_on_red", "red", "red_queue", "mixed", "redgreen"), default="standard", help="Validation environment mode used for checkpoint selection. The red behavior stage defaults this to red.")
    train_parser.add_argument("--checkpoint-interval", type=int, default=10)
    train_parser.add_argument(
        "--validation-scenarios",
        nargs="+",
        default=DEFAULT_VALIDATION_SCENARIOS,
        help="Validation scenarios as lanes:cars:episode_seconds entries.",
    )
    train_parser.add_argument("--seed", type=int, default=7)
    train_parser.set_defaults(func=train)

    eval_parser = subparsers.add_parser("evaluate")
    eval_parser.add_argument("checkpoint", type=Path)
    eval_parser.add_argument("--output-csv", type=Path, required=True)
    eval_parser.add_argument("--episodes", type=int, default=50)
    eval_parser.add_argument("--lanes", type=int, default=2)
    eval_parser.add_argument("--cars", type=int, default=12)
    eval_parser.add_argument("--episode-seconds", type=float, default=120.0)
    eval_parser.add_argument(
        "--eval-mode",
        choices=("standard", "green", "left_green", "left_release", "right_on_red", "red", "red_queue", "yellow", "yellow_clear", "mixed", "redgreen"),
        default="standard",
        help="Use behavior-stage evaluation modes: green, red stop, yellow stop, yellow clear, or sparse mixed full-cycle.",
    )
    eval_parser.add_argument(
        "--green-one-car-per-lane",
        action="store_true",
        help="For green evaluation, set cars to 2 * lanes: one car in each lane on each green-side approach.",
    )
    eval_parser.add_argument("--hidden-size", type=int, default=128)
    eval_parser.add_argument("--graph-layers", type=int, default=2)
    eval_parser.add_argument("--max-cars", type=int, default=50)
    eval_parser.add_argument("--eval-workers", type=int, default=1)
    eval_parser.add_argument("--seed", type=int, default=7)
    eval_parser.set_defaults(func=evaluate)
    return parser.parse_args()


if __name__ == "__main__":
    arguments = parse_args()
    arguments.func(arguments)
