import numpy as np

from intersection_rl.config import EnvConfig, PPOConfig
from intersection_rl.env import IntersectionEnv
from intersection_rl.ppo import PPOTrainer, SharedActorCritic, softmax


def test_actor_critic_shapes_and_probabilities():
    model = SharedActorCritic(22, 32, 9, seed=1)
    observations = np.zeros((7, 22), dtype=np.float32)
    logits, values, _ = model.forward(observations)
    probabilities = softmax(logits)
    assert logits.shape == (7, 9)
    assert values.shape == (7,)
    np.testing.assert_allclose(probabilities.sum(axis=1), 1.0)


def test_short_rollout_and_update_are_finite():
    env = IntersectionEnv(
        EnvConfig(min_cars=8, max_cars=8, episode_seconds=2.0, seed=1)
    )
    config = PPOConfig(
        total_steps=8,
        rollout_steps=8,
        update_epochs=1,
        minibatch_size=32,
        hidden_size=16,
        seed=1,
    )
    trainer = PPOTrainer(env, config)
    rollout = trainer.collect_rollout()
    metrics = trainer.update(rollout)
    assert all(np.isfinite(value) for value in metrics.values())
