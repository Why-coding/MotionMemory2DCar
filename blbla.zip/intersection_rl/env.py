from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from intersection_rl.config import EnvConfig
from intersection_rl.geometry import (
    APPROACHES,
    ROUTES,
    Polyline,
    build_route_path,
)
from intersection_rl.vehicle import Vehicle


class IntersectionEnv(gym.Env[np.ndarray, np.ndarray]):
    """Multi-agent four-way intersection with a parameter-sharing interface.

    The first dimension of the observation and action arrays is a stable vehicle
    slot. Inactive slots are masked in ``info["active_mask"]`` and ignored.
    """

    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 5}
    OBSERVATION_SIZE = 22
    ACTION_COUNT = 9
    ACTION_TO_ACCELERATION = np.repeat(
        np.array([-4.0, 0.0, 2.5], dtype=np.float32), 3
    )
    ACTION_TO_STEERING = np.tile(
        np.array([-1.0, 0.0, 1.0], dtype=np.float32), 3
    )

    def __init__(
        self,
        config: EnvConfig | None = None,
        render_mode: str | None = None,
    ) -> None:
        super().__init__()
        self.config = config or EnvConfig()
        self.render_mode = render_mode
        self.observation_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(self.config.max_cars, self.OBSERVATION_SIZE),
            dtype=np.float32,
        )
        self.action_space = spaces.MultiDiscrete(
            np.full(self.config.max_cars, self.ACTION_COUNT, dtype=np.int64)
        )
        self.vehicles: list[Vehicle] = []
        self.elapsed_seconds = 0.0
        self.step_count = 0
        self.completed_vehicles = 0
        self._collision_pairs: set[tuple[int, int]] = set()
        self._renderer = None

    # Week 5: initialize 8-12 vehicles on legal two-lane movements.
    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed if seed is not None else self.config.seed)
        self.elapsed_seconds = 0.0
        self.step_count = 0
        self.completed_vehicles = 0
        self._collision_pairs.clear()
        self.vehicles = []
        requested_count = (options or {}).get("vehicle_count")
        count = int(
            requested_count
            if requested_count is not None
            else self.np_random.integers(
                self.config.min_cars, self.config.max_cars + 1
            )
        )
        if not self.config.min_cars <= count <= self.config.max_cars:
            raise ValueError("vehicle_count must be inside configured bounds")
        self._spawn_vehicles(count)
        observation = self._get_observation()
        info = self._get_info(np.zeros(self.config.max_cars, dtype=np.float32))
        if self.render_mode == "human":
            self.render()
        return observation, info

    def _spawn_vehicles(self, count: int) -> None:
        queue_spacing = self.config.vehicle_length + 5.0
        queue_levels = int(np.ceil(count / (4 * self.config.lanes_per_approach)))
        maximum_queue_levels = max(
            1, int((self.config.road_length - 12.0) / queue_spacing) + 1
        )
        if queue_levels > maximum_queue_levels:
            capacity = 4 * self.config.lanes_per_approach * maximum_queue_levels
            raise ValueError(
                f"{count} cars do not fit on the configured roads; maximum is {capacity}"
            )
        slot_candidates = [
            (approach, lane, queue_index)
            for queue_index in range(queue_levels)
            for approach in APPROACHES
            for lane in range(self.config.lanes_per_approach)
        ]
        selected = self.np_random.choice(
            len(slot_candidates), size=count, replace=False
        )
        for vehicle_id, slot_index in enumerate(selected):
            approach, lane, queue_index = slot_candidates[int(slot_index)]
            # Week 6: route permissions adapt to the selected lane count.
            if self.config.lanes_per_approach == 1:
                legal_routes: Sequence[str] = ("left", "straight", "right")
            elif lane == 0:
                legal_routes = ("left", "straight")
            elif lane == self.config.lanes_per_approach - 1:
                legal_routes = ("straight", "right")
            else:
                legal_routes = ("straight",)
            route = str(self.np_random.choice(legal_routes))
            # Week 6: each movement may target any outgoing lane.
            destination_lane = int(
                self.np_random.integers(self.config.lanes_per_approach)
            )
            path = Polyline(
                build_route_path(
                    approach,
                    lane,
                    route,
                    self.config.lane_width,
                    self.config.road_length,
                    self.config.intersection_half_size,
                    self.config.lanes_per_approach,
                    destination_lane,
                )
            )
            stop_progress, _ = path.project(
                path.points[1]
            )
            progress = max(0.0, stop_progress - 12.0 - queue_index * queue_spacing)
            speed = float(self.np_random.uniform(3.0, 8.0))
            self.vehicles.append(
                Vehicle(
                    vehicle_id=vehicle_id,
                    approach=approach,
                    lane=lane,
                    route=route,
                    destination_lane=destination_lane,
                    path=path,
                    stop_progress=stop_progress,
                    progress=progress,
                    speed=speed,
                    lateral_offset=float(
                        self.np_random.uniform(
                            -self.config.initial_lateral_noise,
                            self.config.initial_lateral_noise,
                        )
                    ),
                )
            )

    # Week 5: basic longitudinal kinematic model and traffic-rule events.
    def step(
        self, action: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, bool, bool, dict[str, Any]]:
        actions = np.asarray(action, dtype=np.int64)
        if actions.shape != (self.config.max_cars,):
            raise ValueError(f"action must have shape ({self.config.max_cars},)")

        previous_active = np.array(
            [vehicle.active for vehicle in self.vehicles], dtype=bool
        )
        previous_progress = np.array(
            [vehicle.progress for vehicle in self.vehicles], dtype=np.float32
        )
        red_violations = np.zeros(self.config.max_cars, dtype=bool)
        left_yield_violations = np.zeros(self.config.max_cars, dtype=bool)
        right_yield_violations = np.zeros(self.config.max_cars, dtype=bool)
        right_lane_violations = np.zeros(self.config.max_cars, dtype=bool)

        for vehicle in self.vehicles:
            if not vehicle.active:
                continue
            action_index = actions[vehicle.vehicle_id]
            acceleration = float(self.ACTION_TO_ACCELERATION[action_index])
            steering = float(self.ACTION_TO_STEERING[action_index])
            acceleration = float(
                np.clip(
                    acceleration,
                    -self.config.comfortable_braking,
                    self.config.max_acceleration,
                )
            )
            was_before_stop = vehicle.progress < vehicle.stop_progress
            left_conflict = self._left_turn_conflict(vehicle)
            right_conflict = self._right_turn_conflict(vehicle)
            right_on_red = self._can_turn_right_on_red(vehicle)
            vehicle.step(
                acceleration,
                steering,
                self.config.dt,
                self.config.max_speed,
                self.config.lateral_speed,
                self.config.lane_width * 0.75,
            )
            crossed_stop = was_before_stop and vehicle.progress >= vehicle.stop_progress
            if crossed_stop:
                if vehicle.route == "right" and not self._is_rightmost_lane(vehicle):
                    right_lane_violations[vehicle.vehicle_id] = True
                if self._movement_has_green(vehicle):
                    pass
                elif right_on_red:
                    if right_conflict:
                        right_yield_violations[vehicle.vehicle_id] = True
                else:
                    vehicle.crossed_on_red = True
                    red_violations[vehicle.vehicle_id] = True
                if left_conflict:
                    left_yield_violations[vehicle.vehicle_id] = True

        collision_flags = self._detect_collisions()
        newly_completed = sum(
            was_active and not vehicle.active
            for was_active, vehicle in zip(previous_active, self.vehicles)
        )
        self.completed_vehicles += newly_completed
        self.elapsed_seconds += self.config.dt
        self.step_count += 1

        rewards = self._calculate_rewards(
            previous_progress,
            collision_flags,
            red_violations,
            left_yield_violations,
            right_yield_violations,
            right_lane_violations,
        )
        terminated = not any(vehicle.active for vehicle in self.vehicles)
        truncated = self.step_count >= self.config.max_steps
        observation = self._get_observation()
        info = self._get_info(rewards)
        info["collisions"] = int(collision_flags.sum() // 2)
        info["red_light_violations"] = int(red_violations.sum())
        info["left_yield_violations"] = int(left_yield_violations.sum())
        info["right_yield_violations"] = int(right_yield_violations.sum())
        info["right_lane_violations"] = int(right_lane_violations.sum())

        if self.render_mode == "human":
            self.render()
        return observation, rewards, terminated, truncated, info

    def _detect_collisions(self) -> np.ndarray:
        flags = np.zeros(self.config.max_cars, dtype=bool)

        active = [vehicle for vehicle in self.vehicles if vehicle.active]
        for first_index, first in enumerate(active):
            first_position, _ = first.pose()
            for second in active[first_index + 1 :]:
                second_position, _ = second.pose()
                pair = (
                    min(first.vehicle_id, second.vehicle_id),
                    max(first.vehicle_id, second.vehicle_id),
                )
                if (
                    pair not in self._collision_pairs
                    and np.linalg.norm(first_position - second_position)
                    < self.config.collision_distance
                ):
                    self._collision_pairs.add(pair)
                    first.collided = True
                    second.collided = True
                    flags[first.vehicle_id] = True
                    flags[second.vehicle_id] = True
        return flags

    # Week 5: reward traffic compliance, safety, progress, spacing, and lane path.
    def _calculate_rewards(
        self,
        previous_progress: np.ndarray,
        collisions: np.ndarray,
        red_violations: np.ndarray,
        left_yield_violations: np.ndarray,
        right_yield_violations: np.ndarray,
        right_lane_violations: np.ndarray,
    ) -> np.ndarray:
        rewards = np.zeros(self.config.max_cars, dtype=np.float32)
        for vehicle in self.vehicles:
            vehicle_id = vehicle.vehicle_id
            progress = max(0.0, vehicle.progress - previous_progress[vehicle_id])
            reward = 0.08 * progress
            reward -= 0.01  # Discourage blocking the intersection indefinitely.
            reward -= 0.004 * abs(vehicle.acceleration)
            # Week 6: lateral control must converge to the assigned route center.
            reward -= 0.08 * abs(vehicle.lateral_offset)
            reward -= 0.01 * abs(vehicle.steering)

            front_gap = self._front_gap(vehicle)
            if front_gap < self.config.vehicle_length + 2.0:
                reward -= 0.3
            if collisions[vehicle_id]:
                reward -= 10.0
            if red_violations[vehicle_id]:
                reward -= 5.0
            if left_yield_violations[vehicle_id]:
                reward -= 4.0
            if right_yield_violations[vehicle_id]:
                reward -= 4.0
            if right_lane_violations[vehicle_id]:
                reward -= 5.0
            if not vehicle.active and previous_progress[vehicle_id] < vehicle.path.length:
                reward += 3.0

            # Week 7: jerk, explicit speed-limit, and merge-yield terms belong here.
            # Week 9: pedestrian braking and lane-change safety terms belong here.
            # Week 10: goal progress and risky late lane-change terms belong here.
            rewards[vehicle_id] = reward
        return rewards

    # Week 6: selectable protected-left or permissive-left signal plan.
    def _signal_phase(self) -> tuple[str, float]:
        green = self.config.signal_green_seconds
        yellow = self.config.signal_yellow_seconds
        if self.config.protected_left_signal:
            left = self.config.left_signal_green_seconds
            segment = left + green + yellow
            time_in_cycle = self.elapsed_seconds % (2.0 * segment)
            axis = "NS" if time_in_cycle < segment else "EW"
            local_time = time_in_cycle % segment
            if local_time < left:
                return f"{axis}_LEFT_GREEN", local_time / left
            if local_time < left + green:
                return f"{axis}_GREEN", (local_time - left) / green
            return f"{axis}_YELLOW", (local_time - left - green) / yellow

        cycle = 2.0 * (green + yellow)
        time_in_cycle = self.elapsed_seconds % cycle
        if time_in_cycle < green:
            return "NS_GREEN", time_in_cycle / green
        if time_in_cycle < green + yellow:
            return "NS_YELLOW", (time_in_cycle - green) / yellow
        if time_in_cycle < 2.0 * green + yellow:
            return "EW_GREEN", (time_in_cycle - green - yellow) / green
        return "EW_YELLOW", (time_in_cycle - 2.0 * green - yellow) / yellow

    def _movement_has_green(self, vehicle: Vehicle) -> bool:
        return self._has_green(vehicle.approach, vehicle.route)

    def _has_green(self, approach: str, route: str = "straight") -> bool:
        phase, _ = self._signal_phase()
        axis = "NS" if approach in ("N", "S") else "EW"
        if self.config.protected_left_signal and route == "left":
            return phase == f"{axis}_LEFT_GREEN"
        return phase == f"{axis}_GREEN"

    def _left_turn_conflict(self, vehicle: Vehicle) -> bool:
        if (
            self.config.protected_left_signal
            or vehicle.route != "left"
            or not self._movement_has_green(vehicle)
        ):
            return False
        opposite = {"N": "S", "S": "N", "E": "W", "W": "E"}[
            vehicle.approach
        ]
        for other in self.vehicles:
            if (
                not other.active
                or other.approach != opposite
                or other.route != "straight"
            ):
                continue
            distance_to_stop = other.stop_progress - other.progress
            if (
                -2.0 * self.config.intersection_half_size
                <= distance_to_stop
                <= self.config.left_yield_distance
                and other.speed > 0.5
            ):
                return True
        return False

    def _is_rightmost_lane(self, vehicle: Vehicle) -> bool:
        return vehicle.lane == self.config.lanes_per_approach - 1

    def _can_turn_right_on_red(self, vehicle: Vehicle) -> bool:
        if (
            not self.config.allow_right_on_red
            or vehicle.route != "right"
            or not self._is_rightmost_lane(vehicle)
            or self._movement_has_green(vehicle)
        ):
            return False
        phase, _ = self._signal_phase()
        axis = "NS" if vehicle.approach in ("N", "S") else "EW"
        return phase != f"{axis}_YELLOW"

    def _right_turn_conflict(self, vehicle: Vehicle) -> bool:
        if not self._can_turn_right_on_red(vehicle):
            return False
        vehicle_axis = "NS" if vehicle.approach in ("N", "S") else "EW"
        for other in self.vehicles:
            if not other.active or other.vehicle_id == vehicle.vehicle_id:
                continue
            other_axis = "NS" if other.approach in ("N", "S") else "EW"
            opposite = {"N": "S", "S": "N", "E": "W", "W": "E"}[
                vehicle.approach
            ]
            conflicts_by_direction = (
                other_axis != vehicle_axis
                or (other.approach == opposite and other.route == "left")
            )
            if not conflicts_by_direction:
                continue
            distance_to_stop = other.stop_progress - other.progress
            approaching_conflict = (
                self._movement_has_green(other)
                and -2.0 * self.config.intersection_half_size
                <= distance_to_stop
                <= self.config.right_yield_distance
                and other.speed > 0.5
            )
            inside_intersection = (
                -2.0 * self.config.intersection_half_size
                <= distance_to_stop
                <= 0.0
            )
            if approaching_conflict or inside_intersection:
                return True
        return False

    def _movement_permitted(self, vehicle: Vehicle) -> bool:
        if self._movement_has_green(vehicle):
            return not self._left_turn_conflict(vehicle)
        return self._can_turn_right_on_red(vehicle) and not self._right_turn_conflict(
            vehicle
        )

    def _front_gap(self, vehicle: Vehicle) -> float:
        gap = self.config.road_length * 2.0
        for other in self.vehicles:
            if (
                other.vehicle_id == vehicle.vehicle_id
                or not other.active
                or other.approach != vehicle.approach
                or other.lane != vehicle.lane
                or other.progress <= vehicle.progress
            ):
                continue
            gap = min(gap, other.progress - vehicle.progress)
        return gap

    def _nearest_vehicle(self, vehicle: Vehicle) -> float:
        position, _ = vehicle.pose()
        distance = self.config.road_length * 2.0
        for other in self.vehicles:
            if other.vehicle_id == vehicle.vehicle_id or not other.active:
                continue
            other_position, _ = other.pose()
            distance = min(distance, float(np.linalg.norm(position - other_position)))
        return distance

    def _get_observation(self) -> np.ndarray:
        observation = np.zeros(
            (self.config.max_cars, self.OBSERVATION_SIZE), dtype=np.float32
        )
        phase, phase_progress = self._signal_phase()
        for vehicle in self.vehicles:
            if not vehicle.active:
                continue
            position, heading = vehicle.pose()
            distance_to_stop = vehicle.stop_progress - vehicle.progress
            route_one_hot = [float(vehicle.route == route) for route in ROUTES]
            axis_green = float(self._movement_has_green(vehicle))
            axis_yellow = float(
                phase
                == f"{'NS' if vehicle.approach in ('N', 'S') else 'EW'}_YELLOW"
            )
            values = [
                vehicle.speed / self.config.max_speed,
                vehicle.acceleration / self.config.comfortable_braking,
                np.clip(
                    distance_to_stop / self.config.road_length,
                    -1.0,
                    1.0,
                ),
                axis_green,
                axis_yellow,
                1.0 - axis_green - axis_yellow,
                np.clip(
                    self._front_gap(vehicle) / self.config.road_length, 0.0, 1.0
                ),
                np.clip(
                    self._nearest_vehicle(vehicle) / self.config.road_length,
                    0.0,
                    1.0,
                ),
                vehicle.progress / vehicle.path.length,
                vehicle.lane / max(1, self.config.lanes_per_approach - 1),
                *route_one_hot,
                np.sin(heading),
                np.cos(heading),
                phase_progress,
                vehicle.destination_lane
                / max(1, self.config.lanes_per_approach - 1),
                np.clip(
                    vehicle.lateral_offset / self.config.lane_width, -1.0, 1.0
                ),
                float(self._left_turn_conflict(vehicle)),
                float(self._can_turn_right_on_red(vehicle)),
                float(self._right_turn_conflict(vehicle)),
                float(self._is_rightmost_lane(vehicle)),
            ]
            observation[vehicle.vehicle_id] = np.asarray(values, dtype=np.float32)
        return np.clip(observation, -1.0, 1.0)

    def _get_info(self, rewards: np.ndarray) -> dict[str, Any]:
        active_mask = np.zeros(self.config.max_cars, dtype=np.float32)
        for vehicle in self.vehicles:
            active_mask[vehicle.vehicle_id] = float(vehicle.active)
        return {
            "active_mask": active_mask,
            "mean_active_reward": float(
                rewards[active_mask.astype(bool)].mean()
                if active_mask.any()
                else 0.0
            ),
            "completed_vehicles": self.completed_vehicles,
            "signal_phase": self._signal_phase()[0],
            "elapsed_seconds": self.elapsed_seconds,
        }

    def render(self) -> np.ndarray | None:
        if self._renderer is None:
            from intersection_rl.rendering import IntersectionRenderer

            self._renderer = IntersectionRenderer(self.config, self.render_mode)
        return self._renderer.render(self)

    def close(self) -> None:
        if self._renderer is not None:
            self._renderer.close()
            self._renderer = None

