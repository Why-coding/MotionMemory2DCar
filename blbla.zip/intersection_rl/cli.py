from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from intersection_rl.config import EnvConfig, PPOConfig
from intersection_rl.env import IntersectionEnv
from intersection_rl.ppo import PPOTrainer, SharedActorCritic


def add_environment_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--lanes", type=int, choices=range(1, 6), default=2,
        help="incoming lanes per approach (1-5)",
    )
    parser.add_argument(
        "--cars", type=int,
        help="exact number of cars; defaults to a random 8-12",
    )
    parser.add_argument(
        "--left-signal",
        choices=("protected", "yield"),
        default="yield",
        help="protected left arrow or permissive left turn with yielding",
    )
    parser.add_argument(
        "--right-on-red",
        choices=("on", "off"),
        default="on",
        help="allow right turns on red after yielding",
    )


def environment_config(args: argparse.Namespace) -> EnvConfig:
    if args.cars is not None and args.cars < 1:
        raise ValueError("--cars must be at least 1")
    car_counts = (
        {"min_cars": args.cars, "max_cars": args.cars}
        if args.cars is not None
        else {}
    )
    return EnvConfig(
        lanes_per_approach=args.lanes,
        protected_left_signal=args.left_signal == "protected",
        allow_right_on_red=args.right_on_red == "on",
        seed=args.seed,
        **car_counts
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Four-way intersection simulator and PPO policy"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    simulate = subparsers.add_parser("simulate", help="Run the visual simulator")
    simulate.add_argument("--episodes", type=int, default=3)
    simulate.add_argument("--seed", type=int, default=7)
    add_environment_arguments(simulate)
    simulate.add_argument(
        "--policy",
        type=Path,
        help="Optional .npz checkpoint; without it cars use a rule-based driver",
    )

    train = subparsers.add_parser("train", help="Train the shared PPO policy")
    train.add_argument("--steps", type=int, default=100_000)
    train.add_argument("--seed", type=int, default=7)
    add_environment_arguments(train)
    train.add_argument(
        "--checkpoint", type=Path, default=Path("checkpoints/ppo_intersection.npz")
    )

    evaluate = subparsers.add_parser("evaluate", help="Evaluate a checkpoint")
    evaluate.add_argument("policy", type=Path)
    evaluate.add_argument("--episodes", type=int, default=20)
    evaluate.add_argument("--seed", type=int, default=101)
    add_environment_arguments(evaluate)
    return parser


def rule_based_actions(env: IntersectionEnv) -> np.ndarray:
    """A Week 5 baseline used to inspect the simulator before training."""
    actions = np.ones(env.config.max_cars, dtype=np.int64)
    for vehicle in env.vehicles:
        if not vehicle.active:
            continue
        distance_to_stop = vehicle.stop_progress - vehicle.progress
        front_gap = env._front_gap(vehicle)
        should_stop = (
            not env._movement_permitted(vehicle)
            and 0.0 < distance_to_stop < max(8.0, vehicle.speed * 1.5)
        )
        too_close = front_gap < env.config.vehicle_length + 5.0
        acceleration_index = 1
        if should_stop or too_close:
            acceleration_index = 0
        elif vehicle.speed < env.config.max_speed * 0.75:
            acceleration_index = 2
        steering_index = 1
        if vehicle.lateral_offset > 0.08:
            steering_index = 0
        elif vehicle.lateral_offset < -0.08:
            steering_index = 2
        actions[vehicle.vehicle_id] = acceleration_index * 3 + steering_index
    return actions


def load_model(env: IntersectionEnv, checkpoint: Path) -> SharedActorCritic:
    model = SharedActorCritic(
        env.OBSERVATION_SIZE, PPOConfig().hidden_size, env.ACTION_COUNT
    )
    model.load(checkpoint)
    return model


def simulate(args: argparse.Namespace) -> None:
    env = IntersectionEnv(environment_config(args), render_mode="human")
    rng = np.random.default_rng(args.seed)
    model = load_model(env, args.policy) if args.policy else None
    try:
        for episode in range(args.episodes):
            observation, info = env.reset(seed=args.seed + episode)
            done = False
            episode_reward = 0.0
            while not done:
                if model is None:
                    actions = rule_based_actions(env)
                else:
                    actions, _, _ = model.act(
                        observation, rng, deterministic=True
                    )
                observation, rewards, terminated, truncated, info = env.step(actions)
                episode_reward += float(rewards.sum())
                done = terminated or truncated
            print(
                f"episode={episode + 1} reward={episode_reward:.2f} "
                f"completed={info['completed_vehicles']}"
            )
    finally:
        env.close()


def train(args: argparse.Namespace) -> None:
    env = IntersectionEnv(environment_config(args))
    config = PPOConfig(total_steps=args.steps, seed=args.seed)
    try:
        PPOTrainer(env, config).train(args.checkpoint)
        print(f"saved={args.checkpoint}")
    finally:
        env.close()


def evaluate(args: argparse.Namespace) -> None:
    env = IntersectionEnv(environment_config(args))
    model = load_model(env, args.policy)
    rng = np.random.default_rng(args.seed)
    rewards: list[float] = []
    completions: list[int] = []
    collisions = 0
    violations = 0
    left_yield_violations = 0
    right_yield_violations = 0
    right_lane_violations = 0
    try:
        for episode in range(args.episodes):
            observation, _ = env.reset(seed=args.seed + episode)
            done = False
            episode_reward = 0.0
            while not done:
                actions, _, _ = model.act(observation, rng, deterministic=True)
                observation, reward, terminated, truncated, info = env.step(actions)
                episode_reward += float(reward.sum())
                collisions += info["collisions"]
                violations += info["red_light_violations"]
                left_yield_violations += info["left_yield_violations"]
                right_yield_violations += info["right_yield_violations"]
                right_lane_violations += info["right_lane_violations"]
                done = terminated or truncated
            rewards.append(episode_reward)
            completions.append(info["completed_vehicles"])
    finally:
        env.close()
    print(
        f"episodes={args.episodes} mean_reward={np.mean(rewards):.2f} "
        f"mean_completed={np.mean(completions):.2f} "
        f"collisions={collisions} red_violations={violations} "
        f"left_yield={left_yield_violations} "
        f"right_yield={right_yield_violations} "
        f"right_lane={right_lane_violations}"
    )


def main() -> None:
    args = build_parser().parse_args()
    {"simulate": simulate, "train": train, "evaluate": evaluate}[args.command](args)


if __name__ == "__main__":
    main()
