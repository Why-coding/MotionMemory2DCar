# Intersection RL Simulator

A four-way traffic-intersection simulator and a parameter-sharing PPO policy
based on the project plan in `PP1.png`, `PP2.png`, and `PP3.png`.

The current runnable milestone implements **Week 5** and **Week 6**:

- Four-way signalized intersection with one to five incoming lanes per approach.
- Dedicated left-turn-capable left lane and right-turn-capable right lane.
- Eight to twelve vehicles with left, straight, and right routes.
- Kinematic vehicle model with longitudinal and lateral control.
- Shared PPO policy controlling acceleration and steering for every active vehicle.
- Rewards for progress, collisions, red-light violations, front spacing, and
  control smoothness.
- Pygame visualization and headless training/evaluation.

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
```

## Run

Inspect the simulator with the rule-based baseline:

```bash
intersection-rl simulate --episodes 3
```

Train PPO and save a policy:

```bash
intersection-rl train --steps 100000 \
  --checkpoint checkpoints/ppo_intersection.npz
```

Evaluate or visualize the trained policy:

```bash
intersection-rl evaluate checkpoints/ppo_intersection.npz --episodes 20
intersection-rl simulate --policy checkpoints/ppo_intersection.npz
```

Run tests:

```bash
pytest
```

## Agent Interface

The environment has one stable slot per configured vehicle:

- Observation: `(cars, 22)` float array.
- Action: `(cars,)` integer array.
- Actions: nine combinations of brake/coast/accelerate and left/center/right steering.
- Reward: `(cars,)` per-vehicle float array.
- `info["active_mask"]`: identifies active vehicle slots.

The PPO network is shared between cars. During training, each active car is one
sample, which allows the policy to generalize to different traffic counts.

## Week Mapping

The source contains `Week N` comments at the implementation and extension
points.

| Week | Plan and code status |
| --- | --- |
| 5 | Implemented: two-lane signals, kinematics, 8–12 cars, PPO, core rewards |
| 6 | Implemented: 1-5 lanes, protected or yielding left turns, random destination lanes, lateral lane following, right-on-red yielding, and rightmost-lane enforcement |
| 7 | Planned: kinodynamics, speed limits, merge lanes, jerk and merge rewards |
| 8 | Planned: shoulder/parking lanes, parked cars, crosswalk pedestrians |
| 9 | Planned: jaywalking, lane changes, pedestrian braking and safety rewards |
| 10 | Planned: per-car goals and cut-in scenarios |
| 11 | Planned: unprotected turns, stop signs, noise, occlusion, ROS bag adapter |
| 12 | Planned: Nissan simulator deployment and sim-to-sim calibration |

The remaining rows need separate implementation and validation. They are not hidden
behind configuration flags in the current Week 5 environment.

## Choose Lanes and Cars

Use `--lanes` from 1 to 5 and `--cars` for an exact vehicle count:

```bash
intersection-rl simulate --lanes 3 --cars 20
intersection-rl simulate --lanes 4 --cars 32
intersection-rl simulate --lanes 5 --cars 5
```

Train and evaluate with the same layout:

```bash
intersection-rl train --lanes 4 --cars 32 --steps 100000 \
  --checkpoint checkpoints/ppo_4lane_32cars.npz
intersection-rl evaluate checkpoints/ppo_4lane_32cars.npz \
  --lanes 4 --cars 32
```

One to five incoming lanes per approach are supported. The default road length
fits up to 24 cars per selected lane count, for example 48 cars with two lanes
or 120 cars with five lanes.

## Left-Turn Signal Mode

Use a dedicated protected left signal:

```bash
intersection-rl simulate --lanes 4 --cars 20 --left-signal protected
```

During each protected-left phase, only left-turn movements on that road axis
have green. The through signal is red. During the following through phase, the
left signal is red.

Use permissive left turns with yielding:

```bash
intersection-rl simulate --lanes 4 --cars 20 --left-signal yield
```

In yield mode, left turns share the through green and must wait for opposing
straight traffic. Each vehicle receives a random valid outgoing destination
lane. Lateral offset, target lane, and turn conflict are included in the policy
observation; steering and lane-centering rewards allow PPO to learn route
following.

Policy checkpoints created before this interface change are incompatible.
Retrain with the selected `--left-signal`, `--lanes`, and `--cars` settings.

## Right Turn On Red

Right-on-red is enabled by default. A vehicle may use it only from the
rightmost incoming lane and only after conflicting traffic clears:

```bash
intersection-rl simulate --lanes 4 --cars 20 --right-on-red on
```

Disable it when a scenario prohibits right-on-red:

```bash
intersection-rl simulate --lanes 4 --cars 20 --right-on-red off
```

The policy observes whether right-on-red is available, whether conflicting
traffic is present, and whether it is in the rightmost lane. Unsafe yielding,
red-light entry, and wrong-lane right turns have separate penalties and
reported evaluation counters.

## Docker

Do not copy the local `.venv` into the container. Docker installs clean,
container-compatible dependencies from `pyproject.toml`.

Build after unzipping the project:

```bash
docker-compose build
```

Run training headlessly and keep the checkpoint on the host:

```bash
docker-compose run --rm intersection-rl \
  train --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on \
  --steps 100000 --checkpoint checkpoints/week6.npz
```

Evaluate a saved policy:

```bash
docker-compose run --rm intersection-rl \
  evaluate checkpoints/week6.npz \
  --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on \
  --episodes 100
```

### Simulator Window On Linux

Allow the local Docker user to access X11, then launch the simulator:

```bash
xhost +local:docker
docker-compose run --rm simulator \
  simulate --lanes 4 --cars 20 \
  --left-signal protected --right-on-red on
xhost -local:docker
```

The X11 command is for Linux desktops. Windows and macOS need an external X
server, or training/evaluation can be run headlessly without a simulator
window.

### Create A Transfer Zip

Create a clean archive without the machine-specific virtual environment:

```bash
zip -r intersection-rl-week6.zip . \
  -x '.venv/*' '.pytest_cache/*' '__pycache__/*' \
     'intersection_rl.egg-info/*' 'checkpoints/*' '*.zip'
```

Include `checkpoints/*.npz` separately only when a trained policy must also be
transferred. Docker Compose mounts the local `checkpoints/` directory, so new
checkpoints remain available after containers exit.

By default, Compose writes files as Linux user/group `1000:1000`. If the host
account uses different IDs, prefix commands with:

```bash
HOST_UID=$(id -u) HOST_GID=$(id -g) docker-compose run --rm intersection-rl \
  train --steps 100000 --checkpoint checkpoints/week6.npz
```
