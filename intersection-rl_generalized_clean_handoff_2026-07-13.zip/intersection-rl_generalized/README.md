# Intersection RL Generalized

A four-way intersection simulator and shared reinforcement-learning policy for
multi-vehicle traffic control. The current validated scope is protected-left,
no-yellow red/green operation with policy-controlled longitudinal acceleration
and steering.

Last updated: 2026-07-13

## 1. Current Status

The production checkpoint is:

```text
checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz
```

Under the accepted front-bumper geometry, rear-bumper completion, one-shot
dilemma-zone clearance, and 3.5 second all-red protocol, it achieves:

| Regime | 2 lanes | 3 lanes | 4 lanes |
|---|---:|---:|---:|
| Sparse | 100.00% clean at 8 cars | 100.00% clean at 12 cars | 100.00% clean at 16 cars |
| Dense | 100.00% clean at 16 cars | 100.00% at 24 cars, 0.55 proximity/episode | 100.00% clean at 32 cars |
| Stress | 99.58% at 24 cars | 99.17% at 36 cars | 96.46% at 48 cars |

Stress red violations are 0.1, 0.3, and 0.4 per episode respectively. The
4-lane/48-car stress cell also has 0.1 collision, 1.3 proximity, and 0.4 stuck
timeouts per episode.

Current limitations:

- Yellow behavior is not promoted or considered solved.
- Right-on-red is not promoted or considered solved.
- The production policy can remain stopped short when a named demo spawns a
  nearly stationary vehicle far upstream under red.
- A three-component brake/creep/go prewarm fixes that demo creep behavior, but
  it is not promoted because it misses every stress completion floor.
- The simple `intersection-rl train` and `intersection-rl evaluate` commands use
  the legacy vector PPO path. Current graph checkpoints must be evaluated and
  trained with `scripts/train_graph_multitask.py`.
- Canonical policy evaluation runs with the safety shield and intersection
  reservation disabled. Runtime actions are learned policy outputs.

See `CHECKPOINT_REGISTRY.md` for checkpoint roles and `REPORT.md` for the full
technical history.

## 2. Repository Layout

| Path | Purpose |
|---|---|
| `intersection_rl/env.py` | Gymnasium environment, signal rules, rewards, labels, event metrics, geometry semantics |
| `intersection_rl/vehicle.py` | Vehicle state, path progress, and rear-bumper completion |
| `intersection_rl/geometry.py` | Route/path geometry |
| `intersection_rl/graph_observation.py` | Per-vehicle ego-centric graph observations |
| `intersection_rl/graph_ppo.py` | Graph-attention actor-critic, PPO, mixture routing, checkpoint IO, validation |
| `intersection_rl/multitask.py` | Weighted scenario tasks and multi-task reset logic |
| `intersection_rl/scenarios.py` | Shared policy environment and named demo builders |
| `intersection_rl/cli.py` | Simple CLI and visual/headless simulation |
| `intersection_rl/runtime.py` | Local-package guard, geometry marker, checkpoint metadata, provenance banner |
| `scripts/train_graph_multitask.py` | Authoritative current graph train/evaluate launcher |
| `scripts/run_dilemma_latch_rebaseline.py` | Current polish versus old-selected canonical comparison |
| `scripts/run_creep_three_component_promotion.py` | Three-component candidate canonical matrix |
| `scripts/run_three_component_creep_probe.py` | Creep trajectory and routing probe |
| `tests/` | Environment, geometry, PPO, runtime, scenario, and training regression tests |
| `CHECKPOINT_REGISTRY.md` | Source of truth for checkpoint roles |
| `REPORT.md` | Architecture, methods, experiments, bugs, fixes, results, and next work |
| `MANIFEST.md` | Clean handoff ZIP contents |

## 3. Requirements

- Python 3.10 or newer
- Linux, macOS, or Windows with a Python environment capable of installing
  PyTorch and Pygame
- A graphical desktop only when using `--render human`
- No GPU is required. Training uses CUDA automatically when PyTorch reports it
  available.

Python dependencies:

- Gymnasium
- NumPy
- Pygame
- PyTorch
- Matplotlib
- Pytest for development

## 4. Fresh Installation

From the extracted project directory:

```bash
cd intersection-rl_generalized
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
```

On Windows PowerShell, activate with:

```powershell
.venv\Scripts\Activate.ps1
```

Verify the installation:

```bash
python -c "import intersection_rl; print(intersection_rl.__file__); print(intersection_rl.GEOMETRY_CONVENTION)"
intersection-rl --help
python -m pytest tests
```

Expected geometry marker:

```text
front_bumper_v1
```

Expected current test result:

```text
114 passed
```

The installed console launcher and repository scripts force the local repository
onto `sys.path` and assert that `intersection_rl.__file__` resolves inside this
project. This prevents a stale sibling or globally installed package from
silently changing evaluation results.

If the console command is unavailable, use the repository-local equivalent:

```bash
python scripts/run_cli.py --help
```

## 5. Fastest Correct Simulation

Run the named 2-lane demo:

```bash
intersection-rl simulate \
  --demo-scenario demo_redgreen_2l \
  --episodes 1 \
  --render human
```

The demo preset automatically uses:

- The production polish checkpoint unless `--policy` is supplied.
- Protected left phases.
- No yellow.
- No right turns or right-on-red.
- No safety shield or intersection reservation.
- Random legal initial green phase.
- One movement green while conflicting movements are red.
- 3.5 seconds of all-red clearance.
- Front-bumper-safe randomized positions.
- Queue-safe randomized gaps.
- Signal-conditioned speed sampling with a braking-feasibility cap.
- The same `MultiTaskIntersectionEnv` reset path used by headless demo checks.

Named demos:

| Name | Lanes per approach | Cars | Default seed |
|---|---:|---:|---:|
| `demo_redgreen_2l` | 2 | 16 | 730 |
| `demo_redgreen_3l` | 3 | 24 | 730 |
| `demo_redgreen_4l` | 4 | 32 | 730 |

Run all three manually:

```bash
intersection-rl simulate --demo-scenario demo_redgreen_2l --episodes 1
intersection-rl simulate --demo-scenario demo_redgreen_3l --episodes 1
intersection-rl simulate --demo-scenario demo_redgreen_4l --episodes 1
```

Run the identical scenario without opening Pygame:

```bash
intersection-rl simulate \
  --demo-scenario demo_redgreen_3l \
  --episodes 1 \
  --render off
```

Change only the seed:

```bash
intersection-rl simulate \
  --demo-scenario demo_redgreen_3l \
  --seed 731 \
  --episodes 3
```

Use a custom lane/car count while retaining the policy-matched demo builder:

```bash
intersection-rl simulate \
  --demo-redgreen \
  --lanes 3 \
  --cars 18 \
  --seed 900 \
  --episode-seconds 60 \
  --all-red-seconds 3.5
```

Use a specific graph checkpoint:

```bash
intersection-rl simulate \
  --demo-scenario demo_redgreen_2l \
  --policy checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz
```

### Raw simulation mode

Without `--demo-redgreen` or `--demo-scenario`, the CLI constructs a raw
`IntersectionEnv`. This is useful for environment experiments but is not
automatically comparable to canonical graph evaluation.

A policy-aligned raw command is:

```bash
intersection-rl simulate \
  --lanes 3 \
  --cars 24 \
  --left-signal protected \
  --right-turns off \
  --right-on-red off \
  --yellow off \
  --safety-shield off \
  --all-red-seconds 3.5 \
  --random-start on \
  --policy checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz
```

Prefer the demo builder for filming and policy diagnosis because it also supplies
feasible randomized longitudinal positions and the shared task reset.

### Simulation output

At startup, the CLI prints:

- Resolved package path
- Geometry convention
- Checkpoint path and metadata
- Seed
- All-red duration
- Scenario name
- Lane/car count
- Spawn mode

At episode end, it prints:

- `completed_clean` and `failed`
- Red, yellow, collision, and proximity events
- Timeout and stuck-timeout counts
- Legal and dilemma clearer IDs
- True overshoot and stopped-short IDs
- `failure_records` keyed by vehicle ID
- Creep route/component diagnostics
- Safety-shield override count

Failure causes are reported as `red_crossing`, `collision`,
`stuck_timeout`, `moving_timeout`, or `rule_failure`. The recorded phase,
phase age, front-bumper distance to the stop line, and speed describe the state
immediately before failure.

## 6. Best Three Checkpoints To Test

### 1. Production polish checkpoint

```text
checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz
```

Use for normal sparse/dense protected red/green simulation and evaluation.

Metadata:

- Format: `graph_attention_torch_state_npz`
- Actor head: `separate_accel_steer_v1`
- Distribution: `squashed_mixture`
- Geometry: `front_bumper_v1`

### 2. Extreme-stress fallback and immutable backup

```text
checkpoints/protected_redgreen_generalized_v1_selected.npz
```

Use for comparison at 4 lanes/48 cars. It reaches 98.13% completion there under
accepted latch semantics, versus 96.46% for polish, with zero collision,
proximity, and stuck events, but has a higher red rate of 0.9 per episode.

This is an older unstamped checkpoint with a legacy Gaussian action
distribution. The current loader supports it, but the startup provenance warning
must not be ignored.

### 3. Three-component creep diagnostic

```text
results/protected_redgreen_creep_three_component_v1_75k/checkpoints/protected_redgreen_creep_three_component_v1_75k_prewarm.npz
```

Use only to inspect the dedicated learned creep behavior. It improves named demos
to 16/16, 22/24, and 31/32 and removes all creep-related stuck timeouts and
overshoots. It is not production-selected because stress completion falls to
95.83%, 96.81%, and 93.75%.

Metadata:

- Actor head: `separate_accel_steer_creep_v3`
- Components: brake, creep, go
- PPO after prewarm: none
- Runtime action override: none

Example comparison:

```bash
intersection-rl simulate \
  --demo-scenario demo_redgreen_2l \
  --policy results/protected_redgreen_creep_three_component_v1_75k/checkpoints/protected_redgreen_creep_three_component_v1_75k_prewarm.npz
```

Do not overwrite any of these files during experiments.

## 7. Evaluation Instructions

### 7.1 Authoritative graph evaluation

Use this for all three checkpoints listed above:

```bash
python scripts/train_graph_multitask.py evaluate \
  checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz \
  --output-csv results/manual_eval/polish_dense_3l24_seed730.csv \
  --episodes 20 \
  --lanes 3 \
  --cars 24 \
  --episode-seconds 60 \
  --all-red-seconds 3.5 \
  --eval-mode dense_redgreen \
  --max-cars 50 \
  --eval-workers 4 \
  --seed 730
```

Common evaluation modes:

| Mode | Purpose |
|---|---|
| `green` | Green movement and release |
| `left_green` | Protected left movement |
| `left_release` | Red-to-green protected-left release |
| `red` | Closed-signal stopping |
| `lead_red_stop` | Precise low-speed lead stop |
| `lead_red_approach` | Moving approach to a red line |
| `red_queue` | Queue formation under red |
| `dense_redgreen` | Canonical protected red/green cycling |
| `redgreen` | Sparse red/green cycling |
| `right_on_red` | Experimental right-on-red |
| `yellow` | Experimental yellow-stop states |
| `yellow_clear` | Experimental yellow-clear states |
| `mixed` | Broad mixed scenario |

The evaluator is deterministic: it uses the policy mean/argmax action. It writes
one aggregate CSV row and prints the same metrics plus checkpoint provenance.

### 7.2 Canonical nine-cell matrix

Current accepted comparison:

```bash
python scripts/run_dilemma_latch_rebaseline.py
```

This evaluates polish and old-selected with:

- Sparse: 2/8, 3/12, 4/16
- Dense: 2/16, 3/24, 4/32
- Stress: 2/24, 3/36, 4/48
- Sparse seeds: 730 and 731, 20 episodes each
- Dense seeds: 730, 731, and 732, 20 episodes each
- Stress seeds: 730 and 731, 10 episodes each
- 60 second horizon
- 3.5 second all-red
- `dense_redgreen` mode
- Four evaluation workers

Three-component candidate matrix:

```bash
python scripts/run_creep_three_component_promotion.py
```

Completed raw cells are skipped unless the wrapper supports and is invoked with
`--force`. The aggregate output is `summary_by_cell.csv` under the wrapper's
result directory.

### 7.3 Quick headless demo evaluation

The simulation command can be used as a deterministic, failure-rich demo check:

```bash
intersection-rl simulate \
  --demo-scenario demo_redgreen_4l \
  --episodes 5 \
  --render off \
  --policy checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz
```

This is not a substitute for the multi-seed canonical matrix.

### 7.4 Legacy evaluation

`intersection-rl evaluate` loads the legacy vector `SharedActorCritic`. Do not
use it for current graph-attention checkpoints.

It remains available for old vector checkpoints:

```bash
intersection-rl evaluate path/to/legacy_vector_checkpoint.npz \
  --episodes 20 \
  --lanes 2 \
  --cars 8 \
  --left-signal protected \
  --right-turns off \
  --right-on-red off \
  --yellow off \
  --safety-shield off
```

## 8. Training Instructions

### 8.1 Training safety rules

- Never write experimental output over a file in `checkpoints/`.
- Put each run in a new `results/<run_name>/` directory.
- Always provide an initialization checkpoint and reference checkpoint when a
  behavior stage requires anti-forgetting.
- Keep canonical validation and named demos as promotion gates.
- Do not select a checkpoint from training reward alone.
- Preserve the package/geometry/checkpoint provenance line with every log.
- Current yellow and right-on-red stages are experimental.
- The rejected three-component PPO consolidation must not be used as an
  initialization point.

### 8.2 Graph training smoke test

This checks the training pipeline without attempting a useful policy:

```bash
python scripts/train_graph_multitask.py train \
  --behavior-stage green \
  --checkpoint results/smoke_green/checkpoints/smoke_green.npz \
  --steps 4096 \
  --rollout-steps 256 \
  --rollout-workers 2 \
  --max-cars 18 \
  --validation-interval 0 \
  --seed 7
```

### 8.3 Reproduce the promoted polish training shape

Use a new output path:

```bash
python scripts/train_graph_multitask.py train \
  --behavior-stage front_bumper_polish \
  --init-checkpoint checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz \
  --reference-checkpoint checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz \
  --checkpoint results/my_polish_run/checkpoints/my_polish_run.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 4 \
  --validation-episodes 8 \
  --validation-interval 5 \
  --validation-patience 0 \
  --checkpoint-interval 5 \
  --max-cars 50 \
  --seed 814
```

The `front_bumper_polish` preset enables the squashed mixture actor, randomized
3.5-4.5 second training clearance, fixed 3.5 second validation clearance,
queue-aware action targets, creep relabeling, potential shaping, a separate gate
optimizer, gate prewarm/freeze, GO-component KL, and regime-gated validation.

### 8.4 Experimental creep prewarm only

The code defaults `red_creep_component` to stop after supervised prewarm:

```bash
python scripts/train_graph_multitask.py train \
  --behavior-stage red_creep_component \
  --init-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz \
  --reference-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz \
  --checkpoint results/my_creep_prewarm/checkpoints/my_creep_prewarm.npz \
  --steps 75000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 4 \
  --validation-episodes 8 \
  --validation-interval 5 \
  --checkpoint-interval 5 \
  --max-cars 50 \
  --stop-after-mixture-prewarm \
  --seed 928
```

Do not continue into PPO automatically. The accepted prewarm fixed demo creep,
but the subsequent 76.8k PPO consolidation weakened brake/hold behavior and
introduced dense proximity events while still failing stress gates.

### 8.5 Warm start and reference policy

- `--init-checkpoint` loads model weights before training.
- `--reference-checkpoint` loads a frozen policy used by KL losses.
- `--reference-kl-green-only` protects legal GO behavior while adding red
  behavior.
- `--go-component-reference-kl-coefficient` specifically anchors the GO
  mixture component.
- `--reference-kl-all-labels` broadens reference KL to all labeled samples.

A reference checkpoint is required by most focused behavior stages.

### 8.6 Important behavior stages

| Stage | Main use |
|---|---|
| `green` | Basic green movement |
| `protected_green` | Protected green/left foundation |
| `red` | Red-stop behavior |
| `lead_red_stop` | Precise low-speed stop placement |
| `lead_red_approach` | Braking from motion |
| `red_queue` | Queue formation |
| `redgreen_queue_2_per_lane` | Two-deep red/green queues |
| `dense_redgreen_queue` | Three-deep stress queues |
| `redgreen_density_shaping` | Density-weighted potential shaping |
| `front_bumper_polish` | Current promoted red/green training recipe |
| `red_creep_component` | Experimental brake/creep/go prewarm |
| `left_release` | Protected-left release |
| `right_on_red` | Experimental right-on-red |
| `signal` | Broad signal behavior |
| `conflict` | Conflict interaction training |

Run `python scripts/train_graph_multitask.py train --help` for every low-level
hyperparameter and task override.

### 8.7 Training outputs

A graph training run produces:

- `<checkpoint>.npz` final checkpoint
- `<checkpoint_stem>_best.npz` only when validation and hard gates pass
- Periodic `_update_XXXX.npz` checkpoints
- `<checkpoint_stem>_prewarm.npz` when mixture prewarm runs
- `<checkpoint_stem>_train_metrics.csv`
- Console metrics for reward, PPO/value losses, gradient norms, gate routing,
  component actions, KL, validation score, and hard-gate status

Do not treat the final checkpoint as best by default.

### 8.8 Legacy training

`intersection-rl train` uses the older vector observation and NumPy PPO
implementation. It is useful for compatibility experiments, not for reproducing
the current graph policies.

```bash
intersection-rl train \
  --steps 10000 \
  --checkpoint results/legacy_smoke.npz \
  --lanes 2 \
  --cars 8 \
  --yellow off \
  --right-turns off \
  --right-on-red off
```

## 9. Pipeline Flows

### 9.1 Training pipeline

```text
CLI arguments
  -> apply behavior-stage defaults
  -> runtime/package/checkpoint provenance checks
  -> build EnvConfig and weighted ScenarioTask set
  -> create MultiTaskIntersectionEnv rollout workers
  -> reset randomized task, signal, geometry, cars, and feasible speeds
  -> GraphObserver creates one ego-centric graph per active vehicle
  -> GraphActorCritic samples longitudinal and steering actions
  -> environment advances 0.2 seconds and records rewards/events/labels
  -> collect rollout tensors from all workers
  -> compute GAE returns and per-phase normalized advantages
  -> build phase-balanced PPO minibatches
  -> optimize PPO policy + value + entropy + configured auxiliary/KL losses
  -> optionally run separate mixture-gate optimizer
  -> update gradient, route, component, and safety diagnostics
  -> every validation interval, run deterministic validation scenarios
  -> apply all regime hard gates
  -> save _best only when every gate passes and score improves
  -> write periodic/final checkpoints and train_metrics.csv
```

### 9.2 Evaluation pipeline

```text
checkpoint + evaluation arguments
  -> launcher asserts local package and geometry convention
  -> read checkpoint format, actor head, distribution, and geometry metadata
  -> build fixed policy EnvConfig and requested evaluation scenario
  -> reset each seeded episode
  -> GraphObserver encodes active vehicles
  -> policy emits deterministic mean/argmax actions
  -> environment advances and accumulates completion/safety/queue metrics
  -> finish at all vehicles inactive or episode horizon
  -> aggregate episodes into one CSV row
  -> canonical wrappers aggregate seed rows into summary_by_cell.csv
  -> compare each cell with pre-registered promotion floors
```

### 9.3 Simulation pipeline

```text
simulate CLI
  -> choose named demo, custom demo, or raw environment
  -> resolve default or explicit checkpoint
  -> print provenance
  -> shared demo builder configures legal red/green phases and 3.5s all-red
  -> sample random front-bumper-safe positions, queue gaps, and feasible speeds
  -> reset the same environment for visual or headless mode
  -> GraphObserver encodes current state
  -> policy emits deterministic actions
  -> environment advances 0.2 seconds
  -> Pygame renders the same state when --render human
  -> event diagnostics classify legal clearers, overshoots, and stopped-short cars
  -> episode summary reports completed/failed counts and per-vehicle causes
```

## 10. Environment And Policy Semantics

### Geometry

- Stop-line distance is measured from the vehicle front bumper.
- Red/yellow crossing uses the front bumper.
- Stop and queue targets use front-bumper distance.
- Intersection exit and route completion use the rear bumper.
- Lead stop target is 0.1-1.0 m before the line.
- Follower target is a 2.5-3.0 m bumper gap, represented as a 7.0-7.5 m
  center/progress gap for 4.5 m vehicles.
- Geometry marker: `front_bumper_v1`.

### Signals

The validated phase sequence uses protected left and straight phases separated by
all-red. Yellow is disabled for the current production scope. A vehicle already
inside the intersection remains clearance eligible. At a phase transition, a
vehicle that cannot physically stop using 4.0 m/s^2 braking can receive one-shot
dilemma-zone clearance. Eligibility is latched from the transition state and is
never recomputed.

### Actions

Each active vehicle receives:

- Longitudinal action in [-1, 1]
- Steering action in [-1, 1]

The environment scales longitudinal action to acceleration/braking authority and
uses steering for lane centering/route following.

### Runtime policy purity

Canonical runs disable the safety filter and reservation system. Intent labels,
component-route labels, action targets, gate CE, and physics targets are used only
during training. They do not replace the policy action during evaluation or
simulation. Legal clearance latches define environment rules, not controller
actions.

## 11. Metrics And Promotion Gates

Primary metrics:

- Clean completion percentage
- Red/yellow violations per episode
- Collision and proximity events per episode
- Stuck and moving timeouts per episode
- Queue stop-position error
- Follower-gap error
- Lead, second, third-plus, and total discharge delay
- Gate weights/argmax/ambiguity by route class
- Component action means
- PPO/value/auxiliary gradient norms and clipping scale
- Reference and GO-component KL

Current nine-cell floors are encoded in
`GraphPPOTrainer._validation_regime_gates_pass` and documented in
`CHECKPOINT_REGISTRY.md`. A training checkpoint is not promoted merely because
reward or average validation score improved.

## 12. Troubleshooting

### Wrong package path

Symptom: results look like an old baseline or geometry changes appear absent.

Fix:

```bash
python -m pip install -e ".[dev]"
python -c "import intersection_rl; print(intersection_rl.__file__)"
```

The path must resolve inside this project. Use `python scripts/run_cli.py` or
`python scripts/train_graph_multitask.py` from the repository root.

### Pygame window does not open

Use `--render off` on a headless machine. On Linux, ensure the display session is
available before `--render human`.

### Graph policy max-car error

The checkpoint stores its graph observation dimensions. Use `--max-cars 50` for
current advanced evaluation and do not request more cars than the checkpoint
supports.

### Simulation differs from evaluation

Use a named demo and fixed checkpoint/seed. Confirm the provenance banner shows:

- Local generalized package
- `front_bumper_v1`
- Expected checkpoint
- 3.5 second all-red
- Expected scenario/seed

Raw simulation and canonical evaluation are intentionally different scenario
constructors.

### Cars fail at the horizon while moving

A moving timeout is not a stuck timeout. Rear-bumper completion requires the
whole vehicle to clear the route. Inspect `failure_records` and increase
`--episode-seconds` only for diagnosis; do not silently change the canonical
60 second protocol.

### Cars start far upstream and do not creep

This is a known production-policy coverage gap in randomized demos. Test the
three-component prewarm checkpoint to confirm the dedicated creep mechanism, but
do not treat it as production because it fails stress floors.

## 13. Reproducibility Checklist

Before reporting a number, record:

- Command
- Resolved package path
- Geometry convention
- Checkpoint path and metadata
- Scenario/eval mode
- Lane and car count
- Episode horizon
- All-red duration
- Seeds and episodes per seed
- Safety-shield/reservation status
- Result CSV path
- Whether the checkpoint passed every hard gate

Do not compare checkpoints evaluated with different geometry, clearance,
dilemma-latch, horizon, signal, or spawn semantics.

## 14. Next Planned Work

The next admissible red/green branch is prewarm-only third-plus/deep-queue route
coverage for the three-component model. PPO stays off until the prewarm passes
the named demos and all nine canonical cells. Before yellow PPO begins, legacy
brake/hold behavior must be protected from shared-trunk optimizer drift.

After that gate passes, yellow is the next feature. The intended yellow decision
is observable clear-versus-stop behavior based on the braking envelope, with the
existing clearance mechanism allowing vehicles that legally entered to finish.

For complete reasoning, experiment history, bugs, and architecture, read
`REPORT.md`.
