# Forced-GO Creep Probe Summary

Date: 2026-07-12
Status: ROUTE-ONLY CHANGE REJECTED; NO TRAINING STARTED

## Design

The promoted checkpoint was run in baseline and forced modes with identical seed
730 resets. Forced mode selected the existing GO longitudinal component only while
a creep state was latched and the physical stop envelope had not tripped. At
envelope trip, routing returned to the native brake component. Every affected
vehicle's speed, distance, component outputs, route state, and handoff were written
to the trajectory CSVs.

## Results

| Scenario | Mode | Completed | Red | Timeout | Stuck | Envelope trip distance | Trip speed | Max closed speed | Brake-to-GO returns |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| demo 2l/16 | baseline | 12 | 0 | 4 | 4 | - | - | 0.47 | 0 |
| demo 2l/16 | forced GO | 8 | 8 | 0 | 0 | 8.70m | 5.84m/s | 7.34m/s | 5 |
| demo 3l/24 | baseline | 19 | 1 | 4 | 3 | 1.97m | 0.00m/s | 0.50m/s | 0 |
| demo 3l/24 | forced GO | 8 | 16 | 0 | 0 | 4.19m | 5.07m/s | 6.97m/s | 0 |
| demo 4l/32 | baseline | 30 | 0 | 2 | 1 | - | - | 0.48m/s | 0 |
| demo 4l/32 | forced GO | 11 | 21 | 0 | 0 | 4.24m | 5.20m/s | 7.26m/s | 0 |
| canonical 2l/16 | baseline/forced | 16 | 0 | 0 | 0 | no intervention | | | 0 |
| canonical 4l/32 | baseline/forced | 32 | 0 | 0 | 0 | no intervention | | | 0 |

The route-only best case is rejected. It replaces stopped-short timeouts with red
crossings. GO accelerates the initially stationary cars to roughly 5-6m/s before the
envelope trips, and the existing brake component does not stop them from that
handoff state. One 2-lane vehicle also re-entered GO from braking five times,
confirming the possible sawtooth boundary failure. The dominant signature is
overshoot, not oscillation.

The canonical near-line controls had zero creep interventions and were byte-for-byte
behaviorally unchanged at the endpoint level. This confirms the proposed route mask
is scoped to the missing far-stationary state.

The first run's per-vehicle overshoot-list calculation included post-completion
positions and was invalid; that summary column was cleared rather than reported.
Aggregate red counts and all trajectory data are valid, and the probe code now uses
actual crossed_on_red state for future per-vehicle lists.

## Decision

A gate-only change is insufficient. Any GO-routing leg must moderate the GO
component before the handoff and explicitly supervise handoff states. Update-1
effective gradient remains mandatory. If moderation either pulls green GO below
+0.35 or still cannot produce a bounded closed-red speed profile with no red
crossings, escalate directly to a third brake/creep/go component instead of tuning
coefficients.
