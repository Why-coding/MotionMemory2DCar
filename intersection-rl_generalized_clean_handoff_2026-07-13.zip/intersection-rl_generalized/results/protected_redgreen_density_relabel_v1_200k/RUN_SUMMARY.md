# Protected Red/Green Density Relabel v1 200k

Date: 2026-07-10

## Status

BEHAVIORAL NON-KEEPER. Do not promote any checkpoint from this run to the top-level `checkpoints/` folder.

This run tested the localized label-routing fix for the previous density/potential branch:

- start from `results/protected_redgreen_mixture_prewarm_gokl_v1b_200k/checkpoints/protected_redgreen_mixture_prewarm_gokl_v1b_200k.npz`
- green reference: `checkpoints/protected_green_squashed_base_v1_250k_selected.npz`
- behavior stage: `redgreen_density_shaping`
- closed-red gate labels changed from distance-unconditioned `STOP` to braking-envelope-conditioned `STOP`
- far-upstream closed-red approach states are masked out of gate CE instead of supervised as `STOP` or `GO`
- stop-label latching added after entering the braking envelope, clearing on hold/green release
- stop-label target uses the same unified stop target as the potential: stop line for leads, front-vehicle safe gap for followers
- go-component reference KL is scoped to green-permitted go states
- potential red stop shaping, weighted 1/2/3-cars-per-inbound-lane curriculum, separate gate optimizer, gate CE floor, and go-component KL were retained
- no safety shield, no rule/action override, no yellow, no right-on-red

## Verification

Before launch:

- `../.venv/bin/python -m py_compile intersection_rl/config.py intersection_rl/env.py intersection_rl/graph_ppo.py scripts/train_graph_multitask.py`: passed
- targeted label tests: 4 passed
- `../.venv/bin/python -m pytest`: 74 passed, 1 warning
- `../.venv/bin/python scripts/reward_sanity.py`: normalized reward sanity remained stable; potential approach step about `+0.2`
- post-change replay sanity confirmed far-upstream closed-red states are no longer supervised as `STOP`: sparse 2-lane replay bucket `24-45m` produced `IGNORE` labels instead of uniform `STOP`

## Training Result

Completed 202,752 rollout steps / 66 updates.

Best validation checkpoint:

`results/protected_redgreen_density_relabel_v1_200k/checkpoints/protected_redgreen_density_relabel_v1_200k_best.npz`

Best validation occurred at update 35 with validation score `-97047.9965`. The final checkpoint did not improve on that.

Mechanism stayed healthy:

- prewarm reached the gate target in 1 step because the init gate was already aligned under the new labels
- gate unfroze at update 10 and held through the run
- final update 66: stop action `-0.592`, go action `+0.427`
- final update 66: brake weight on stop `0.997`, go weight on go `0.997`
- no mixture/gate regression was observed

Saved-best validation rows:

| Update | Validation Score | Stop Action | Go Action | W Stop | W Go | Red | Collisions | Proximity |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 5 | -132641.56 | -0.586 | +0.431 | 0.999 | 0.985 | 29 | 30 | 363 |
| 10 | -126510.55 | -0.611 | +0.473 | 1.000 | 0.994 | 17 | 3 | 5 |
| 15 | -109957.46 | -0.595 | +0.444 | 0.998 | 0.996 | 15 | 12 | 36 |
| 35 | -97048.00 | -0.610 | +0.437 | 0.999 | 0.997 | 30 | 15 | 22 |

Training CSV: `results/protected_redgreen_density_relabel_v1_200k/checkpoints/protected_redgreen_density_relabel_v1_200k_train_metrics.csv`

## Deterministic Eval: Dense Queue Mode

Protocol: `evaluate --eval-mode dense_redgreen`, 6 episodes each, seed 700.

| Lanes | Cars | Completion | Red/ep | Collisions/ep | Inside-collision vehicles/ep | Proximity/ep | Stuck TO/ep | Queue Error | Lead Error | 2nd Error | 3rd+ Error | Discharge Delay | Stop Action | Go Action |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 8 | 16.67% | 0.00 | 2.83 | 5.67 | 2.33 | 0.17 | 0.00 | 0.00 | 0.00 | 0.00 | 4.80s | -0.597 | +0.474 |
| 2 | 16 | 29.17% | 0.50 | 4.67 | 9.33 | 6.83 | 0.00 | 0.20 | 0.02 | 0.36 | 0.00 | 10.57s | -0.628 | +0.463 |
| 2 | 24 | 35.42% | 2.50 | 4.50 | 9.00 | 9.33 | 0.83 | 2.74 | 2.22 | 3.72 | 1.84 | 36.93s | -0.581 | +0.410 |
| 3 | 12 | 36.11% | 0.00 | 3.00 | 6.00 | 8.17 | 0.17 | 0.00 | 0.00 | 0.00 | 0.00 | 6.67s | -0.631 | +0.478 |
| 3 | 24 | 33.33% | 1.33 | 6.00 | 12.00 | 9.50 | 0.67 | 0.53 | 0.20 | 0.92 | 0.00 | 17.93s | -0.569 | +0.459 |
| 3 | 36 | 41.67% | 3.33 | 6.33 | 12.67 | 32.83 | 1.67 | 3.15 | 3.12 | 4.33 | 1.06 | 55.80s | -0.598 | +0.406 |
| 4 | 16 | 35.42% | 0.00 | 4.33 | 8.83 | 4.67 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 8.53s | -0.645 | +0.479 |
| 4 | 32 | 40.62% | 1.00 | 7.33 | 15.17 | 9.67 | 1.17 | 1.65 | 1.58 | 1.74 | 0.00 | 27.07s | -0.624 | +0.453 |
| 4 | 48 | 39.93% | 4.17 | 9.00 | 18.67 | 52.50 | 1.83 | 3.25 | 2.60 | 4.90 | 1.16 | 87.77s | -0.607 | +0.386 |

CSV: `results/protected_redgreen_density_relabel_v1_200k/evals/eval_best_dense_redgreen_summary.csv`

## Deterministic Eval: Original Sparse Redgreen Mode

Protocol: `evaluate --eval-mode redgreen`, 6 episodes each, seed 710.

| Lanes | Cars | Completion | Red/ep | Collisions/ep | Inside-collision vehicles/ep | Proximity/ep | Stuck TO/ep | Queue Error | Lead Error | 2nd Error | 3rd+ Error | Discharge Delay | Stop Action | Go Action |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 8 | 41.67% | 1.17 | 0.17 | 0.33 | 0.17 | 1.50 | 14.25 | 14.25 | 0.00 | 0.00 | 6.40s | -0.516 | +0.478 |
| 3 | 12 | 44.44% | 1.33 | 1.00 | 2.17 | 0.83 | 1.33 | 15.80 | 15.80 | 0.00 | 0.00 | 8.53s | -0.548 | +0.478 |
| 4 | 16 | 48.96% | 1.67 | 1.33 | 2.83 | 0.00 | 1.33 | 16.92 | 16.92 | 0.00 | 0.00 | 10.67s | -0.570 | +0.478 |

CSV: `results/protected_redgreen_density_relabel_v1_200k/evals/eval_best_redgreen_sparse_summary.csv`

## Diagnosis

The relabel/latch fix worked at the mechanism level, but the resulting policy is not usable for demos.

What improved:

- Far-upstream closed-red states are no longer supervised as `STOP` by the gate CE.
- Red compliance is strong in low-density dense-redgreen evals: 0.00 red violations per episode on 2/3/4 lanes at 1 car per inbound lane.
- The two-mode mechanism held: stop labels route to the brake component and go labels route to the go component with near-saturated weights.

What failed:

- Completion remained very low: 16.67% to 41.67% across the dense matrix, and only 41.67% to 48.96% in original sparse redgreen eval.
- Collision failures are now primarily inside the intersection, not before the stop line. In dense mode, inside-collision vehicles ranged from 5.67 to 18.67 per episode.
- Original sparse redgreen still shows very large lead stop placement errors: 14.25m / 15.80m / 16.92m on 2/3/4 lanes.
- Dense follower behavior degrades with traffic: at 3 cars per inbound lane, follower/second/third-plus release delays grow sharply, and queue stop/gap errors rise.

This means the next blocker is not the mixture head, gate optimizer, or basic red braking expression. The policy now needs release/conflict behavior and stop-placement shaping that does not destroy completion. A blind 1M-step continuation of this exact setup is not justified because the deterministic eval failure is structural, not merely undertrained.

## Next Step

Do not promote this checkpoint and do not overwrite the top-level demo checkpoints.

Recommended next iteration:

1. Add route-specific diagnostics for stuck/incomplete vehicles and release delay: protected-left versus straight, plus queue position 1st/2nd/3rd+.
2. Inspect deterministic replays for whether inside-intersection collisions happen between protected-left movements and opposing/straight movements, or from same-lane discharge bunching.
3. Fix the release/conflict branch before training longer. Candidate fixes are dense next-release task weighting, stronger green conflict/TTC representation use, or a training-only auxiliary signal for green release/yield intent if diagnostics show label/intent mismatch.
4. Only after release/conflict metrics improve should the run be extended beyond 200k. A 1M run is appropriate only when mid-run deterministic completion, collision location, and release-delay trends are improving.

## Artifact Map

- Run summary: `results/protected_redgreen_density_relabel_v1_200k/RUN_SUMMARY.md`
- Best checkpoint: `results/protected_redgreen_density_relabel_v1_200k/checkpoints/protected_redgreen_density_relabel_v1_200k_best.npz`
- Final checkpoint: `results/protected_redgreen_density_relabel_v1_200k/checkpoints/protected_redgreen_density_relabel_v1_200k.npz`
- Training metrics: `results/protected_redgreen_density_relabel_v1_200k/checkpoints/protected_redgreen_density_relabel_v1_200k_train_metrics.csv`
- Dense eval summary: `results/protected_redgreen_density_relabel_v1_200k/evals/eval_best_dense_redgreen_summary.csv`
- Sparse eval summary: `results/protected_redgreen_density_relabel_v1_200k/evals/eval_best_redgreen_sparse_summary.csv`

## Clearance Sweep Addendum - 2026-07-10

All-red clearance and clearance-eligible semantics were implemented and evaluated after this run. See `clearance_sweep/SWEEP_SUMMARY.md` and `clearance_sweep/summary.csv` for the consolidated tables. The sweep shows that corrected clearance semantics plus 3.5-4.5s all-red removes most inside-intersection collisions; remaining work is proportional braking, creep/re-approach relabeling, and dense queue/discharge behavior.
