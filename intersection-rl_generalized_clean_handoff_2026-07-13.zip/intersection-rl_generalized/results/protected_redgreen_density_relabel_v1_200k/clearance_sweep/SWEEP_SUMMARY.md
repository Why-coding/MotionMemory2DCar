# Clearance Sweep Summary

Date: 2026-07-10

Checkpoint evaluated: `results/protected_redgreen_density_relabel_v1_200k/checkpoints/protected_redgreen_density_relabel_v1_200k_best.npz`

Artifacts:
- Raw eval CSVs: `results/protected_redgreen_density_relabel_v1_200k/clearance_sweep/eval*.csv`
- Consolidated CSV: `results/protected_redgreen_density_relabel_v1_200k/clearance_sweep/summary.csv`

## Implementation Tested

This sweep tests the new all-red clearance model and clearance-eligible semantics:

- `signal_all_red_seconds` was added to the environment config and CLI eval/train path.
- Protected-left sequencing now inserts all-red after every movement phase: left, through, opposite left, opposite through.
- A vehicle that was already past its stop line at the phase transition is latched as clearance-eligible until it exits, completes, fails, or times out.
- Clearance-eligible vehicles still receive `movement_permitted=True`; vehicles before the stop line during all-red remain closed and crossing after the switch is a violation.
- Collision diagnostics now record whether inside-intersection collision pairs involved clearance-eligible vehicles and whether they happened soon after phase changes.
- Multitask release-time sampling treats all-red as part of the before-next-green window.

## Verification

- `../.venv/bin/python -m py_compile intersection_rl/config.py intersection_rl/env.py intersection_rl/multitask.py scripts/train_graph_multitask.py tests/test_env.py` passed before the sweep.
- `../.venv/bin/python -m pytest tests/test_env.py -k "all_red or clearance or protected_left_phase"` passed: 6 passed, 46 deselected.
- `../.venv/bin/python -m pytest` passed: 78 passed, 1 warning.

## Seed 700 Stress Sweep

| seed | lanes/cars | all-red | complete % | complete/100 green-s | coll/ep | inside veh/ep | inside CE pairs/ep | inside non-CE pairs/ep | prox/ep | red/ep | stuck/ep | queue err m | discharge delay s/ep |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 700 | 3 / 36 | 0.0 | 77.31 | 46.39 | 1.33 | 2.67 | 1.33 | 0.00 | 24.83 | 3.00 | 0.17 | 3.22 | 54.37 |
| 700 | 3 / 36 | 2.0 | 81.02 | 60.05 | 0.17 | 0.33 | 0.17 | 0.00 | 0.00 | 3.50 | 1.67 | 1.99 | 57.20 |
| 700 | 3 / 36 | 3.5 | 80.09 | 67.84 | 0.17 | 0.33 | 0.17 | 0.00 | 0.17 | 1.50 | 2.67 | 2.05 | 55.33 |
| 700 | 3 / 36 | 4.5 | 78.24 | 71.80 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 1.17 | 3.67 | 1.63 | 55.53 |
| 700 | 4 / 48 | 0.0 | 73.61 | 58.89 | 2.50 | 5.17 | 2.67 | 0.00 | 26.67 | 5.33 | 0.17 | 3.05 | 78.70 |
| 700 | 4 / 48 | 2.0 | 80.56 | 79.61 | 0.50 | 1.00 | 0.50 | 0.00 | 25.33 | 3.67 | 2.67 | 2.28 | 95.53 |
| 700 | 4 / 48 | 3.5 | 80.56 | 90.98 | 0.17 | 0.33 | 0.17 | 0.00 | 30.17 | 3.00 | 3.00 | 2.09 | 96.37 |
| 700 | 4 / 48 | 4.5 | 78.82 | 96.44 | 0.17 | 0.33 | 0.17 | 0.00 | 33.17 | 2.50 | 4.67 | 1.66 | 99.93 |

## Seed 720 Sweep

| seed | lanes/cars | all-red | complete % | complete/100 green-s | coll/ep | inside veh/ep | inside CE pairs/ep | inside non-CE pairs/ep | prox/ep | red/ep | stuck/ep | queue err m | discharge delay s/ep |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 720 | 2 / 8 | 0.0 | 100.00 | 13.33 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 4.80 |
| 720 | 2 / 8 | 2.0 | 100.00 | 16.47 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 5.07 |
| 720 | 2 / 8 | 3.5 | 100.00 | 18.82 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 5.07 |
| 720 | 2 / 8 | 4.5 | 100.00 | 20.39 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 5.07 |
| 720 | 3 / 36 | 0.0 | 82.87 | 49.72 | 0.83 | 1.67 | 0.83 | 0.00 | 18.33 | 2.67 | 0.00 | 2.39 | 50.07 |
| 720 | 3 / 36 | 2.0 | 81.94 | 60.74 | 0.33 | 0.67 | 0.33 | 0.00 | 0.33 | 2.83 | 1.33 | 1.72 | 48.13 |
| 720 | 3 / 36 | 3.5 | 82.87 | 70.20 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 2.00 | 2.50 | 1.95 | 45.47 |
| 720 | 3 / 36 | 4.5 | 80.09 | 73.50 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 1.50 | 3.00 | 1.78 | 44.90 |
| 720 | 4 / 48 | 0.0 | 80.21 | 64.17 | 2.17 | 3.67 | 1.83 | 0.00 | 47.33 | 2.83 | 0.33 | 2.13 | 76.50 |
| 720 | 4 / 48 | 2.0 | 81.25 | 80.29 | 1.33 | 2.33 | 1.17 | 0.00 | 34.17 | 2.67 | 1.67 | 1.71 | 80.17 |
| 720 | 4 / 48 | 3.5 | 81.94 | 92.55 | 0.67 | 1.17 | 0.67 | 0.00 | 37.83 | 1.67 | 3.00 | 1.67 | 78.27 |
| 720 | 4 / 48 | 4.5 | 80.56 | 98.56 | 0.50 | 0.67 | 0.33 | 0.00 | 2.17 | 2.00 | 4.00 | 1.62 | 76.03 |

## Analysis

- The largest result is the corrected observation semantics, not the all-red duration. The previous seed-700 4-lane/48-car eval had roughly 9.0 collisions/ep, 18.67 inside-collision vehicles/ep, and 39.93% completion. With corrected clearance eligibility and still 0.0s all-red, the same stress cell is 2.50 collisions/ep, 5.17 inside-collision vehicles/ep, and 73.61% completion. That isolates the legal-clearer freeze bug: vehicles that had legally entered before a phase change were seeing a closed signal, routing to the brake component, and stopping inside the intersection.
- The all-red interval is the second, separate effect. In seed 700, 3-lane/36-car collisions fall from 1.33/ep at 0.0s to 0.00/ep at 4.5s. In 4-lane/48-car, collisions fall from 2.50/ep at 0.0s to 0.17/ep at 3.5s and 0.17/ep at 4.5s. In other words: corrected legal-clearer semantics removes most of the failure, and all-red timing removes most of the remaining phase-transition gap.
- Residual inside collisions in the stress cells are still almost entirely clearance-related: `inside_collision_pairs_without_clearance_eligible_per_ep` is 0.0 across the seed-700 stress sweep. This points away from random cross-traffic policy failure and toward late clearers, dense discharge timing, or insufficient clearance for the hardest protected-left/dense cases.
- Proximity improves strongly with clearance in seed 720 4-lane/48-car: 47.33/ep at 0.0s, 37.83/ep at 3.5s, and 2.17/ep at 4.5s.
- Longer all-red consumes green time. The raw completion dip at 4.5s should be read alongside `completed_per_100_green_seconds`; this is why the summary keeps both columns.
- The remaining non-architecture problems are still visible: red violations, stop placement, queue freezing/discharge delay, and residual dense 4-lane clearance/proximity. The mixture gate and go-component retention are not the current blocker.

## Recommendation

Use the corrected clearance semantics going forward. For the next training leg, start with `--all-red-seconds 3.5` as the default because it removes most clearance collisions with less throughput loss than 4.5s. Keep 4.5s as the immediate alternative if protected-left residual collisions persist after training with clearance.

Do not run a blind 1M-step job on the current behavior. The next run should be a 200k diagnostic leg with:

- all-red clearance enabled,
- proportional brake-component action target against the unified queue target,
- creep/re-approach relabel for vehicles stopped too far upstream,
- the same mixture/gate optimizer setup that already held,
- dense and sparse evals with these clearance diagnostics kept in selection.
