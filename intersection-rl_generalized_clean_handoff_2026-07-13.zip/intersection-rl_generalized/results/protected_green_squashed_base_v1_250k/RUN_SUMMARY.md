# protected_green_squashed_base_v1_250k

Purpose: green-first protected-left base trained from scratch with the squashed Gaussian continuous actor and acceleration shortcut.

Training command:
```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage protected_green \
  --checkpoint checkpoints/protected_green_squashed_base_v1_250k.npz \
  --steps 250000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 4 \
  --checkpoint-interval 10 \
  --max-cars 50 \
  --learning-rate 1e-4 \
  --target-kl 0.01 \
  --entropy-coefficient 0.0015 \
  --reward-clip 320 \
  --action-distribution squashed_gaussian
```

Selected checkpoint copied to:
`checkpoints/protected_green_squashed_base_v1_250k_selected.npz`

Archived training artifacts in this folder:
- `protected_green_squashed_base_v1_250k_best.npz`
- `protected_green_squashed_base_v1_250k.npz`
- `protected_green_squashed_base_v1_250k_train_metrics.csv`
- periodic update checkpoints
- deterministic eval CSVs

Deterministic eval summary, 12 episodes each, 2 cars per lane:

| mode | lanes/cars | completed | collisions | proximity | red/closed | timeouts | action_go_mean | std_go_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| left_green | 2/4 | 100.0% | 0.0/ep | 0.0/ep | 0.0/ep | 0.0/ep | 0.486 | 0.351 |
| left_green | 3/6 | 100.0% | 0.0/ep | 0.0/ep | 0.0/ep | 0.0/ep | 0.480 | 0.353 |
| left_green | 4/8 | 100.0% | 0.0/ep | 0.0/ep | 0.0/ep | 0.0/ep | 0.468 | 0.357 |
| green | 2/4 | 100.0% | 0.0/ep | 0.0/ep | 0.0/ep | 0.0/ep | 0.485 | 0.351 |
| green | 3/6 | 100.0% | 0.0/ep | 0.0/ep | 0.0/ep | 0.0/ep | 0.486 | 0.351 |
| green | 4/8 | 100.0% | 0.0/ep | 0.0/ep | 0.0/ep | 0.0/ep | 0.486 | 0.351 |

Notes:
- Runtime remains pure policy output. No safety shield or action override was used.
- Yellow and right-on-red remain excluded in this training/eval path.
- Use this checkpoint as the green init/reference for the next protected red/green fine-tune.
