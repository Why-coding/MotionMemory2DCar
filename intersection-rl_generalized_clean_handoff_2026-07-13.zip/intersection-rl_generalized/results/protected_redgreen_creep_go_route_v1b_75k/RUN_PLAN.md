# Moderated Creep-to-GO Route v1b 75k Run Plan

Date: 2026-07-12
Status: PRE-REGISTERED BEFORE RELAUNCH

All v1 labels, targets, model/reference, seed, task weights, losses, clearance, and
hard gates remain unchanged. Sole change: mixture gate prewarm cap 20 -> 3000, with
early exit on the already-defined saturation thresholds. PPO must not begin unless
prewarm reports reached=1.

    ../.venv/bin/python scripts/train_graph_multitask.py train       --behavior-stage red_creep_component       --init-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz       --reference-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz       --checkpoint results/protected_redgreen_creep_go_route_v1b_75k/checkpoints/protected_redgreen_creep_go_route_v1b_75k.npz       --steps 75000 --rollout-steps 256 --rollout-workers 12       --validation-workers 4 --validation-episodes 8 --validation-interval 25       --validation-patience 0 --checkpoint-interval 5 --max-cars 50 --seed 928
