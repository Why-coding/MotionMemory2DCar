# Moderated Creep-to-GO Route v1b Summary

Date: 2026-07-12
Status: STOPPED AFTER UPDATE 1; THIRD-COMPONENT ESCALATION TRIGGERED

The 3000-step gate prewarm did not meet the pre-committed thresholds:

- brake/go route weights: 0.837 / 0.839
- brake/go argmax: 0.905 / 0.898
- ambiguity: 0.088 / 0.090
- reached: 0

The plateau is a representational conflict in the two-way gate under independent
creep routing, not missing labels or gradient starvation. Proceeding anyway produced
route accuracy 0.799, 119 rollout red events, KL 0.020, and gate ambiguity 0.160.

Component outputs themselves were viable: routed creep +0.309 toward +0.385, green
GO +0.457, and ordinary brake -0.143. Lowering route thresholds or continuing CE
would violate the pre-committed no-coefficient-search rule. No checkpoint is
promoted.

Decision: implement the pre-named three-component brake/creep/go mixture with a
three-way gate. Preserve the promoted two-component checkpoint through explicit
2-to-3 migration: brake -> brake, GO -> GO, initialize creep separately, and prewarm
the new gate before PPO.
