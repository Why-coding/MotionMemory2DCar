# Moderated Creep-to-GO Route v1 75k Run Plan

Date: 2026-07-12
Status: PRE-REGISTERED BEFORE TRAINING

## Controlled Design

- Init/reference: promoted front-bumper polish v1b.
- Runtime intent remains STOP for closed-red creep.
- Independent binary component route:
  - far, latched creep before physical envelope trip -> GO component
  - envelope trip, ordinary braking, and HOLD -> brake component
  - permitted movement -> GO component
- GO creep target uses the distance-conditioned profile capped at 1.5m/s.
- Stationary far-red drills remain 18% total.
- Huber beta 20, value coefficient 0.1, action auxiliary 0.05.
- Green GO reference KL remains 1.0.
- Random 3.5-4.5s training clearance; fixed 3.5s validation.

## Update-1 Acceptance

Creep route samples must be present. Raw and effective creep action gradients must be
nonzero, gate CE must include the new binary route labels, and the routed component
mean/target must be reported. Stop immediately if the new loss is again crushed by
global clipping.

## Hard Gates

- Accepted-latch canonical sparse/dense table remains the no-regression floor.
- Named demos must have zero red, collision, proximity, and stopped-short timeout.
- Affected trajectories must stay near the 1.5m/s creep cap, hand off once to brake,
  settle in the bumper stop window, and release on green.
- Green GO must remain >= +0.35 after update 10.

## Pre-committed Escalation

Escalate directly to a third brake/creep/go component, with no coefficient search,
if any of these occur:

1. Green GO remains below +0.35 for two consecutive updates after update 10.
2. Moderated creep still converges to cruise-like speed or crosses red.
3. Creep remains non-positive despite a healthy effective gradient.
4. A canonical gate fails and GO-mean/reference-KL diagnostics attribute the failure
   to creep supervision pressure rather than seed noise or a label bug.

## Launch

    ../.venv/bin/python scripts/train_graph_multitask.py train       --behavior-stage red_creep_component       --init-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz       --reference-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz       --checkpoint results/protected_redgreen_creep_go_route_v1_75k/checkpoints/protected_redgreen_creep_go_route_v1_75k.npz       --steps 75000 --rollout-steps 256 --rollout-workers 12       --validation-workers 4 --validation-episodes 8 --validation-interval 25       --validation-patience 0 --checkpoint-interval 5 --max-cars 50 --seed 928
