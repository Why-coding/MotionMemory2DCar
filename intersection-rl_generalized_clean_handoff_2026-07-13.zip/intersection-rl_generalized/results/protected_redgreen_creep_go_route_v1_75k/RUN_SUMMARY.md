# Moderated Creep-to-GO Route v1 Summary

Date: 2026-07-12
Status: STOPPED AFTER UPDATE 1; NOT PROMOTED

Independent route labels and action supervision worked: update 1 contained 131 creep
samples, routed GO mean was +0.423 against a +0.544 target, green GO remained +0.459,
and ordinary moving brake was -0.249. The action mechanism therefore started close
to the moderated target without green erosion.

The 20-step gate prewarm was insufficient to overturn the established brake route:
GO-route argmax/weight remained about 0.34 and route gate accuracy was 0.679. The run
was stopped before further PPO. This is a saturated-gate initialization budget issue,
not a policy/third-component trigger.

v1b changes only the prewarm cap from 20 to 3000 steps. Prewarm exits early as soon
as the existing 0.85 weight, 0.95 argmax, and ambiguity thresholds are met.
