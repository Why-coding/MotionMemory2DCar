# Protected Red/Green Mixture Prewarm Go-KL v1b 200k

Date: 2026-07-08

## Status

MECHANISM SUCCESS, BEHAVIORAL NON-KEEPER. Do not promote any checkpoint from this run to the top-level `checkpoints/` folder.

This run answered the architecture question that previous probes could not: a prewarmed 2-mode continuous mixture policy can hold separate stop and go behavior through PPO, including after PPO is allowed to update the gate. However, the learned behavior is not demo-grade because dense red/green completion and discharge are poor.

## Implementation Tested

- Supervised gate prewarm before PPO.
- Gate unfreeze based on routing stability, not soft stop weight alone:
  - stop-label brake argmax `>= 0.98`
  - go-label go argmax `>= 0.98`
  - stop/go ambiguous share `<= 0.05`
  - sustained for 10 updates.
- Gate CE decay scheduled relative to the actual unfreeze event.
- Gate CE retained a floor rather than dropping to zero.
- Separate gate optimizer retained.
- Go-component reference KL added on go-labeled states.
- Huber value loss retained.

## Verification

- `../.venv/bin/python -m py_compile intersection_rl/graph_ppo.py intersection_rl/config.py scripts/train_graph_multitask.py`: passed.
- `../.venv/bin/python -m pytest tests/test_ppo.py -q`: 8 passed.
- `../.venv/bin/python -m pytest -q`: 69 passed, 1 warning.

## Prewarm

Prewarm-only checkpoint:

`results/protected_redgreen_mixture_prewarm_gokl_v1_200k/prewarm/protected_redgreen_mixture_prewarm_gokl_v1_prewarm_only.npz`

The supervised gate prewarm reached the robustness target at step 750:

| Metric | Value |
|---|---:|
| Brake weight on stop labels | 0.880 |
| Go weight on go labels | 0.855 |
| Stop argmax share | 1.000 |
| Go argmax share | 1.000 |
| Ambiguous stop share | 0.000 |
| Ambiguous go share | 0.000 |

Pre-PPO sanity checks:

| Eval | Result |
|---|---|
| `left_green`, 2 lanes / 8 cars / 8 episodes | 100% completion, 0 red, 0 collision/proximity/stuck |
| `red_queue`, 2 lanes / 16 cars / 6 episodes | stop action mean `-0.449`; behavior bad as expected before PPO, with 0% completion |

Dense `left_green` at 2 lanes / 16 cars did not fit the current left-green eval spawn geometry, which reported maximum 10 cars. Dense `redgreen` at 16/24/32 cars fits.

## Branch v1, Go-KL 0.2

Run:

`results/protected_redgreen_mixture_prewarm_gokl_v1_200k/checkpoints/`

This branch was interrupted at update 19 because the precommitted go-protection trigger fired. The go-label action mean fell below `+0.35` several times despite go-component KL being active:

| Update | Go Action Mean | Stop Action Mean | Brake Weight on Stop | Go Weight on Go | Go KL | Red Count |
|---:|---:|---:|---:|---:|---:|---:|
| 15 | +0.372 | -0.491 | 0.964 | 0.939 | 0.219 | 7 |
| 16 | +0.179 | -0.493 | 0.902 | 0.921 | 0.592 | 6 |
| 18 | +0.286 | -0.509 | 0.946 | 0.918 | 0.218 | 20 |
| 19 | +0.319 | -0.529 | 0.929 | 0.961 | 0.194 | 1 |

Decision: relaunch from the same prewarmed checkpoint with stronger go-component KL.

## Branch v1b, Go-KL 1.0

Run:

`results/protected_redgreen_mixture_prewarm_gokl_v1b_200k/checkpoints/`

Key command settings:

- init: prewarmed mixture checkpoint above
- reference: `checkpoints/protected_green_squashed_base_v1_250k_selected.npz`
- behavior stage: `redgreen`
- action distribution: `squashed_mixture`
- steps target: 200000, completed 202752 rollout steps / 66 updates
- rollout workers: 12
- validation workers: 4
- validation scenarios: `2:4:60 3:6:60 4:8:60 2:16:60 3:24:60 4:32:60`
- gate CE: `0.8`, decay after unfreeze + 20 updates, floor `0.05`
- go-component reference KL coefficient: `1.0`
- Huber value beta: `20`
- value coefficient: `0.1`

## Mechanism Result

The gate unfroze at update 36 and held for 30 further updates. The post-unfreeze retention test passed.

| Update | Gate Frozen | Since Unfreeze | Stop Action | Go Action | Brake Weight Stop | Go Weight Go | Gate CE Weight | Rollout Red |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 25 | 1 | 0 | -0.540 | +0.476 | 0.997 | 0.999 | 0.800 | 23 |
| 36 | 0 | 0 | -0.529 | +0.469 | 0.984 | 0.999 | 0.800 | 5 |
| 45 | 0 | 9 | -0.612 | +0.472 | 0.998 | 1.000 | 0.800 | 8 |
| 56 | 0 | 20 | -0.597 | +0.468 | 0.987 | 0.999 | 0.800 | 8 |
| 60 | 0 | 24 | -0.574 | +0.475 | 0.995 | 1.000 | 0.700 | 8 |
| 66 | 0 | 30 | -0.550 | +0.489 | 0.985 | 0.998 | 0.550 | 3 |

Interpretation:

- The mixture gate can be installed and retained.
- PPO did not erase the gate after unfreeze.
- Stronger go-component KL prevented sustained go erosion.
- The old action-head/gate mechanism is no longer the main blocker.

## Dense Eval

Protocol: deterministic `redgreen`, 6 episodes each, same seeds for old and new, dense 2 cars per inbound lane.

### New Final Checkpoint

`results/protected_redgreen_mixture_prewarm_gokl_v1b_200k/checkpoints/protected_redgreen_mixture_prewarm_gokl_v1b_200k.npz`

| Lanes | Cars | Completion | Red/ep | Collisions/ep | Proximity/ep | Stuck TO/ep | Stop Action | Go Action | Queue Delay/ep |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 16 | 41.67% | 2.67 | 1.33 | 1.00 | 2.00 | -0.550 | +0.455 | 22.43s |
| 3 | 24 | 52.78% | 3.17 | 1.33 | 1.17 | 2.83 | -0.550 | +0.439 | 36.13s |
| 4 | 32 | 53.13% | 3.33 | 2.83 | 4.17 | 2.17 | -0.551 | +0.438 | 45.63s |

### New Local Best Checkpoint

`results/protected_redgreen_mixture_prewarm_gokl_v1b_200k/checkpoints/protected_redgreen_mixture_prewarm_gokl_v1b_200k_best.npz`

| Lanes | Cars | Completion | Red/ep | Collisions/ep | Proximity/ep | Stuck TO/ep | Stop Action | Go Action | Queue Delay/ep |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 16 | 45.83% | 3.00 | 1.17 | 1.17 | 1.17 | -0.541 | +0.384 | 26.60s |
| 3 | 24 | 59.72% | 3.17 | 0.67 | 2.50 | 2.17 | -0.541 | +0.402 | 35.07s |
| 4 | 32 | 65.10% | 4.33 | 1.17 | 4.17 | 1.67 | -0.541 | +0.405 | 43.47s |

### Old Selected Checkpoint

`checkpoints/protected_redgreen_generalized_v1_selected.npz`

| Lanes | Cars | Completion | Red/ep | Collisions/ep | Proximity/ep | Stuck TO/ep | Stop Action | Go Action | Queue Delay/ep |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 16 | 65.63% | 5.50 | 0.00 | 0.00 | 0.00 | -0.044 | +0.661 | 6.30s |
| 3 | 24 | 68.75% | 6.83 | 0.33 | 30.00 | 0.00 | -0.054 | +0.663 | 10.33s |
| 4 | 32 | 78.65% | 6.83 | 0.00 | 34.33 | 0.00 | -0.064 | +0.663 | 15.17s |

## Diagnosis

The new policy is not a keeper. It improves the learned stop/go action separation and lowers red violations relative to the old selected checkpoint on dense eval, but it sacrifices too much completion and discharge quality.

Failure mode:

- The policy now brakes decisively on stop labels.
- It often stops too far upstream or holds too long.
- Queue discharge delay is very large.
- Dense completion is worse than the old selected checkpoint.
- Collisions/proximity/stuck timeouts regress versus the old selected checkpoint.

This is the timing/queue-placement/release branch, not an action-distribution branch.

## Next Step

Do not promote any checkpoint from this run.

The next run should keep the working mixture/gate setup and target timing/placement:

1. Add unified stop-point potential toward `min(stop_line - margin, lead_rear - safe_gap)`.
2. Penalize stopping too far upstream more directly while preserving red crossing penalties.
3. Add release/discharge shaping after green so stopped queues restart promptly.
4. Keep go-component KL protection active.
5. Keep gate CE floor active.
6. Select checkpoints with dense completion, red violations, stuck timeouts, queue placement, and discharge delay together.
