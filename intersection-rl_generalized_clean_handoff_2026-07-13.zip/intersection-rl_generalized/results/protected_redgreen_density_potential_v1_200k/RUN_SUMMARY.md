# Protected Red/Green Density Potential v1 200k

Date: 2026-07-09

## Status

BEHAVIORAL NON-KEEPER. Do not promote any checkpoint from this run to the top-level `checkpoints/` folder.

This run kept the verified two-mode continuous mixture mechanism frozen and tested the timing/queue-placement branch:

- start from `results/protected_redgreen_mixture_prewarm_gokl_v1b_200k/checkpoints/protected_redgreen_mixture_prewarm_gokl_v1b_200k.npz`
- green reference: `checkpoints/protected_green_squashed_base_v1_250k_selected.npz`
- behavior stage: `redgreen_density_shaping`
- potential red stop shaping enabled with coefficient `0.45`, gamma `0.99`
- weighted density task mix over 2/3/4 lanes and 1/2/3 cars per inbound lane
- no safety shield, no rule/action override, no yellow, no right-on-red
- mixture gate CE, separate gate optimizer, go-component KL, and Huber value loss retained

## Verification

Before launch:

- `../.venv/bin/python -m py_compile intersection_rl/config.py intersection_rl/env.py intersection_rl/graph_ppo.py scripts/train_graph_multitask.py scripts/reward_sanity.py tests/test_env.py`: passed
- targeted potential reward tests: 3 passed
- `../.venv/bin/python scripts/reward_sanity.py`: potential approach step about `+0.2`, far hold telescoping term about `+0.1`, target hold about `+0.6`
- `../.venv/bin/python -m pytest`: 70 passed, 1 warning

## Training Result

Completed 202,752 rollout steps / 66 updates.

Best validation checkpoint:

`results/protected_redgreen_density_potential_v1_200k/checkpoints/protected_redgreen_density_potential_v1_200k_best.npz`

Best validation occurred at update 60 with validation score `-102156.08`. The final checkpoint did not improve on that.

Mechanism stayed healthy through the run:

- gate unfroze at update 10 and remained stable
- final update 66: stop action `-0.658`, go action `+0.465`
- final update 66: brake weight on stop `0.999`, go weight on go `0.997`
- no gate regression observed despite CE decay to `0.125` by update 66

## Deterministic Eval: Dense Queue Mode

Protocol: `evaluate --eval-mode dense_redgreen`, 6 episodes each, seed 700.

| Lanes | Cars | Completion | Red/ep | Collisions/ep | Proximity/ep | Stuck TO/ep | Queue Error | Queue Delay/ep | Stop Action | Go Action |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 8 | 16.67% | 0.00 | 2.83 | 2.17 | 0.17 | 0.00 | 4.80s | -0.643 | +0.486 |
| 3 | 12 | 37.50% | 0.00 | 3.00 | 3.00 | 0.17 | 0.00 | 6.67s | -0.642 | +0.488 |
| 4 | 16 | 35.42% | 0.00 | 4.33 | 3.67 | 0.00 | 0.00 | 8.53s | -0.652 | +0.488 |
| 2 | 16 | 33.33% | 0.50 | 4.17 | 14.33 | 0.00 | 0.19 | 11.00s | -0.619 | +0.473 |
| 3 | 24 | 35.42% | 0.67 | 5.83 | 18.00 | 1.00 | 1.21 | 20.37s | -0.608 | +0.461 |
| 4 | 32 | 40.10% | 1.00 | 7.67 | 22.00 | 1.00 | 1.50 | 27.17s | -0.618 | +0.455 |
| 2 | 24 | 33.33% | 2.67 | 4.17 | 10.83 | 1.33 | 3.02 | 41.03s | -0.632 | +0.405 |
| 3 | 36 | 37.50% | 3.33 | 7.00 | 51.17 | 1.83 | 3.00 | 64.30s | -0.636 | +0.394 |
| 4 | 48 | 30.90% | 4.83 | 10.67 | 85.00 | 2.50 | 4.63 | 124.33s | -0.642 | +0.352 |

CSV: `results/protected_redgreen_density_potential_v1_200k/evals/eval_best_dense_redgreen_summary.csv`

## Deterministic Eval: Original Sparse Redgreen Mode

Protocol: `evaluate --eval-mode redgreen`, 6 episodes each, seed 710.

| Lanes | Cars | Completion | Red/ep | Collisions/ep | Proximity/ep | Stuck TO/ep | Queue Error | Queue Delay/ep | Stop Action | Go Action |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 8 | 45.83% | 1.17 | 0.17 | 0.00 | 1.50 | 14.63 | 6.40s | -0.617 | +0.489 |
| 3 | 12 | 52.78% | 1.33 | 0.67 | 0.83 | 1.33 | 16.13 | 8.53s | -0.631 | +0.487 |
| 4 | 16 | 57.29% | 1.67 | 1.17 | 1.50 | 1.33 | 17.14 | 10.67s | -0.642 | +0.486 |

CSV: `results/protected_redgreen_density_potential_v1_200k/evals/eval_best_redgreen_sparse_summary.csv`

## Diagnosis

The potential/density run successfully preserved the action mechanism and improved red discipline in some queue-heavy settings, but it produced a non-demo policy.

Main failure mode:

- Stop/go action separation is not the blocker anymore.
- The policy brakes strongly and often stops far upstream in original redgreen mode.
- Dense queue mode creates collision/proximity failures and poor completion.
- Queue placement improves in some rollout windows, but deterministic validation is not stable enough.
- At 3-cars-per-inbound-lane density, red violations and queue delay still grow sharply.

Follow-up replay diagnosis on 2026-07-10 localized the primary bug to training labels, not the mixture mechanism. Closed-red `STOP` labels were distance-unconditioned: sparse 2-lane replay showed `STOP` labels across the `24-45m`, `10-24m`, `2-10m`, and `0-2m` buckets with deterministic longitudinal action around `-0.62` in every bucket. The gate routed to brake far upstream because CE supervision taught it to do that. Dense replay showed stuck/slow release in both left and straight queues, especially 2nd/3rd+ positions, and collisions mostly after the stop line during discharge.

Do not use this checkpoint for videos or demo fallback. The current demo fallback remains `checkpoints/protected_redgreen_generalized_v1_selected.npz`.

## Next Step

The next iteration should not change the mixture/gate optimizer stack. Fix the training labels first:

1. Use braking-envelope-conditioned closed-red labels against the unified stop target: lead stop target before the line, follower target behind the front vehicle.
2. Mask far-upstream red approach states out of gate CE instead of labeling them `GO` or `STOP`.
3. Keep one-way stop-label latching once a vehicle enters the braking envelope, clearing on hold/green release.
4. Scope go-component KL to green-permitted go states only.
5. Regenerate the gate prewarm batch under the new labels, verify green retention and red approach/brake onset before PPO, then run a 200k leg. The brake-component action target is now the second-line fix only if brake onset is correct but overshoot/placement remains poor.
