# Front-Bumper Geometry Re-baseline Plan

Date: 2026-07-11

Purpose: replace the 2026-07-10 corrected-clearance baseline with a same-policy,
same-protocol comparison under the front-bumper stop-line convention and
rear-bumper completion convention. Expectations below were recorded before
running any evaluation.

## Checkpoints

- old selected: `checkpoints/protected_redgreen_generalized_v1_selected.npz`
- new keeper: `checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz`

Both checkpoints predate checkpoint geometry stamping and are expected to report
`checkpoint_geometry_convention=unstamped_legacy`. They must still be evaluated
under the same `front_bumper_v1` runtime.

## Fixed Eval Settings

- Eval mode: `dense_redgreen`
- All-red clearance: `3.5s`
- Episode length: `60s`
- Evaluation workers: `4`
- Protected left, no yellow, no right-on-red
- Runtime source must resolve inside `intersection-rl_generalized`
- Runtime geometry marker must be `front_bumper_v1`

## Matrix and Budget

Sparse, 20 episodes per seed on seeds 730 and 731:

- 2 lanes / 8 cars
- 3 lanes / 12 cars
- 4 lanes / 16 cars

Dense, 20 episodes per seed on seeds 730, 731, and 732:

- 2 lanes / 16 cars
- 3 lanes / 24 cars
- 4 lanes / 32 cars

Stress, 10 episodes per seed on seeds 730 and 731:

- 2 lanes / 24 cars
- 3 lanes / 36 cars
- 4 lanes / 48 cars

## Pre-registered Expected Signature

1. Red violations may tick up slightly on both checkpoints because front-bumper
   crossings that center-referenced semantics accepted are now counted.
2. Placement and queue-error columns may shift by roughly half a vehicle length
   where the old policy stopped to the old center-referenced target.
3. Completion should move little. Rear-bumper route completion is slightly
   stricter and may turn a marginal horizon completion into a timeout.
4. Relative checkpoint comparisons remain meaningful because both policies are
   evaluated with the same corrected ruler.

A small red or timeout increase matching this signature is a geometry
measurement correction, not by itself a policy regression. Any asymmetric or
large shift requires cell-level diagnosis.

## Promotion Criteria

The 2026-07-10 criteria remain unchanged: the keeper must retain sparse and
2/3-lane dense safety/completion, avoid collision/proximity/timeout regression,
and become competitive in 4-lane dense and stress before replacing the broad
visual fallback. This run establishes the new regression floor; it does not
promote either checkpoint by itself.

## Calibration Note for the Next Leg

The lead stop target and action-target envelope now consume front-bumper
distance. Follower potential/action targets intentionally continue to consume
center-progress gaps of 7.0-7.5m, equivalent to 2.5-3.0m bumper clearance for
equal 4.5m vehicles. Re-derive the proportional brake and creep thresholds
against those explicit meanings before training.
