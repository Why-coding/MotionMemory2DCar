# Front-Bumper Geometry Re-baseline Summary

Date: 2026-07-11

This report compares the original selected demo checkpoint and the corrected-clearance
keeper under the front-bumper stop-line convention, rear-bumper completion convention,
and the same canonical July 10 evaluation budget.

## Inputs and Provenance

- Old selected: `checkpoints/protected_redgreen_generalized_v1_selected.npz`
- New keeper: `checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz`
- Runtime package: `intersection-rl_generalized/intersection_rl`
- Runtime geometry: `front_bumper_v1`
- Both checkpoints: `separate_accel_steer_v1`, legacy/unstamped geometry metadata
- Old selected distribution: `legacy_gaussian`
- Keeper distribution: `squashed_mixture`
- Eval mode: `dense_redgreen`
- All-red: `3.5s`
- Episode length: `60s`
- Raw CSVs: `raw/*.csv`
- Per-run logs: `logs/*.log`
- Aggregated CSV: `summary_by_cell.csv`
- Pre-registered expectations: `REBASELINE_PLAN.md`

Every raw CSV and log includes the resolved package path, runtime geometry,
checkpoint format, actor head, action distribution, checkpoint geometry marker,
seed, and clearance duration.

## Canonical Result

Values are completion %, red/collision/proximity/stuck events per episode, and
queue discharge delay seconds per episode.

| Regime | Cell | Checkpoint | Complete | Red | Collision | Proximity | Stuck | Discharge |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| sparse | 2l/8 | old selected | 88.75 | 0.90 | 0.00 | 0.00 | 0.00 | 3.28 |
| sparse | 2l/8 | keeper | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 5.11 |
| sparse | 3l/12 | old selected | 89.17 | 1.30 | 0.00 | 0.00 | 0.00 | 4.66 |
| sparse | 3l/12 | keeper | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 7.36 |
| sparse | 4l/16 | old selected | 89.38 | 1.70 | 0.00 | 0.00 | 0.00 | 6.12 |
| sparse | 4l/16 | keeper | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 9.61 |
| dense | 2l/16 | old selected | 93.75 | 1.00 | 0.00 | 0.00 | 0.00 | 7.18 |
| dense | 2l/16 | keeper | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 10.73 |
| dense | 3l/24 | old selected | 92.92 | 1.70 | 0.00 | 0.00 | 0.00 | 10.28 |
| dense | 3l/24 | keeper | 97.64 | 0.00 | 0.00 | 0.30 | 0.00 | 17.12 |
| dense | 4l/32 | old selected | 93.44 | 2.10 | 0.00 | 0.00 | 0.00 | 13.52 |
| dense | 4l/32 | keeper | 90.16 | 0.05 | 1.22 | 0.75 | 0.00 | 23.27 |
| stress | 2l/24 | old selected | 93.75 | 1.50 | 0.00 | 0.00 | 0.00 | 10.94 |
| stress | 2l/24 | keeper | 78.75 | 2.70 | 0.20 | 0.20 | 1.30 | 26.69 |
| stress | 3l/36 | old selected | 93.33 | 2.40 | 0.00 | 0.00 | 0.00 | 15.20 |
| stress | 3l/36 | keeper | 82.22 | 2.20 | 0.20 | 0.00 | 3.00 | 41.91 |
| stress | 4l/48 | old selected | 92.92 | 3.40 | 0.00 | 0.00 | 0.00 | 20.16 |
| stress | 4l/48 | keeper | 81.88 | 2.80 | 0.70 | 0.90 | 3.20 | 66.69 |

## Comparison With the Superseded July 10 Table

- Old selected is invariant in every promotion metric across all nine cells.
  Small queue-error/discharge differences are at numerical sampling precision.
- Keeper sparse and dense 2-lane are invariant and remain solved.
- Keeper dense 3-lane improves from 97.22% to 97.64% completion. The prior
  0.05 collision/episode becomes zero collisions with 0.30 proximity
  events/episode; moving timeouts remain 0.57/episode.
- Keeper dense 4-lane changes from 90.47% to 90.16% completion and from 1.17
  to 1.22 collisions/episode. Red remains 0.05 and stuck remains zero.
- Keeper stress 2-lane changes from 79.58% to 78.75% completion and from 0.10
  to 0.20 collisions/episode; red and stuck are unchanged.
- Keeper stress 3-lane keeps 82.22% completion and 0.20 collisions/episode;
  red improves from 2.30 to 2.20 while stuck moves from 2.90 to 3.00.
- Keeper stress 4-lane changes from 82.08% to 81.88% completion; red,
  collisions, and stuck remain 2.80, 0.70, and 3.20 per episode.

The preregistered large 2.25m placement shift did not occur because spawn
centers, line-relative observations, targets, and crossing semantics moved
together. This is the intended behavior-preserving conversion: rendered
vehicle bodies move behind the line while policy-relative distances remain
aligned. Small keeper interaction and horizon deltas are real but do not
change any regime verdict.

## Verdict

Do not promote the keeper over the old selected broad visual fallback yet.

The keeper remains the correct initialization/reference for the polish leg:
it solves sparse and 2/3-lane dense red discipline, but 4-lane dense clearance
collisions and 3-cars-per-lane follower discharge/stuck remain blockers. The
July 11 table is now the no-regression floor for that leg.

## Next Leg Calibration

- Re-derive proportional brake and creep-window thresholds using front-bumper
  stop distance.
- Keep follower queue targets explicit as 7.0-7.5m center gap, equivalent to
  2.5-3.0m bumper clearance for equal 4.5m vehicles.
- Fix follower release labeling if the green latch teaches sequential
  standstill-gap opening; otherwise add deep queue-discharge drills.
- Train with randomized 3.5-4.5s clearance, stress-weighted replay, and
  regime-gated selection against this table.
