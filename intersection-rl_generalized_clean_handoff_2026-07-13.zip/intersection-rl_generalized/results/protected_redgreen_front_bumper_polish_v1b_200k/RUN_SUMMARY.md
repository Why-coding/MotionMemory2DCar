# Protected Red/Green Front-Bumper Polish v1b 200k

Date: 2026-07-11
Status: ROLE-BASED PROMOTION

## Training

The corrected v1b run completed 202,752 rollout steps / 66 updates from the
front-bumper keeper. Update 35 was selected with validation score `41147.20`;
updates 10, 35, 50, and 60 passed every hard solved-regime gate.

The original v1 branch was interrupted at update 11 because GO action eroded below
the existing `+0.35` trigger with GO-component KL `0.03`. V1b changed only that
coefficient to the previously proven `1.0`. The final v1b mechanism remained stable:
GO action `+0.441`, brake/go routing weights `0.998/0.998`.

## Canonical Evaluation

Protocol: front-bumper canonical matrix, fixed 3.5s all-red, 60s episodes. Sparse
uses seeds 730/731 with 20 episodes each; dense uses 730/731/732 with 20 each;
stress uses 730/731 with 10 each.

Compact values are completion % / red / collision / proximity / stuck / discharge s.

| Regime | Cell | Keeper | Polish best |
|---|---:|---:|---:|
| sparse | 2l/8 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 / 5.1 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 / 5.0 |
| sparse | 3l/12 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 / 7.4 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 / 7.2 |
| sparse | 4l/16 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 / 9.6 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 / 9.3 |
| dense | 2l/16 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 / 10.7 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 / 10.3 |
| dense | 3l/24 | 97.64 / 0.00 / 0.00 / 0.30 / 0.00 / 17.1 | 100.00 / 0.00 / 0.00 / 0.55 / 0.00 / 15.0 |
| dense | 4l/32 | 90.16 / 0.05 / 1.22 / 0.75 / 0.00 / 23.3 | 99.90 / 0.03 / 0.00 / 0.00 / 0.00 / 19.8 |
| stress | 2l/24 | 78.75 / 2.70 / 0.20 / 0.20 / 1.30 / 26.7 | 83.33 / 4.00 / 0.00 / 0.00 / 0.00 / 16.5 |
| stress | 3l/36 | 82.22 / 2.20 / 0.20 / 0.00 / 3.00 / 41.9 | 87.50 / 4.50 / 0.00 / 0.00 / 0.00 / 24.0 |
| stress | 4l/48 | 81.88 / 2.80 / 0.70 / 0.90 / 3.20 / 66.7 | 91.46 / 2.80 / 0.10 / 1.30 / 0.40 / 39.5 |

## Decision

Promote the update-35 best checkpoint as the current front-bumper red/green demo
model for sparse and dense 1-2 cars per inbound lane. It preserves perfect sparse
behavior, solves 4-lane dense collisions, and improves dense discharge.

Do not claim stress solved. Stress discharge and stuck behavior improve strongly, but
2/24 and 3/36 red violations regress to 4.0 and 4.5 per episode. Keep the original
selected checkpoint as the stress-throughput fallback until a stress-red polish leg
passes both throughput and discipline.

Promoted checkpoint:

`checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz`

## Artifacts

- Training metrics: `checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_train_metrics.csv`
- Canonical CSV: `promotion/summary_by_cell.csv`
- Raw evaluation CSVs and logs: `promotion/raw/`, `promotion/logs/`
- Interrupted v1 diagnosis: `../protected_redgreen_front_bumper_polish_v1_200k/RUN_SUMMARY.md`

## Shared Demo Builder Follow-Up - 2026-07-11

Implemented one red/green scenario factory used by graph evaluation/validation and the
visual CLI. Named demos use 3.5s all-red, random legal green initialization, no
yellow/RoR/shield/reservation, randomized front-bumper-safe upstream positions,
queue-safe gaps, and braking-feasible signal-conditioned speeds. Headless and visual
modes share the same reset path and seed.

Seed-730 randomized approach diagnostics at 60s:

| Scenario | Clean | Failed | Red | Collision | Timeout | Stuck |
|---|---:|---:|---:|---:|---:|---:|
| demo_redgreen_2l | 11/16 | 5 | 1 | 0 | 4 | 4 |
| demo_redgreen_3l | 17/24 | 7 | 3 | 0 | 4 | 3 |
| demo_redgreen_4l | 26/32 | 6 | 4 | 0 | 2 | 2 |

No vehicle spawned over the line. The counted red crossings are genuine rollout
events, while legal clearers are reported separately. A trajectory trace localized stopped-short
behavior: a closed lane leader received creep/GO labels at 26.3m and 3.9m short while
the deterministic brake component remained negative. This is a policy action gap on
random approach states, not a simulation geometry or configuration mismatch.

A short canonical dense 3l/24 regression after factory extraction remained 100%
complete with zero red, collision, proximity, or timeout. The role-based promotion is
unchanged. Any follow-up training should target closed-red creep action and phase-end
re-stop while retaining the canonical table as a hard floor.
