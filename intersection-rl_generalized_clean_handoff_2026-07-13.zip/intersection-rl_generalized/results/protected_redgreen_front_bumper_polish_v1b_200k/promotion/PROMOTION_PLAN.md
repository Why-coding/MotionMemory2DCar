# Canonical Promotion Evaluation Plan

Date: 2026-07-11
Status: PRE-REGISTERED BEFORE EVALUATION

Candidate:
`checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_best.npz`
(relative to this run directory).

Protocol is imported directly from `scripts/run_front_bumper_rebaseline.py`:

- sparse: seeds 730-731, 20 episodes/seed, cells 2/8, 3/12, 4/16
- dense: seeds 730-732, 20 episodes/seed, cells 2/16, 3/24, 4/32
- stress: seeds 730-731, 10 episodes/seed, cells 2/24, 3/36, 4/48
- 60 seconds, dense_redgreen, fixed 3.5s all-red, four eval workers

Promotion requires same-ruler comparison with
`results/front_bumper_rebaseline_2026_07_11/summary_by_cell.csv`. The internal
training gate is necessary but not sufficient.
