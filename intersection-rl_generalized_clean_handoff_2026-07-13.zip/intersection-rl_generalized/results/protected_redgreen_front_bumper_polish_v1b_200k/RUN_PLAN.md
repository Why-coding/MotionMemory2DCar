# Front-Bumper Polish v1b 200k Run Plan

Date: 2026-07-11
Status: PRE-REGISTERED BEFORE RELAUNCH

This is the controlled correction of v1. All inputs, seed 814, task weights, geometry,
clearance randomization, action calibration, validation protocol, and hard gates from
`../protected_redgreen_front_bumper_polish_v1_200k/RUN_PLAN.md` remain unchanged.

## Sole Change

- GO-component reference KL coefficient: `0.03 -> 1.0`.

The value `1.0` is not a new sweep choice: the prior
`protected_redgreen_mixture_prewarm_gokl_v1b_200k` diagnostic established it as the
setting that prevented sustained GO-component erosion after `0.2` failed.

## Additional Stop Rule

Interrupt if the legal-GO action mean is below `+0.35` on two consecutive printed
updates after update 10, or if GO routing itself loses saturation. Hard regime gates
remain mandatory for saving `_best`.

## Launch Command

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage front_bumper_polish \
  --init-checkpoint checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz \
  --reference-checkpoint checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz \
  --checkpoint results/protected_redgreen_front_bumper_polish_v1b_200k/checkpoints/protected_redgreen_front_bumper_polish_v1b_200k.npz \
  --steps 200000 --rollout-steps 256 --rollout-workers 12 \
  --validation-workers 4 --validation-episodes 8 --validation-interval 5 \
  --validation-patience 0 --checkpoint-interval 5 --max-cars 50 --seed 814
```

Focused regression tests: `12 passed`.
