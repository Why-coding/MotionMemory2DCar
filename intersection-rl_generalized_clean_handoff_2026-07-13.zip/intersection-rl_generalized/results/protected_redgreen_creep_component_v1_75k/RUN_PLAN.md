# Red Creep Component v1 75k Run Plan

Date: 2026-07-12
Status: PRE-REGISTERED BEFORE TRAINING

## Objective

Teach the brake mixture component to produce low positive acceleration for
stationary closed-red vehicles far upstream, then taper to HOLD in the bumper-true
stop window. The promoted sparse/dense behavior and the accepted dilemma-latch
baseline are hard no-regression floors.

## Controlled Changes

- Initialize and reference the promoted front-bumper polish v1b checkpoint.
- Relabel creep as STOP/brake-component routing, not GO-component routing.
- Add deterministic 2/3/4-lane far-upstream stationary red creep drills.
- Supervise the brake component with the existing distance-conditioned target,
  capped at 3.0 m/s and decreasing to zero at the stop window.
- Keep randomized 3.5-4.5s training clearance and fixed 3.5s validation clearance.
- Preserve the GO component with coefficient-1.0 reference KL.
- Train for 75k environment steps; no patience-based early stop.

## Training Diagnostics

The run must contain positive creep_action_samples, nonzero
grad_norm_creep_action, and a brake-component creep mean moving toward the
positive creep_action_target_mean. STOP/GO gate routing must remain saturated and
the legal-GO mean must not remain below +0.35 for two printed updates after update
10.

## Promotion Gates

1. The accepted dilemma-latch canonical table is the regression floor. Sparse and
   dense 2/3/4-lane demo cells must retain their solved safety/completion behavior.
2. Named demo_redgreen_2l, demo_redgreen_3l, and demo_redgreen_4l scenarios
   must have zero stopped-short timeouts, zero red violations, and zero collisions.
3. A stationary far-upstream red vehicle must visibly close to the stop window
   within the red interval, settle to HOLD without chatter, and release on green.
4. Stress remains reported but is not a promotion gate beyond avoiding a broad
   regression.

## Launch Command

    ../.venv/bin/python scripts/train_graph_multitask.py train       --behavior-stage red_creep_component       --init-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz       --reference-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz       --checkpoint results/protected_redgreen_creep_component_v1_75k/checkpoints/protected_redgreen_creep_component_v1_75k.npz       --steps 75000 --rollout-steps 256 --rollout-workers 12       --validation-workers 4 --validation-episodes 8 --validation-interval 5       --validation-patience 0 --checkpoint-interval 5 --max-cars 50 --seed 927
