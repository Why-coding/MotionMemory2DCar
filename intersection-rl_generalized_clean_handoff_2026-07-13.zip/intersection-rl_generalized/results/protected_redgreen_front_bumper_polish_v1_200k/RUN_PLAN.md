# Front-Bumper Polish v1 200k Run Plan

Date: 2026-07-11
Status: PRE-REGISTERED BEFORE TRAINING

## Objective

Train one keeper-initialized diagnostic polish leg that preserves the solved sparse and
2/3-lane dense regimes while improving bumper-true stop placement, queue discharge,
4-lane dense conflict handling, and stress completion.

## Fixed Inputs

- Init/reference checkpoint: `checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz`
- Geometry convention: `front_bumper_v1`
- Behavior stage: `front_bumper_polish`
- Training all-red clearance: uniformly sampled `3.5-4.5s` per episode
- Validation all-red clearance: fixed `3.5s`
- Seed: `814`
- Budget: `200000` rollout steps; no validation early stopping

## Mechanism Changes Under Test

- Proportional bumper-distance brake target and bumper-calibrated queue target.
- Closed-red creep/re-approach labels only when more than 2m short and at or below 0.5m/s.
- Creep GO labels train the red action target but are excluded from legal-GO gate CE.
- Deep-queue discharge/stress task allocation is 40.5% of the curriculum.
- Randomized clearance training for robustness.
- Keeper reference KL and hard solved-regime validation gates.

The derivation found no sequential follower-release label bug: under the production
configuration, all three queued vehicles receive GO when green begins. The discharge
fix is therefore task coverage/optimization, not a green safe-gap relabel.

## Hard Best-Checkpoint Gates

A checkpoint cannot become `_best` unless all five solved cells are present and pass:

| Cell | Min completion | Max red | Max collision | Max proximity | Max stuck |
|---|---:|---:|---:|---:|---:|
| 2 lanes / 8 cars | 98% | 0.125/ep | 0.125/ep | 0.25/ep | 0.125/ep |
| 3 lanes / 12 cars | 98% | 0.125/ep | 0.125/ep | 0.25/ep | 0.125/ep |
| 4 lanes / 16 cars | 98% | 0.125/ep | 0.125/ep | 0.25/ep | 0.125/ep |
| 2 lanes / 16 cars | 98% | 0.125/ep | 0.125/ep | 0.25/ep | 0.125/ep |
| 3 lanes / 24 cars | 95% | 0.125/ep | 0.25/ep | 0.75/ep | 0.125/ep |

The 4-lane dense and all stress cells remain in the validation score and promotion
evaluation, but do not weaken the no-regression floor above.

## Pre-Registered Reading Rules

1. Reject any candidate that fails a solved-cell hard gate, regardless of aggregate score.
2. Dense discharge delay should move toward the old selected checkpoint's roughly
   7/10/13s signature; improvement here is the leading indicator for stress throughput.
3. The target promotion candidate should retain the keeper's zero-red sparse behavior
   and near-zero-red 2/3-lane dense behavior.
4. Randomized clearance is successful only if fixed-3.5s validation does not regress and
   the canonical promotion matrix confirms robustness.
5. A front-bumper-era checkpoint must carry `geometry_convention=front_bumper_v1`.
6. Do not promote from training metrics alone. Run the complete canonical multi-seed
   front-bumper matrix against the July 11 keeper and old-selected baselines.

## Launch Command

```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage front_bumper_polish \
  --init-checkpoint checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz \
  --reference-checkpoint checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz \
  --checkpoint results/protected_redgreen_front_bumper_polish_v1_200k/checkpoints/protected_redgreen_front_bumper_polish_v1_200k.npz \
  --steps 200000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 4 \
  --validation-episodes 8 \
  --validation-interval 5 \
  --validation-patience 0 \
  --checkpoint-interval 5 \
  --max-cars 50 \
  --seed 814
```

## Pre-Launch Verification

- Gate/action smoke: passed; prewarm completed in one step with
  `w_stop=0.998`, `w_go=0.993`, and legal-label gate accuracy `1.000`.
- Full test suite: `92 passed`, one third-party pygame deprecation warning.
