# Named Demo Latch Baseline

Date: 2026-07-12
Seed: 730
Episode horizon: 60 simulated seconds
Clearance: 3.5 seconds

| Checkpoint | Scenario | Completed | Failed | Red | Collision | Proximity | Timeout/Stuck |
|---|---|---:|---:|---:|---:|---:|---:|
| polish-selected | demo 2l/16 | 12 | 4 | 0 | 0 | 0 | 4/4 |
| polish-selected | demo 3l/24 | 19 | 5 | 1 | 0 | 0 | 4/3 |
| polish-selected | demo 4l/32 | 30 | 2 | 0 | 0 | 0 | 2/1 |
| old-selected | demo 2l/16 | 16 | 0 | 0 | 0 | 0 | 0/0 |
| old-selected | demo 3l/24 | 22 | 2 | 2 | 0 | 142 | 0/0 |
| old-selected | demo 4l/32 | 31 | 1 | 1 | 0 | 130 | 0/0 |

The promoted polish checkpoint remains the visual default because it has no
proximity events or collisions and better red discipline. Its far-upstream
stationary creep/timeouts remain the visible demo defect. Old-selected clears more
vehicles but is not the broad visual fallback because its 3/4-lane random demos add
red failures and large proximity counts.
