# protected_redgreen_squashed_greeninit_v1_100k

Verdict: failed red/green fine-tune. Do not use for demo.

Purpose: test green-first red/green fine-tune from `checkpoints/protected_green_squashed_base_v1_250k_selected.npz` using the squashed Gaussian continuous actor, acceleration shortcut, explicit next-release queue task mix, and green reference KL.

Training notes:
- Runtime remains pure policy output.
- No safety shield, no hard action override, no runtime rule override.
- No yellow and no right-on-red.
- No training-only action-target loss was enabled.
- Red-state std was healthy from update 1: `std_stop=0.422`, later around `0.50-0.55`.
- Best validation occurred around update 10; later checkpoints regressed.

Training command:
```bash
../.venv/bin/python scripts/train_graph_multitask.py train \
  --behavior-stage redgreen \
  --training-tasks green_1to2_per_lane_2l green_1to2_per_lane_3l green_1to2_per_lane_4l green_queue_discharge red_queue_2_per_lane_2l red_queue_2_per_lane_3l red_queue_2_per_lane_4l redgreen_next_release redgreen_1_per_lane_2l redgreen_1_per_lane_3l redgreen_1_per_lane_4l redgreen_2_per_lane_2l redgreen_2_per_lane_3l redgreen_2_per_lane_4l \
  --init-checkpoint checkpoints/protected_green_squashed_base_v1_250k_selected.npz \
  --reference-checkpoint checkpoints/protected_green_squashed_base_v1_250k_selected.npz \
  --checkpoint checkpoints/protected_redgreen_squashed_greeninit_v1_100k.npz \
  --steps 100000 \
  --rollout-steps 256 \
  --rollout-workers 12 \
  --validation-workers 8 \
  --validation-interval 5 \
  --validation-episodes 4 \
  --validation-scenarios 2:4:60 3:6:60 4:8:60 \
  --checkpoint-interval 5 \
  --max-cars 50 \
  --learning-rate 3e-5 \
  --target-kl 0.01 \
  --entropy-coefficient 0.0015 \
  --reward-clip 320 \
  --action-distribution squashed_gaussian
```

Deterministic redgreen eval summary, 12 episodes each, 2 cars per lane:

| lanes/cars | completed | red violations/ep | collisions/ep | proximity/ep | timeouts/ep | action_stop_mean | std_stop_mean | action_go_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2/4 | 35.42% | 1.17 | 0.0 | 0.0 | 1.42 | -0.128 | 0.541 | 0.221 |
| 3/6 | 68.06% | 1.83 | 0.0 | 0.0 | 0.08 | -0.074 | 0.524 | 0.397 |
| 4/8 | 71.88% | 2.00 | 0.0 | 0.0 | 0.25 | -0.096 | 0.531 | 0.387 |

Deterministic green-retention eval summary, 12 episodes each, 2 cars per lane:

| lanes/cars | completed | collisions/ep | proximity/ep | timeouts/ep | action_go_mean |
| --- | --- | --- | --- | --- | --- |
| 2/4 | 100.0% | 0.0 | 0.0 | 0.0 | 0.374 |
| 3/6 | 100.0% | 0.0 | 0.0 | 0.0 | 0.418 |
| 4/8 | 100.0% | 0.0 | 0.0 | 0.0 | 0.433 |

Diagnostic interpretation:
- Green retention succeeded.
- Red-state exploration was healthy, so this was not a variance-collapse failure.
- Deterministic stop mean remained too close to zero despite high stop brake share from noise.
- This triggers the predefined escalation: implement a 2-mode continuous mixture head or stronger pathway separation, rather than more coefficient tuning.

Shortcut weights:
- Green base: approximately `[+0.00377, -0.00304, +0.00575]`, bias `+0.00575`.
- Fine-tune best: approximately `[+0.00372, -0.00274, +0.00631]`, bias `+0.00627`.
- The shortcut barely changed, so it did not solve stop/go separation in this run.
