# Gradient Diagnostics

Date: 2026-07-08

This file records the gradient analysis that led to the mixture-gate fix and the follow-up probe results.

## Original Failure Localization

The failed run was:

`results/protected_redgreen_mixture_greeninit_v1_100k/`

Symptom:

- Mixture gate CE was enabled and labels were correct.
- Gate weights stayed near `0.47-0.49`.
- `mixture_ambiguous_stop_label_share` stayed near `1.0`.
- Deterministic red/green eval remained poor.

Manual gradient decomposition on a real PPO batch showed the issue was arithmetic, not model capacity:

| Quantity | Value |
|---|---:|
| Weighted value gradient norm | ~360 |
| Weighted gate CE gradient norm | ~5 |
| Global PPO clip scale | ~0.00139 |
| Effective gate CE gradient after clipping | ~0.0068 |

Interpretation:

- The value gradient dominated the shared global gradient norm.
- Global clipping scaled all gradients by about `1/720`.
- Gate CE was technically present but numerically erased.
- This explains why gate CE stayed near chance even though offline gate-only training worked.

## Plumbing Checks

Before changing the optimizer path, the gate CE plumbing was checked:

| Check | Result |
|---|---|
| Gate CE coefficient active | yes, effective coefficient `0.8` |
| Gate CE loss | near `ln(2) ~= 0.693` during failed joint training |
| Stop/hold/go label mapping | correct |
| Stop/hold/go samples present in minibatches | yes |
| Gate gradients before global clipping | nonzero |
| Detach boundary | trunk detached, gate parameters still connected |

## Offline Gate-Only Test

A saved rollout-style mixed batch was used to train only the gate with CE.

Batch label counts:

| Label | Samples |
|---|---:|
| stop | 6553 |
| hold | 542 |
| go | 2934 |

After 300 gate-only steps:

| Metric | Result |
|---|---:|
| Brake weight on stop labels | ~0.848 |
| Go weight on go labels | ~0.687 |
| Stop argmax share | 1.0 |
| Go argmax share | 1.0 |
| Ambiguous stop share | 0.0 |

Interpretation:

- The gate can classify from the existing representation.
- The failed joint run was not blocked by missing features or impossible labels.
- The problem was optimizer/clipping interaction.

## Implemented Fix

Implemented in:

- `intersection_rl/config.py`
- `intersection_rl/graph_ppo.py`
- `scripts/train_graph_multitask.py`

Changes:

- Add `value_loss_huber_beta`.
- Add permanent gradient diagnostics:
  - `grad_norm_policy`
  - `grad_norm_value`
  - `grad_norm_value_mse`
  - `grad_norm_gate_ce`
  - `main_grad_norm`
  - `main_grad_clip_scale`
  - `gate_grad_norm`
  - `gate_grad_clip_scale`
  - `value_error_abs_mean`
  - `value_error_abs_max`
- Add separate mixture-gate optimizer.
- Run PPO backward/step first.
- Zero gradients.
- Run detached-trunk gate CE backward/step second.
- Optionally freeze PPO gradients into the gate until saturation.

Probe run:

`results/protected_redgreen_mixture_gatefix_probe_v1_75k/`

## Gate-Fix Probe Gradient Results

Metrics source:

`results/protected_redgreen_mixture_gatefix_probe_v1_75k/checkpoints/protected_redgreen_mixture_gatefix_probe_v1_75k_train_metrics.csv`

| Update | Value Loss | MSE Value Loss | Grad Value | Grad Value MSE | Main Clip Scale | Gate Grad | Gate Clip Scale | Gate Frozen |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 52.147 | 5270.6 | 3.58 | 194.43 | 0.125 | 1.33 | 1.000 | 1 |
| 5 | 44.660 | 3738.9 | 0.70 | 44.19 | 0.309 | 0.87 | 1.000 | 1 |
| 10 | 39.869 | 3112.7 | 10.31 | 661.62 | 0.062 | 0.50 | 1.000 | 1 |
| 15 | 67.464 | 6388.8 | 3.10 | 353.68 | 0.212 | 0.92 | 1.000 | 1 |
| 20 | 45.158 | 3466.3 | 0.88 | 82.40 | 0.232 | 0.47 | 1.000 | 1 |
| 25 | 36.989 | 1857.9 | 1.09 | 80.65 | 0.217 | 0.32 | 1.000 | 1 |

Key result:

- The old `0.00139` global clip-scale problem was fixed.
- The main PPO clip scale was still sometimes active, but now in a usable range: roughly `0.06-0.31`.
- The gate optimizer was not clipped away: `gate_grad_clip_scale=1.0` throughout the reported validation checkpoints.

## Gate/Action Mechanism Results

| Update | Gate Loss | Gate Acc | Stop Action Mean | Go Action Mean | Brake Weight on Stop | Go Weight on Go | Ambiguous Stop Share |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 5 | 0.688 | 0.593 | -0.091 | +0.222 | 0.468 | 0.552 | 0.997 |
| 10 | 0.459 | 0.796 | -0.197 | +0.258 | 0.585 | 0.749 | 0.070 |
| 15 | 0.607 | 0.800 | -0.566 | -0.342 | 0.613 | 0.499 | 0.427 |
| 20 | 0.463 | 1.000 | -0.461 | +0.131 | 0.625 | 0.642 | 0.285 |
| 25 | 0.297 | 1.000 | -0.370 | +0.213 | 0.761 | 0.749 | 0.000 |

Interpretation:

- Gate CE now trains.
- Stop-label action became meaningfully negative.
- Go-label action recovered positive by update 25.
- The precommitted saturation trigger was still not reached:
  - required stop brake weight `>= 0.80`
  - actual final value `0.761`
  - saturated updates `0`

## Deterministic Eval Result

Checkpoint:

`results/protected_redgreen_mixture_gatefix_probe_v1_75k/checkpoints/protected_redgreen_mixture_gatefix_probe_v1_75k_best.npz`

Density note: this was a sparse mechanism-probe eval with `cars=4/6/8`, not 2 cars per physical lane. Dense 2-cars-per-inbound-lane eval should use `cars=16/24/32` for 2/3/4-lane systems.

| Lanes | Cars | Completion | Red Violations | Collisions | Proximity | Stop Action Mean | Brake Weight on Stop |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2 | 4 | 50.00% | 1.08/ep | 0.00/ep | 0.00/ep | -0.342 | 0.645 |
| 3 | 6 | 69.44% | 1.00/ep | 0.00/ep | 0.00/ep | -0.342 | 0.648 |
| 4 | 8 | 72.92% | 1.08/ep | 0.17/ep | 0.08/ep | -0.339 | 0.649 |

Conclusion:

- The gradient bug is fixed.
- The checkpoint is not a keeper.
- The next problem is not gate-gradient plumbing; it is installing a stronger prewarmed gate/component specialization before PPO and then testing timing/queue placement.
