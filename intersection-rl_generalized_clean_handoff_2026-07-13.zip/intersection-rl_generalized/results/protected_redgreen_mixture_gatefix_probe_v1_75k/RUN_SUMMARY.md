# Protected Red/Green Mixture Gate-Fix Probe v1 75k

Date: 2026-07-08

## Status

UNDER-BUDGET DIAGNOSTIC; NOT A KEEPER. Do not promote any checkpoint from this run to the top-level `checkpoints/` folder.

This run fixed the previous mixture-gate training bug and showed improving gate/action mechanisms, but it ended before the gate unfreeze/post-unfreeze question could be tested. The resulting policy is still not a demo or keeper checkpoint. Artifacts are retained only under this `results/` directory.

## Implementation Tested

- Separate mixture-gate optimizer for training-only gate CE.
- PPO update and gate CE update are sequential:
  - PPO backward/step first.
  - zero gradients.
  - detached-trunk gate CE backward/step second.
- Mixture gate parameters are excluded from PPO gradients until the gate saturation trigger is met.
- Gate unfreeze trigger:
  - brake weight on stop labels `>= 0.80`
  - for `10` consecutive updates.
- Huber value loss enabled with `value_loss_huber_beta=20`.
- Value coefficient reduced to `0.1`.
- Permanent gradient diagnostics added:
  - `grad_norm_policy`
  - `grad_norm_value`
  - `grad_norm_value_mse`
  - `grad_norm_gate_ce`
  - `main_grad_norm`
  - `main_grad_clip_scale`
  - `gate_grad_norm`
  - `gate_grad_clip_scale`
  - `value_error_abs_mean`
  - `value_error_abs_max`
  - `mixture_gate_ppo_frozen`
  - `mixture_gate_saturated_updates`

## Verification Before Probe

- `../.venv/bin/python -m py_compile intersection_rl/graph_ppo.py intersection_rl/config.py scripts/train_graph_multitask.py`: passed.
- `../.venv/bin/python -m pytest tests/test_ppo.py -q`: 8 passed.
- `../.venv/bin/python -m pytest -q`: 69 passed, 1 warning.

Tiny smoke train with the new optimizer path passed. By update 2, gate CE was moving the gate independently (`gate_loss=0.227`, `gate_grad_clip_scale=1.0`, `w_stop=0.780`, `stop_a=-0.540`).

## Training Run

Checkpoint root:

`results/protected_redgreen_mixture_gatefix_probe_v1_75k/checkpoints/`

Top-level `checkpoints/` was not modified.

Key command settings:

- init/reference: `checkpoints/protected_green_squashed_base_v1_250k_selected.npz`
- behavior stage: `redgreen`
- action distribution: `squashed_mixture`
- steps target: `75000`, completed at update 25 / 76800 rollout steps
- rollout workers: 12
- validation workers: 4
- validation scenarios: `2:4:60 3:6:60 4:8:60`
- LR: `3e-5`
- target KL: `0.01`
- entropy coefficient: `0.0015`
- mixture gate CE: start `0.8`, decay after update 30 to floor `0.05`
- separate gate optimizer LR: `0.003`
- gate max grad norm: `5.0`
- Huber value beta: `20`
- value coefficient: `0.1`

## Mechanism Diagnostics

| Update | Val Score | Stop Action Mean | Go Action Mean | Brake Weight on Stop | Go Weight on Go | Ambiguous Stop Share | Gate Acc | Main Clip Scale | Gate Clip Scale | Gate Frozen |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 5 | -236390 | -0.091 | +0.222 | 0.468 | 0.552 | 0.997 | 0.593 | 0.309 | 1.000 | 1 |
| 10 | -83638 | -0.197 | +0.258 | 0.585 | 0.749 | 0.070 | 0.796 | 0.062 | 1.000 | 1 |
| 15 | -222641 | -0.566 | -0.342 | 0.613 | 0.499 | 0.427 | 0.800 | 0.212 | 1.000 | 1 |
| 20 | -78752 | -0.461 | +0.131 | 0.625 | 0.642 | 0.285 | 1.000 | 0.232 | 1.000 | 1 |
| 25 | -61419 | -0.370 | +0.213 | 0.761 | 0.749 | 0.000 | 1.000 | 0.217 | 1.000 | 1 |

The prior failure was fixed: the gate CE was no longer crushed by global PPO clipping, and deterministic stop-label actions became meaningfully negative. The gate was still improving when the short probe ended: brake weight on stop labels climbed to `0.761`, ambiguous stop share fell to `0.000`, and gate accuracy reached `1.000`. The pre-committed soft-weight trigger was not reached, so the checkpoint is not promotable, but this should be read as under-budget rather than as a mechanism plateau.

## Deterministic Best Eval

Checkpoint:

`results/protected_redgreen_mixture_gatefix_probe_v1_75k/checkpoints/protected_redgreen_mixture_gatefix_probe_v1_75k_best.npz`

Evaluation mode: `redgreen`, 12 episodes each, sparse mechanism-probe density, 60 s episodes.

Important density note: the probe used `cars=4/6/8` for 2/3/4-lane systems. That is not 2 cars per physical lane. For dense demo/eval with 2 cars per inbound lane, use `cars=16/24/32` for 2/3/4-lane systems.

| Lanes | Cars | Completed | Red Violations | Collisions | Proximity | Stuck Timeouts | Stop Action Mean | Go Action Mean | Brake Weight on Stop | Go Weight on Go |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 4 | 50.00% | 1.08/ep | 0.00/ep | 0.00/ep | 0.50/ep | -0.342 | +0.256 | 0.645 | 0.811 |
| 3 | 6 | 69.44% | 1.00/ep | 0.00/ep | 0.00/ep | 0.42/ep | -0.342 | +0.235 | 0.648 | 0.824 |
| 4 | 8 | 72.92% | 1.08/ep | 0.17/ep | 0.08/ep | 0.42/ep | -0.339 | +0.217 | 0.649 | 0.841 |

The run is not demo-grade. It is worse than the selected fallback checkpoint on completion and not better on red violations.

## Diagnosis

The arithmetic bug is fixed. Huber value loss and the separate gate optimizer prevented value gradients from erasing the gate CE update. The mechanism now produces real stop braking and stable go routing on go labels.

The remaining failure is not "gate CE cannot train." The gate trained monotonically under its separate CE optimizer, but the short probe ended before it met the soft-weight robustness margin and before PPO was allowed to update the gate. Therefore this run did not test post-unfreeze gate retention. The clearest remaining issue is component interference: the go-label action fell far below the green base and briefly went negative, so the next run must protect the go component explicitly while prewarming the gate.

## Next Step

Do not tune reward weights next. The next implementation should add a short supervised gate/component prewarm before PPO:

1. Build a mixed red/green rollout-label batch from the green-warm-started mixture.
2. Freeze trunk and PPO.
3. Train only the mixture gate with CE until deterministic gate metrics are saturated:
   - brake weight on stop labels `>= 0.85`
   - go weight on go labels `>= 0.85`
   - ambiguous stop/go share near `0`
4. Redefine gate unfreeze around argmax stability, not soft weight alone:
   - stop-label brake argmax share `>= 0.98`
   - go-label go argmax share `>= 0.98`
   - stop/go ambiguous share `<= 0.05`
   - sustained for `10` consecutive updates
5. During the first PPO phase, keep gate PPO gradients disabled and keep a CE floor. After unfreeze, observe at least `20-30` additional updates.
6. Protect component specialization:
   - keep the go component close to the green reference on go states
   - treat go-label action mean below about `+0.35` as go erosion
   - route stop-label learning primarily to the brake component
7. Run a `150-200k` mixed probe, not another `75k` probe.

If the prewarmed gate holds and green is protected but red violations or stop placement remain poor, the next diagnosis is timing/queue placement, not action parameterization.
