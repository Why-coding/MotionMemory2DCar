# Speed-Augmented Prewarm Probe Result

Date: 2026-07-12
Checkpoint: protected_redgreen_creep_three_component_v1_75k_prewarm_speed_augmented_rejected.npz
Decision: Rejected before PPO.

Speed augmentation corrected the component profile: canonical handoff speeds fell to
0.8-1.9m/s and the prior >3m/s servo failures mostly disappeared. The probe
still produced 6/9/12 red failures in named-demo baseline and regressed every
canonical control.

Representative traces show the route label correctly changing from creep to
brake/hold at the window while the learned gate continues selecting creep with
0.91-0.99 probability. The brake component remains negative and available, but
is not executed. The compatibility-masked teacher rollout contained no
post-creep transition states, so initial prewarm could not supervise this
boundary.

The next attempt uses supervised dataset aggregation only: prewarm on the
compatibility-masked teacher data, collect rollouts from the resulting enabled
creep policy, then re-prewarm on the actual creep-to-hold transition states.
No PPO, reward update, runtime override, coefficient change, or threshold
change is involved.
