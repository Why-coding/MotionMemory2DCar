# Unaugmented Prewarm Probe Result

Date: 2026-07-12
Checkpoint: protected_redgreen_creep_three_component_v1_75k_prewarm_unaugmented_rejected.npz
Decision: Rejected before PPO.

## Prewarm

The corrected three-way ambiguity metric passed at step 2400:

- Route weights: 0.903 / 0.892 / 1.000
- Route argmax: 0.962 / 0.951 / 1.000
- Route ambiguity: 0.043 / 0.027 / 0.000
- Original-state creep MSE: 0.0023
- PPO started: no

## Probe

The checkpoint removed stuck timeouts but converted the behavior into red
crossings. Named-demo baseline completion was 10/16, 9/24, and 11/32 with
6, 15, and 21 red failures. Canonical controls also regressed.

Trace localization:

- At 1.5-3.0m/s, creep output remained positive (+0.161 mean).
- Above 3.0m/s, creep output remained positive (+0.100 mean).
- Maximum creep-state speed reached 4.86m/s.
- Creep-to-brake handoffs exceeded 3m/s in named and canonical cases.
- Baseline and forced-creep canonical results were identical, confirming the
  trained gate selected the faulty creep component rather than hiding it.

The compatibility-masked teacher generated mostly near-stationary creep
states, so prewarm never supervised the negative side of the speed servo.
This is a task-coverage failure in auxiliary prewarm, not a PPO or reward
failure. The next attempt adds deterministic 0/0.5/1.5/2.5/4.0m/s speed
augmentation to creep-head prewarm while leaving gate data, thresholds,
curriculum, and PPO disabled.
