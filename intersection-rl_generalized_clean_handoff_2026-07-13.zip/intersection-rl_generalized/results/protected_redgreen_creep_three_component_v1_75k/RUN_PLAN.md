# Three-Component Creep Leg Plan

Date: 2026-07-12

## Scope

Add a dedicated longitudinal brake/creep/go mixture without changing the
promoted checkpoint's behavior during migration. Yellow remains parked until
this leg either promotes or localizes an environment-side blocker.

## Pre-Registered Expectations

- Legacy two-component migration preserves brake/GO gate weights and
  deterministic actions exactly while creep is compatibility-masked.
- Route labels are 0=brake, 1=creep, 2=go. A moving far-red vehicle
  remains supervision-masked until the existing dynamic braking envelope
  engages: target error <= 2m or safety-scaled required deceleration reaches
  the configured 4.0m/s^2 threshold. Thus an isolated 60m/13m/s approach is
  PPO-owned and masked, not creep-labeled. Low-speed re-approach enters creep
  only when speed <= 0.5m/s and target error > 2m.
- Creep uses a 1.5 m/s distance-tapered speed servo, not constant positive
  acceleration. It remains selected until the stop window. The physical
  emergency-brake escape changes only the training intent/route label when a
  latched creep state becomes physically infeasible; it never modifies or
  replaces the policy's executed action.
- Prewarm must contain all three route classes and meet, per class: target
  weight >= 0.85, argmax share >= 0.95, ambiguous share <= 0.05. Creep action
  MSE must be <= 0.02. Failure aborts before PPO.
- The creep stage stops after accepted prewarm by default. Run the trajectory
  probe on the saved prewarm checkpoint, then use the explicit continuation
  flag with prewarm disabled for the optional PPO leg.
- The trajectory probe must show bounded speed, no red overshoot, no repeated
  brake/creep sawtooth, and final front-bumper placement in the stop window.

## No-Regression Floors

Use the accepted dilemma-latch table as the policy floor:

- Sparse 2/8, 3/12, 4/16: 100% completion and zero red, collision, proximity,
  and stuck events.
- Dense 2/16: 100% clean.
- Dense 3/24: 100% completion, zero red/collision/stuck, proximity no worse
  than 0.55 per episode.
- Dense 4/32: 100% clean.
- Stress 2/24: completion >= 99.58%, red <= 0.1/episode, zero
  collision/proximity/stuck.
- Stress 3/36: completion >= 99.17%, red <= 0.3/episode, zero
  collision/proximity/stuck.
- Stress 4/48: no regression from the polish latch baseline (96.46%
  completion, 0.4 red, 0.1 collision, 1.3 proximity, 0.4 stuck per episode).
- Named demos must have zero creep-related stuck timeouts; red/collision/
  proximity results may not regress from the accepted named-demo baseline.

## Decision

Run the forced-creep trajectory probe after prewarm. The probe must report
creep-to-brake handoff speed; any handoff above 3m/s is a target-form failure.
If the prewarmed checkpoint completes named demos at 16/16, 24/24, and 32/32
with zero red/collision/proximity/stuck events and unchanged canonical controls,
skip the 50-75k leg and run only a 20-update PPO stability confirmation.
Otherwise start one 50-75k PPO leg only if the probe is safe but still needs
policy refinement. Promote only after all floors pass. Yellow is the immediate
next implementation after promotion.

## Execution Outcome - 2026-07-13

The learned-servo prewarm passed all pre-registered route and MSE thresholds.
Its named-demo result was safely better than the accepted polish baseline but
did not meet the strict no-leg 16/24/32 clean shortcut, so the 75k consolidation
branch ran. All five nine-cell validations failed the hard floor; no PPO
checkpoint was selected.

The subsequent canonical multi-seed evaluation passed every sparse/dense floor
at 100% completion with zero safety or timeout events, but failed all stress
completion floors (95.83/96.81/93.75%). Stress 4l/48 also failed red and stuck
limits. The prewarm and PPO checkpoints are therefore not promoted. PPO
diagnostics additionally show persistent dense proximity/discharge erosion while
the gate remains frozen, localizing the training risk to legacy actor/shared-
feature drift rather than gate unfreezing.

Yellow remains parked. The next admissible candidate is prewarm-only
third-plus/deep-queue routing coverage followed by the same probe and canonical
matrix. See `RUN_SUMMARY.md`.
