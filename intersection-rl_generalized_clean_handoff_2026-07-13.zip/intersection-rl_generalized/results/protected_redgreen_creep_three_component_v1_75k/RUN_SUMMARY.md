# Three-Component Creep v1 75k Summary

Date: 2026-07-13
Status: CANONICAL PROMOTION REJECTED; PPO CONSOLIDATION REJECTED; NOT PROMOTED

## Implemented Mechanism

- Added an exact-migration brake/creep/go actor head (`actor_head=separate_accel_steer_creep_v3`).
- Added an observable queue-target-error gate feature and a zero-initialized learned creep-servo residual over speed and nearest available stopping distance.
- Made line-related queue geometry consistent in the labeler, gate feature, and creep action target: use the nearer of the stop-line target and lead-gap target.
- Added deterministic joint speed/distance servo prewarm coverage and supervised on-policy aggregation rounds.
- Expanded hard checkpoint selection to the full nine-cell sparse, dense, and stress floor.
- Runtime actions remain policy outputs. All geometry/routing/servo rules in this leg are training labels, auxiliary targets, or legal environment semantics; there is no action override.

## Accepted Prewarm

Checkpoint: `results/protected_redgreen_creep_three_component_v1_75k/checkpoints/protected_redgreen_creep_three_component_v1_75k_prewarm.npz`

Final aggregation round:

- Gate target weights (brake/creep/go): 0.922 / 0.906 / 1.000
- Gate argmax shares: 0.975 / 0.953 / 1.000
- Ambiguous shares: 0.021 / 0.049 / 0.000
- Rollout creep-servo MSE: 0.0029
- Joint-grid creep-servo MSE: 0.0035
- PPO started: no

## Full Probe

Seed 730, 60 simulated seconds, 3.5s all-red:

| Scenario | Accepted polish baseline | Prewarm candidate | Red | Collision | Proximity | Timeout | Stuck |
|---|---:|---:|---:|---:|---:|---:|---:|
| demo 2l/16 | 12/16 | 16/16 | 0 | 0 | 0 | 0 | 0 |
| demo 3l/24 | 19/24 | 22/24 | 1 | 0 | 0 | 1 | 0 |
| demo 4l/32 | 30/32 | 31/32 | 0 | 0 | 0 | 1 | 0 |

The remaining red event is vehicle 20 in the 3-lane case. It is a non-creep moving red approach, not a creep overshoot. The remaining timeout vehicles are 0 (3 lanes) and 4 (4 lanes); both are moving at 13.4m/s beyond the intersection and miss rear-bumper completion at the episode horizon. Creep handoff speed is bounded (maximum 1.24m/s), no creep overshoot occurs, and every listed brake-to-creep transition is a single normal re-engagement rather than repeated sawtooth.

Single-episode canonical controls remained clean at 2/16, 3/24, and 4/32. Full trajectories and the table are in `prewarm_servo_residual_full_probe/`.

## PPO Consolidation

The pre-registered safe-but-incomplete branch ran for 76,800 steps (25 updates) from the accepted prewarm checkpoint. Validation ran at updates 5, 10, 15, 20, and 25 against all nine hard-gated cells.

- Every validation returned `gate=0`.
- No best checkpoint was selected.
- PPO access to mixture-gate parameters remained frozen for the entire run.
- Final creep mean/target: +0.097 / +0.119.
- Final GO mean: +0.448.
- `protected_redgreen_creep_three_component_v1_75k_consolidation.npz` and periodic checkpoints are diagnostic only and must not be promoted.

### Consolidation Diagnosis

The prewarm checkpoint had not yet passed the nine-cell floor, so five failed
consolidation gates do not by themselves prove that PPO degraded a fully passing
candidate. The canonical evaluation below shows that the prewarm already misses
all three stress completion floors.

PPO nevertheless caused a separate, measurable dense-cell regression:

- Prewarm dense 2l/16: 100% complete, zero events, 11.13s discharge.
- Update 5 dense 2l/16, seed 730, 8 episodes: 100% complete but 0.25
  proximity events/episode and 11.78s discharge.
- Update 25 on the same check: 100% complete but 0.25 proximity
  events/episode and 12.18s discharge.
- Mean hold action weakened from about -0.295 at prewarm to -0.249 at update 5
  and -0.174 at update 25.

The gate-unfreeze hypothesis is ruled out: PPO access to gate-head parameters was
frozen for every update, gate CE accuracy stayed 0.930-0.991, and GO action stayed
near +0.45. Value learning also improved rather than diverged (explained variance
0.359 to 0.741). The primary observed mechanism is actor/shared-representation
erosion of brake/hold behavior under the clipped main optimizer. Mean effective
creep-auxiliary gradient was only 0.0048 (maximum 0.0132) while the mean main
gradient clip scale was 0.175. Gate CE uses detached shared features, so it cannot
anchor the actor trunk against PPO/value updates.

## Canonical Promotion Evaluation

Protocol: `dense_redgreen`, 3.5s all-red, 60s episodes. Sparse uses seeds
730/731 with 20 episodes per seed; dense uses 730/731/732 with 20 episodes per
seed; stress uses 730/731 with 10 episodes per seed.

| Regime | Cell | Complete % | Red/ep | Collision/ep | Proximity/ep | Stuck/ep | Moving timeout/ep | Discharge s | Gate |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| sparse | 2l/8 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 6.00 | pass |
| sparse | 3l/12 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 9.06 | pass |
| sparse | 4l/16 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 12.12 | pass |
| dense | 2l/16 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 11.13 | pass |
| dense | 3l/24 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 17.34 | pass |
| dense | 4l/32 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 23.85 | pass |
| stress | 2l/24 | 95.83 | 0.10 | 0.00 | 0.00 | 0.00 | 0.90 | 19.07 | fail |
| stress | 3l/36 | 96.81 | 0.20 | 0.00 | 0.00 | 0.05 | 0.90 | 28.80 | fail |
| stress | 4l/48 | 93.75 | 0.90 | 0.00 | 0.00 | 1.10 | 1.00 | 46.31 | fail |

All sparse/dense cells are exactly clean, but dense discharge is slower than the
polish floor (11.13/17.34/23.85s versus 10.29/15.01/19.83s). Stress completion
misses all three floors; 4l/48 also exceeds the red and stuck limits. Stress
traces expose a deep-queue routing coverage gap: brake argmax on stop-labelled
states is only about 44-58% in stress, versus 100% in dense, and third-plus queue
placement error rises to roughly 0.75-1.32m.

Artifacts: `promotion/summary_by_cell.csv`, `promotion/raw/`, and
`promotion/logs/`.

## Decision

Keep `protected_redgreen_front_bumper_polish_v1b_200k_selected.npz` as the
production default. Do not promote the prewarm or consolidation checkpoints, and
do not start yellow from either one. The prewarm remains a diagnostic/demo-density
artifact proving that dedicated learned creep routing and a learned servo solve the
far-upstream stationary-red failure without runtime action overrides.

The next red/green experiment, if the all-nine-cell promotion rule remains
mandatory, is prewarm-only deep-queue coverage: add deterministic third-plus
queue routing/transition states, leave PPO off, and rerun the probe plus canonical
matrix. Separately, yellow PPO must not begin until legacy brake/hold behavior is
protected from shared-trunk updates; gate freezing alone is insufficient because
the detached gate CE does not stabilize shared actor features.

Verification: full test suite passes (114 tests collected).
