# Dilemma-Latch Rebaseline Summary

Date: 2026-07-12
Status: ACCEPTED

## Decision

Keep the one-shot dilemma-zone clearance latch as permanent legal semantics. The
candidate policy and its actions are unchanged. Eligibility is decided only at an
actual permitted-phase transition, from the position and speed latched at that tick,
and only when stopping requires more than the physical 4.0 m/s^2 brake authority.

## Result

| Regime | Lanes/Cars | Completion | Red/ep | Collision/ep | Proximity/ep | Stuck/ep |
|---|---:|---:|---:|---:|---:|---:|
| sparse | 2/8 | 100.00% | 0.00 | 0.00 | 0.00 | 0.00 |
| sparse | 3/12 | 100.00% | 0.00 | 0.00 | 0.00 | 0.00 |
| sparse | 4/16 | 100.00% | 0.00 | 0.00 | 0.00 | 0.00 |
| dense | 2/16 | 100.00% | 0.00 | 0.00 | 0.00 | 0.00 |
| dense | 3/24 | 100.00% | 0.00 | 0.00 | 0.55 | 0.00 |
| dense | 4/32 | 100.00% | 0.00 | 0.00 | 0.00 | 0.00 |
| stress | 2/24 | 99.58% | 0.10 | 0.00 | 0.00 | 0.00 |
| stress | 3/36 | 99.17% | 0.30 | 0.00 | 0.00 | 0.00 |
| stress | 4/48 | 96.46% | 0.40 | 0.10 | 1.30 | 0.40 |

Sparse and dense metrics are effectively invariant except dense 4/32 improved from
99.90% completion and 0.03 red/episode to 100% and zero red. Stress red violations
fell from 4.0/4.5/2.8 to 0.1/0.3/0.4 per episode, with no broad collision,
proximity, stuck, discharge, or placement regression. The stress placement movement
is explained by the larger survivor sample after formerly illegal phase-end
crossings became legal clearers.

The named 2-lane demo seed 730 also changed vehicle 12 from a red failure into a
dilemma clearer. Its four stopped-short timeouts remained, as pre-registered; those
belong to the brake-component creep training leg.

Full data: summary_by_cell.csv.


## Same-Semantics Old-Selected Comparison

Old-selected was rerun with the identical latch-era protocol.

| Regime | Cell | Old completion/red/coll/prox/stuck | Polish completion/red/coll/prox/stuck |
|---|---:|---:|---:|
| sparse | 2/8 | 100.00 / 0 / 0 / 0 / 0 | 100.00 / 0 / 0 / 0 / 0 |
| sparse | 3/12 | 100.00 / 0 / 0 / 0 / 0 | 100.00 / 0 / 0 / 0 / 0 |
| sparse | 4/16 | 100.00 / 0 / 0 / 0 / 0 | 100.00 / 0 / 0 / 0 / 0 |
| dense | 2/16 | 100.00 / 0 / 0 / 0 / 0 | 100.00 / 0 / 0 / 0 / 0 |
| dense | 3/24 | 100.00 / 0 / 0 / 0 / 0 | 100.00 / 0 / 0.55 / 0 |
| dense | 4/32 | 100.00 / 0 / 0 / 0 / 0 | 100.00 / 0 / 0 / 0 / 0 |
| stress | 2/24 | 96.67 / 0.8 / 0 / 0 / 0 | 99.58 / 0.1 / 0 / 0 / 0 |
| stress | 3/36 | 98.06 / 0.7 / 0 / 0 / 0 | 99.17 / 0.3 / 0 / 0 / 0 |
| stress | 4/48 | 98.13 / 0.9 / 0 / 0 / 0 | 96.46 / 0.4 / 0.1 / 1.3 / 0.4 |

The latch also removes most historical old-selected failures. Full retirement is not
supported: polish is the better 2/3-lane stress policy, while old-selected is still
the better 4-lane extreme-stress fallback on completion, collision/proximity/stuck,
placement, and discharge (28.78s versus 39.83s). Its red rate remains higher
(0.9 versus 0.4 per episode).

Old-selected's broad fallback role is retired. Its retained role is specifically
4-lane/48-car extreme stress plus immutable backup. demo_safe remains frozen
regardless.
