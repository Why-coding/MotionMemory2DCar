# Dilemma-Latch Rebaseline Plan

Date: 2026-07-12
Status: PRE-REGISTERED BEFORE EVALUATION

Checkpoint: `protected_redgreen_front_bumper_polish_v1b_200k_selected.npz`

Protocol is the unchanged canonical front-bumper matrix: fixed 3.5s all-red,
60s episodes, sparse seeds 730/731 x20, dense seeds 730/731/732 x20, and stress
seeds 730/731 x10.

## Semantic Change

At a permitted-phase to all-red transition, a still-active vehicle before the line is
latched clearance-eligible only when its transition-tick state requires more than the
physical maximum braking authority of 4.0m/s^2. Eligibility is one-shot and is never
recomputed later in all-red.

## Pre-Registered Expectations

1. Near-identical canonical metrics in every cell because dilemma transitions are rare.
2. Red violations may decrease slightly, with corresponding small completion gains.
3. Stress red may move more than sparse/dense because assertive discharge reaches more
   phase boundaries.
4. Collision, proximity, placement, queue-gap, or broad discharge movement is an
   over-grant tripwire and rejects the latch.
5. Named demo seed 730 should convert vehicle 12 from red failure to dilemma clearer;
   stopped-short timeout behavior should remain until the creep leg.

The canonical sparse rows are not far-upstream coverage: they use the dense_redgreen
near-line low-speed task (0.2-1.0m lead target and 0-1m/s closed spawn). Their 100%
result therefore does not contradict the random-demo initial-red creep gap.


## Old-Selected Retirement Addendum (pre-registered 2026-07-12)

Old-selected is now rerun under the accepted one-shot dilemma latch with the exact
same cells, seeds, episode counts, and 3.5s clearance. Because it is slower and less
assertive than polish-selected, expect fewer dilemma-zone events and therefore a
smaller improvement than the promoted policy. Sparse/dense metrics should otherwise
remain stable. Retire its stress-fallback role if polish-selected remains better on
same-semantics stress completion and safety; keep demo_safe unchanged as immutable
backup regardless.
