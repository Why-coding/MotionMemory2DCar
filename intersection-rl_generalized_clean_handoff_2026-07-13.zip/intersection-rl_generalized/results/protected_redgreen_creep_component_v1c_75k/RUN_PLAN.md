# Red Creep Component v1c 75k Run Plan

Date: 2026-07-12
Status: PRE-REGISTERED BEFORE RELAUNCH

Controlled calibration after v1b component interference:

- stationary creep drills: 36% -> 18% total (6% per lane-count task)
- auxiliary action coefficient: 0.08 -> 0.05
- Huber beta 20 and value coefficient 0.1 retained
- all labels, targets, checkpoints, seed, clearance, gate, and GO KL unchanged
- canonical validation runs at the 75k endpoint; periodic update checkpoints remain

Promotion requires both modes to separate: creep component mean positive and moving
regular-brake component mean negative toward its negative target. The canonical and
named-demo gates remain unchanged.

    ../.venv/bin/python scripts/train_graph_multitask.py train       --behavior-stage red_creep_component       --init-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz       --reference-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz       --checkpoint results/protected_redgreen_creep_component_v1c_75k/checkpoints/protected_redgreen_creep_component_v1c_75k.npz       --steps 75000 --rollout-steps 256 --rollout-workers 12       --validation-workers 4 --validation-episodes 8 --validation-interval 25       --validation-patience 0 --checkpoint-interval 5 --max-cars 50 --seed 927
