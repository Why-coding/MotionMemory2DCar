# Red Creep Component v1c 75k Summary

Date: 2026-07-12
Status: COMPLETED; HARD GATES FAILED; NOT PROMOTED

## Mechanism Result

The reduced 18% stationary-drill mix preserved a distinct negative moving-brake
mode but did not make creep reliably positive. At update 25:

- creep component mean: -0.041, target +0.506
- moving-brake component mean: -0.065, target -0.196
- GO mean: +0.454
- gate routing: 1.000 brake argmax on STOP and 1.000 GO argmax on GO
- effective creep gradient: 0.042

The endpoint canonical validation score was -276508.6 and the regime gate failed.
No best checkpoint was saved.

## Named Demo Result

| Scenario | Completed | Failed | Red | Collision | Proximity | Stuck |
|---|---:|---:|---:|---:|---:|---:|
| demo_redgreen_2l | 16/16 | 0 | 0 | 0 | 0 | 0 |
| demo_redgreen_3l | 22/24 | 2 | 2 | 0 | 0 | 0 |
| demo_redgreen_4l | 30/32 | 2 | 2 | 0 | 0 | 0 |

The 2-lane episode completed only because the initially stopped vehicles eventually
received green; its measured creep brake mean remained -0.164. The 3/4-lane failures
were genuine red crossings, not timeouts or dilemma-latched clearers.

## Decision

Do not promote v1, v1b, or v1c. Keep
checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz as the
default sparse/dense policy.

The experiments localize the remaining design issue: one brake component cannot
reliably learn positive far-red creep and preserve strong negative approach braking
under the current shared routing. The next attempt should keep intent STOP but route
creep states independently to the GO component, with explicit red-creep gate targets
and action supervision. Green GO remains protected by the existing coefficient-1.0
GO reference KL. This uses the already healthy red-state GO output without changing
runtime purity or weakening red rules.
