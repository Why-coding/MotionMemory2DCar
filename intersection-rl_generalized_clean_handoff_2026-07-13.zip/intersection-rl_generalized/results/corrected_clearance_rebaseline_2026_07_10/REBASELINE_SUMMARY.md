# Corrected Clearance Re-baseline Summary

Date: 2026-07-10

This report compares the original selected demo checkpoint against the corrected-clearance keeper under the same corrected environment.

## Inputs

- Old selected: `checkpoints/protected_redgreen_generalized_v1_selected.npz`
- New keeper: `checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz`
- Eval mode: `dense_redgreen`
- All-red: `3.5s`
- Episode length: `60s`
- Raw CSVs: `results/corrected_clearance_rebaseline_2026_07_10/raw/*.csv`
- Aggregated CSV: `results/corrected_clearance_rebaseline_2026_07_10/summary_by_cell.csv`
- Pre-committed criteria: `results/corrected_clearance_rebaseline_2026_07_10/REBASELINE_PLAN.md`

## Verdict

Do not replace the original selected checkpoint as the general demo fallback yet.

The new keeper is much better under corrected semantics on sparse and 2/3-lane dense rows: it reaches 100% sparse completion with zero red violations, and it beats the old checkpoint on 2/3-lane dense completion and red safety. However, it has a repeatable 4-lane dense collision residual and poor 3-cars-per-lane stress behavior. That fails the pre-committed collision/stuck criterion for promotion.

Operationally:

- Keep `protected_redgreen_generalized_v1_selected.npz` as the most visually stable broad demo fallback for now.
- Keep `protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz` as the corrected-semantics safety candidate and training base/reference for the next polish run.
- The next training leg should target 4-lane dense collision/proximity and 3-per-lane stuck/discharge, not the gate/distribution architecture.

## Sparse Rows

| checkpoint | lanes/cars | seeds | eps | complete % | complete/100 green-s | red/ep | coll/ep | inside veh/ep | prox/ep | stuck/ep | queue err m | stopped far/ep | discharge delay s/ep |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| new_keeper | 2 / 8 | 730,731 | 40 | 100.00 | 18.82 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 5.11 |
| old_selected | 2 / 8 | 730,731 | 40 | 88.75 | 16.71 | 0.90 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 3.28 |
| new_keeper | 3 / 12 | 730,731 | 40 | 100.00 | 28.24 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 7.36 |
| old_selected | 3 / 12 | 730,731 | 40 | 89.17 | 25.18 | 1.30 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 4.66 |
| new_keeper | 4 / 16 | 730,731 | 40 | 100.00 | 37.65 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 9.61 |
| old_selected | 4 / 16 | 730,731 | 40 | 89.38 | 33.65 | 1.70 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 6.12 |

## Dense Rows

| checkpoint | lanes/cars | seeds | eps | complete % | complete/100 green-s | red/ep | coll/ep | inside veh/ep | prox/ep | stuck/ep | queue err m | stopped far/ep | discharge delay s/ep |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| new_keeper | 2 / 16 | 730,731,732 | 60 | 100.00 | 37.65 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 10.73 |
| old_selected | 2 / 16 | 730,731,732 | 60 | 93.75 | 35.29 | 1.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.51 | 104.35 | 7.18 |
| new_keeper | 3 / 24 | 730,731,732 | 60 | 97.22 | 54.90 | 0.00 | 0.05 | 0.10 | 0.00 | 0.00 | 0.34 | 60.00 | 17.17 |
| old_selected | 3 / 24 | 730,731,732 | 60 | 92.92 | 52.47 | 1.70 | 0.00 | 0.00 | 0.00 | 0.00 | 0.55 | 154.00 | 10.29 |
| new_keeper | 4 / 32 | 730,731,732 | 60 | 90.47 | 68.12 | 0.05 | 1.17 | 2.33 | 0.80 | 0.00 | 0.45 | 118.42 | 23.14 |
| old_selected | 4 / 32 | 730,731,732 | 60 | 93.44 | 70.35 | 2.10 | 0.00 | 0.00 | 0.00 | 0.00 | 0.52 | 185.30 | 13.52 |

## Stress Rows

| checkpoint | lanes/cars | seeds | eps | complete % | complete/100 green-s | red/ep | coll/ep | inside veh/ep | prox/ep | stuck/ep | queue err m | stopped far/ep | discharge delay s/ep |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| new_keeper | 2 / 24 | 730,731 | 20 | 79.58 | 44.94 | 2.70 | 0.10 | 0.20 | 0.15 | 1.30 | 2.41 | 457.05 | 26.49 |
| old_selected | 2 / 24 | 730,731 | 20 | 93.75 | 52.94 | 1.50 | 0.00 | 0.00 | 0.00 | 0.00 | 0.33 | 96.90 | 10.94 |
| new_keeper | 3 / 36 | 730,731 | 20 | 82.22 | 69.65 | 2.30 | 0.20 | 0.40 | 0.10 | 2.90 | 1.92 | 572.95 | 41.60 |
| old_selected | 3 / 36 | 730,731 | 20 | 93.33 | 79.06 | 2.40 | 0.00 | 0.00 | 0.00 | 0.00 | 0.32 | 125.80 | 15.24 |
| new_keeper | 4 / 48 | 730,731 | 20 | 82.08 | 92.71 | 2.80 | 0.70 | 1.00 | 1.00 | 3.20 | 2.00 | 852.70 | 65.42 |
| old_selected | 4 / 48 | 730,731 | 20 | 92.92 | 104.94 | 3.40 | 0.00 | 0.00 | 0.00 | 0.00 | 0.32 | 154.70 | 20.16 |

## Analysis

- Sparse corrected-semantics result is a major reversal of the old pre-fix verdict. The keeper averages 100.00% completion, 0.00 red/ep, and 0.00 collisions/ep at 2 lanes / 8 cars, while the old selected averages 88.75% completion and 0.90 red/ep.
- Dense 2/3 lanes favor the keeper: 100% completion and zero red at 2 lanes / 16 cars; about 97% completion and zero red at 3 lanes / 24 cars, with only 0.05 collisions/ep.
- Dense 4 lanes blocks promotion. Old selected averages 93.44% completion, 2.10 red/ep, and 0.00 collisions/ep. The keeper averages 90.47% completion, 0.05 red/ep, and 1.17 collisions/ep. This is a clear red-safety win but a collision/completion regression.
- Stress 3-cars-per-lane is not solved by the keeper. At 4 lanes / 48 cars, old selected averages 92.92% completion, 3.40 red/ep, and 0.00 collisions/ep. The keeper averages 82.08% completion, 2.80 red/ep, 0.70 collisions/ep, and 3.20 stuck timeouts/ep.
- Queue placement is no longer the visible blocker in sparse/dense rows under this eval protocol; the keeper's queue error is near zero through 2-lane dense and modest in 3/4-lane dense. The bigger blocker is dense interaction safety and stuck/discharge at stress density.

## Next Step

Run the planned polish/training leg, not a 1M blind run:

1. Use corrected clearance semantics with either `--all-red-seconds 4.5` for the next diagnostic run or randomized clearance in the 3.5-4.5s range once that knob is implemented.
2. Keep the verified mixture/gate setup.
3. Add proportional brake target and creep/re-approach relabel as planned.
4. Add/weight dense 4-lane and 3-cars-per-lane release/discharge scenarios carefully, while retaining sparse replay.
5. Selection must include 4-lane dense collision/proximity/stuck metrics, not only completion/red.

Promotion after the polish run should require beating the old selected checkpoint on dense 4-lane collisions/stuck while retaining the keeper's red-safety advantage.

## Blocking-Regime Diagnostic Addendum

See `diagnostics/BLOCKER_DIAGNOSTICS.md`. The follow-up diagnostic reframes the remaining work: sparse and 2/3-lane dense are solved by the keeper; 4l/32 collisions are mostly clearance-duration/left-arc related and improve sharply at 4.5s all-red; 3-cars-per-lane stress remains a follower-chain discharge/stuck problem that clearance alone does not solve.
