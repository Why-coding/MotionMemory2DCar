# Corrected Clearance Re-baseline Plan

Date: 2026-07-10

Purpose: compare the original selected demo checkpoint and the new corrected-clearance keeper under the same corrected environment before any new training.

## Checkpoints

- old selected: `checkpoints/protected_redgreen_generalized_v1_selected.npz`
- new keeper: `checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz`

## Fixed Eval Settings

- `--eval-mode dense_redgreen`
- `--all-red-seconds 3.5`
- `--episode-seconds 60`
- `--eval-workers 4`
- protected left, no yellow, no right-on-red as encoded in the current env/eval harness

## Matrix

Sparse rows:
- 2 lanes / 8 cars
- 3 lanes / 12 cars
- 4 lanes / 16 cars

Dense rows:
- 2 lanes / 16 cars
- 3 lanes / 24 cars
- 4 lanes / 32 cars

Stress rows:
- 2 lanes / 24 cars
- 3 lanes / 36 cars
- 4 lanes / 48 cars

## Episode Budget

- Sparse: 20 episodes per seed, seeds 730 and 731.
- Dense: 20 episodes per seed, seeds 730, 731, and 732. These rows drive promotion decisions.
- Stress: 10 episodes per seed, seeds 730 and 731. These rows diagnose robustness but do not alone decide promotion.

## Pre-committed Promotion Criteria

Promote the new keeper over `protected_redgreen_generalized_v1_selected.npz` as the demo fallback only if all of these hold under corrected semantics:

1. Sparse and dense completion are at least as good as the old selected checkpoint within normal seed noise.
2. Red violations are clearly lower, especially on dense rows.
3. Collisions, proximity, and stuck/moving timeouts do not regress under the identical protocol.
4. Queue placement is not visually embarrassing: lead stop error and cars-stopped-too-far metrics must not make demo video quality worse than the old selected checkpoint.
5. Throughput-normalized completion does not reveal that any raw completion advantage is only an artifact of all-red timing.

If the keeper wins safety but loses visibly on stop placement, keep both: old selected remains the visual demo fallback, keeper becomes the corrected-semantics safety candidate, and the next training leg is precision polish: proportional brake target plus creep/re-approach relabel.

If sparse completion remains poor under corrected semantics, stop before training and inspect sparse route/position diagnostics; do not launch a blind long run.
