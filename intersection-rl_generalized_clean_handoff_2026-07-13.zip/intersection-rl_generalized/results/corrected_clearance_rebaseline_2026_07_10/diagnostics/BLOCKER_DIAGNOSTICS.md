# Blocking-Regime Diagnostics

Date: 2026-07-10

Checkpoint: `checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz`

Purpose: localize the two remaining blockers after the corrected-clearance re-baseline: 4-lane dense collisions and 3-cars-per-lane stress stuck/discharge.

## Artifacts

- 4.5s clearance retest CSVs: `results/corrected_clearance_rebaseline_2026_07_10/diagnostics/clearance_4p5_retest/*.csv`
- Event sampler summary: `results/corrected_clearance_rebaseline_2026_07_10/diagnostics/targeted_diagnostics_summary.csv`
- Collision event samples: `results/corrected_clearance_rebaseline_2026_07_10/diagnostics/*_collisions.csv`
- Green-slow event samples: `results/corrected_clearance_rebaseline_2026_07_10/diagnostics/*_green_slow_events.csv`

## 4-Lane Dense Collision Branch

| checkpoint/config | complete % | red/ep | coll/ep | inside CE pairs/ep | inside non-CE pairs/ep | within-3s pairs/ep | stuck/ep |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| old selected, 3.5s | 93.44 | 2.10 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| keeper, 3.5s | 90.47 | 0.05 | 1.17 | 1.17 | 0.00 | 0.13 | 0.00 |
| keeper, 4.5s retest | 95.26 | 0.37 | 0.15 | 0.15 | 0.00 | 0.10 | 0.00 |

Interpretation:

- The 3.5s 4l/32 collisions are entirely inside-intersection and clearance-eligible in the official eval metrics, with zero non-clearance inside collision pairs.
- Increasing all-red from 3.5s to 4.5s improves completion from 90.47% to 95.26% and reduces collisions from 1.17/ep to 0.15/ep.
- Sampled collision route pairs at 4l/32 were mostly left-vs-straight: 16 (100.0%) of 16.
- This blocker is mostly a clearance-duration/config issue, not a general collision-policy failure. A 4.5s default or clearance randomization over roughly 3.5-4.5s should be tested before adding collision reward machinery.

## Stress Stuck / Discharge Branch

| cell | complete % | complete/100 green-s | red/ep | coll/ep | stuck/ep | moving timeout/ep | discharge delay s/ep |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| keeper 2l/24, 3.5s | 79.58 | 44.94 | 2.70 | 0.10 | 1.30 | 0.70 | 26.49 |
| keeper 3l/36, 3.5s | 82.22 | 69.65 | 2.30 | 0.20 | 2.90 | 0.80 | 41.60 |
| keeper 4l/48, 3.5s | 82.08 | 92.71 | 2.80 | 0.70 | 3.20 | 1.20 | 65.42 |
| keeper 4l/48, 4.5s retest | 80.83 | 98.90 | 2.80 | 0.50 | 3.40 | 2.00 | 72.08 |

Green-slow event samples by queue position:

| cell | sampled slow rows | lead | second | third+ | left route | straight route | avg lead dist | avg second dist | avg third+ dist |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2l/24 | 808 | 186 (23.0%) | 272 (33.7%) | 350 (43.3%) | 568 (70.3%) | 240 (29.7%) | 1.68 | 8.39 | 15.09 |
| 3l/36 | 1251 | 248 (19.8%) | 446 (35.7%) | 557 (44.5%) | 743 (59.4%) | 508 (40.6%) | 1.63 | 8.27 | 15.10 |
| 4l/48 | 4025 | 732 (18.2%) | 1350 (33.5%) | 1943 (48.3%) | 1706 (42.4%) | 2319 (57.6%) | 2.22 | 8.27 | 14.98 |

Interpretation:

- Stress is not fixed by 4.5s clearance: 4l/48 completion stays near 81%, red stays 2.8/ep, and stuck remains 3.4/ep.
- Stress stuck is follower-chain discharge, not lead-only release. In the 4l/48 event sample, third-plus vehicles account for 1943 (48.3%) of green-slow rows and second vehicles account for 1350 (33.5%); leads are only 732 (18.2%).
- The route split is not protected-left-only. In 4l/48, straight-route slow rows (2319 (57.6%)) slightly exceed left-route slow rows (1706 (42.4%)).
- The distances show geometric compounding: lead slow rows are near the line, second vehicles average about 8m back, and third-plus vehicles average about 15m back. This matches a queue-depth/discharge-chain bottleneck.

## Decision

- Treat sparse and 2/3-lane dense as solved under corrected semantics.
- For 4l/32, test/train with 4.5s clearance or randomized 3.5-4.5s clearance; do not add collision reward first.
- For 3-cars-per-lane stress, train specifically on dense follower discharge and stop-short recovery. This is where proportional brake target, creep/re-approach relabel, and stronger dense release task weighting belong.
- Keep selection gates regime-specific: sparse and 2/3-lane dense must not regress; 4l/32 collisions should stay near zero; stress stuck/discharge must improve before any 1M-scale run.
