# Protected Red/Green Mixture Green-Init v1 100k

Date: 2026-07-08

## Status

FAILED DIAGNOSTIC. Do not promote any checkpoint from this run to the top-level `checkpoints/` folder.

The run was intentionally interrupted after update 23 because the pre-committed gate criterion was clearly missed by update 20. Active artifacts are kept only under this `results/` directory.

## Implementation Tested

- `squashed_mixture` actor distribution.
- Longitudinal action uses a 2-component squashed Gaussian mixture:
  - component 0: brake
  - component 1: go
- Steering remains a single squashed Gaussian.
- Deterministic runtime/eval uses the argmax component mean, not the weighted mixture mean.
- Green squashed base warm-start copies the existing acceleration head into the go component.
- Brake component initializes with negative bias.
- Gate initializes go-biased.
- Training-only mixture gate CE routes stop/hold labels to brake and go labels to go.
- Gate CE uses detached shared features by default.
- Added train/eval diagnostics for action means, std, gate weights, gate argmax share, and ambiguous gate share.

## Verification Before Training

- `../.venv/bin/python -m py_compile intersection_rl/graph_ppo.py intersection_rl/config.py scripts/train_graph_multitask.py tests/test_ppo.py`: passed.
- `../.venv/bin/python -m pytest tests/test_ppo.py -q`: 8 passed.
- `../.venv/bin/python -m pytest -q`: 69 passed, 1 warning.

Warm-start smoke checkpoint:

`results/mixture_warmstart_smoke/protected_green_squashed_mixture_warmstart_smoke.npz`

Deterministic `left_green` warm-start eval, 12 episodes each:

| Lanes | Cars | Completed | Red | Collisions | Proximity | Stuck | Go weight on go labels |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2 | 4 | 100.0% | 0.0/ep | 0.0/ep | 0.0/ep | 0.0/ep | 0.622 |
| 3 | 6 | 100.0% | 0.0/ep | 0.0/ep | 0.0/ep | 0.0/ep | 0.622 |
| 4 | 8 | 100.0% | 0.0/ep | 0.0/ep | 0.0/ep | 0.0/ep | 0.622 |

## Training Run

Checkpoint root:

`results/protected_redgreen_mixture_greeninit_v1_100k/checkpoints/`

Top-level `checkpoints/` was not modified.

Key command settings:

- init/reference: `checkpoints/protected_green_squashed_base_v1_250k_selected.npz`
- behavior stage: `redgreen`
- action distribution: `squashed_mixture`
- steps target: 100000, interrupted at update 23 / 70656 rollout steps
- rollout workers: 12
- validation workers: 4
- validation scenarios: `2:4:60 3:6:60 4:8:60`
- LR: `3e-5`
- target KL: `0.01`
- entropy coefficient: `0.0015`
- mixture gate CE: start `0.8`, decay after update 20 to floor `0.05`

## Gate Diagnostics

| Update | Val Score | Rollout Clean | Rollout Red | Stop Action Mean | Go Action Mean | Brake Weight on Stop | Go Weight on Go | Ambiguous Stop Share |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | n/a | 18 | 123 | +0.390 | +0.474 | 0.379 | 0.621 | 0.000 |
| 5 | -77251 | 4 | 22 | +0.056 | +0.263 | 0.371 | 0.611 | 0.310 |
| 10 | -213309 | 0 | 1 | -0.113 | -0.107 | 0.379 | 0.621 | 0.000 |
| 15 | -92491 | 0 | 45 | +0.289 | +0.299 | 0.477 | 0.527 | 1.000 |
| 20 | -79928 | 3 | 83 | +0.440 | +0.371 | 0.468 | 0.565 | 1.000 |
| 23 | n/a | 4 | 68 | +0.320 | +0.384 | 0.489 | 0.545 | 1.000 |

The gate did not reach the target `brake_weight_stop_label_mean > 0.8`. By update 15-23 it hovered near 0.5 with `mixture_ambiguous_stop_label_share=1.0`, which is the chattering/averaging failure mode.

## Deterministic Best Eval

The saved `_best` checkpoint was also not usable:

| Lanes | Cars | Completed | Red Violations | Collisions | Proximity | Stop Action Mean | Brake Weight on Stop | Brake Argmax on Stop |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 4 | 27.08% | 2.92/ep | 0.0/ep | 0.0/ep | +0.407 | 0.405 | 0.000 |
| 3 | 6 | 22.22% | 4.67/ep | 0.0/ep | 0.0/ep | +0.396 | 0.404 | 0.000 |
| 4 | 8 | 29.17% | 5.67/ep | 0.0/ep | 0.0/ep | +0.397 | 0.404 | 0.000 |

## Diagnosis

The mixture distribution and warm-start wiring work, but the gate did not learn fast enough or cleanly enough under the current PPO update. It drifted from the go prior toward a near-0.5 ambiguous gate instead of saturating to brake on stop/hold states. This means the two components were still not assigned distinct responsibilities during mixed training.

The next change should target the gate, not reward weights:

1. Give the gate its own shortcut features, including closed-signal and movement-permitted flags, rather than reusing only the acceleration shortcut.
2. Initialize the gate shortcut with a strong learned prior: movement permitted -> go component, movement not permitted -> brake component. This is parameter initialization, not a runtime override, and the CE/PPO update can still change it.
3. Consider a separate higher LR or gate-only supervised warm-start for a few thousand samples before PPO, because the shared PPO LR of `3e-5` moved the gate too slowly.
4. Keep the go component anchored to the green reference during red/green training.

Do not run another long training job until the gate warm-start or gate optimizer change is implemented and smoke-checked.
