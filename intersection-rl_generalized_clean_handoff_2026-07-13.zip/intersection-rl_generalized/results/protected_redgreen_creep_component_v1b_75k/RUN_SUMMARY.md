# Red Creep Component v1b 75k Summary

Date: 2026-07-12
Status: ABORTED AT UPDATE 19 / 58,368 STEPS; NOT PROMOTED

Huber beta 20 and value coefficient 0.1 fixed gradient delivery. Effective creep
gradient increased from v1's roughly 0.001-0.010 to 0.07-0.28, and the creep mean
crossed positive by update 8 while GO and gate routing remained stable.

The 36% far-stationary drill share overcorrected the shared brake component:
aggregate STOP action also crossed positive and canonical validation failed at
updates 5, 10, and 15. By update 19 creep was +0.064 but STOP was +0.035, with
large red counts in rollout. The run was stopped before the redundant update-20
validation. No best checkpoint passed the hard gate.

v1c keeps the proven gradient correction but reduces stationary drills from 36% to
18%, reduces auxiliary coefficient from 0.08 to 0.05, and logs moving-brake
component/target metrics separately from creep.
