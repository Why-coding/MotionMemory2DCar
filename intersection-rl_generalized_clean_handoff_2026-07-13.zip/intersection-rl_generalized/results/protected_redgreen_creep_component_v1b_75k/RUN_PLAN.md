# Red Creep Component v1b 75k Run Plan

Date: 2026-07-12
Status: PRE-REGISTERED BEFORE RELAUNCH

All v1 task, label, target, checkpoint, seed, clearance, and gate settings remain
unchanged. The sole training-mechanics correction is the proven combination:

- value coefficient: 0.5 -> 0.1
- value loss: MSE -> Huber beta 20

This must raise effective_grad_creep_action materially above v1's roughly
0.001-0.010 while preserving saturated routing and GO >= +0.35. The original
canonical and named-demo promotion gates remain unchanged.

    ../.venv/bin/python scripts/train_graph_multitask.py train       --behavior-stage red_creep_component       --init-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz       --reference-checkpoint checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz       --checkpoint results/protected_redgreen_creep_component_v1b_75k/checkpoints/protected_redgreen_creep_component_v1b_75k.npz       --steps 75000 --rollout-steps 256 --rollout-workers 12       --validation-workers 4 --validation-episodes 8 --validation-interval 5       --validation-patience 0 --checkpoint-interval 5 --max-cars 50 --seed 927
