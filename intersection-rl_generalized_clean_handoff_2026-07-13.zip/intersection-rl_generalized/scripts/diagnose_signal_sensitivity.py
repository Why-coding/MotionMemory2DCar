from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
import torch

from intersection_rl.config import EnvConfig
from intersection_rl.env import IntersectionEnv
from intersection_rl.geometry import Polyline, build_route_path
from intersection_rl.graph_observation import GraphObserver
from intersection_rl.graph_ppo import GraphActorCritic


PHASE_TIMES = {
    "green": lambda env: env.config.left_signal_green_seconds + 1.0,
    "yellow": lambda env: env.config.left_signal_green_seconds + env.config.signal_green_seconds + 0.5,
    "red": lambda env: (
        env.config.left_signal_green_seconds
        + env.config.signal_green_seconds
        + env.config.signal_yellow_seconds
        + env.config.left_signal_green_seconds
        + 1.0
    ),
}


def checkpoint_metadata(path: Path) -> dict[str, int]:
    data = np.load(path, allow_pickle=False)
    return {
        "ego_size": int(data["ego_size"]),
        "node_size": int(data["node_size"]),
        "edge_size": int(data["edge_size"]),
        "max_nodes": int(data["max_nodes"]),
        "hidden_size": int(data["hidden_size"]),
        "action_size": int(data["action_size"]),
        "layers": int(data["layers"]),
    }


def configure_vehicle(env: IntersectionEnv, *, phase: str, distance: float, speed: float, route: str) -> None:
    env.elapsed_seconds = float(PHASE_TIMES[phase](env))
    vehicle = env.vehicles[0]
    vehicle.approach = "N"
    vehicle.route = route
    vehicle.lane = 0 if route == "left" else min(1, env.episode_lanes_per_approach - 1)
    vehicle.destination_lane = env._destination_lane_for_route(vehicle.lane, route)
    vehicle.path = Polyline(
        build_route_path(
            vehicle.approach,
            vehicle.lane,
            vehicle.route,
            env.config.lane_width,
            env.config.road_length,
            env.config.intersection_half_size,
            env.episode_lanes_per_approach,
            vehicle.destination_lane,
        )
    )
    vehicle.stop_progress, _ = vehicle.path.project(vehicle.path.points[1])
    vehicle.progress = max(0.0, vehicle.stop_progress - distance)
    vehicle.speed = speed
    vehicle.acceleration = 0.0
    vehicle.steering = 0.0
    vehicle.lateral_offset = 0.0
    vehicle.active = True
    vehicle.failed = False
    vehicle.collided = False
    vehicle.legal_stall_seconds = 0.0
    vehicle.blocked_stall_seconds = 0.0
    env._predictive_cache_key = None
    env._predictive_cache = None
    env._route_conflict_cache.clear()


def evaluate_case(model: GraphActorCritic, observer: GraphObserver, env: IntersectionEnv) -> dict[str, float | str]:
    observation = observer.encode(env)
    vehicle = env.vehicles[0]
    with torch.no_grad():
        ego = torch.as_tensor(observation["ego"], dtype=torch.float32, device=model.device)
        nodes = torch.as_tensor(observation["nodes"], dtype=torch.float32, device=model.device)
        edges = torch.as_tensor(observation["edges"], dtype=torch.float32, device=model.device)
        node_mask = torch.as_tensor(observation["node_mask"], dtype=torch.float32, device=model.device)
        mean, values, intent_logits = model._forward_tensor(ego, nodes, edges, node_mask)
        probs = torch.softmax(intent_logits[vehicle.vehicle_id], dim=-1).cpu().numpy()
        action = mean[vehicle.vehicle_id].cpu().numpy()
        value = float(values[vehicle.vehicle_id].cpu().item())
    info = env._get_info(np.zeros(env.config.max_cars, dtype=np.float32))
    label = int(info["intent_labels"][vehicle.vehicle_id])
    pred = int(np.argmax(probs))
    return {
        "signal_phase": env._signal_phase()[0],
        "movement_green": float(env._movement_has_green(vehicle)),
        "movement_yellow": float(env._movement_has_yellow(vehicle)),
        "movement_permitted": float(env._movement_permitted(vehicle)),
        "label": env.INTENT_NAMES[label] if label >= 0 else "ignore",
        "predicted_intent": env.INTENT_NAMES[pred],
        "accel_mean": float(action[0]),
        "steer_mean": float(action[1]),
        "value": value,
        "p_stop": float(probs[env.INTENT_STOP]),
        "p_hold": float(probs[env.INTENT_HOLD]),
        "p_go": float(probs[env.INTENT_GO]),
        "p_yield": float(probs[env.INTENT_YIELD]),
    }


def run(args: argparse.Namespace) -> None:
    metadata = checkpoint_metadata(args.checkpoint)
    observer = GraphObserver(max_vehicle_nodes=args.max_cars)
    model = GraphActorCritic(
        metadata["ego_size"],
        metadata["node_size"],
        metadata["edge_size"],
        metadata["max_nodes"],
        hidden_size=metadata["hidden_size"],
        action_size=metadata["action_size"],
        layers=metadata["layers"],
        seed=args.seed,
    )
    model.load(args.checkpoint)
    model.eval()

    env = IntersectionEnv(
        EnvConfig(
            max_cars=args.max_cars,
            min_cars=1,
            lanes_per_approach=args.lanes,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            strict_lane_mapping=True,
            safety_filter_enabled=False,
            intersection_reservation_enabled=False,
            curriculum_enabled=False,
            curriculum_progression_enabled=False,
            initial_lateral_noise=0.0,
            randomize_initial_signal_phase=False,
            seed=args.seed,
        )
    )

    rows: list[dict[str, float | str]] = []
    try:
        for route in args.routes:
            for distance in args.distances:
                for speed in args.speeds:
                    for phase in args.phases:
                        env.reset(seed=args.seed, options={"vehicle_count": 1})
                        configure_vehicle(env, phase=phase, distance=distance, speed=speed, route=route)
                        row = {
                            "checkpoint": str(args.checkpoint),
                            "route": route,
                            "phase_request": phase,
                            "distance_to_stop": float(distance),
                            "speed": float(speed),
                            **evaluate_case(model, observer, env),
                        }
                        rows.append(row)
    finally:
        env.close()

    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    print(f"wrote={args.output_csv} rows={len(rows)}")
    for row in rows:
        print(
            " ".join(
                f"{key}={row[key]}"
                for key in (
                    "route",
                    "phase_request",
                    "signal_phase",
                    "distance_to_stop",
                    "speed",
                    "label",
                    "predicted_intent",
                    "accel_mean",
                    "p_stop",
                    "p_hold",
                    "p_go",
                )
            )
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Diagnose whether graph policy actions/logits respond to traffic signal changes.")
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("--output-csv", type=Path, required=True)
    parser.add_argument("--max-cars", type=int, default=50)
    parser.add_argument("--lanes", type=int, default=2)
    parser.add_argument("--distances", type=float, nargs="+", default=[6.0, 15.0, 30.0])
    parser.add_argument("--speeds", type=float, nargs="+", default=[0.0, 2.0, 6.0])
    parser.add_argument("--phases", nargs="+", choices=tuple(PHASE_TIMES), default=["green", "yellow", "red"])
    parser.add_argument("--routes", nargs="+", choices=["straight", "left"], default=["straight"])
    parser.add_argument("--seed", type=int, default=7)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
