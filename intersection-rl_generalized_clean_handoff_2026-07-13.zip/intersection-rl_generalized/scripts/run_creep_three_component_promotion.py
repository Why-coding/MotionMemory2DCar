from __future__ import annotations

import run_front_bumper_rebaseline as canonical


canonical.RESULT_ROOT = (
    canonical.PROJECT_ROOT
    / "results/protected_redgreen_creep_three_component_v1_75k/promotion"
)
canonical.CHECKPOINTS = {
    "creep_three_component_prewarm": (
        "results/protected_redgreen_creep_three_component_v1_75k/checkpoints/"
        "protected_redgreen_creep_three_component_v1_75k_prewarm.npz"
    ),
}


if __name__ == "__main__":
    canonical.main()
