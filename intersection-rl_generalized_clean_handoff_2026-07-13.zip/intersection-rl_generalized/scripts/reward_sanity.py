from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from intersection_rl.config import EnvConfig


def estimate_cases(config: EnvConfig) -> list[tuple[str, float, str]]:
    # These are deliberately simple paper estimates. They are not simulator rollouts.
    red_approach_steps = 18
    red_hold_steps = 25
    green_drive_steps = 70
    green_stuck_steps = 50
    red_far_idle_steps = 80

    red_approach_step = config.queue_approach_reward * 0.65
    red_hold_step = (
        config.queue_stop_position_reward
        + config.closed_signal_stop_window_zero_speed_reward
        + config.closed_signal_hold_reward
    )
    green_drive_step = config.progress_reward * 0.85 + config.permitted_speed_reward * 0.55
    green_release_step = config.green_queue_progress_reward * 0.35 + config.permitted_acceleration_reward * 0.50

    correct = (
        red_approach_steps * red_approach_step
        + red_hold_steps * red_hold_step
        + green_drive_steps * green_drive_step
        + 12 * green_release_step
        + config.clean_completion_bonus
    )

    red_far_idle_step = -config.queue_far_idle_penalty * 0.9
    green_stuck_step = -(
        config.green_zero_speed_penalty
        + config.permitted_idle_penalty
        + config.legal_stall_penalty
        + config.green_queue_idle_penalty
    )
    all_brake = (
        red_far_idle_steps * red_far_idle_step
        + green_stuck_steps * green_stuck_step
        - config.timeout_failure_penalty
    )

    red_violation = (
        25 * (config.progress_reward * 0.8 + config.permitted_speed_reward * 0.5)
        - config.red_light_violation_penalty
    )

    green_stuck = green_stuck_steps * green_stuck_step - config.timeout_failure_penalty

    rough_slow_complete = (
        15 * red_approach_step
        + 20 * red_hold_step
        + 90 * (config.progress_reward * 0.45 + config.permitted_speed_reward * 0.25)
        + config.clean_completion_bonus
    )

    coefficient = config.closed_signal_stop_potential_coefficient or 0.45
    potential_good_approach_step = coefficient * 0.45
    potential_far_hold_step = coefficient * (1.0 - config.closed_signal_stop_potential_gamma) * 20.0
    potential_target_hold_step = (
        config.closed_signal_stop_potential_hold_reward
        + config.closed_signal_hold_reward
        - config.closed_signal_stop_potential_speed_penalty * 0.0
    )

    return [
        ("clean_stop_release_complete", correct, "should be strongly positive"),
        ("rough_slow_but_complete", rough_slow_complete, "should remain positive"),
        ("red_violation_no_collision", red_violation, "should be negative"),
        ("stop_far_then_timeout", all_brake, "should be clearly negative"),
        ("green_stuck_timeout", green_stuck, "should be clearly negative"),
        ("potential_good_approach_step", potential_good_approach_step, "approx reward for closing stop-target error by 0.45m"),
        ("potential_far_hold_step", potential_far_hold_step, "small gamma telescoping term for holding 20m from target"),
        ("potential_target_hold_step", potential_target_hold_step, "small stopped-in-window reward retained under potential shaping"),
    ]


def main() -> None:
    config = EnvConfig(closed_signal_stop_potential_coefficient=0.45)
    print("Normalized reward sanity estimates")
    print(f"dt={config.dt} max_speed={config.max_speed} max_acceleration={config.max_acceleration}")
    print(f"completion_bonus={config.clean_completion_bonus} timeout_penalty={config.timeout_failure_penalty} red_penalty={config.red_light_violation_penalty}")
    for name, total, note in estimate_cases(config):
        print(f"{name}: total={total:.1f} ({note})")


if __name__ == "__main__":
    main()
