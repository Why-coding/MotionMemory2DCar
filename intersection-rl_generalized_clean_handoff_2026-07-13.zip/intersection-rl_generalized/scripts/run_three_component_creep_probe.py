"""Probe three-component creep routing and speed-servo behavior."""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from pathlib import Path
import sys

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
project_root_text = str(PROJECT_ROOT)
sys.path[:] = [entry for entry in sys.path if entry != project_root_text]
sys.path.insert(0, project_root_text)

from intersection_rl.cli import load_graph_model
from intersection_rl.multitask import MultiTaskIntersectionEnv
from intersection_rl.runtime import assert_project_runtime, print_provenance_banner
from intersection_rl.scenarios import (
    DEMO_SCENARIOS,
    build_demo_redgreen_env,
    policy_env_config,
    redgreen_task,
)


assert_project_runtime(PROJECT_ROOT)


@dataclass(frozen=True, slots=True)
class ProbeCase:
    name: str
    lanes: int
    cars: int
    dense: bool


CASES = (
    ProbeCase("demo_redgreen_2l", 2, 16, False),
    ProbeCase("demo_redgreen_3l", 3, 24, False),
    ProbeCase("demo_redgreen_4l", 4, 32, False),
    ProbeCase("canonical_dense_2l", 2, 16, True),
    ProbeCase("canonical_dense_restop_3l", 3, 24, True),
    ProbeCase("canonical_dense_4l", 4, 32, True),
)


def creep_route_state(env, vehicle) -> tuple[str, bool, bool]:
    labels = env._intent_labels()
    should_brake, _ = env._closed_signal_brake_label_state(vehicle)
    creep_latched = bool(env._intent_creep_latched[vehicle.vehicle_id])
    route_label = int(env._component_route_labels(labels)[vehicle.vehicle_id])
    route = {
        0: "brake_handoff" if creep_latched else "brake",
        1: "creep_window",
        2: "go",
    }.get(route_label, "native")
    return route, should_brake, creep_latched


def build_env(case: ProbeCase, seed: int) -> MultiTaskIntersectionEnv:
    if case.name in DEMO_SCENARIOS:
        return build_demo_redgreen_env(
            DEMO_SCENARIOS[case.name],
            max_cars=50,
            episode_seconds=60.0,
            all_red_seconds=3.5,
        )
    config = policy_env_config(
        max_cars=50,
        lanes=case.lanes,
        seed=seed,
        episode_seconds=60.0,
        all_red_seconds=3.5,
    )
    config.intent_creep_reapproach_enabled = True
    task = redgreen_task(
        name=case.name,
        lanes=case.lanes,
        cars=case.cars,
        episode_seconds=60.0,
        dense=case.dense,
    )
    return MultiTaskIntersectionEnv(config, tasks=(task,))


def run_case(
    case: ProbeCase,
    *,
    checkpoint: Path,
    seed: int,
    force_creep: bool,
    output_dir: Path,
) -> dict[str, object]:
    env = build_env(case, seed)
    model, observer = load_graph_model(checkpoint)
    trajectory_rows: list[dict[str, object]] = []
    affected: set[int] = set()
    overshoots: set[int] = set()
    envelope_trip: dict[int, tuple[float, float, float]] = {}
    creep_to_brake_handoff: dict[int, tuple[float, float, float, str]] = {}
    final_stop_distance: dict[int, float] = {}
    previous_route: dict[int, str] = {}
    brake_to_creep: dict[int, int] = {}
    max_closed_speed: dict[int, float] = {}
    red_vehicle_ids: set[int] = set()
    timeout_vehicle_ids: set[int] = set()
    event_totals = {
        "red": 0,
        "collisions": 0,
        "proximity": 0,
        "timeouts": 0,
        "stuck": 0,
    }
    try:
        _, info = env.reset(seed=seed)
        done = False
        while not done:
            labels = env._intent_labels()
            graph_observation = observer.encode(env)
            actions, _, _ = model.act(graph_observation, deterministic=True)
            weights = model.action_mixture_weights(graph_observation)
            components = model.action_component_means(graph_observation)
            if weights is None or components is None:
                raise ValueError("Three-component creep probe requires a squashed-mixture checkpoint")

            phase, _ = env._signal_phase()
            for vehicle in env.vehicles:
                if not vehicle.active:
                    continue
                vehicle_id = vehicle.vehicle_id
                distance = env._distance_to_stop_line(vehicle)
                target_error, _ = env._closed_signal_stop_target_error(vehicle)
                _, stopped_near_target = (
                    env._closed_signal_brake_label_state(vehicle)
                )
                route, should_brake, creep_latched = creep_route_state(
                    env, vehicle
                )
                creep_window = route == "creep_window"
                brake_handoff = route == "brake_handoff"
                if creep_latched:
                    affected.add(vehicle_id)
                    max_closed_speed[vehicle_id] = max(
                        max_closed_speed.get(vehicle_id, 0.0),
                        float(vehicle.speed),
                    )
                if brake_handoff and vehicle_id not in envelope_trip:
                    envelope_trip[vehicle_id] = (
                        float(env.elapsed_seconds),
                        float(distance),
                        float(vehicle.speed),
                    )
                prior_route = previous_route.get(vehicle_id)
                creep_handoff = (
                    prior_route == "creep_window"
                    and route in {"brake", "brake_handoff"}
                )
                if creep_handoff and vehicle_id not in creep_to_brake_handoff:
                    creep_to_brake_handoff[vehicle_id] = (
                        float(env.elapsed_seconds),
                        float(distance),
                        float(vehicle.speed),
                        route,
                    )
                if (
                    prior_route in {"brake", "brake_handoff"}
                    and route == "creep_window"
                ):
                    brake_to_creep[vehicle_id] = brake_to_creep.get(vehicle_id, 0) + 1
                previous_route[vehicle_id] = route

                base_action = float(actions[vehicle_id, 0])
                if force_creep and creep_window:
                    actions[vehicle_id, 0] = components[
                        vehicle_id, model.CREEP_COMPONENT
                    ]
                trajectory_rows.append(
                    {
                        "case": case.name,
                        "mode": "forced_creep" if force_creep else "baseline",
                        "time": round(float(env.elapsed_seconds), 3),
                        "vehicle_id": vehicle_id,
                        "phase": phase,
                        "distance_to_stop": float(distance),
                        "target_error": (
                            "" if target_error is None else float(target_error)
                        ),
                        "speed": float(vehicle.speed),
                        "intent_label": int(labels[vehicle_id]),
                        "creep_latched": int(creep_latched),
                        "should_brake": int(should_brake),
                        "stopped_near_target": int(stopped_near_target),
                        "route": route,
                        "creep_to_brake_handoff": int(creep_handoff),
                        "base_action": base_action,
                        "applied_action": float(actions[vehicle_id, 0]),
                        "brake_component": float(components[vehicle_id, model.BRAKE_COMPONENT]),
                        "creep_component": float(components[vehicle_id, model.CREEP_COMPONENT]),
                        "go_component": float(components[vehicle_id, model.GO_COMPONENT]),
                        "brake_weight": float(weights[vehicle_id, model.BRAKE_COMPONENT]),
                        "creep_weight": float(weights[vehicle_id, model.CREEP_COMPONENT]),
                        "go_weight": float(weights[vehicle_id, model.GO_COMPONENT]),
                    }
                )

            active_before_step = {
                vehicle.vehicle_id for vehicle in env.vehicles if vehicle.active
            }
            _, _, terminated, truncated, info = env.step(actions)
            event_totals["red"] += int(info.get("red_light_violations", 0))
            event_totals["collisions"] += int(info.get("collisions", 0))
            event_totals["proximity"] += int(info.get("proximity_events", 0))
            event_totals["timeouts"] += int(info.get("timeout_failures", 0))
            event_totals["stuck"] += int(info.get("stuck_timeout_failures", 0))
            for vehicle in env.vehicles:
                vehicle_id = vehicle.vehicle_id
                if (
                    vehicle_id in active_before_step
                    and not vehicle.active
                    and vehicle.failed
                ):
                    if vehicle.crossed_on_red:
                        red_vehicle_ids.add(vehicle_id)
                    elif truncated:
                        timeout_vehicle_ids.add(vehicle_id)
                distance = env._distance_to_stop_line(vehicle)
                if vehicle_id in affected and vehicle.crossed_on_red:
                    overshoots.add(vehicle_id)
                target_error, _ = env._closed_signal_stop_target_error(vehicle)
                if (
                    vehicle_id in affected
                    and target_error is not None
                    and abs(target_error)
                    <= env.config.intent_stop_label_target_tolerance
                    and vehicle.speed < 0.5
                ):
                    final_stop_distance.setdefault(vehicle_id, float(distance))
            done = terminated or truncated
    finally:
        env.close()

    mode = "forced_creep" if force_creep else "baseline"
    trajectory_path = output_dir / f"{case.name}_{mode}_trajectory.csv"
    trajectory_path.parent.mkdir(parents=True, exist_ok=True)
    with trajectory_path.open("w", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(trajectory_rows[0]))
        writer.writeheader()
        writer.writerows(trajectory_rows)

    trip_distances = [item[1] for item in envelope_trip.values()]
    trip_speeds = [item[2] for item in envelope_trip.values()]
    handoff_distances = [item[1] for item in creep_to_brake_handoff.values()]
    handoff_speeds = [item[2] for item in creep_to_brake_handoff.values()]
    return {
        "case": case.name,
        "mode": mode,
        "completed": int(info.get("completed_clean", 0)),
        "failed": int(info.get("failed_vehicles", 0)),
        **event_totals,
        "red_vehicle_ids": ",".join(map(str, sorted(red_vehicle_ids))),
        "timeout_vehicle_ids": ",".join(map(str, sorted(timeout_vehicle_ids))),
        "affected_vehicles": len(affected),
        "envelope_trips": len(envelope_trip),
        "mean_trip_distance": (
            float(np.mean(trip_distances)) if trip_distances else ""
        ),
        "mean_trip_speed": float(np.mean(trip_speeds)) if trip_speeds else "",
        "creep_to_brake_handoffs": len(creep_to_brake_handoff),
        "mean_handoff_distance": (
            float(np.mean(handoff_distances)) if handoff_distances else ""
        ),
        "mean_handoff_speed": (
            float(np.mean(handoff_speeds)) if handoff_speeds else ""
        ),
        "max_handoff_speed": max(handoff_speeds) if handoff_speeds else "",
        "handoff_above_3mps_vehicles": ",".join(
            str(vehicle_id)
            for vehicle_id, item in sorted(creep_to_brake_handoff.items())
            if item[2] > 3.0
        ),
        "overshoot_vehicles": ",".join(map(str, sorted(overshoots))),
        "oscillating_vehicles": ",".join(
            str(vehicle_id)
            for vehicle_id, count in sorted(brake_to_creep.items())
            if count > 1
        ),
        "brake_to_creep_transitions": sum(brake_to_creep.values()),
        "mean_final_stop_distance": (
            float(np.mean(list(final_stop_distance.values())))
            if final_stop_distance
            else ""
        ),
        "max_closed_speed": (
            max(max_closed_speed.values()) if max_closed_speed else ""
        ),
        "trajectory_csv": str(
            trajectory_path.relative_to(PROJECT_ROOT)
            if trajectory_path.is_absolute()
            else trajectory_path
        ),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path(
            "checkpoints/"
            "protected_redgreen_front_bumper_polish_v1b_200k_selected.npz"
        ),
    )
    parser.add_argument("--seed", type=int, default=730)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/three_component_creep_probe"),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    checkpoint = args.checkpoint
    output_dir = args.output_dir
    print_provenance_banner(
        command="three_component_creep_probe",
        project_root=PROJECT_ROOT,
        checkpoint=checkpoint,
        seed=args.seed,
        all_red_seconds=3.5,
        extra={"cases": len(CASES), "modes": "baseline,forced_creep"},
    )
    rows = [
        run_case(
            case,
            checkpoint=checkpoint,
            seed=args.seed,
            force_creep=force_creep,
            output_dir=output_dir,
        )
        for case in CASES
        for force_creep in (False, True)
    ]
    summary_path = output_dir / "summary.csv"
    with summary_path.open("w", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    for row in rows:
        print(" ".join(f"{key}={value}" for key, value in row.items()))
    print(f"summary={summary_path}")


if __name__ == "__main__":
    main()
