from __future__ import annotations

import argparse
import csv
import sys
from dataclasses import replace as dataclass_replace
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
project_root_text = str(PROJECT_ROOT)
sys.path[:] = [entry for entry in sys.path if entry != project_root_text]
sys.path.insert(0, project_root_text)

from intersection_rl.config import EnvConfig, PPOConfig
from intersection_rl.env import IntersectionEnv
from intersection_rl.graph_observation import GraphObserver
from intersection_rl.graph_ppo import GraphActorCritic, GraphPPOTrainer
from intersection_rl.multitask import DEFAULT_TASKS, MultiTaskIntersectionEnv, ScenarioTask
from intersection_rl.runtime import assert_project_runtime, print_provenance_banner
from intersection_rl.scenarios import policy_env_config, redgreen_task


assert_project_runtime(PROJECT_ROOT)


LEGACY_REPLAY_TASKS = ["red_heavy", "yellow_stop_drill", "stop_line_drill", "dense_queue_stop"]
DEFAULT_VALIDATION_SCENARIOS = ["2:8:60", "2:24:120", "3:24:120", "3:36:150", "4:30:150", "4:50:150"]
RED_VALIDATION_SCENARIOS = ["2:4:60", "3:6:60", "4:8:60"]
LEAD_RED_STOP_VALIDATION_SCENARIOS = ["2:4:60", "3:6:60", "4:8:60"]
LEAD_RED_APPROACH_VALIDATION_SCENARIOS = ["2:4:60", "3:6:60", "4:8:60"]
RED_QUEUE_VALIDATION_SCENARIOS = ["2:8:60", "3:12:60", "4:16:60", "2:16:75", "3:24:75", "4:32:75"]
GREEN_VALIDATION_SCENARIOS = ["2:4:60", "3:6:60", "4:8:60"]
LEFT_GREEN_VALIDATION_SCENARIOS = ["2:4:60", "3:4:60", "4:4:60"]
LEFT_RELEASE_VALIDATION_SCENARIOS = ["2:4:60", "3:4:60", "4:4:60"]
REDGREEN_VALIDATION_SCENARIOS = ["2:8:60", "3:12:60", "4:16:60"]
DENSE_REDGREEN_VALIDATION_SCENARIOS = ["2:24:60", "3:36:60", "4:48:60"]
QUEUE2_REDGREEN_VALIDATION_SCENARIOS = ["2:16:60", "3:24:60", "4:32:60"]
DENSITY_SHAPING_VALIDATION_SCENARIOS = [
    "2:8:60", "3:12:60", "4:16:60",
    "2:16:60", "3:24:60", "4:32:60",
    "2:24:60", "3:36:60", "4:48:60",
]
RIGHT_ON_RED_VALIDATION_SCENARIOS = ["2:8:30", "3:12:30", "4:16:30"]

BEHAVIOR_STAGE_TASKS = {
    "green": [
        "green_basic",
        "green_queue_basic",
    ],
    "protected_green": [
        "green_basic",
        "green_queue_basic",
        "left_green_basic",
        "left_green_queue_basic",
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
    ],
    "lead_red_approach": [
        "lead_red_approach_2l",
        "lead_red_approach_3l",
        "lead_red_approach_4l",
        "lead_red_stop_precision_2l",
        "lead_red_stop_precision_3l",
        "lead_red_stop_precision_4l",
        "green_basic",
        "green_queue_basic",
        "left_green_basic",
    ],
    "lead_red_stop": [
        "lead_red_stop_precision_2l",
        "lead_red_stop_precision_3l",
        "lead_red_stop_precision_4l",
        "green_basic",
        "green_queue_basic",
        "left_green_basic",
    ],
    "red": [
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
    ],
    "red_squashed_probe": [
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "red_queue_1_per_lane_2l",
        "red_queue_1_per_lane_3l",
        "red_queue_1_per_lane_4l",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
    ],
    "red_queue": [
        "red_queue_1_per_lane_2l",
        "red_queue_1_per_lane_3l",
        "red_queue_1_per_lane_4l",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "green_queue_discharge",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "redgreen_aux_warmstart_from_scratch": [
        "green_basic",
        "green_queue_basic",
        "left_green_basic",
        "left_green_queue_basic",
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "red_queue_1_per_lane_2l",
        "red_queue_1_per_lane_3l",
        "red_queue_1_per_lane_4l",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
        "green_queue_discharge",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
        "redgreen_2_per_lane_2l",
        "redgreen_2_per_lane_3l",
        "redgreen_2_per_lane_4l",
    ],
    "redgreen_mixed_from_scratch": [
        "green_basic",
        "green_queue_basic",
        "left_green_basic",
        "left_green_queue_basic",
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "red_queue_1_per_lane_2l",
        "red_queue_1_per_lane_3l",
        "red_queue_1_per_lane_4l",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
        "green_queue_discharge",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
        "redgreen_2_per_lane_2l",
        "redgreen_2_per_lane_3l",
        "redgreen_2_per_lane_4l",
    ],
    "redgreen_queue_2_per_lane": [
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
        "green_queue_discharge",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
        "redgreen_2_per_lane_2l",
        "redgreen_2_per_lane_3l",
        "redgreen_2_per_lane_4l",
    ],
    "dense_redgreen_queue": [
        "dense_green_discharge_3_per_green_lane_2l",
        "dense_green_discharge_3_per_green_lane_3l",
        "dense_green_discharge_3_per_green_lane_4l",
        "dense_red_queue_3_per_lane_2l",
        "dense_red_queue_3_per_lane_3l",
        "dense_red_queue_3_per_lane_4l",
        "dense_redgreen_release_3_per_lane_2l",
        "dense_redgreen_release_3_per_lane_3l",
        "dense_redgreen_release_3_per_lane_4l",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
        "redgreen_2_per_lane_2l",
        "redgreen_2_per_lane_3l",
        "redgreen_2_per_lane_4l",
    ],
    "left_release": [
        "left_redgreen_release",
        "left_green_basic",
        "left_green_queue_basic",
    ],
    "right_on_red": [
        "right_on_red_basic",
        "right_on_red_conflict",
        "right_on_red_queue",
        "right_on_red_mixed",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "redgreen": [
        "green_basic",
        "green_queue_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "left_green_basic",
        "left_green_queue_basic",
        "redgreen_next_release",
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "signal": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "yellow_clear_basic",
        "signal_mixed_basic",
    ],
    "queue": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "dense_queue_stop",
        "green_queue_discharge",
        "sparse_mixed",
    ],
    "conflict": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "dense_queue_stop",
        "green_queue_discharge",
        "sparse_mixed",
        "medium_mixed",
        "protected_left_heavy",
    ],
}

BEHAVIOR_STAGE_REPLAY_TASKS = {
    "green": ["green_basic", "green_queue_basic"],
    "protected_green": ["green_basic", "green_queue_basic", "left_green_basic", "left_green_queue_basic", "green_1to2_per_lane_2l", "green_1to2_per_lane_3l", "green_1to2_per_lane_4l"],
    "lead_red_approach": [
        "lead_red_approach_2l",
        "lead_red_approach_3l",
        "lead_red_approach_4l",
        "lead_red_stop_precision_2l",
        "lead_red_stop_precision_3l",
        "lead_red_stop_precision_4l",
        "green_basic",
        "green_queue_basic",
        "left_green_basic",
    ],
    "lead_red_stop": [
        "lead_red_stop_precision_2l",
        "lead_red_stop_precision_3l",
        "lead_red_stop_precision_4l",
        "green_basic",
        "green_queue_basic",
        "left_green_basic",
    ],
    "left_release": ["left_redgreen_release", "left_green_basic", "left_green_queue_basic"],
    "red": [
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
    ],
    "red_squashed_probe": [
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "red_queue_1_per_lane_2l",
        "red_queue_1_per_lane_3l",
        "red_queue_1_per_lane_4l",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
    ],
    "red_queue": [
        "red_queue_1_per_lane_2l",
        "red_queue_1_per_lane_3l",
        "red_queue_1_per_lane_4l",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "green_queue_discharge",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "redgreen_aux_warmstart_from_scratch": [
        "green_basic",
        "green_queue_basic",
        "left_green_basic",
        "left_green_queue_basic",
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "red_queue_1_per_lane_2l",
        "red_queue_1_per_lane_3l",
        "red_queue_1_per_lane_4l",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
        "green_queue_discharge",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
        "redgreen_2_per_lane_2l",
        "redgreen_2_per_lane_3l",
        "redgreen_2_per_lane_4l",
    ],
    "redgreen_mixed_from_scratch": [
        "green_basic",
        "green_queue_basic",
        "left_green_basic",
        "left_green_queue_basic",
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
        "red_stop_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "red_queue_1_per_lane_2l",
        "red_queue_1_per_lane_3l",
        "red_queue_1_per_lane_4l",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
        "green_queue_discharge",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
        "redgreen_2_per_lane_2l",
        "redgreen_2_per_lane_3l",
        "redgreen_2_per_lane_4l",
    ],
    "redgreen_queue_2_per_lane": [
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
        "green_queue_discharge",
        "red_queue_2_per_lane_2l",
        "red_queue_2_per_lane_3l",
        "red_queue_2_per_lane_4l",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
        "redgreen_2_per_lane_2l",
        "redgreen_2_per_lane_3l",
        "redgreen_2_per_lane_4l",
    ],
    "dense_redgreen_queue": [
        "dense_green_discharge_3_per_green_lane_2l",
        "dense_green_discharge_3_per_green_lane_3l",
        "dense_green_discharge_3_per_green_lane_4l",
        "dense_red_queue_3_per_lane_2l",
        "dense_red_queue_3_per_lane_3l",
        "dense_red_queue_3_per_lane_4l",
        "dense_redgreen_release_3_per_lane_2l",
        "dense_redgreen_release_3_per_lane_3l",
        "dense_redgreen_release_3_per_lane_4l",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
        "redgreen_2_per_lane_2l",
        "redgreen_2_per_lane_3l",
        "redgreen_2_per_lane_4l",
    ],
    "right_on_red": [
        "right_on_red_basic",
        "right_on_red_conflict",
        "right_on_red_queue",
        "right_on_red_mixed",
        "redgreen_next_release",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "redgreen": [
        "green_basic",
        "green_queue_basic",
        "red_brake_basic",
        "red_creep_release_basic",
        "left_green_basic",
        "left_green_queue_basic",
        "redgreen_next_release",
        "green_1to2_per_lane_2l",
        "green_1to2_per_lane_3l",
        "green_1to2_per_lane_4l",
        "redgreen_1_per_lane_2l",
        "redgreen_1_per_lane_3l",
        "redgreen_1_per_lane_4l",
    ],
    "signal": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "yellow_clear_basic",
        "signal_mixed_basic",
    ],
    "queue": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "dense_queue_stop",
        "green_queue_discharge",
    ],
    "conflict": [
        "green_basic",
        "green_queue_basic",
        "red_stop_basic",
        "yellow_stop_basic",
        "dense_queue_stop",
        "green_queue_discharge",
        "protected_left_heavy",
    ],
}


DENSITY_SHAPING_TASKS = (
    "redgreen_next_release",
    "green_1to2_per_lane_2l",
    "green_1to2_per_lane_3l",
    "green_1to2_per_lane_4l",
    "red_queue_1_per_lane_2l",
    "red_queue_1_per_lane_3l",
    "red_queue_1_per_lane_4l",
    "redgreen_1_per_lane_2l",
    "redgreen_1_per_lane_3l",
    "redgreen_1_per_lane_4l",
    "green_queue_discharge",
    "red_queue_2_per_lane_2l",
    "red_queue_2_per_lane_3l",
    "red_queue_2_per_lane_4l",
    "redgreen_2_per_lane_2l",
    "redgreen_2_per_lane_3l",
    "redgreen_2_per_lane_4l",
    "dense_green_discharge_3_per_green_lane_2l",
    "dense_green_discharge_3_per_green_lane_3l",
    "dense_green_discharge_3_per_green_lane_4l",
    "dense_red_queue_3_per_lane_2l",
    "dense_red_queue_3_per_lane_3l",
    "dense_red_queue_3_per_lane_4l",
    "dense_redgreen_release_3_per_lane_2l",
    "dense_redgreen_release_3_per_lane_3l",
    "dense_redgreen_release_3_per_lane_4l",
)

DENSITY_SHAPING_TASK_WEIGHTS = {
    "redgreen_next_release": 0.0600,
    "green_1to2_per_lane_2l": 0.0200,
    "green_1to2_per_lane_3l": 0.0200,
    "green_1to2_per_lane_4l": 0.0200,
    "red_queue_1_per_lane_2l": 0.0350,
    "red_queue_1_per_lane_3l": 0.0350,
    "red_queue_1_per_lane_4l": 0.0350,
    "redgreen_1_per_lane_2l": 0.0450,
    "redgreen_1_per_lane_3l": 0.0450,
    "redgreen_1_per_lane_4l": 0.0450,
    "green_queue_discharge": 0.0500,
    "red_queue_2_per_lane_2l": 0.0550,
    "red_queue_2_per_lane_3l": 0.0550,
    "red_queue_2_per_lane_4l": 0.0550,
    "redgreen_2_per_lane_2l": 0.0750,
    "redgreen_2_per_lane_3l": 0.0750,
    "redgreen_2_per_lane_4l": 0.0750,
    "dense_green_discharge_3_per_green_lane_2l": 0.0067,
    "dense_green_discharge_3_per_green_lane_3l": 0.0067,
    "dense_green_discharge_3_per_green_lane_4l": 0.0066,
    "dense_red_queue_3_per_lane_2l": 0.0200,
    "dense_red_queue_3_per_lane_3l": 0.0200,
    "dense_red_queue_3_per_lane_4l": 0.0200,
    "dense_redgreen_release_3_per_lane_2l": 0.0400,
    "dense_redgreen_release_3_per_lane_3l": 0.0400,
    "dense_redgreen_release_3_per_lane_4l": 0.0400,
}

POLISH_TASKS = DENSITY_SHAPING_TASKS + (
    "red_brake_basic",
    "red_creep_release_basic",
    "lead_red_approach_2l",
    "lead_red_approach_3l",
    "lead_red_approach_4l",
    "lead_red_stop_precision_2l",
    "lead_red_stop_precision_3l",
    "lead_red_stop_precision_4l",
)

POLISH_TASK_WEIGHTS = {
    "red_brake_basic": 0.040,
    "red_creep_release_basic": 0.050,
    "lead_red_approach_2l": 0.020,
    "lead_red_approach_3l": 0.020,
    "lead_red_approach_4l": 0.020,
    "lead_red_stop_precision_2l": 0.010,
    "lead_red_stop_precision_3l": 0.010,
    "lead_red_stop_precision_4l": 0.010,
    "redgreen_next_release": 0.040,
    "green_1to2_per_lane_2l": 0.010,
    "green_1to2_per_lane_3l": 0.010,
    "green_1to2_per_lane_4l": 0.010,
    "red_queue_1_per_lane_2l": 0.015,
    "red_queue_1_per_lane_3l": 0.015,
    "red_queue_1_per_lane_4l": 0.015,
    "redgreen_1_per_lane_2l": 0.025,
    "redgreen_1_per_lane_3l": 0.025,
    "redgreen_1_per_lane_4l": 0.025,
    "green_queue_discharge": 0.030,
    "red_queue_2_per_lane_2l": 0.025,
    "red_queue_2_per_lane_3l": 0.025,
    "red_queue_2_per_lane_4l": 0.025,
    "redgreen_2_per_lane_2l": 0.040,
    "redgreen_2_per_lane_3l": 0.040,
    "redgreen_2_per_lane_4l": 0.040,
    "dense_green_discharge_3_per_green_lane_2l": 0.060,
    "dense_green_discharge_3_per_green_lane_3l": 0.060,
    "dense_green_discharge_3_per_green_lane_4l": 0.060,
    "dense_red_queue_3_per_lane_2l": 0.025,
    "dense_red_queue_3_per_lane_3l": 0.025,
    "dense_red_queue_3_per_lane_4l": 0.025,
    "dense_redgreen_release_3_per_lane_2l": 0.050,
    "dense_redgreen_release_3_per_lane_3l": 0.050,
    "dense_redgreen_release_3_per_lane_4l": 0.050,
}

BEHAVIOR_STAGE_TASKS["redgreen_density_shaping"] = list(DENSITY_SHAPING_TASKS)
BEHAVIOR_STAGE_REPLAY_TASKS["redgreen_density_shaping"] = list(DENSITY_SHAPING_TASKS)
BEHAVIOR_STAGE_TASKS["front_bumper_polish"] = list(POLISH_TASKS)
BEHAVIOR_STAGE_REPLAY_TASKS["front_bumper_polish"] = list(POLISH_TASKS)

CREEP_COMPONENT_TASKS = POLISH_TASKS + (
    "red_creep_far_stationary_2l",
    "red_creep_far_stationary_3l",
    "red_creep_far_stationary_4l",
)
CREEP_COMPONENT_TASK_WEIGHTS = {
    name: weight * 0.82 for name, weight in POLISH_TASK_WEIGHTS.items()
}
CREEP_COMPONENT_TASK_WEIGHTS.update({
    "red_creep_far_stationary_2l": 0.06,
    "red_creep_far_stationary_3l": 0.06,
    "red_creep_far_stationary_4l": 0.06,
})
BEHAVIOR_STAGE_TASKS["red_creep_component"] = list(CREEP_COMPONENT_TASKS)
BEHAVIOR_STAGE_REPLAY_TASKS["red_creep_component"] = list(CREEP_COMPONENT_TASKS)


def apply_density_task_weights(
    tasks: tuple[ScenarioTask, ...],
    stage: str | None,
) -> tuple[ScenarioTask, ...]:
    if stage == "redgreen_density_shaping":
        weights = DENSITY_SHAPING_TASK_WEIGHTS
    elif stage == "front_bumper_polish":
        weights = POLISH_TASK_WEIGHTS
    elif stage == "red_creep_component":
        weights = CREEP_COMPONENT_TASK_WEIGHTS
    else:
        return tasks
    return tuple(
        dataclass_replace(task, weight=weights.get(task.name, task.weight))
        for task in tasks
    )


def apply_behavior_stage_defaults(args: argparse.Namespace) -> None:
    if args.behavior_stage:
        stage = args.behavior_stage
        if args.training_tasks is None:
            args.training_tasks = BEHAVIOR_STAGE_TASKS[stage]
        if args.safety_replay_tasks is None:
            args.safety_replay_tasks = BEHAVIOR_STAGE_REPLAY_TASKS[stage]
        if stage == "signal" and args.intent_action_loss_coefficient <= 0.0:
            args.intent_action_loss_coefficient = 0.03

        if stage in {"green", "protected_green"}:
            args.validation_eval_mode = "green"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = GREEN_VALIDATION_SCENARIOS

        if stage != "green":
            requires_reference = stage not in {"redgreen", "protected_green", "redgreen_mixed_from_scratch", "redgreen_aux_warmstart_from_scratch", "red_squashed_probe"}
            if requires_reference and args.reference_checkpoint is None:
                raise ValueError(
                    f"--behavior-stage {stage} adds a new behavior and requires "
                    "--reference-checkpoint for anti-forgetting KL"
                )
            if args.reference_checkpoint is not None:
                if args.reference_kl_coefficient <= 0.0 and args.reference_kl_all_coefficient <= 0.0:
                    args.reference_kl_coefficient = 0.015
                    args.reference_kl_all_coefficient = 0.005
                args.reference_kl_stop_hold_only = False
                if stage in {"red", "lead_red_stop", "lead_red_approach", "red_queue", "redgreen_queue_2_per_lane", "dense_redgreen_queue", "redgreen_density_shaping", "front_bumper_polish", "red_creep_component", "redgreen", "left_release", "right_on_red"}:
                    args.reference_kl_green_only = True

        if stage == "lead_red_approach":
            args.validation_eval_mode = "lead_red_approach"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = LEAD_RED_APPROACH_VALIDATION_SCENARIOS

        if stage == "lead_red_stop":
            args.validation_eval_mode = "lead_red_stop"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = LEAD_RED_STOP_VALIDATION_SCENARIOS

        if stage == "red_squashed_probe":
            args.validation_eval_mode = "red_queue"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = RED_QUEUE_VALIDATION_SCENARIOS
            args.action_distribution = "squashed_gaussian"
            args.entropy_coefficient = max(args.entropy_coefficient, 0.001)
            args.target_kl = max(args.target_kl, 0.01)

        if stage == "red_queue":
            args.validation_eval_mode = "red_queue"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = RED_QUEUE_VALIDATION_SCENARIOS

        if stage == "redgreen_aux_warmstart_from_scratch":
            args.action_distribution = "squashed_gaussian"
            args.validation_eval_mode = "dense_redgreen"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = QUEUE2_REDGREEN_VALIDATION_SCENARIOS
            if args.intent_action_loss_coefficient <= 0.0:
                args.intent_action_loss_coefficient = 0.25
            if args.intent_action_loss_decay_start_updates <= 0:
                args.intent_action_loss_decay_start_updates = 30
            if args.intent_action_loss_decay_updates <= 0:
                args.intent_action_loss_decay_updates = 60
            args.red_action_target_only = True
            args.queue_action_target = True
            if args.red_target_crawl_speed is None:
                args.red_target_crawl_speed = 1.0
            if args.red_target_approach_gain is None:
                args.red_target_approach_gain = 0.35
            if args.red_target_brake_safety is None:
                args.red_target_brake_safety = 1.35
            if args.red_target_min_brake is None:
                args.red_target_min_brake = 0.5

        if stage == "redgreen_mixed_from_scratch":
            args.action_distribution = "squashed_gaussian"
            args.validation_eval_mode = "dense_redgreen"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = QUEUE2_REDGREEN_VALIDATION_SCENARIOS
            args.intent_action_loss_coefficient = 0.0
            args.queue_action_target = False

        if stage == "redgreen_queue_2_per_lane":
            args.validation_eval_mode = "dense_redgreen"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = QUEUE2_REDGREEN_VALIDATION_SCENARIOS
            if args.intent_action_loss_coefficient <= 0.0:
                args.intent_action_loss_coefficient = 0.008
            args.queue_action_target = True

        if stage == "dense_redgreen_queue":
            args.validation_eval_mode = "dense_redgreen"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = DENSE_REDGREEN_VALIDATION_SCENARIOS
            if args.intent_action_loss_coefficient <= 0.0:
                args.intent_action_loss_coefficient = 0.03
            args.queue_action_target = True

        if stage == "redgreen_density_shaping":
            args.validation_eval_mode = "dense_redgreen"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = DENSITY_SHAPING_VALIDATION_SCENARIOS
            args.intent_action_loss_coefficient = 0.0
            args.queue_action_target = False
            if args.red_stop_potential_coefficient is None:
                args.red_stop_potential_coefficient = 0.45

        if stage == "front_bumper_polish":
            args.action_distribution = "squashed_mixture"
            args.validation_eval_mode = "dense_redgreen"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = DENSITY_SHAPING_VALIDATION_SCENARIOS
            if args.validation_all_red_seconds is None:
                args.validation_all_red_seconds = 3.5
            args.validation_regime_gates = True
            if args.all_red_seconds <= 0.0:
                args.all_red_seconds = 3.5
            if args.all_red_seconds_min is None:
                args.all_red_seconds_min = 3.5
            if args.all_red_seconds_max is None:
                args.all_red_seconds_max = 4.5
            if args.intent_action_loss_coefficient <= 0.0:
                args.intent_action_loss_coefficient = 0.03
            if args.intent_action_loss_decay_start_updates <= 0:
                args.intent_action_loss_decay_start_updates = 30
            if args.intent_action_loss_decay_updates <= 0:
                args.intent_action_loss_decay_updates = 30
            if args.intent_action_loss_final_coefficient <= 0.0:
                args.intent_action_loss_final_coefficient = 0.01
            args.red_action_target_only = True
            args.queue_action_target = True
            args.creep_reapproach_label = True
            if args.red_target_crawl_speed is None:
                args.red_target_crawl_speed = 1.0
            if args.red_target_approach_gain is None:
                args.red_target_approach_gain = 0.35
            if args.red_target_queue_lead_margin is None:
                args.red_target_queue_lead_margin = 0.8
            if args.red_target_brake_safety is None:
                args.red_target_brake_safety = 1.35
            if args.red_target_min_brake is None:
                args.red_target_min_brake = 0.0
            if args.red_stop_potential_coefficient is None:
                args.red_stop_potential_coefficient = 0.45
            if args.mixture_gate_loss_coefficient <= 0.0:
                args.mixture_gate_loss_coefficient = 0.8
            if args.mixture_gate_loss_decay_start_updates <= 0:
                args.mixture_gate_loss_decay_start_updates = 30
            if args.mixture_gate_loss_decay_updates <= 0:
                args.mixture_gate_loss_decay_updates = 30
            if args.mixture_gate_loss_final_coefficient <= 0.0:
                args.mixture_gate_loss_final_coefficient = 0.05
            args.mixture_gate_separate_optimizer = True
            args.mixture_gate_freeze_ppo_until_saturated = True
            if args.mixture_gate_learning_rate == 3e-3:
                args.mixture_gate_learning_rate = 1e-3
            if args.mixture_gate_unfreeze_argmax_threshold == 0.98:
                args.mixture_gate_unfreeze_argmax_threshold = 0.95
            if args.mixture_gate_prewarm_steps <= 0:
                args.mixture_gate_prewarm_steps = 50
            if args.go_component_reference_kl_coefficient <= 0.0:
                args.go_component_reference_kl_coefficient = 1.0

        if stage == "red_creep_component":
            args.action_distribution = "squashed_mixture"
            if args.value_coefficient == 0.5:
                args.value_coefficient = 0.1
            if args.value_loss_huber_beta <= 0.0:
                args.value_loss_huber_beta = 20.0
            args.validation_eval_mode = "dense_redgreen"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = DENSITY_SHAPING_VALIDATION_SCENARIOS
            if args.validation_all_red_seconds is None:
                args.validation_all_red_seconds = 3.5
            args.validation_regime_gates = True
            if args.all_red_seconds <= 0.0:
                args.all_red_seconds = 3.5
            if args.all_red_seconds_min is None:
                args.all_red_seconds_min = 3.5
            if args.all_red_seconds_max is None:
                args.all_red_seconds_max = 4.5
            if args.intent_action_loss_coefficient <= 0.0:
                args.intent_action_loss_coefficient = 0.05
            if args.intent_action_loss_final_coefficient <= 0.0:
                args.intent_action_loss_final_coefficient = args.intent_action_loss_coefficient
            args.intent_action_loss_decay_start_updates = 0
            args.intent_action_loss_decay_updates = 0
            args.red_action_target_only = True
            args.queue_action_target = True
            args.creep_reapproach_label = True
            if args.red_target_crawl_speed is None:
                args.red_target_crawl_speed = 1.5
            if args.red_target_approach_gain is None:
                args.red_target_approach_gain = 0.35
            if args.red_target_queue_lead_margin is None:
                args.red_target_queue_lead_margin = 0.8
            if args.red_target_brake_safety is None:
                args.red_target_brake_safety = 1.35
            if args.red_target_min_brake is None:
                args.red_target_min_brake = 0.0
            if args.red_stop_potential_coefficient is None:
                args.red_stop_potential_coefficient = 0.45
            if args.mixture_gate_loss_coefficient <= 0.0:
                args.mixture_gate_loss_coefficient = 0.2
            if args.mixture_gate_loss_final_coefficient <= 0.0:
                args.mixture_gate_loss_final_coefficient = 0.05
            args.mixture_gate_separate_optimizer = True
            args.mixture_gate_freeze_ppo_until_saturated = True
            if args.mixture_gate_learning_rate == 3e-3:
                args.mixture_gate_learning_rate = 1e-3
            if args.mixture_gate_unfreeze_argmax_threshold == 0.98:
                args.mixture_gate_unfreeze_argmax_threshold = 0.95
            if args.mixture_gate_prewarm_steps == 0:
                args.mixture_gate_prewarm_steps = 3000
            if args.stop_after_mixture_prewarm is None:
                args.stop_after_mixture_prewarm = True
            if args.go_component_reference_kl_coefficient <= 0.0:
                args.go_component_reference_kl_coefficient = 1.0

        if stage == "right_on_red":
            args.validation_eval_mode = "right_on_red"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = RIGHT_ON_RED_VALIDATION_SCENARIOS

        if stage == "left_release":
            args.validation_eval_mode = "left_release"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = LEFT_RELEASE_VALIDATION_SCENARIOS

        if stage == "protected_green":
            args.action_distribution = "squashed_gaussian"
            args.validation_eval_mode = "left_green"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = LEFT_GREEN_VALIDATION_SCENARIOS

        if stage == "red":
            args.validation_eval_mode = "red"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = RED_VALIDATION_SCENARIOS

        if stage == "redgreen":
            args.validation_eval_mode = "redgreen"
            if args.validation_interval == 10:
                args.validation_interval = 5
            if args.validation_scenarios == DEFAULT_VALIDATION_SCENARIOS:
                args.validation_scenarios = REDGREEN_VALIDATION_SCENARIOS
    if args.safety_replay_tasks is None:
        args.safety_replay_tasks = LEGACY_REPLAY_TASKS


def base_env_config(max_cars: int, seed: int, episode_seconds: float) -> EnvConfig:
    return policy_env_config(
        max_cars=max_cars,
        lanes=4,
        seed=seed,
        episode_seconds=episode_seconds,
        all_red_seconds=0.0,
    )


def _nominal_green_seconds_per_episode(episode_seconds: float, all_red_seconds: float) -> float:
    base = EnvConfig(protected_left_signal=True)
    green_seconds = 2.0 * (base.left_signal_green_seconds + base.signal_green_seconds)
    cycle_seconds = green_seconds + 4.0 * max(0.0, all_red_seconds)
    if cycle_seconds <= 0.0:
        return episode_seconds
    return episode_seconds * green_seconds / cycle_seconds


def train(args: argparse.Namespace) -> None:
    apply_behavior_stage_defaults(args)
    primary_checkpoint = args.init_checkpoint or args.checkpoint
    print_provenance_banner(
        command="graph_train",
        project_root=PROJECT_ROOT,
        checkpoint=primary_checkpoint,
        seed=args.seed,
        all_red_seconds=args.all_red_seconds,
        extra={
            "checkpoint_role": "init" if args.init_checkpoint else "output",
            "output_checkpoint": args.checkpoint,
            "reference_checkpoint": args.reference_checkpoint or "none",
            "configured_action_distribution": args.action_distribution,
            "training_clearance_range": (
                f"{args.all_red_seconds_min}-{args.all_red_seconds_max}"
                if args.all_red_seconds_min is not None or args.all_red_seconds_max is not None
                else "fixed"
            ),
            "validation_all_red_seconds": args.validation_all_red_seconds,
        },
    )
    if args.reference_checkpoint and args.reference_checkpoint != primary_checkpoint:
        print_provenance_banner(
            command="graph_train_reference",
            project_root=PROJECT_ROOT,
            checkpoint=args.reference_checkpoint,
            seed=args.seed,
            all_red_seconds=args.all_red_seconds,
        )
    observer = GraphObserver(max_vehicle_nodes=args.max_cars)
    tasks = tuple(task for task in DEFAULT_TASKS if task.name in set(args.training_tasks)) if args.training_tasks else DEFAULT_TASKS
    tasks = apply_density_task_weights(tasks, args.behavior_stage)
    if not tasks:
        raise ValueError("--training-tasks did not match any known task names")
    env_config = base_env_config(args.max_cars, args.seed, 120.0)
    env_config.signal_all_red_seconds = max(0.0, float(args.all_red_seconds))
    env_config.signal_all_red_seconds_min = args.all_red_seconds_min
    env_config.signal_all_red_seconds_max = args.all_red_seconds_max
    env_config.intent_creep_reapproach_enabled = args.creep_reapproach_label
    env_config.intent_creep_reapproach_min_target_error = args.creep_reapproach_min_target_error
    env_config.intent_creep_reapproach_max_speed = args.creep_reapproach_max_speed
    env_config.intent_creep_route_max_speed = args.creep_route_max_speed
    if args.closed_signal_approach_speed_gain is not None:
        env_config.closed_signal_approach_speed_gain = args.closed_signal_approach_speed_gain
    if args.red_stop_potential_coefficient is not None:
        env_config.closed_signal_stop_potential_coefficient = args.red_stop_potential_coefficient
    if args.red_stop_potential_gamma is not None:
        env_config.closed_signal_stop_potential_gamma = args.red_stop_potential_gamma
    if args.red_stop_potential_window is not None:
        env_config.closed_signal_stop_potential_window = args.red_stop_potential_window
    if args.red_stop_potential_hold_reward is not None:
        env_config.closed_signal_stop_potential_hold_reward = args.red_stop_potential_hold_reward
    if args.red_stop_potential_speed_penalty is not None:
        env_config.closed_signal_stop_potential_speed_penalty = args.red_stop_potential_speed_penalty
    env = MultiTaskIntersectionEnv(env_config, tasks=tasks)
    config = PPOConfig(
        total_steps=args.steps,
        rollout_steps=args.rollout_steps,
        update_epochs=args.update_epochs,
        minibatch_size=args.minibatch_size,
        reward_clip=args.reward_clip,
        hidden_size=args.hidden_size,
        action_distribution=args.action_distribution,
        action_min_log_std=args.action_min_log_std,
        action_max_log_std=args.action_max_log_std,
        action_initial_log_std_longitudinal=args.action_initial_log_std_longitudinal,
        action_initial_log_std_steering=args.action_initial_log_std_steering,
        learning_rate=args.learning_rate,
        target_kl=args.target_kl,
        value_coefficient=args.value_coefficient,
        value_loss_huber_beta=args.value_loss_huber_beta,
        entropy_coefficient=args.entropy_coefficient,
        intent_loss_coefficient=args.intent_loss_coefficient,
        intent_loss_warmup_updates=args.intent_loss_warmup_updates,
        intent_loss_ramp_updates=args.intent_loss_ramp_updates,
        intent_detach_shared=args.intent_detach_shared,
        intent_action_loss_coefficient=args.intent_action_loss_coefficient,
        intent_action_loss_decay_start_updates=args.intent_action_loss_decay_start_updates,
        intent_action_loss_decay_updates=args.intent_action_loss_decay_updates,
        intent_action_loss_final_coefficient=args.intent_action_loss_final_coefficient,
        intent_action_loss_red_only=args.red_action_target_only,
        mixture_gate_loss_coefficient=args.mixture_gate_loss_coefficient,
        mixture_gate_loss_decay_start_updates=args.mixture_gate_loss_decay_start_updates,
        mixture_gate_loss_decay_updates=args.mixture_gate_loss_decay_updates,
        mixture_gate_loss_final_coefficient=args.mixture_gate_loss_final_coefficient,
        mixture_gate_loss_detach_shared=args.mixture_gate_loss_detach_shared,
        mixture_gate_separate_optimizer=args.mixture_gate_separate_optimizer,
        mixture_gate_learning_rate=args.mixture_gate_learning_rate,
        mixture_gate_max_grad_norm=args.mixture_gate_max_grad_norm,
        mixture_gate_prewarm_steps=args.mixture_gate_prewarm_steps,
        mixture_gate_prewarm_batch_size=args.mixture_gate_prewarm_batch_size,
        mixture_gate_prewarm_stop_weight_threshold=args.mixture_gate_prewarm_stop_weight_threshold,
        mixture_gate_prewarm_creep_weight_threshold=args.mixture_gate_prewarm_creep_weight_threshold,
        mixture_gate_prewarm_go_weight_threshold=args.mixture_gate_prewarm_go_weight_threshold,
        mixture_gate_prewarm_ambiguous_threshold=args.mixture_gate_prewarm_ambiguous_threshold,
        mixture_creep_prewarm_action_loss_threshold=args.mixture_creep_prewarm_action_loss_threshold,
        stop_after_mixture_prewarm=bool(args.stop_after_mixture_prewarm),
        mixture_gate_freeze_ppo_until_saturated=args.mixture_gate_freeze_ppo_until_saturated,
        mixture_gate_unfreeze_weight_threshold=args.mixture_gate_unfreeze_weight_threshold,
        mixture_gate_unfreeze_argmax_threshold=args.mixture_gate_unfreeze_argmax_threshold,
        mixture_gate_unfreeze_ambiguous_threshold=args.mixture_gate_unfreeze_ambiguous_threshold,
        mixture_gate_unfreeze_patience_updates=args.mixture_gate_unfreeze_patience_updates,
        mixture_gate_loss_decay_after_unfreeze=args.mixture_gate_loss_decay_after_unfreeze,
        go_component_reference_kl_coefficient=args.go_component_reference_kl_coefficient,
        reference_kl_coefficient=args.reference_kl_coefficient,
        reference_kl_all_coefficient=args.reference_kl_all_coefficient,
        reference_kl_stop_hold_only=args.reference_kl_stop_hold_only,
        reference_kl_green_only=args.reference_kl_green_only,
        phase_advantage_normalization=args.phase_advantage_normalization,
        phase_balanced_minibatches=args.phase_balanced_minibatches,
        safety_replay_workers=args.safety_replay_workers,
        stop_action_exploration_probability=args.stop_action_exploration_probability,
        stop_action_exploration_mean=args.stop_action_exploration_mean,
        stop_action_exploration_std=args.stop_action_exploration_std,
        safety_replay_tasks=tuple(args.safety_replay_tasks),
        rollout_closed_signal_stop_threshold=args.rollout_closed_signal_stop_threshold,
        rollout_guard_warmup_updates=args.rollout_guard_warmup_updates,
        task_phase1_updates=args.task_phase1_updates,
        task_phase2_updates=args.task_phase2_updates,
        validation_interval_updates=args.validation_interval,
        validation_episodes=args.validation_episodes,
        validation_patience=args.validation_patience,
        validation_eval_mode=args.validation_eval_mode,
        validation_all_red_seconds=(
            args.validation_all_red_seconds
            if args.validation_all_red_seconds is not None
            else args.all_red_seconds
        ),
        validation_regime_gates_enabled=args.validation_regime_gates,
        physics_action_target_queue_following_enabled=args.queue_action_target,
        checkpoint_interval_updates=args.checkpoint_interval,
        seed=args.seed,
    )
    if args.red_target_crawl_speed is not None:
        config.physics_action_target_red_crawl_speed = args.red_target_crawl_speed
    if args.red_target_approach_gain is not None:
        config.physics_action_target_red_approach_gain = args.red_target_approach_gain
    if args.red_target_stop_margin is not None:
        config.physics_action_target_stop_margin = args.red_target_stop_margin
    if args.red_target_queue_lead_margin is not None:
        config.physics_action_target_queue_lead_margin = args.red_target_queue_lead_margin
    if args.red_target_brake_safety is not None:
        config.physics_action_target_brake_safety_factor = args.red_target_brake_safety
    if args.red_target_min_brake is not None:
        config.physics_action_target_red_min_brake_accel = args.red_target_min_brake
    config.max_grad_norm = args.max_grad_norm
    trainer = GraphPPOTrainer(
        env,
        config,
        observer,
        layers=args.graph_layers,
        rollout_workers=args.rollout_workers,
        validation_workers=args.validation_workers,
    )
    if args.init_checkpoint:
        trainer.model.load(args.init_checkpoint)
    if args.behavior_stage == "red_creep_component":
        trainer.model.set_creep_component_enabled(True)
    if args.reference_checkpoint:
        trainer.load_reference_policy(args.reference_checkpoint)
    trainer.train(args.checkpoint, validation_scenarios=parse_validation_scenarios(args.validation_scenarios))


def _empty_eval_totals() -> dict[str, float]:
    return {
        "completed": 0.0,
        "failed": 0.0,
        "timeouts": 0.0,
        "stuck_timeouts": 0.0,
        "collisions": 0.0,
        "proximity_events": 0.0,
        "red": 0.0,
        "yellow": 0.0,
        "closed": 0.0,
        "failed_by_red": 0.0,
        "failed_by_yellow": 0.0,
        "failed_by_collision": 0.0,
        "collision_vehicles_before_stop_line": 0.0,
        "collision_vehicles_inside_intersection": 0.0,
        "collision_vehicles_after_stop_line": 0.0,
        "collision_pairs_with_clearance_eligible": 0.0,
        "inside_collision_pairs_with_clearance_eligible": 0.0,
        "inside_collision_pairs_without_clearance_eligible": 0.0,
        "inside_collision_pairs_within_1s_phase_change": 0.0,
        "inside_collision_pairs_within_2s_phase_change": 0.0,
        "inside_collision_pairs_within_3s_phase_change": 0.0,
        "failed_by_left_yield": 0.0,
        "failed_by_right_yield": 0.0,
        "right_yield": 0.0,
        "right_on_red_entries": 0.0,
        "failed_by_lane_violation": 0.0,
        "front_gap_violations": 0.0,
        "queue_stop_position_error_sum": 0.0,
        "queue_stop_position_samples": 0.0,
        "queue_stop_position_error_lead_sum": 0.0,
        "queue_stop_position_error_lead_samples": 0.0,
        "queue_stop_position_error_second_sum": 0.0,
        "queue_stop_position_error_second_samples": 0.0,
        "queue_stop_position_error_third_plus_sum": 0.0,
        "queue_stop_position_error_third_plus_samples": 0.0,
        "queue_follower_gap_error_sum": 0.0,
        "queue_follower_gap_samples": 0.0,
        "cars_stopped_too_far_from_stop_line": 0.0,
        "lead_green_start_delay_seconds": 0.0,
        "follower_green_start_delay_seconds": 0.0,
        "second_green_start_delay_seconds": 0.0,
        "third_plus_green_start_delay_seconds": 0.0,
        "queue_discharge_delay_seconds": 0.0,
        "lead_green_stuck_events": 0.0,
        "follower_green_stuck_events": 0.0,
        "second_green_stuck_events": 0.0,
        "third_plus_green_stuck_events": 0.0,
        "green_stopped_too_far_events": 0.0,
        "queue_red_crossings": 0.0,
        "intent_total": 0.0,
        "intent_correct": 0.0,
        "intent_label_stop": 0.0,
        "intent_pred_stop": 0.0,
        "intent_correct_stop": 0.0,
        "intent_label_hold": 0.0,
        "intent_pred_hold": 0.0,
        "intent_correct_hold": 0.0,
        "intent_label_go": 0.0,
        "intent_pred_go": 0.0,
        "intent_correct_go": 0.0,
        "intent_label_yield": 0.0,
        "intent_pred_yield": 0.0,
        "intent_correct_yield": 0.0,
        "intent_true_stop_pred_stop": 0.0,
        "intent_true_stop_pred_hold": 0.0,
        "intent_true_stop_pred_go": 0.0,
        "intent_true_stop_pred_yield": 0.0,
        "intent_true_hold_pred_stop": 0.0,
        "intent_true_hold_pred_hold": 0.0,
        "intent_true_hold_pred_go": 0.0,
        "intent_true_hold_pred_yield": 0.0,
        "intent_true_go_pred_stop": 0.0,
        "intent_true_go_pred_hold": 0.0,
        "intent_true_go_pred_go": 0.0,
        "intent_true_go_pred_yield": 0.0,
        "intent_true_yield_pred_stop": 0.0,
        "intent_true_yield_pred_hold": 0.0,
        "intent_true_yield_pred_go": 0.0,
        "intent_true_yield_pred_yield": 0.0,
        "action_longitudinal_sum": 0.0,
        "action_longitudinal_count": 0.0,
        "action_brake_count": 0.0,
        "action_stop_label_sum": 0.0,
        "action_stop_label_count": 0.0,
        "action_stop_label_brake_count": 0.0,
        "std_stop_label_sum": 0.0,
        "std_stop_label_count": 0.0,
        "action_hold_label_sum": 0.0,
        "action_hold_label_count": 0.0,
        "action_hold_label_brake_count": 0.0,
        "std_hold_label_sum": 0.0,
        "std_hold_label_count": 0.0,
        "action_go_label_sum": 0.0,
        "action_go_label_count": 0.0,
        "action_go_label_brake_count": 0.0,
        "std_go_label_sum": 0.0,
        "std_go_label_count": 0.0,
        "mixture_brake_weight_stop_label_sum": 0.0,
        "mixture_brake_weight_stop_label_count": 0.0,
        "mixture_brake_argmax_stop_label_count": 0.0,
        "mixture_ambiguous_stop_label_count": 0.0,
        "mixture_brake_weight_hold_label_sum": 0.0,
        "mixture_brake_weight_hold_label_count": 0.0,
        "mixture_brake_argmax_hold_label_count": 0.0,
        "mixture_ambiguous_hold_label_count": 0.0,
        "mixture_go_weight_go_label_sum": 0.0,
        "mixture_go_weight_go_label_count": 0.0,
        "mixture_go_argmax_go_label_count": 0.0,
        "mixture_ambiguous_go_label_count": 0.0,
        "mixture_go_weight_green_opening_gap_sum": 0.0,
        "mixture_go_weight_green_opening_gap_count": 0.0,
        "mixture_go_argmax_green_opening_gap_count": 0.0,
        "mixture_ambiguous_green_opening_gap_count": 0.0,
        "spawned": 0.0,
    }


def _accumulate_eval_intents(
    totals: dict[str, float],
    labels,
    predictions,
    active_mask,
) -> None:
    import numpy as np

    labels = np.asarray(labels, dtype=np.int64)
    predictions = np.asarray(predictions, dtype=np.int64)
    active = np.asarray(active_mask, dtype=np.float32) > 0.5
    valid = active & (labels >= 0)
    if not np.any(valid):
        return
    valid_labels = labels[valid]
    valid_predictions = predictions[valid]
    correct = valid_labels == valid_predictions
    totals["intent_total"] += float(valid_labels.size)
    totals["intent_correct"] += float(correct.sum())
    for index, name in enumerate(("stop", "hold", "go", "yield")):
        label_mask = valid_labels == index
        pred_mask = valid_predictions == index
        totals[f"intent_label_{name}"] += float(label_mask.sum())
        totals[f"intent_pred_{name}"] += float(pred_mask.sum())
        totals[f"intent_correct_{name}"] += float((label_mask & correct).sum())
    for true_index, true_name in enumerate(("stop", "hold", "go", "yield")):
        for pred_index, pred_name in enumerate(("stop", "hold", "go", "yield")):
            totals[f"intent_true_{true_name}_pred_{pred_name}"] += float(
                ((valid_labels == true_index) & (valid_predictions == pred_index)).sum()
            )


def _accumulate_eval_actions(
    totals: dict[str, float],
    labels,
    actions,
    active_mask,
    action_std=None,
    mixture_weights=None,
    observation=None,
) -> None:
    import numpy as np

    labels = np.asarray(labels, dtype=np.int64)
    actions = np.asarray(actions, dtype=np.float32)
    std_values = None if action_std is None else np.asarray(action_std, dtype=np.float32)
    weight_values = None if mixture_weights is None else np.asarray(mixture_weights, dtype=np.float32)
    ego_values = None if observation is None else np.asarray(observation.get("ego"), dtype=np.float32)
    active = np.asarray(active_mask, dtype=np.float32) > 0.5
    valid = active & (labels >= 0)
    if not np.any(valid):
        return
    longitudinal = actions[valid, 0]
    valid_labels = labels[valid]
    totals["action_longitudinal_sum"] += float(longitudinal.sum())
    totals["action_longitudinal_count"] += float(longitudinal.size)
    totals["action_brake_count"] += float((longitudinal < -0.05).sum())
    for index, name in ((0, "stop"), (1, "hold"), (2, "go")):
        mask = valid_labels == index
        if np.any(mask):
            values = longitudinal[mask]
            totals[f"action_{name}_label_sum"] += float(values.sum())
            totals[f"action_{name}_label_count"] += float(values.size)
            totals[f"action_{name}_label_brake_count"] += float((values < -0.05).sum())
            if std_values is not None:
                label_std = std_values[valid][mask, 0]
                totals[f"std_{name}_label_sum"] += float(label_std.sum())
                totals[f"std_{name}_label_count"] += float(label_std.size)
            if weight_values is not None:
                label_weights = weight_values[valid][mask]
                if label_weights.size > 0:
                    brake_weight = label_weights[:, 0]
                    go_weight = label_weights[:, -1]
                    argmax = np.argmax(label_weights, axis=-1)
                    ambiguous = (brake_weight > 0.4) & (brake_weight < 0.6)
                    if index in (0, 1):
                        totals[f"mixture_brake_weight_{name}_label_sum"] += float(brake_weight.sum())
                        totals[f"mixture_brake_weight_{name}_label_count"] += float(brake_weight.size)
                        totals[f"mixture_brake_argmax_{name}_label_count"] += float((argmax == 0).sum())
                        totals[f"mixture_ambiguous_{name}_label_count"] += float(ambiguous.sum())
                    elif index == 2:
                        totals["mixture_go_weight_go_label_sum"] += float(go_weight.sum())
                        totals["mixture_go_weight_go_label_count"] += float(go_weight.size)
                        totals["mixture_go_argmax_go_label_count"] += float((argmax == label_weights.shape[1] - 1).sum())
                        totals["mixture_ambiguous_go_label_count"] += float(ambiguous.sum())
    if weight_values is not None and ego_values is not None:
        label_weights = weight_values[valid]
        ego_valid = ego_values[valid]
        if label_weights.size > 0 and ego_valid.size > 0:
            brake_weight = label_weights[:, 0]
            go_weight = label_weights[:, -1]
            argmax = np.argmax(label_weights, axis=-1)
            ambiguous = (brake_weight > 0.4) & (brake_weight < 0.6)
            min_gap_norm = 7.0 / 65.0
            green_opening = (
                (valid_labels == 2)
                & (ego_valid[:, 14] > 0.5)
                & (ego_valid[:, 2] > 0.0)
                & (ego_valid[:, 22] > min_gap_norm)
                & (ego_valid[:, 22] < 0.95)
                & (ego_valid[:, 23] < 0.05)
            )
            if np.any(green_opening):
                totals["mixture_go_weight_green_opening_gap_sum"] += float(go_weight[green_opening].sum())
                totals["mixture_go_weight_green_opening_gap_count"] += float(green_opening.sum())
                totals["mixture_go_argmax_green_opening_gap_count"] += float((argmax[green_opening] == 1).sum())
                totals["mixture_ambiguous_green_opening_gap_count"] += float(ambiguous[green_opening].sum())


def _evaluate_episode_range(payload: dict) -> dict[str, float]:
    import torch

    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass

    observer = GraphObserver(max_vehicle_nodes=payload["max_cars"])
    env_config = base_env_config(
        payload["max_cars"], payload["seed"], payload["episode_seconds"]
    )
    env_config.signal_all_red_seconds = max(0.0, float(payload.get("all_red_seconds", 0.0)))
    env_config.lanes_per_approach = payload["lanes"]
    if payload.get("eval_mode") in {"green", "left_green", "left_release", "right_on_red", "red", "lead_red_stop", "lead_red_approach", "red_queue", "dense_redgreen", "yellow", "yellow_clear", "mixed", "redgreen"}:
        mode = payload.get("eval_mode")
        offset_min = None
        offset_max = None
        queue_gap_min = 12.0
        queue_gap_max = 14.0
        allow_ror = False
        right_turns = False
        if mode == "red":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 10.0, 30.0
            speed_min, speed_max = 2.0, 6.0
            permitted_only = False
        elif mode == "lead_red_stop":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 0.2, 1.0
            speed_min, speed_max = 0.0, 0.0
            permitted_only = False
        elif mode == "lead_red_approach":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 2.0, 8.0
            speed_min, speed_max = 0.2, 1.5
            permitted_only = False
        elif mode == "red_queue":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 0.2, 1.0
            speed_min, speed_max = 0.0, 2.5
            queue_gap_min, queue_gap_max = 7.0, 7.5
            permitted_only = False
        elif mode == "dense_redgreen":
            signal_mode = "redgreen"
            spawn_filter = "all"
            lead_min, lead_max = 0.2, 1.0
            speed_min, speed_max = 0.0, 1.0
            queue_gap_min, queue_gap_max = 7.0, 7.5
            permitted_only = False
        elif mode == "yellow":
            signal_mode = "yellow"
            spawn_filter = "yellow"
            lead_min, lead_max = 28.0, 48.0
            speed_min, speed_max = 0.3, 1.2
            permitted_only = False
        elif mode == "yellow_clear":
            signal_mode = "yellow"
            spawn_filter = "yellow"
            lead_min, lead_max = 8.0, 14.0
            speed_min, speed_max = 2.0, 4.0
            permitted_only = False
            offset_min, offset_max = 2.0, 8.0
        elif mode == "mixed":
            signal_mode = "random"
            spawn_filter = "all"
            lead_min, lead_max = 18.0, 42.0
            speed_min, speed_max = 0.0, 1.0
            permitted_only = False
        elif mode == "right_on_red":
            signal_mode = "right_on_red"
            spawn_filter = "right_red_conflict"
            lead_min, lead_max = 8.0, 24.0
            speed_min, speed_max = 0.0, 2.5
            permitted_only = False
            allow_ror = True
            right_turns = True
        elif mode == "redgreen":
            signal_mode = "redgreen"
            spawn_filter = "all"
            lead_min, lead_max = 10.0, 32.0
            speed_min, speed_max = 0.0, 2.0
            queue_gap_min, queue_gap_max = 7.0, 7.5
            permitted_only = False
        elif mode == "left_green":
            signal_mode = "left_green"
            spawn_filter = "green"
            lead_min, lead_max = 4.5, 18.0
            speed_min, speed_max = 0.0, 0.0
            permitted_only = True
        elif mode == "left_release":
            signal_mode = "left_release"
            spawn_filter = "next_left_release"
            lead_min, lead_max = 10.0, 22.0
            speed_min, speed_max = 2.0, 5.0
            queue_gap_min, queue_gap_max = 7.0, 7.5
            permitted_only = False
        else:
            signal_mode = "green"
            spawn_filter = "green"
            lead_min, lead_max = 6.0, 24.0
            speed_min, speed_max = 0.0, 0.0
            permitted_only = True
        task = ScenarioTask(
            f"eval_{mode}",
            payload["lanes"],
            payload["lanes"],
            payload["cars"],
            payload["cars"],
            payload["episode_seconds"],
            payload["episode_seconds"],
            1.0,
            signal_mode,
            lead_min,
            lead_max,
            queue_gap_min,
            queue_gap_max,
            speed_min,
            speed_max,
            permitted_only,
            spawn_filter,
            offset_min,
            offset_max,
            allow_ror,
            right_turns,
        )
        if mode in {"dense_redgreen", "redgreen"}:
            task = redgreen_task(
                name=f"eval_{mode}",
                lanes=payload["lanes"],
                cars=payload["cars"],
                episode_seconds=payload["episode_seconds"],
                dense=mode == "dense_redgreen",
            )
        env = MultiTaskIntersectionEnv(env_config, tasks=(task,))
    else:
        env = IntersectionEnv(env_config)
    spec = observer.spec
    model = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=payload["hidden_size"],
        layers=payload["graph_layers"],
        seed=payload["seed"],
    )
    model.load(payload["checkpoint"])
    model.eval()
    totals = _empty_eval_totals()
    try:
        for episode in range(payload["episode_start"], payload["episode_stop"]):
            _, info = env.reset(seed=payload["seed"] + episode, options={"vehicle_count": payload["cars"]})
            observation = observer.encode(env)
            done = False
            while not done:
                predicted_intents = model.predict_intents(observation)
                _accumulate_eval_intents(
                    totals,
                    info.get("intent_labels", []),
                    predicted_intents,
                    info.get("active_mask", []),
                )
                action_std = model.action_std(observation)
                mixture_weights = model.action_mixture_weights(observation)
                actions, _, _ = model.act(observation, deterministic=True)
                _accumulate_eval_actions(
                    totals,
                    info.get("intent_labels", []),
                    actions,
                    info.get("active_mask", []),
                    action_std,
                    mixture_weights,
                    observation,
                )
                _, _, terminated, truncated, info = env.step(actions)
                totals["collisions"] += int(info.get("collisions", 0))
                totals["proximity_events"] += int(info.get("proximity_events", 0))
                totals["red"] += int(info.get("red_light_violations", 0))
                totals["yellow"] += int(info.get("yellow_light_violations", 0))
                totals["closed"] += float(info.get("closed_signal_violations", 0))
                totals["right_yield"] += float(info.get("right_yield_violations", 0))
                totals["right_on_red_entries"] += float(info.get("right_on_red_entries", 0))
                totals["timeouts"] += float(info.get("timeout_failures", 0))
                totals["stuck_timeouts"] += float(info.get("stuck_timeout_failures", 0))
                for key in (
                    "failed_by_red",
                    "failed_by_yellow",
                    "failed_by_collision",
                    "collision_vehicles_before_stop_line",
                    "collision_vehicles_inside_intersection",
                    "collision_vehicles_after_stop_line",
                    "collision_pairs_with_clearance_eligible",
                    "inside_collision_pairs_with_clearance_eligible",
                    "inside_collision_pairs_without_clearance_eligible",
                    "inside_collision_pairs_within_1s_phase_change",
                    "inside_collision_pairs_within_2s_phase_change",
                    "inside_collision_pairs_within_3s_phase_change",
                    "failed_by_left_yield",
                    "failed_by_right_yield",
                    "failed_by_lane_violation",
                    "front_gap_violations",
                    "queue_stop_position_error_sum",
                    "queue_stop_position_samples",
                    "queue_stop_position_error_lead_sum",
                    "queue_stop_position_error_lead_samples",
                    "queue_stop_position_error_second_sum",
                    "queue_stop_position_error_second_samples",
                    "queue_stop_position_error_third_plus_sum",
                    "queue_stop_position_error_third_plus_samples",
                    "queue_follower_gap_error_sum",
                    "queue_follower_gap_samples",
                    "cars_stopped_too_far_from_stop_line",
                    "lead_green_start_delay_seconds",
                    "follower_green_start_delay_seconds",
                    "second_green_start_delay_seconds",
                    "third_plus_green_start_delay_seconds",
                    "queue_discharge_delay_seconds",
                    "lead_green_stuck_events",
                    "follower_green_stuck_events",
                    "second_green_stuck_events",
                    "third_plus_green_stuck_events",
                    "green_stopped_too_far_events",
                    "queue_red_crossings",
                ):
                    totals[key] += float(info.get(key, 0.0))
                observation = observer.encode(env)
                done = terminated or truncated
            totals["completed"] += float(info.get("completed_clean", 0))
            totals["failed"] += float(info.get("failed_vehicles", 0))
            totals["spawned"] += float(payload["cars"])
    finally:
        env.close()
    return totals


def _merge_eval_totals(items: list[dict[str, float]]) -> dict[str, float]:
    totals = _empty_eval_totals()
    for item in items:
        for key in totals:
            totals[key] += float(item.get(key, 0.0))
    return totals


def _eval_row(args: argparse.Namespace, totals: dict[str, int], eval_workers: int) -> dict[str, float | int | str]:
    nominal_green_seconds = _nominal_green_seconds_per_episode(
        args.episode_seconds,
        float(getattr(args, "all_red_seconds", 0.0)),
    )
    total_nominal_green_seconds = args.episodes * nominal_green_seconds
    return {
        "checkpoint": str(args.checkpoint),
        **getattr(args, "_runtime_provenance", {}),
        "episodes": args.episodes,
        "eval_workers": eval_workers,
        "seed": args.seed,
        "lanes": args.lanes,
        "cars": args.cars,
        "episode_seconds": args.episode_seconds,
        "eval_mode": getattr(args, "eval_mode", "standard"),
        "all_red_seconds": float(getattr(args, "all_red_seconds", 0.0)),
        "green_one_car_per_lane": int(getattr(args, "green_one_car_per_lane", False)),
        "nominal_green_seconds_per_ep": nominal_green_seconds,
        "completed_per_100_green_seconds": 100.0 * totals["completed"] / max(total_nominal_green_seconds, 1.0),
        "completed_pct": 100.0 * totals["completed"] / max(totals["spawned"], 1),
        "failed_pct": 100.0 * totals["failed"] / max(totals["spawned"], 1),
        "non_timeout_failed_pct": 100.0 * max(0, totals["failed"] - totals["timeouts"]) / max(totals["spawned"], 1),
        "incomplete_pct": 100.0 * totals["timeouts"] / max(totals["spawned"], 1),
        "timeout_pct": 100.0 * totals["timeouts"] / max(totals["spawned"], 1),
        "stuck_timeout_pct": 100.0 * totals["stuck_timeouts"] / max(totals["spawned"], 1),
        "moving_timeout_pct": 100.0 * max(0.0, totals["timeouts"] - totals["stuck_timeouts"]) / max(totals["spawned"], 1),
        "stuck_share_of_incomplete_pct": 100.0 * totals["stuck_timeouts"] / max(totals["timeouts"], 1.0),
        "moving_share_of_incomplete_pct": 100.0 * max(0.0, totals["timeouts"] - totals["stuck_timeouts"]) / max(totals["timeouts"], 1.0),
        "timeout_failures_per_ep": totals["timeouts"] / args.episodes,
        "stuck_timeouts_per_ep": totals["stuck_timeouts"] / args.episodes,
        "moving_timeouts_per_ep": max(0.0, totals["timeouts"] - totals["stuck_timeouts"]) / args.episodes,
        "collisions_per_ep": totals["collisions"] / args.episodes,
        "collision_vehicles_before_stop_line_per_ep": totals["collision_vehicles_before_stop_line"] / args.episodes,
        "collision_vehicles_inside_intersection_per_ep": totals["collision_vehicles_inside_intersection"] / args.episodes,
        "collision_vehicles_after_stop_line_per_ep": totals["collision_vehicles_after_stop_line"] / args.episodes,
        "collision_pairs_with_clearance_eligible_per_ep": totals["collision_pairs_with_clearance_eligible"] / args.episodes,
        "inside_collision_pairs_with_clearance_eligible_per_ep": totals["inside_collision_pairs_with_clearance_eligible"] / args.episodes,
        "inside_collision_pairs_without_clearance_eligible_per_ep": totals["inside_collision_pairs_without_clearance_eligible"] / args.episodes,
        "inside_collision_pairs_within_1s_phase_change_per_ep": totals["inside_collision_pairs_within_1s_phase_change"] / args.episodes,
        "inside_collision_pairs_within_2s_phase_change_per_ep": totals["inside_collision_pairs_within_2s_phase_change"] / args.episodes,
        "inside_collision_pairs_within_3s_phase_change_per_ep": totals["inside_collision_pairs_within_3s_phase_change"] / args.episodes,
        "proximity_events_per_ep": totals["proximity_events"] / args.episodes,
        "red_violations_per_ep": totals["red"] / args.episodes,
        "yellow_violations_per_ep": totals["yellow"] / args.episodes,
        "closed_signal_violations_per_ep": totals["closed"] / args.episodes,
        "failed_by_red_per_ep": totals["failed_by_red"] / args.episodes,
        "failed_by_yellow_per_ep": totals["failed_by_yellow"] / args.episodes,
        "failed_by_collision_per_ep": totals["failed_by_collision"] / args.episodes,
        "failed_by_left_yield_per_ep": totals["failed_by_left_yield"] / args.episodes,
        "failed_by_right_yield_per_ep": totals["failed_by_right_yield"] / args.episodes,
        "right_yield_violations_per_ep": totals["right_yield"] / args.episodes,
        "right_on_red_entries_per_ep": totals["right_on_red_entries"] / args.episodes,
        "failed_by_lane_violation_per_ep": totals["failed_by_lane_violation"] / args.episodes,
        "front_gap_violations_per_ep": totals["front_gap_violations"] / args.episodes,
        "queue_stop_position_error_avg": totals["queue_stop_position_error_sum"] / max(totals["queue_stop_position_samples"], 1.0),
        "queue_stop_position_samples_per_ep": totals["queue_stop_position_samples"] / args.episodes,
        "queue_stop_position_error_lead_avg": totals["queue_stop_position_error_lead_sum"] / max(totals["queue_stop_position_error_lead_samples"], 1.0),
        "queue_stop_position_error_second_avg": totals["queue_stop_position_error_second_sum"] / max(totals["queue_stop_position_error_second_samples"], 1.0),
        "queue_stop_position_error_third_plus_avg": totals["queue_stop_position_error_third_plus_sum"] / max(totals["queue_stop_position_error_third_plus_samples"], 1.0),
        "queue_follower_gap_error_avg": totals["queue_follower_gap_error_sum"] / max(totals["queue_follower_gap_samples"], 1.0),
        "cars_stopped_too_far_from_stop_line_per_ep": totals["cars_stopped_too_far_from_stop_line"] / args.episodes,
        "lead_green_start_delay_seconds_per_ep": totals["lead_green_start_delay_seconds"] / args.episodes,
        "follower_green_start_delay_seconds_per_ep": totals["follower_green_start_delay_seconds"] / args.episodes,
        "second_green_start_delay_seconds_per_ep": totals["second_green_start_delay_seconds"] / args.episodes,
        "third_plus_green_start_delay_seconds_per_ep": totals["third_plus_green_start_delay_seconds"] / args.episodes,
        "queue_discharge_delay_seconds_per_ep": totals["queue_discharge_delay_seconds"] / args.episodes,
        "lead_green_stuck_events_per_ep": totals["lead_green_stuck_events"] / args.episodes,
        "follower_green_stuck_events_per_ep": totals["follower_green_stuck_events"] / args.episodes,
        "second_green_stuck_events_per_ep": totals["second_green_stuck_events"] / args.episodes,
        "third_plus_green_stuck_events_per_ep": totals["third_plus_green_stuck_events"] / args.episodes,
        "green_stopped_too_far_events_per_ep": totals["green_stopped_too_far_events"] / args.episodes,
        "queue_red_crossings_per_ep": totals["queue_red_crossings"] / args.episodes,
        "red_drill_safe_pct": 100.0 * max(0.0, totals["spawned"] - totals["closed"]) / max(totals["spawned"], 1.0),
        "action_longitudinal_mean": totals["action_longitudinal_sum"] / max(totals["action_longitudinal_count"], 1.0),
        "action_brake_share": totals["action_brake_count"] / max(totals["action_longitudinal_count"], 1.0),
        "action_stop_label_mean": totals["action_stop_label_sum"] / max(totals["action_stop_label_count"], 1.0),
        "action_stop_label_brake_share": totals["action_stop_label_brake_count"] / max(totals["action_stop_label_count"], 1.0),
        "std_stop_label_mean": totals["std_stop_label_sum"] / max(totals["std_stop_label_count"], 1.0),
        "action_hold_label_mean": totals["action_hold_label_sum"] / max(totals["action_hold_label_count"], 1.0),
        "action_hold_label_brake_share": totals["action_hold_label_brake_count"] / max(totals["action_hold_label_count"], 1.0),
        "std_hold_label_mean": totals["std_hold_label_sum"] / max(totals["std_hold_label_count"], 1.0),
        "action_go_label_mean": totals["action_go_label_sum"] / max(totals["action_go_label_count"], 1.0),
        "action_go_label_brake_share": totals["action_go_label_brake_count"] / max(totals["action_go_label_count"], 1.0),
        "std_go_label_mean": totals["std_go_label_sum"] / max(totals["std_go_label_count"], 1.0),
        "mixture_brake_weight_stop_label_mean": totals["mixture_brake_weight_stop_label_sum"] / max(totals["mixture_brake_weight_stop_label_count"], 1.0),
        "mixture_brake_argmax_stop_label_share": totals["mixture_brake_argmax_stop_label_count"] / max(totals["mixture_brake_weight_stop_label_count"], 1.0),
        "mixture_ambiguous_stop_label_share": totals["mixture_ambiguous_stop_label_count"] / max(totals["mixture_brake_weight_stop_label_count"], 1.0),
        "mixture_brake_weight_hold_label_mean": totals["mixture_brake_weight_hold_label_sum"] / max(totals["mixture_brake_weight_hold_label_count"], 1.0),
        "mixture_brake_argmax_hold_label_share": totals["mixture_brake_argmax_hold_label_count"] / max(totals["mixture_brake_weight_hold_label_count"], 1.0),
        "mixture_ambiguous_hold_label_share": totals["mixture_ambiguous_hold_label_count"] / max(totals["mixture_brake_weight_hold_label_count"], 1.0),
        "mixture_go_weight_go_label_mean": totals["mixture_go_weight_go_label_sum"] / max(totals["mixture_go_weight_go_label_count"], 1.0),
        "mixture_go_argmax_go_label_share": totals["mixture_go_argmax_go_label_count"] / max(totals["mixture_go_weight_go_label_count"], 1.0),
        "mixture_ambiguous_go_label_share": totals["mixture_ambiguous_go_label_count"] / max(totals["mixture_go_weight_go_label_count"], 1.0),
        "mixture_go_weight_green_opening_gap_mean": totals["mixture_go_weight_green_opening_gap_sum"] / max(totals["mixture_go_weight_green_opening_gap_count"], 1.0),
        "mixture_go_argmax_green_opening_gap_share": totals["mixture_go_argmax_green_opening_gap_count"] / max(totals["mixture_go_weight_green_opening_gap_count"], 1.0),
        "mixture_ambiguous_green_opening_gap_share": totals["mixture_ambiguous_green_opening_gap_count"] / max(totals["mixture_go_weight_green_opening_gap_count"], 1.0),
        "intent_accuracy": totals["intent_correct"] / max(totals["intent_total"], 1.0),
        "intent_total_per_ep": totals["intent_total"] / args.episodes,
        "intent_label_stop_per_ep": totals["intent_label_stop"] / args.episodes,
        "intent_pred_stop_per_ep": totals["intent_pred_stop"] / args.episodes,
        "intent_recall_stop": totals["intent_correct_stop"] / max(totals["intent_label_stop"], 1.0),
        "intent_label_hold_per_ep": totals["intent_label_hold"] / args.episodes,
        "intent_pred_hold_per_ep": totals["intent_pred_hold"] / args.episodes,
        "intent_recall_hold": totals["intent_correct_hold"] / max(totals["intent_label_hold"], 1.0),
        "intent_label_go_per_ep": totals["intent_label_go"] / args.episodes,
        "intent_pred_go_per_ep": totals["intent_pred_go"] / args.episodes,
        "intent_recall_go": totals["intent_correct_go"] / max(totals["intent_label_go"], 1.0),
        "intent_label_yield_per_ep": totals["intent_label_yield"] / args.episodes,
        "intent_pred_yield_per_ep": totals["intent_pred_yield"] / args.episodes,
        "intent_recall_yield": totals["intent_correct_yield"] / max(totals["intent_label_yield"], 1.0),
        "intent_true_stop_pred_stop_per_ep": totals["intent_true_stop_pred_stop"] / args.episodes,
        "intent_true_stop_pred_hold_per_ep": totals["intent_true_stop_pred_hold"] / args.episodes,
        "intent_true_stop_pred_go_per_ep": totals["intent_true_stop_pred_go"] / args.episodes,
        "intent_true_stop_pred_yield_per_ep": totals["intent_true_stop_pred_yield"] / args.episodes,
        "intent_true_hold_pred_stop_per_ep": totals["intent_true_hold_pred_stop"] / args.episodes,
        "intent_true_hold_pred_hold_per_ep": totals["intent_true_hold_pred_hold"] / args.episodes,
        "intent_true_hold_pred_go_per_ep": totals["intent_true_hold_pred_go"] / args.episodes,
        "intent_true_hold_pred_yield_per_ep": totals["intent_true_hold_pred_yield"] / args.episodes,
        "intent_true_go_pred_stop_per_ep": totals["intent_true_go_pred_stop"] / args.episodes,
        "intent_true_go_pred_hold_per_ep": totals["intent_true_go_pred_hold"] / args.episodes,
        "intent_true_go_pred_go_per_ep": totals["intent_true_go_pred_go"] / args.episodes,
        "intent_true_go_pred_yield_per_ep": totals["intent_true_go_pred_yield"] / args.episodes,
        "intent_true_yield_pred_stop_per_ep": totals["intent_true_yield_pred_stop"] / args.episodes,
        "intent_true_yield_pred_hold_per_ep": totals["intent_true_yield_pred_hold"] / args.episodes,
        "intent_true_yield_pred_go_per_ep": totals["intent_true_yield_pred_go"] / args.episodes,
        "intent_true_yield_pred_yield_per_ep": totals["intent_true_yield_pred_yield"] / args.episodes,
    }


def evaluate(args: argparse.Namespace) -> None:
    if args.green_one_car_per_lane:
        args.eval_mode = "green"
        args.cars = 2 * int(args.lanes)
    args._runtime_provenance = print_provenance_banner(
        command="graph_evaluate",
        project_root=PROJECT_ROOT,
        checkpoint=args.checkpoint,
        seed=args.seed,
        seeds=str(args.seed),
        all_red_seconds=args.all_red_seconds,
        extra={
            "episodes": args.episodes,
            "lanes": args.lanes,
            "cars": args.cars,
            "eval_mode": args.eval_mode,
        },
    )
    eval_workers = max(1, min(int(args.eval_workers), int(args.episodes)))
    payload_base = {
        "checkpoint": str(args.checkpoint),
        "max_cars": args.max_cars,
        "seed": args.seed,
        "episode_seconds": args.episode_seconds,
        "lanes": args.lanes,
        "cars": args.cars,
        "hidden_size": args.hidden_size,
        "graph_layers": args.graph_layers,
        "eval_mode": args.eval_mode,
        "all_red_seconds": args.all_red_seconds,
    }
    if eval_workers == 1:
        totals = _evaluate_episode_range(
            {**payload_base, "episode_start": 0, "episode_stop": args.episodes}
        )
    else:
        payloads = []
        for worker_index in range(eval_workers):
            start = worker_index * args.episodes // eval_workers
            stop = (worker_index + 1) * args.episodes // eval_workers
            if start == stop:
                continue
            payloads.append({**payload_base, "episode_start": start, "episode_stop": stop})
        with ProcessPoolExecutor(max_workers=eval_workers) as executor:
            totals = _merge_eval_totals(list(executor.map(_evaluate_episode_range, payloads)))

    row = _eval_row(args, totals, eval_workers)
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(row))
        writer.writeheader()
        writer.writerow(row)
    print(" ".join(f"{key}={value}" for key, value in row.items()))


def parse_validation_scenarios(values: list[str]) -> tuple[tuple[int, int, float], ...]:
    scenarios: list[tuple[int, int, float]] = []
    for value in values:
        lanes_text, cars_text, seconds_text = value.split(":")
        scenarios.append((int(lanes_text), int(cars_text), float(seconds_text)))
    return tuple(scenarios)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train/evaluate graph-attention multi-task PPO.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    train_parser = subparsers.add_parser("train")
    train_parser.add_argument("--checkpoint", type=Path, default=Path("checkpoints/graph_multitask_v1.npz"))
    train_parser.add_argument("--init-checkpoint", type=Path)
    train_parser.add_argument("--reference-checkpoint", type=Path)
    train_parser.add_argument("--steps", type=int, default=200_000)
    train_parser.add_argument("--rollout-steps", type=int, default=256)
    train_parser.add_argument("--update-epochs", type=int, default=4)
    train_parser.add_argument("--minibatch-size", type=int, default=512)
    train_parser.add_argument("--reward-clip", type=float, default=20.0)
    train_parser.add_argument("--hidden-size", type=int, default=128)
    train_parser.add_argument("--action-distribution", choices=("legacy_gaussian", "squashed_gaussian", "squashed_mixture"), default="legacy_gaussian", help="Actor distribution for continuous actions. squashed_gaussian uses tanh-corrected bounded actions with state-dependent std.")
    train_parser.add_argument("--action-min-log-std", type=float, default=-2.302585092994046, help="Minimum per-action log std; default is log(0.1).")
    train_parser.add_argument("--action-max-log-std", type=float, default=0.0, help="Maximum per-action log std.")
    train_parser.add_argument("--action-initial-log-std-longitudinal", type=float, default=-0.8, help="Initial state-dependent longitudinal log std for squashed Gaussian.")
    train_parser.add_argument("--action-initial-log-std-steering", type=float, default=-1.5, help="Initial state-dependent steering log std for squashed Gaussian.")
    train_parser.add_argument("--graph-layers", type=int, default=2)
    train_parser.add_argument("--rollout-workers", type=int, default=8)
    train_parser.add_argument("--max-cars", type=int, default=50)
    train_parser.add_argument("--all-red-seconds", type=float, default=0.0, help="Base all-red clearance interval inserted after each green/yellow phase.")
    train_parser.add_argument("--all-red-seconds-min", type=float, default=None, help="Optional minimum per-episode training clearance.")
    train_parser.add_argument("--all-red-seconds-max", type=float, default=None, help="Optional maximum per-episode training clearance.")
    train_parser.add_argument("--validation-all-red-seconds", type=float, default=None, help="Fixed all-red clearance used by validation workers.")
    train_parser.add_argument("--learning-rate", type=float, default=8e-5)
    train_parser.add_argument("--target-kl", type=float, default=0.008)
    train_parser.add_argument("--value-coefficient", type=float, default=0.5, help="Value loss coefficient. Lower values let behavior/action losses dominate focused drills.")
    train_parser.add_argument("--value-loss-huber-beta", type=float, default=0.0, help="Use Huber value loss with this beta to cap critic gradients; 0 keeps MSE value loss.")
    train_parser.add_argument("--max-grad-norm", type=float, default=0.5, help="Global gradient clipping norm.")
    train_parser.add_argument("--entropy-coefficient", type=float, default=0.0003)
    train_parser.add_argument("--intent-loss-coefficient", type=float, default=0.0, help="Intent classifier loss. Default is 0 for the separate acceleration/steering actor.")
    train_parser.add_argument("--intent-loss-warmup-updates", type=int, default=10)
    train_parser.add_argument("--intent-loss-ramp-updates", type=int, default=30)
    train_parser.add_argument("--intent-action-loss-coefficient", type=float, default=0.0)
    train_parser.add_argument("--intent-action-loss-decay-start-updates", type=int, default=0, help="Start decaying the training-only auxiliary action loss after this update.")
    train_parser.add_argument("--intent-action-loss-decay-updates", type=int, default=0, help="Number of updates over which the auxiliary action loss decays.")
    train_parser.add_argument("--intent-action-loss-final-coefficient", type=float, default=0.0, help="Final auxiliary action loss coefficient after decay.")
    train_parser.add_argument("--red-action-target-only", action="store_true", help="Apply auxiliary action-target loss only to red/closed-signal vehicles before the stop line.")
    train_parser.add_argument("--mixture-gate-loss-coefficient", type=float, default=0.0, help="Training-only CE loss that routes stop/hold labels to the brake mixture component and go labels to the go component.")
    train_parser.add_argument("--mixture-gate-loss-decay-start-updates", type=int, default=0, help="Start decaying the mixture gate CE loss after this update.")
    train_parser.add_argument("--mixture-gate-loss-decay-updates", type=int, default=0, help="Number of updates over which the mixture gate CE loss decays.")
    train_parser.add_argument("--mixture-gate-loss-final-coefficient", type=float, default=0.0, help="Final mixture gate CE coefficient after decay; use a small floor to prevent gate drift.")
    train_parser.add_argument("--mixture-gate-shared-gradient", dest="mixture_gate_loss_detach_shared", action="store_false", help="Allow mixture gate CE to update shared features. Default keeps CE detached from the shared trunk.")
    train_parser.add_argument("--mixture-gate-separate-optimizer", action="store_true", help="Train mixture gate CE in a separate post-PPO optimizer step so global PPO clipping cannot erase it.")
    train_parser.add_argument("--mixture-gate-learning-rate", type=float, default=3e-3, help="Learning rate for the separate mixture gate optimizer.")
    train_parser.add_argument("--mixture-gate-max-grad-norm", type=float, default=5.0, help="Clip norm for the separate mixture gate optimizer.")
    train_parser.add_argument("--mixture-gate-prewarm-steps", type=int, default=0, help="Before PPO, train only mixture gate CE on a collected mixed rollout batch for this many optimizer steps.")
    train_parser.add_argument("--mixture-gate-prewarm-batch-size", type=int, default=1024, help="Batch size for supervised mixture gate prewarm.")
    train_parser.add_argument("--mixture-gate-prewarm-stop-weight-threshold", type=float, default=0.85, help="Prewarm target brake weight on brake-routed samples.")
    train_parser.add_argument("--mixture-gate-prewarm-creep-weight-threshold", type=float, default=0.85, help="Prewarm target creep weight on creep-routed samples.")
    train_parser.add_argument("--mixture-gate-prewarm-go-weight-threshold", type=float, default=0.85, help="Prewarm target go weight on go-routed samples.")
    train_parser.add_argument("--mixture-gate-prewarm-ambiguous-threshold", type=float, default=0.05, help="Prewarm target maximum ambiguous gate share for every route class.")
    train_parser.add_argument("--mixture-creep-prewarm-action-loss-threshold", type=float, default=0.02, help="Maximum creep speed-servo MSE required before PPO starts.")
    train_parser.add_argument("--stop-after-mixture-prewarm", dest="stop_after_mixture_prewarm", action="store_true", help="Save the accepted prewarm checkpoint and exit before PPO.")
    train_parser.add_argument("--continue-after-mixture-prewarm", dest="stop_after_mixture_prewarm", action="store_false", help="Continue into PPO after accepted prewarm.")
    train_parser.set_defaults(stop_after_mixture_prewarm=None)
    train_parser.add_argument("--mixture-gate-freeze-ppo-until-saturated", action="store_true", help="Prevent PPO gradients from updating gate params until stop/go routing is stable for the patience window.")
    train_parser.add_argument("--mixture-gate-unfreeze-weight-threshold", type=float, default=0.80, help="Optional brake-weight margin on stop labels for unfreezing PPO access to gate params; set 0 to use argmax/ambiguity only.")
    train_parser.add_argument("--mixture-gate-unfreeze-argmax-threshold", type=float, default=0.98, help="Required stop/go argmax routing share before PPO can update gate params.")
    train_parser.add_argument("--mixture-gate-unfreeze-ambiguous-threshold", type=float, default=0.05, help="Maximum stop/go ambiguous gate share before PPO can update gate params.")
    train_parser.add_argument("--mixture-gate-unfreeze-patience-updates", type=int, default=10, help="Consecutive saturated updates required before PPO can update gate params.")
    train_parser.add_argument("--mixture-gate-loss-decay-after-unfreeze", action="store_true", help="Start mixture gate CE decay schedule relative to the gate unfreeze update instead of absolute update zero.")
    train_parser.set_defaults(mixture_gate_loss_detach_shared=True)
    train_parser.add_argument("--go-component-reference-kl-coefficient", type=float, default=0.0, help="KL coefficient that keeps the mixture go component close to the reference policy on go-labeled states.")
    train_parser.add_argument("--reference-kl-coefficient", type=float, default=0.0)
    train_parser.add_argument("--reference-kl-all-coefficient", type=float, default=0.0)
    train_parser.add_argument("--red-target-crawl-speed", type=float, default=None, help="Override the auxiliary red-stop crawl speed target in m/s.")
    train_parser.add_argument("--red-target-approach-gain", type=float, default=None, help="Override the auxiliary red-stop distance-to-target speed gain.")
    train_parser.add_argument("--red-target-stop-margin", type=float, default=None, help="Override the auxiliary target stopping distance before the stop line in meters.")
    train_parser.add_argument("--red-target-queue-lead-margin", type=float, default=None, help="Front-bumper stop margin used by the queue-aware auxiliary target for lead vehicles.")
    train_parser.add_argument("--red-target-brake-safety", type=float, default=None, help="Override the auxiliary red-stop braking safety factor.")
    train_parser.add_argument("--red-target-min-brake", type=float, default=None, help="Minimum auxiliary braking acceleration in m/s^2 when a red-facing car is above the desired stop profile.")
    train_parser.add_argument("--queue-action-target", action="store_true", help="Use front-vehicle queue gaps as a training-only auxiliary action target on red queue samples.")
    train_parser.add_argument("--creep-reapproach-label", action="store_true", help="Latch slow closed-red vehicles far short of their queue target into brake-component creep supervision until they reach the hold window.")
    train_parser.add_argument("--creep-reapproach-min-target-error", type=float, default=2.0)
    train_parser.add_argument("--creep-reapproach-max-speed", type=float, default=0.5)
    train_parser.add_argument("--creep-route-max-speed", type=float, default=2.0, help="Observable brake/creep route boundary in m/s; must remain above the creep servo target.")
    train_parser.add_argument("--closed-signal-approach-speed-gain", type=float, default=None, help="Override reward-side closed-signal target speed gain.")
    train_parser.add_argument("--red-stop-potential-coefficient", type=float, default=None, help="Enable potential-based red queue shaping with this coefficient. Zero or omitted keeps legacy red-zone shaping.")
    train_parser.add_argument("--red-stop-potential-gamma", type=float, default=None, help="Discount used in gamma*phi(next)-phi(current) red stop potential shaping.")
    train_parser.add_argument("--red-stop-potential-window", type=float, default=None, help="Target-error window in meters for red stop hold reward under potential shaping.")
    train_parser.add_argument("--red-stop-potential-hold-reward", type=float, default=None, help="Small hold reward at the red queue target under potential shaping.")
    train_parser.add_argument("--red-stop-potential-speed-penalty", type=float, default=None, help="Speed penalty scale inside the red queue target window under potential shaping.")
    train_parser.add_argument(
        "--behavior-stage",
        choices=sorted(BEHAVIOR_STAGE_TASKS),
        help="Behavior curriculum stage. Fine-tune stages that add behavior may require --reference-checkpoint.",
    )
    train_parser.add_argument(
        "--reference-kl-green-only",
        action="store_true",
        help="Apply reference-policy KL only to legal green/go samples. Useful when adding red-stop behavior from a green checkpoint.",
    )
    train_parser.add_argument(
        "--reference-kl-all-labels",
        dest="reference_kl_stop_hold_only",
        action="store_false",
        help="Apply reference-policy KL on all labeled active samples instead of only stop/hold labels.",
    )
    train_parser.set_defaults(reference_kl_stop_hold_only=True, reference_kl_green_only=False)
    train_parser.add_argument("--safety-replay-workers", type=int, default=0)
    train_parser.add_argument("--stop-action-exploration-probability", type=float, default=0.0, help="Training-only probability of sampling brake-biased longitudinal actions on stop-labeled rollout states.")
    train_parser.add_argument("--stop-action-exploration-mean", type=float, default=-0.65, help="Mean longitudinal action for training-only stop-labeled brake exploration.")
    train_parser.add_argument("--stop-action-exploration-std", type=float, default=0.20, help="Stddev for training-only stop-labeled brake exploration.")
    train_parser.add_argument("--training-tasks", nargs="+", default=None, help="Optional task names to include in the training distribution.")
    train_parser.add_argument(
        "--safety-replay-tasks",
        nargs="+",
        default=None,
        help="Task names assigned to dedicated behavior replay rollout workers.",
    )
    train_parser.add_argument("--rollout-closed-signal-stop-threshold", type=float, default=0.0)
    train_parser.add_argument("--rollout-guard-warmup-updates", type=int, default=0)
    train_parser.add_argument("--task-phase1-updates", type=int, default=0)
    train_parser.add_argument("--task-phase2-updates", type=int, default=0)
    train_parser.add_argument(
        "--no-phase-advantage-normalization",
        dest="phase_advantage_normalization",
        action="store_false",
        help="Disable per-intent/phase advantage normalization.",
    )
    train_parser.add_argument(
        "--no-phase-balanced-minibatches",
        dest="phase_balanced_minibatches",
        action="store_false",
        help="Disable per-intent/phase balanced PPO minibatches.",
    )
    train_parser.set_defaults(phase_advantage_normalization=True, phase_balanced_minibatches=True)
    train_parser.add_argument(
        "--intent-shared-gradient",
        dest="intent_detach_shared",
        action="store_false",
        help="Allow intent loss to update shared actor/critic features. Default keeps intent loss detached.",
    )
    train_parser.set_defaults(intent_detach_shared=True)
    train_parser.add_argument("--validation-interval", type=int, default=10)
    train_parser.add_argument("--validation-episodes", type=int, default=8)
    train_parser.add_argument("--validation-workers", type=int, default=4)
    train_parser.add_argument("--validation-patience", type=int, default=10)
    train_parser.add_argument("--validation-regime-gates", action="store_true", help="Require solved sparse and 2/3-lane dense cells to clear hard no-regression gates before saving best.")
    train_parser.add_argument("--validation-eval-mode", choices=("standard", "green", "left_green", "left_release", "right_on_red", "red", "lead_red_stop", "lead_red_approach", "red_queue", "dense_redgreen", "mixed", "redgreen"), default="standard", help="Validation environment mode used for checkpoint selection. The red behavior stage defaults this to red.")
    train_parser.add_argument("--checkpoint-interval", type=int, default=10)
    train_parser.add_argument(
        "--validation-scenarios",
        nargs="+",
        default=DEFAULT_VALIDATION_SCENARIOS,
        help="Validation scenarios as lanes:cars:episode_seconds entries.",
    )
    train_parser.add_argument("--seed", type=int, default=7)
    train_parser.set_defaults(func=train)

    eval_parser = subparsers.add_parser("evaluate")
    eval_parser.add_argument("checkpoint", type=Path)
    eval_parser.add_argument("--output-csv", type=Path, required=True)
    eval_parser.add_argument("--episodes", type=int, default=50)
    eval_parser.add_argument("--lanes", type=int, default=2)
    eval_parser.add_argument("--cars", type=int, default=12)
    eval_parser.add_argument("--episode-seconds", type=float, default=120.0)
    eval_parser.add_argument("--all-red-seconds", type=float, default=0.0, help="All-red clearance interval inserted after each green/yellow phase during evaluation.")
    eval_parser.add_argument(
        "--eval-mode",
        choices=("standard", "green", "left_green", "left_release", "right_on_red", "red", "lead_red_stop", "lead_red_approach", "red_queue", "dense_redgreen", "yellow", "yellow_clear", "mixed", "redgreen"),
        default="standard",
        help="Use behavior-stage evaluation modes: green, red stop, yellow stop, yellow clear, or sparse mixed full-cycle.",
    )
    eval_parser.add_argument(
        "--green-one-car-per-lane",
        action="store_true",
        help="For green evaluation, set cars to 2 * lanes: one car in each lane on each green-side approach.",
    )
    eval_parser.add_argument("--hidden-size", type=int, default=128)
    eval_parser.add_argument("--graph-layers", type=int, default=2)
    eval_parser.add_argument("--max-cars", type=int, default=50)
    eval_parser.add_argument("--eval-workers", type=int, default=1)
    eval_parser.add_argument("--seed", type=int, default=7)
    eval_parser.set_defaults(func=evaluate)
    return parser.parse_args()


if __name__ == "__main__":
    arguments = parse_args()
    arguments.func(arguments)
