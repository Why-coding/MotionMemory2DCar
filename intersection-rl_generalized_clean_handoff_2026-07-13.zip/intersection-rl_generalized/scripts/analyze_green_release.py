from __future__ import annotations

import argparse
import csv
import sys
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from intersection_rl.config import EnvConfig
from intersection_rl.graph_observation import GraphObserver
from intersection_rl.graph_ppo import GraphActorCritic
from intersection_rl.multitask import MultiTaskIntersectionEnv, ScenarioTask


@dataclass
class VehicleReleaseTrace:
    episode: int
    vehicle_id: int
    approach: str
    lane: int
    route: str
    start_distance_to_stop: float
    start_speed: float
    saw_closed_before_green: bool = False
    first_green_time: float | None = None
    first_green_distance_to_stop: float | None = None
    first_green_speed: float | None = None
    first_green_action: float | None = None
    release_time: float | None = None
    max_legal_stall_seconds: float = 0.0
    max_blocked_stall_seconds: float = 0.0
    early_green_actions: list[float] = field(default_factory=list)
    early_green_speeds: list[float] = field(default_factory=list)
    early_green_progress: float = 0.0
    final_distance_to_stop: float = 0.0
    final_speed: float = 0.0
    outcome: str = "unknown"

    def row(self, episode_seconds: float) -> dict[str, float | int | str]:
        if self.first_green_time is None:
            release_delay = ""
            censored_delay = ""
        else:
            end_time = self.release_time if self.release_time is not None else episode_seconds
            release_delay = max(0.0, end_time - self.first_green_time)
            censored_delay = int(self.release_time is None)
        return {
            "episode": self.episode,
            "vehicle_id": self.vehicle_id,
            "approach": self.approach,
            "lane": self.lane,
            "route": self.route,
            "start_distance_to_stop": self.start_distance_to_stop,
            "start_speed": self.start_speed,
            "saw_closed_before_green": int(self.saw_closed_before_green),
            "first_green_time": "" if self.first_green_time is None else self.first_green_time,
            "first_green_distance_to_stop": ""
            if self.first_green_distance_to_stop is None
            else self.first_green_distance_to_stop,
            "first_green_speed": "" if self.first_green_speed is None else self.first_green_speed,
            "first_green_action": "" if self.first_green_action is None else self.first_green_action,
            "release_time": "" if self.release_time is None else self.release_time,
            "release_delay_seconds": release_delay,
            "release_delay_censored": censored_delay,
            "early_green_action_mean": float(np.mean(self.early_green_actions))
            if self.early_green_actions
            else "",
            "early_green_brake_share": float(np.mean(np.asarray(self.early_green_actions) < 0.0))
            if self.early_green_actions
            else "",
            "early_green_speed_mean": float(np.mean(self.early_green_speeds))
            if self.early_green_speeds
            else "",
            "early_green_progress": self.early_green_progress,
            "max_legal_stall_seconds": self.max_legal_stall_seconds,
            "max_blocked_stall_seconds": self.max_blocked_stall_seconds,
            "final_distance_to_stop": self.final_distance_to_stop,
            "final_speed": self.final_speed,
            "outcome": self.outcome,
        }


def make_env(max_cars: int, lanes: int, cars: int, episode_seconds: float, seed: int) -> MultiTaskIntersectionEnv:
    config = EnvConfig(
        max_cars=max_cars,
        min_cars=1,
        lanes_per_approach=lanes,
        episode_seconds=episode_seconds,
        protected_left_signal=True,
        allow_right_on_red=False,
        right_turns_enabled=False,
        strict_lane_mapping=True,
        initial_lateral_noise=0.0,
        randomize_initial_signal_phase=True,
        safety_filter_enabled=False,
        intersection_reservation_enabled=False,
        curriculum_enabled=False,
        curriculum_progression_enabled=False,
        seed=seed,
    )
    task = ScenarioTask(
        "diagnostic_redgreen",
        lanes,
        lanes,
        cars,
        cars,
        episode_seconds,
        episode_seconds,
        1.0,
        "redgreen",
        10.0,
        32.0,
        12.0,
        14.0,
        0.0,
        2.0,
        False,
        "all",
    )
    return MultiTaskIntersectionEnv(config, tasks=(task,))


def make_model(observer: GraphObserver, checkpoint: Path, hidden_size: int, graph_layers: int, seed: int) -> GraphActorCritic:
    spec = observer.spec
    model = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=hidden_size,
        layers=graph_layers,
        seed=seed,
    )
    model.load(checkpoint)
    model.eval()
    return model


def classify_outcome(env: MultiTaskIntersectionEnv, vehicle_id: int, truncated: bool) -> str:
    vehicle = env.vehicles[vehicle_id]
    if not vehicle.failed and not vehicle.active:
        return "completed"
    if vehicle.crossed_on_red:
        return "red_violation"
    if vehicle.collided:
        return "collision"
    if truncated:
        if (
            vehicle.legal_stall_seconds >= env.config.stuck_timeout_seconds
            or vehicle.blocked_stall_seconds >= env.config.stuck_timeout_seconds
        ):
            return "stuck_timeout"
        return "moving_timeout"
    if vehicle.failed:
        return "failed_other"
    return "active"


def run_episode(
    env: MultiTaskIntersectionEnv,
    observer: GraphObserver,
    model: GraphActorCritic,
    episode: int,
    seed: int,
    cars: int,
    release_speed: float,
    early_window_seconds: float,
) -> list[VehicleReleaseTrace]:
    _, info = env.reset(seed=seed, options={"vehicle_count": cars})
    traces = {}
    for vehicle in env.vehicles:
        distance_to_stop = vehicle.stop_progress - vehicle.progress
        traces[vehicle.vehicle_id] = VehicleReleaseTrace(
            episode=episode,
            vehicle_id=vehicle.vehicle_id,
            approach=vehicle.approach,
            lane=vehicle.lane,
            route=vehicle.route,
            start_distance_to_stop=float(distance_to_stop),
            start_speed=float(vehicle.speed),
            final_distance_to_stop=float(distance_to_stop),
            final_speed=float(vehicle.speed),
        )

    observation = observer.encode(env)
    done = False
    truncated = False
    previous_progress = {vehicle.vehicle_id: float(vehicle.progress) for vehicle in env.vehicles}
    while not done:
        actions, _, _ = model.act(observation, deterministic=True)
        now = float(info["elapsed_seconds"])
        for vehicle in env.vehicles:
            trace = traces[vehicle.vehicle_id]
            if not vehicle.active:
                continue
            distance_to_stop = float(vehicle.stop_progress - vehicle.progress)
            movement_permitted = env._movement_permitted(vehicle)
            front_gap, _, _ = env._front_vehicle_metrics(vehicle)
            legally_clear = movement_permitted and front_gap > env.config.minimum_front_gap
            if not movement_permitted and distance_to_stop > 0.0:
                trace.saw_closed_before_green = True
            if legally_clear and trace.first_green_time is None:
                trace.first_green_time = now
                trace.first_green_distance_to_stop = distance_to_stop
                trace.first_green_speed = float(vehicle.speed)
                trace.first_green_action = float(actions[vehicle.vehicle_id, 0])
            if trace.first_green_time is not None and now - trace.first_green_time <= early_window_seconds:
                trace.early_green_actions.append(float(actions[vehicle.vehicle_id, 0]))
                trace.early_green_speeds.append(float(vehicle.speed))
            trace.max_legal_stall_seconds = max(
                trace.max_legal_stall_seconds,
                float(vehicle.legal_stall_seconds),
            )
            trace.max_blocked_stall_seconds = max(
                trace.max_blocked_stall_seconds,
                float(vehicle.blocked_stall_seconds),
            )

        _, _, terminated, truncated, info = env.step(actions)
        for vehicle in env.vehicles:
            trace = traces[vehicle.vehicle_id]
            old_progress = previous_progress.get(vehicle.vehicle_id, float(vehicle.progress))
            progress_delta = max(0.0, float(vehicle.progress) - old_progress)
            previous_progress[vehicle.vehicle_id] = float(vehicle.progress)
            trace.final_distance_to_stop = float(vehicle.stop_progress - vehicle.progress)
            trace.final_speed = float(vehicle.speed)
            if trace.first_green_time is not None:
                trace.early_green_progress += progress_delta
            if (
                trace.first_green_time is not None
                and trace.release_time is None
                and vehicle.speed >= release_speed
            ):
                trace.release_time = float(info["elapsed_seconds"])
        observation = observer.encode(env)
        done = terminated or truncated

    for vehicle_id, trace in traces.items():
        trace.outcome = classify_outcome(env, vehicle_id, truncated)
    return list(traces.values())


def summarize(rows: list[dict[str, float | int | str]]) -> dict[str, float | int]:
    total = len(rows)
    waited = [row for row in rows if row["saw_closed_before_green"] == 1 and row["first_green_time"] != ""]
    completed = sum(1 for row in rows if row["outcome"] == "completed")
    red = sum(1 for row in rows if row["outcome"] == "red_violation")
    stuck = sum(1 for row in rows if row["outcome"] == "stuck_timeout")
    moving = sum(1 for row in rows if row["outcome"] == "moving_timeout")
    release_delays = [
        float(row["release_delay_seconds"])
        for row in waited
        if row["release_delay_seconds"] != "" and row["release_delay_censored"] == 0
    ]
    censored = sum(1 for row in waited if row["release_delay_censored"] == 1)
    early_actions = [
        float(row["early_green_action_mean"])
        for row in waited
        if row["early_green_action_mean"] != ""
    ]
    early_brake = [
        float(row["early_green_brake_share"])
        for row in waited
        if row["early_green_brake_share"] != ""
    ]
    return {
        "vehicles": total,
        "red_wait_then_green_vehicles": len(waited),
        "completed_pct": 100.0 * completed / max(total, 1),
        "red_violation_pct": 100.0 * red / max(total, 1),
        "stuck_timeout_pct": 100.0 * stuck / max(total, 1),
        "moving_timeout_pct": 100.0 * moving / max(total, 1),
        "released_pct_of_waited": 100.0 * (len(waited) - censored) / max(len(waited), 1),
        "release_delay_mean": float(np.mean(release_delays)) if release_delays else 0.0,
        "release_delay_p90": float(np.percentile(release_delays, 90)) if release_delays else 0.0,
        "unreleased_after_green": censored,
        "early_green_action_mean": float(np.mean(early_actions)) if early_actions else 0.0,
        "early_green_brake_share": float(np.mean(early_brake)) if early_brake else 0.0,
    }


def main() -> None:
    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
    parser = argparse.ArgumentParser(description="Diagnose deterministic green-release behavior from a redgreen checkpoint.")
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("--lanes", type=int, default=2)
    parser.add_argument("--cars", type=int, default=8)
    parser.add_argument("--episodes", type=int, default=10)
    parser.add_argument("--episode-seconds", type=float, default=60.0)
    parser.add_argument("--max-cars", type=int, default=50)
    parser.add_argument("--hidden-size", type=int, default=128)
    parser.add_argument("--graph-layers", type=int, default=2)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--release-speed", type=float, default=0.8)
    parser.add_argument("--early-window-seconds", type=float, default=4.0)
    parser.add_argument("--output-csv", type=Path, default=None)
    args = parser.parse_args()

    observer = GraphObserver(max_vehicle_nodes=args.max_cars)
    model = make_model(observer, args.checkpoint, args.hidden_size, args.graph_layers, args.seed)
    env = make_env(args.max_cars, args.lanes, args.cars, args.episode_seconds, args.seed)
    rows: list[dict[str, float | int | str]] = []
    try:
        for episode in range(args.episodes):
            traces = run_episode(
                env,
                observer,
                model,
                episode,
                args.seed + episode,
                args.cars,
                args.release_speed,
                args.early_window_seconds,
            )
            rows.extend(trace.row(args.episode_seconds) for trace in traces)
    finally:
        env.close()

    summary = summarize(rows)
    for key, value in summary.items():
        if isinstance(value, float):
            print(f"{key}={value:.4f}")
        else:
            print(f"{key}={value}")

    if args.output_csv is not None:
        args.output_csv.parent.mkdir(parents=True, exist_ok=True)
        with args.output_csv.open("w", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)


if __name__ == "__main__":
    main()
