from __future__ import annotations

from pathlib import Path

import run_front_bumper_rebaseline as canonical


canonical.RESULT_ROOT = (
    canonical.PROJECT_ROOT
    / "results/protected_redgreen_front_bumper_polish_v1b_200k/promotion"
)
canonical.CHECKPOINTS = {
    "polish_best": (
        "results/protected_redgreen_front_bumper_polish_v1b_200k/checkpoints/"
        "protected_redgreen_front_bumper_polish_v1b_200k_best.npz"
    ),
}


if __name__ == "__main__":
    canonical.main()
