from __future__ import annotations

import run_front_bumper_rebaseline as canonical


canonical.RESULT_ROOT = (
    canonical.PROJECT_ROOT
    / "results/dilemma_latch_rebaseline_2026_07_12"
)
canonical.CHECKPOINTS = {
    "old_selected": (
        "checkpoints/"
        "protected_redgreen_generalized_v1_selected.npz"
    ),
    "polish_selected": (
        "checkpoints/"
        "protected_redgreen_front_bumper_polish_v1b_200k_selected.npz"
    ),
}


if __name__ == "__main__":
    canonical.main()
