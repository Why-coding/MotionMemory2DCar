from __future__ import annotations

import argparse
import csv
from pathlib import Path
import subprocess
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULT_ROOT = PROJECT_ROOT / "results/front_bumper_rebaseline_2026_07_11"
CHECKPOINTS = {
    "old_selected": "checkpoints/protected_redgreen_generalized_v1_selected.npz",
    "new_keeper": "checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz",
}
MATRIX = {
    "sparse": {
        "cells": ((2, 8), (3, 12), (4, 16)),
        "seeds": (730, 731),
        "episodes": 20,
    },
    "dense": {
        "cells": ((2, 16), (3, 24), (4, 32)),
        "seeds": (730, 731, 732),
        "episodes": 20,
    },
    "stress": {
        "cells": ((2, 24), (3, 36), (4, 48)),
        "seeds": (730, 731),
        "episodes": 10,
    },
}
MEAN_COLUMNS = (
    "completed_pct",
    "completed_per_100_green_seconds",
    "red_violations_per_ep",
    "collisions_per_ep",
    "collision_vehicles_inside_intersection_per_ep",
    "inside_collision_pairs_with_clearance_eligible_per_ep",
    "inside_collision_pairs_without_clearance_eligible_per_ep",
    "proximity_events_per_ep",
    "stuck_timeouts_per_ep",
    "moving_timeouts_per_ep",
    "queue_stop_position_error_lead_avg",
    "queue_stop_position_error_second_avg",
    "queue_stop_position_error_third_plus_avg",
    "queue_follower_gap_error_avg",
    "cars_stopped_too_far_from_stop_line_per_ep",
    "lead_green_start_delay_seconds_per_ep",
    "follower_green_start_delay_seconds_per_ep",
    "second_green_start_delay_seconds_per_ep",
    "third_plus_green_start_delay_seconds_per_ep",
    "queue_discharge_delay_seconds_per_ep",
)


def cases():
    for checkpoint_name, checkpoint in CHECKPOINTS.items():
        for regime, config in MATRIX.items():
            for lanes, cars in config["cells"]:
                for seed in config["seeds"]:
                    yield {
                        "checkpoint_name": checkpoint_name,
                        "checkpoint": checkpoint,
                        "regime": regime,
                        "lanes": lanes,
                        "cars": cars,
                        "seed": seed,
                        "episodes": config["episodes"],
                    }


def case_stem(case: dict[str, object]) -> str:
    return (
        f"{case['checkpoint_name']}_{case['regime']}_"
        f"{case['lanes']}l_{case['cars']}c_seed{case['seed']}"
    )


def run_case(case: dict[str, object], force: bool, dry_run: bool) -> None:
    raw_dir = RESULT_ROOT / "raw"
    log_dir = RESULT_ROOT / "logs"
    raw_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    stem = case_stem(case)
    output_csv = raw_dir / f"{stem}.csv"
    log_path = log_dir / f"{stem}.log"
    if output_csv.exists() and not force:
        print(f"skip_complete case={stem}", flush=True)
        return

    command = [
        sys.executable,
        "-u",
        "scripts/train_graph_multitask.py",
        "evaluate",
        str(case["checkpoint"]),
        "--output-csv",
        str(output_csv.relative_to(PROJECT_ROOT)),
        "--episodes",
        str(case["episodes"]),
        "--lanes",
        str(case["lanes"]),
        "--cars",
        str(case["cars"]),
        "--episode-seconds",
        "60",
        "--all-red-seconds",
        "3.5",
        "--eval-mode",
        "dense_redgreen",
        "--max-cars",
        "50",
        "--eval-workers",
        "4",
        "--seed",
        str(case["seed"]),
    ]
    print(f"start case={stem}", flush=True)
    if dry_run:
        print("command=" + " ".join(command), flush=True)
        return
    with log_path.open("w") as log:
        process = subprocess.Popen(
            command,
            cwd=PROJECT_ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        assert process.stdout is not None
        for line in process.stdout:
            log.write(line)
            log.flush()
            print(line, end="", flush=True)
        return_code = process.wait()
    if return_code != 0:
        output_csv.unlink(missing_ok=True)
        raise RuntimeError(f"Evaluation failed for {stem}; see {log_path}")
    print(f"complete case={stem}", flush=True)


def aggregate() -> None:
    rows = []
    for checkpoint_name in CHECKPOINTS:
        for regime, config in MATRIX.items():
            for lanes, cars in config["cells"]:
                seed_rows = []
                for seed in config["seeds"]:
                    path = RESULT_ROOT / "raw" / (
                        f"{checkpoint_name}_{regime}_{lanes}l_{cars}c_seed{seed}.csv"
                    )
                    if not path.exists():
                        raise FileNotFoundError(f"Missing rebaseline artifact: {path}")
                    with path.open(newline="") as source:
                        seed_rows.append(next(csv.DictReader(source)))

                episodes_total = sum(int(row["episodes"]) for row in seed_rows)
                first = seed_rows[0]
                summary = {
                    "checkpoint": checkpoint_name,
                    "density": regime,
                    "lanes": lanes,
                    "cars": cars,
                    "seeds": ",".join(str(seed) for seed in config["seeds"]),
                    "episodes_total": episodes_total,
                    "n_seed_rows": len(seed_rows),
                    "package_path": first["package_path"],
                    "geometry_convention": first["geometry_convention"],
                    "checkpoint_format": first["checkpoint_format"],
                    "actor_head": first["actor_head"],
                    "action_distribution": first["action_distribution"],
                    "checkpoint_geometry_convention": first["checkpoint_geometry_convention"],
                }
                for column in MEAN_COLUMNS:
                    summary[column] = sum(
                        float(row[column]) * int(row["episodes"]) for row in seed_rows
                    ) / episodes_total
                sample_total = sum(
                    float(row["queue_stop_position_samples_per_ep"]) * int(row["episodes"])
                    for row in seed_rows
                )
                summary["queue_stop_position_error_avg"] = (
                    sum(
                        float(row["queue_stop_position_error_avg"])
                        * float(row["queue_stop_position_samples_per_ep"])
                        * int(row["episodes"])
                        for row in seed_rows
                    )
                    / max(sample_total, 1.0)
                )
                rows.append(summary)

    output = RESULT_ROOT / "summary_by_cell.csv"
    with output.open("w", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"aggregated={output}", flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the canonical front-bumper rebaseline.")
    parser.add_argument("--force", action="store_true", help="Rerun completed raw cells.")
    parser.add_argument("--dry-run", action="store_true", help="Print commands without running them.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    for case in cases():
        run_case(case, force=args.force, dry_run=args.dry_run)
    if not args.dry_run:
        aggregate()


if __name__ == "__main__":
    main()
