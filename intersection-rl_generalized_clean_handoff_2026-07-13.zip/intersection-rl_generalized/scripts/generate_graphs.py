from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib.pyplot as plt


EVAL_METRICS = [
    ("completed_pct", "Completion %"),
    ("failed_pct", "Failure %"),
    ("non_timeout_failed_pct", "Non-timeout failure %"),
    ("incomplete_pct", "Incomplete / timeout %"),
    ("stuck_timeout_pct", "Stuck timeout %"),
    ("timeout_failures_per_ep", "Timeouts / episode"),
    ("stuck_timeouts_per_ep", "Stuck timeouts / episode"),
    ("collisions_per_ep", "Collisions / episode"),
    ("proximity_events_per_ep", "Proximity events / episode"),
    ("red_violations_per_ep", "Red violations / episode"),
    ("yellow_violations_per_ep", "Yellow violations / episode"),
    ("closed_signal_violations_per_ep", "Closed-signal violations / episode"),
]

TRAIN_SERIES = [
    ("rollout_mean_reward", "Rollout mean reward"),
    ("completed_clean", "Clean completions / update"),
    ("failed", "Failures / update"),
    ("collisions", "Collisions / update"),
    ("proximity_events", "Proximity events / update"),
    ("red", "Red violations / update"),
    ("yellow", "Yellow violations / update"),
    ("closed_signal", "Closed-signal violations / update"),
    ("value_loss", "Value loss"),
    ("entropy", "Entropy"),
]


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="") as source:
        return list(csv.DictReader(source))


def read_eval_rows(results_dir: Path) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for path in sorted(results_dir.glob("*eval*.csv")):
        with path.open(newline="") as source:
            for row in csv.DictReader(source):
                if "completed_pct" not in row or "cars" not in row:
                    continue
                row["source"] = path.name
                rows.append(row)
    return rows


def as_float(row: dict[str, str], key: str) -> float:
    try:
        return float(row.get(key, "0") or 0.0)
    except ValueError:
        return 0.0


def plot_eval(rows: list[dict[str, str]], output_dir: Path) -> None:
    if not rows:
        return
    output_dir.mkdir(parents=True, exist_ok=True)
    labels = []
    for row in rows:
        lanes = int(as_float(row, "lanes"))
        cars = int(as_float(row, "cars"))
        seconds = int(as_float(row, "episode_seconds"))
        labels.append(f"{lanes}L {cars}C\n{seconds}s")
    for key, title in EVAL_METRICS:
        values = [as_float(row, key) for row in rows]
        fig, ax = plt.subplots(figsize=(10, 4.8))
        ax.bar(labels, values, color="#2563eb")
        ax.set_title(title)
        ax.set_ylabel(title)
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()
        fig.savefig(output_dir / f"eval_{key}.png", dpi=160)
        plt.close(fig)


def plot_training(rows: list[dict[str, str]], output_dir: Path) -> None:
    if not rows:
        return
    output_dir.mkdir(parents=True, exist_ok=True)
    updates = [as_float(row, "update") for row in rows]
    for key, title in TRAIN_SERIES:
        values = [as_float(row, key) for row in rows]
        fig, ax = plt.subplots(figsize=(10, 4.8))
        ax.plot(updates, values, linewidth=1.8, color="#0f766e")
        ax.set_title(title)
        ax.set_xlabel("Update")
        ax.set_ylabel(title)
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(output_dir / f"train_{key}.png", dpi=160)
        plt.close(fig)

    validation_rows = [row for row in rows if row.get("validation_score")]
    if validation_rows:
        val_updates = [as_float(row, "update") for row in validation_rows]
        val_scores = [as_float(row, "validation_score") for row in validation_rows]
        best_scores = [as_float(row, "best_validation_score") for row in validation_rows]
        fig, ax = plt.subplots(figsize=(10, 4.8))
        ax.plot(val_updates, val_scores, marker="o", label="validation")
        ax.plot(val_updates, best_scores, marker="s", label="best so far")
        ax.set_title("Validation score")
        ax.set_xlabel("Update")
        ax.set_ylabel("Score")
        ax.grid(alpha=0.25)
        ax.legend()
        fig.tight_layout()
        fig.savefig(output_dir / "train_validation_score.png", dpi=160)
        plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate graph-policy training/evaluation figures.")
    parser.add_argument("--results-dir", type=Path, default=Path("results"))
    parser.add_argument("--output-dir", type=Path, default=Path("graphs"))
    parser.add_argument("--train-metrics", type=Path, default=Path("checkpoints/graph_multitask_v1_train_metrics.csv"))
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    plot_eval(read_eval_rows(args.results_dir), args.output_dir)
    plot_training(read_csv_rows(args.train_metrics), args.output_dir)
