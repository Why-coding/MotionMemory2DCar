from __future__ import annotations

from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
project_root_text = str(PROJECT_ROOT)
sys.path[:] = [entry for entry in sys.path if entry != project_root_text]
sys.path.insert(0, project_root_text)

import intersection_rl
from intersection_rl.cli import main
from intersection_rl.runtime import assert_project_runtime


assert_project_runtime(PROJECT_ROOT)


if __name__ == "__main__":
    main()
