"""Compatibility wrapper for the superseded forced-GO probe module."""

from scripts.run_three_component_creep_probe import creep_route_state, main


if __name__ == "__main__":
    main()
