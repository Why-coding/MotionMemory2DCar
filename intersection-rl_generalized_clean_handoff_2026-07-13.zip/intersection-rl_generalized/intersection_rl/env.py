from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from intersection_rl.config import EnvConfig
from intersection_rl.geometry import (
    APPROACHES,
    ROUTES,
    Polyline,
    build_route_path,
)
from intersection_rl.vehicle import Vehicle


class IntersectionEnv(gym.Env[np.ndarray, np.ndarray]):
    """Multi-agent four-way intersection with a parameter-sharing interface.

    The first dimension of the observation and action arrays is a stable vehicle
    slot. Inactive slots are masked in ``info["active_mask"]`` and ignored.
    """

    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 5}
    OBSERVATION_SIZE = 34
    ACTION_SIZE = 2
    INTENT_IGNORE = -1
    INTENT_STOP = 0
    INTENT_HOLD = 1
    INTENT_GO = 2
    INTENT_YIELD = 3
    INTENT_NAMES = ("stop", "hold", "go", "yield")

    def __init__(
        self,
        config: EnvConfig | None = None,
        render_mode: str | None = None,
    ) -> None:
        super().__init__()
        self.config = config or EnvConfig()
        self.render_mode = render_mode
        self.observation_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(self.config.max_cars, self.OBSERVATION_SIZE),
            dtype=np.float32,
        )
        self.action_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(self.config.max_cars, self.ACTION_SIZE),
            dtype=np.float32,
        )
        self.vehicles: list[Vehicle] = []
        self.elapsed_seconds = 0.0
        self.step_count = 0
        self.completed_vehicles = 0
        self.failed_vehicles = 0
        self.safety_overrides = 0
        self._intent_stop_latched = np.zeros(self.config.max_cars, dtype=bool)
        self._intent_creep_latched = np.zeros(self.config.max_cars, dtype=bool)
        self._clearance_eligible = np.zeros(self.config.max_cars, dtype=bool)
        self._dilemma_clearance_eligible = np.zeros(
            self.config.max_cars, dtype=bool
        )
        self._signal_phase_name = ""
        self._signal_phase_elapsed_seconds = 0.0
        self._collision_pairs: set[tuple[int, int]] = set()
        self._last_collision_pairs: set[tuple[int, int]] = set()
        self._predictive_cache_key: tuple[tuple[int, bool, float, float, float], ...] | None = None
        self._predictive_cache: np.ndarray | None = None
        self._route_conflict_cache: dict[tuple[tuple[object, ...], tuple[object, ...]], bool] = {}
        self._renderer = None
        self.episode_lanes_per_approach = self.config.lanes_per_approach
        self.episode_protected_left_signal = self.config.protected_left_signal
        self.episode_allow_right_on_red = self.config.allow_right_on_red
        self.episode_safety_filter_enabled = self.config.safety_filter_enabled
        self.episode_min_cars = self.config.min_cars
        self.episode_max_cars = self.config.max_cars
        self.episode_resets = 0

    # Week 5: initialize 8-12 vehicles on legal two-lane movements.
    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed if seed is not None else self.config.seed)
        self.elapsed_seconds = 0.0
        self.step_count = 0
        self.completed_vehicles = 0
        self.failed_vehicles = 0
        self.safety_overrides = 0
        self._ensure_intent_latch_size()
        self._intent_stop_latched[:] = False
        self._intent_creep_latched[:] = False
        self._ensure_clearance_latch_size()
        self._clearance_eligible[:] = False
        self._dilemma_clearance_eligible[:] = False
        self._signal_phase_name = ""
        self._signal_phase_elapsed_seconds = 0.0
        self._collision_pairs.clear()
        self._last_collision_pairs.clear()
        self._predictive_cache_key = None
        self._predictive_cache = None
        self._route_conflict_cache.clear()
        self.vehicles = []
        self._sample_episode_configuration()
        if self.config.randomize_initial_signal_phase:
            if self.config.randomize_initial_green_phase_only:
                self.elapsed_seconds = self._sample_initial_green_signal_time()
            else:
                self.elapsed_seconds = float(
                    self.np_random.uniform(0.0, self._signal_cycle_seconds())
                )
        if options and "initial_signal_time" in options:
            self.elapsed_seconds = float(options["initial_signal_time"])
        self._sync_signal_phase_tracker()
        dropout = self.config.safety_filter_dropout_rate if self.config.safety_filter_enabled else 0.0
        self.episode_safety_filter_enabled = (
            self.config.safety_filter_enabled
            and float(self.np_random.random()) >= dropout
        )
        self.episode_resets += 1
        requested_count = (options or {}).get("vehicle_count")
        capacity = self._lane_capacity(self.episode_lanes_per_approach)
        min_count = self.episode_min_cars
        max_count = min(self.episode_max_cars, capacity)
        if min_count > max_count:
            raise ValueError(
                "sampled lane count cannot fit the configured minimum cars"
            )
        count = int(
            requested_count
            if requested_count is not None
            else self.np_random.integers(min_count, max_count + 1)
        )
        if not min_count <= count <= max_count:
            raise ValueError("vehicle_count must be inside configured bounds")
        self._spawn_vehicles(count)
        observation = self._get_observation()
        info = self._get_info(np.zeros(self.config.max_cars, dtype=np.float32))
        if self.render_mode == "human":
            self.render()
        return observation, info


    def _sample_episode_configuration(self) -> None:
        if self.config.curriculum_enabled and self.config.curriculum_progression_enabled:
            episode = self.episode_resets
            self.episode_protected_left_signal = self.config.protected_left_signal
            self.episode_allow_right_on_red = self.config.allow_right_on_red
            if self.config.curriculum_stage == 2:
                self.episode_lanes_per_approach = 2
                if episode < self.config.stage2_phase1_episodes:
                    car_count = min(8, self.config.curriculum_max_cars)
                    self.episode_min_cars = car_count
                    self.episode_max_cars = car_count
                    return
                if episode < self.config.stage2_phase2_episodes:
                    car_count = min(10, self.config.curriculum_max_cars)
                    self.episode_min_cars = car_count
                    self.episode_max_cars = car_count
                    return
                if episode < self.config.stage2_phase3_episodes:
                    car_count = min(11, self.config.curriculum_max_cars)
                    self.episode_min_cars = car_count
                    self.episode_max_cars = car_count
                    return
                if episode < self.config.stage2_phase4_episodes:
                    car_count = min(12, self.config.curriculum_max_cars)
                    self.episode_min_cars = car_count
                    self.episode_max_cars = car_count
                    return
            elif self.config.curriculum_stage == 3:
                self.episode_protected_left_signal = True
                self.episode_allow_right_on_red = True
                if episode < self.config.stage3_phase1_episodes:
                    self.episode_lanes_per_approach = 2
                    car_count = min(8, self.config.curriculum_max_cars)
                    self.episode_min_cars = car_count
                    self.episode_max_cars = car_count
                    return
                if episode < self.config.stage3_phase2_episodes:
                    self.episode_lanes_per_approach = 2
                    car_count = min(10, self.config.curriculum_max_cars)
                    self.episode_min_cars = car_count
                    self.episode_max_cars = car_count
                    return
                if episode < self.config.stage3_phase3_episodes:
                    self.episode_lanes_per_approach = 2
                    car_count = min(12, self.config.curriculum_max_cars)
                    self.episode_min_cars = car_count
                    self.episode_max_cars = car_count
                    return
                if episode < self.config.stage3_phase4_episodes:
                    self.episode_lanes_per_approach = self.config.curriculum_max_lanes
                    car_count = min(10, self.config.curriculum_max_cars)
                    self.episode_min_cars = car_count
                    self.episode_max_cars = car_count
                    return
                if episode < self.config.stage3_phase5_episodes:
                    self.episode_lanes_per_approach = self.config.curriculum_max_lanes
                    car_count = min(12, self.config.curriculum_max_cars)
                    self.episode_min_cars = car_count
                    self.episode_max_cars = car_count
                    return
                if episode < self.config.stage3_phase6_episodes:
                    self.episode_lanes_per_approach = self.config.curriculum_max_lanes
                    car_count = min(14, self.config.curriculum_max_cars)
                    self.episode_min_cars = car_count
                    self.episode_max_cars = car_count
                    return
            else:
                if episode < self.config.curriculum_phase1_episodes:
                    self.episode_lanes_per_approach = self.config.curriculum_min_lanes
                    self.episode_min_cars = min(2, self.config.curriculum_max_cars)
                    self.episode_max_cars = min(2, self.config.curriculum_max_cars)
                    return
                if episode < self.config.curriculum_phase2_episodes:
                    self.episode_lanes_per_approach = self.config.curriculum_min_lanes
                    self.episode_min_cars = min(4, self.config.curriculum_max_cars)
                    self.episode_max_cars = min(4, self.config.curriculum_max_cars)
                    return
                if episode < self.config.curriculum_phase3_episodes:
                    self.episode_lanes_per_approach = self.config.curriculum_max_lanes
                    self.episode_min_cars = min(4, self.config.curriculum_max_cars)
                    self.episode_max_cars = min(4, self.config.curriculum_max_cars)
                    return
        if not self.config.curriculum_enabled:
            self.episode_lanes_per_approach = self.config.lanes_per_approach
            self.episode_min_cars = self.config.min_cars
            self.episode_max_cars = self.config.max_cars
            self.episode_protected_left_signal = self.config.protected_left_signal
            self.episode_allow_right_on_red = self.config.allow_right_on_red
            return
        self.episode_lanes_per_approach = int(
            self.np_random.integers(
                self.config.curriculum_min_lanes,
                self.config.curriculum_max_lanes + 1,
            )
        )
        self.episode_min_cars = self.config.curriculum_min_cars
        self.episode_max_cars = self.config.curriculum_max_cars
        self.episode_protected_left_signal = (
            bool(self.np_random.integers(2))
            if self.config.curriculum_randomize_left_signal
            else self.config.protected_left_signal
        )
        self.episode_allow_right_on_red = (
            bool(self.np_random.integers(2))
            if self.config.curriculum_randomize_right_on_red
            else self.config.allow_right_on_red
        )


    def _queue_spacing(self) -> float:
        return max(
            self.config.queue_follower_gap_target_min,
            self.config.spawn_queue_gap,
        )

    def _lane_capacity(self, lane_count: int) -> int:
        queue_spacing = self._queue_spacing()
        lead_gap = max(self.config.spawn_lead_gap, self.config.queue_stop_target_min)
        available_length = self.config.road_length - self._half_vehicle_length() - lead_gap
        maximum_queue_levels = max(1, int(max(0.0, available_length) / queue_spacing) + 1)
        return 4 * lane_count * maximum_queue_levels

    def _half_vehicle_length(self) -> float:
        return 0.5 * max(0.0, float(self.config.vehicle_length))

    def _front_progress(self, vehicle: Vehicle, progress: float | None = None) -> float:
        center_progress = vehicle.progress if progress is None else float(progress)
        return center_progress + self._half_vehicle_length()

    def _rear_progress(self, vehicle: Vehicle, progress: float | None = None) -> float:
        center_progress = vehicle.progress if progress is None else float(progress)
        return center_progress - self._half_vehicle_length()

    def _distance_to_stop_line(self, vehicle: Vehicle, progress: float | None = None) -> float:
        return float(vehicle.stop_progress - self._front_progress(vehicle, progress))

    def _has_crossed_stop_line(self, vehicle: Vehicle, progress: float | None = None) -> bool:
        return self._distance_to_stop_line(vehicle, progress) <= 0.0

    def _center_progress_for_front_distance(self, vehicle: Vehicle, distance_to_stop: float) -> float:
        return float(vehicle.stop_progress - self._half_vehicle_length() - distance_to_stop)

    def _legal_routes_for_lane(self, lane: int) -> tuple[str, ...]:
        if self.episode_lanes_per_approach == 1:
            routes: tuple[str, ...] = ("left", "straight", "right")
        elif self.config.strict_lane_mapping:
            if lane == 0:
                routes = ("left",)
            elif lane == self.episode_lanes_per_approach - 1:
                routes = ("straight", "right")
            else:
                routes = ("straight",)
        elif lane == 0:
            routes = ("left", "straight")
        elif lane == self.episode_lanes_per_approach - 1:
            routes = ("straight", "right")
        else:
            routes = ("straight",)
        if not self.config.right_turns_enabled:
            routes = tuple(route for route in routes if route != "right")
        if not routes:
            routes = ("straight",)
        return routes

    def _destination_lane_for_route(self, lane: int, route: str) -> int:
        if not self.config.strict_lane_mapping:
            return int(self.np_random.integers(self.episode_lanes_per_approach))
        if route == "left":
            return 0
        if route == "right":
            return self.episode_lanes_per_approach - 1
        return min(lane, self.episode_lanes_per_approach - 1)

    def _initial_speed_for_vehicle(self, vehicle: Vehicle) -> float:
        if self._movement_has_green(vehicle):
            return float(
                self.np_random.uniform(
                    self.config.spawn_green_min_speed,
                    self.config.spawn_green_max_speed,
                )
            )
        return float(self.config.spawn_red_speed)

    def _sample_initial_green_signal_time(self) -> float:
        green = self.config.signal_green_seconds
        all_red = max(0.0, self.config.signal_all_red_seconds)
        starts_and_durations: list[tuple[float, float]] = []
        if self.episode_protected_left_signal:
            left = self.config.left_signal_green_seconds
            yellow = max(0.0, self.config.signal_yellow_seconds)
            segment = left + all_red + green + yellow + all_red
            for axis_start in (0.0, segment):
                starts_and_durations.append((axis_start, left))
                starts_and_durations.append((axis_start + left + all_red, green))
        else:
            yellow = max(0.0, self.config.signal_yellow_seconds)
            segment = green + yellow + all_red
            starts_and_durations.extend(((0.0, green), (segment, green)))
        start, duration = starts_and_durations[
            int(self.np_random.integers(0, len(starts_and_durations)))
        ]
        start_window = min(duration, max(self.config.dt, 0.2 * duration))
        return float(start + self.np_random.uniform(0.0, start_window))

    def _random_spawn_geometry(
        self,
        selected_slots: list[tuple[str, int, tuple[str, ...], int]],
    ) -> dict[tuple[str, int, int], float]:
        if not self.config.spawn_randomize_longitudinal_positions:
            return {}
        lead_min = max(
            self.config.queue_stop_target_max,
            self.config.spawn_random_lead_gap_min,
        )
        lead_max = max(lead_min, self.config.spawn_random_lead_gap_max)
        gap_min = max(
            self.config.minimum_front_gap,
            self.config.spawn_random_queue_gap_min,
        )
        gap_max = max(gap_min, self.config.spawn_random_queue_gap_max)
        distances: dict[tuple[str, int, int], float] = {}
        by_lane: dict[tuple[str, int], set[int]] = {}
        for approach, lane, _, queue_index in selected_slots:
            by_lane.setdefault((approach, lane), set()).add(queue_index)
        maximum_front_distance = self.config.road_length - self._half_vehicle_length()
        for lane_key, indices in by_lane.items():
            ordered = sorted(indices)
            spacings = {
                index: float(self.np_random.uniform(gap_min, gap_max))
                for index in ordered
                if index > 0
            }
            trailing_distance = sum(spacings.values())
            bounded_lead_max = min(
                lead_max,
                maximum_front_distance - trailing_distance,
            )
            lead_distance = float(
                self.np_random.uniform(
                    lead_min,
                    max(lead_min, bounded_lead_max),
                )
            )
            distance = lead_distance
            for index in ordered:
                if index > 0:
                    distance += spacings[index]
                distances[(*lane_key, index)] = distance
        return distances

    def _apply_random_spawn_speeds(self) -> None:
        if not self.config.spawn_randomize_longitudinal_positions:
            return
        closed_minimum = max(
            0.0,
            self.config.spawn_random_closed_speed_min,
        )
        closed_maximum = max(
            closed_minimum,
            self.config.spawn_random_closed_speed_max,
        )
        green_minimum = max(
            0.0,
            self.config.spawn_random_green_speed_min,
        )
        green_maximum = max(
            green_minimum,
            self.config.spawn_random_green_speed_max,
        )
        braking = max(self.config.comfortable_braking, 1e-3)
        safety = max(self.config.spawn_speed_safety_factor, 1.0)
        by_lane: dict[tuple[str, int], list[Vehicle]] = {}
        for vehicle in self.vehicles:
            by_lane.setdefault((vehicle.approach, vehicle.lane), []).append(vehicle)
        for lane_vehicles in by_lane.values():
            lane_vehicles.sort(key=lambda item: item.progress, reverse=True)
            front: Vehicle | None = None
            for vehicle in lane_vehicles:
                speed_minimum, speed_maximum = (
                    (green_minimum, green_maximum)
                    if self._movement_has_green(vehicle)
                    else (closed_minimum, closed_maximum)
                )
                sampled_speed = float(
                    self.np_random.uniform(speed_minimum, speed_maximum)
                )
                line_available = max(
                    0.0,
                    self._distance_to_stop_line(vehicle)
                    - self.config.queue_stop_target_max,
                )
                speed_cap = np.sqrt(2.0 * braking * line_available / safety)
                if front is not None:
                    gap_available = max(
                        0.0,
                        front.progress
                        - vehicle.progress
                        - self.config.minimum_front_gap,
                    )
                    following_cap = np.sqrt(
                        max(
                            0.0,
                            front.speed * front.speed
                            + 2.0 * braking * gap_available / safety,
                        )
                    )
                    speed_cap = min(speed_cap, following_cap)
                vehicle.speed = float(
                    min(sampled_speed, speed_cap, self.config.max_speed)
                )
                front = vehicle

    def _spawn_vehicles(self, count: int) -> None:
        queue_spacing = self._queue_spacing()
        lead_gap = max(self.config.spawn_lead_gap, self.config.queue_stop_target_min)
        base_slots: list[tuple[str, int, tuple[str, ...]]] = []
        for approach in APPROACHES:
            for lane in range(self.episode_lanes_per_approach):
                legal_routes = self._legal_routes_for_lane(lane)
                signal_filter = self.config.spawn_signal_filter
                if self.config.spawn_permitted_movements_only or signal_filter == "green":
                    legal_routes = tuple(
                        route for route in legal_routes if self._has_green(approach, route)
                    )
                elif signal_filter == "yellow":
                    phase, _ = self._signal_phase()
                    axis = "NS" if approach in ("N", "S") else "EW"
                    legal_routes = legal_routes if phase == f"{axis}_YELLOW" else ()
                elif signal_filter == "next_left_release":
                    phase, _ = self._signal_phase()
                    approach_axis = "NS" if approach in ("N", "S") else "EW"
                    next_left_axis = "EW" if phase in {"NS_GREEN", "NS_ALL_RED"} else "NS" if phase in {"EW_GREEN", "EW_ALL_RED"} else ""
                    legal_routes = tuple(
                        route for route in legal_routes
                        if route == "left" and approach_axis == next_left_axis and not self._has_green(approach, route)
                    )
                elif signal_filter == "next_release":
                    phase, _ = self._signal_phase()
                    approach_axis = "NS" if approach in ("N", "S") else "EW"
                    if phase.endswith("_LEFT_GREEN") or phase.endswith("_LEFT_ALL_RED"):
                        next_axis = phase[:2]
                        next_routes = ("straight",)
                    elif phase in {"NS_GREEN", "NS_ALL_RED"}:
                        next_axis = "EW"
                        next_routes = ("left",)
                    elif phase in {"EW_GREEN", "EW_ALL_RED"}:
                        next_axis = "NS"
                        next_routes = ("left",)
                    else:
                        next_axis = ""
                        next_routes = ()
                    legal_routes = tuple(
                        route for route in legal_routes
                        if approach_axis == next_axis and route in next_routes and not self._has_green(approach, route)
                    )
                elif signal_filter == "right_red":
                    phase, _ = self._signal_phase()
                    axis = "NS" if approach in ("N", "S") else "EW"
                    axis_yellow = phase == f"{axis}_YELLOW"
                    legal_routes = tuple(
                        route for route in legal_routes
                        if route == "right" and not self._has_green(approach, route) and not axis_yellow
                    )
                elif signal_filter == "right_red_conflict":
                    phase, _ = self._signal_phase()
                    axis = "NS" if approach in ("N", "S") else "EW"
                    axis_yellow = phase == f"{axis}_YELLOW"
                    legal_routes = tuple(
                        route for route in legal_routes
                        if (route == "right" and not self._has_green(approach, route) and not axis_yellow)
                        or (route == "straight" and self._has_green(approach, route))
                    )
                elif signal_filter == "closed":
                    phase, _ = self._signal_phase()
                    axis = "NS" if approach in ("N", "S") else "EW"
                    axis_yellow = phase == f"{axis}_YELLOW"
                    legal_routes = tuple(
                        route for route in legal_routes if not self._has_green(approach, route) and not axis_yellow
                    )
                if legal_routes:
                    base_slots.append((approach, lane, legal_routes))
        if not base_slots:
            raise ValueError("no legal spawn slots are available for the current signal phase")
        queue_levels = int(np.ceil(count / len(base_slots)))
        available_length = self.config.road_length - self._half_vehicle_length() - lead_gap
        maximum_queue_levels = max(1, int(max(0.0, available_length) / queue_spacing) + 1)
        if queue_levels > maximum_queue_levels:
            capacity = len(base_slots) * maximum_queue_levels
            raise ValueError(
                f"{count} cars do not fit on the configured roads; maximum is {capacity}"
            )
        slot_candidates = [
            (approach, lane, legal_routes, queue_index)
            for queue_index in range(queue_levels)
            for approach, lane, legal_routes in base_slots
        ]
        selected = self.np_random.choice(
            len(slot_candidates), size=count, replace=False
        )
        selected_slots = [
            slot_candidates[int(slot_index)] for slot_index in selected
        ]
        random_distances = self._random_spawn_geometry(selected_slots)
        for vehicle_id, (
            approach,
            lane,
            legal_routes,
            queue_index,
        ) in enumerate(selected_slots):
            if (
                self.config.curriculum_stage == 3
                and self.episode_allow_right_on_red
                and "right" in legal_routes
                and float(self.np_random.random()) < self.config.stage3_right_turn_probability
            ):
                route = "right"
            else:
                route = str(self.np_random.choice(legal_routes))
            destination_lane = self._destination_lane_for_route(lane, route)
            path = Polyline(
                build_route_path(
                    approach,
                    lane,
                    route,
                    self.config.lane_width,
                    self.config.road_length,
                    self.config.intersection_half_size,
                    self.episode_lanes_per_approach,
                    destination_lane,
                )
            )
            stop_progress, _ = path.project(path.points[1])
            if self.config.spawn_randomize_longitudinal_positions:
                distance_to_stop = random_distances[
                    (approach, lane, queue_index)
                ]
                progress = max(
                    0.0,
                    stop_progress
                    - self._half_vehicle_length()
                    - distance_to_stop,
                )
            elif (
                self.config.spawn_progress_offset_min is not None
                and self.config.spawn_progress_offset_max is not None
            ):
                offset = float(
                    self.np_random.uniform(
                        self.config.spawn_progress_offset_min,
                        self.config.spawn_progress_offset_max,
                    )
                )
                progress = max(0.0, stop_progress - self._half_vehicle_length() + offset - queue_index * queue_spacing)
            else:
                progress = max(0.0, stop_progress - self._half_vehicle_length() - lead_gap - queue_index * queue_spacing)
            vehicle = Vehicle(
                vehicle_id=vehicle_id,
                approach=approach,
                lane=lane,
                route=route,
                destination_lane=destination_lane,
                path=path,
                stop_progress=stop_progress,
                progress=progress,
                speed=0.0,
                lateral_offset=float(
                    self.np_random.uniform(
                        -self.config.initial_lateral_noise,
                        self.config.initial_lateral_noise,
                    )
                ),
            )
            vehicle.speed = self._initial_speed_for_vehicle(vehicle)
            self.vehicles.append(vehicle)
        self._apply_random_spawn_speeds()

    # Week 5: basic longitudinal kinematic model and traffic-rule events.
    def step(
        self, action: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, bool, bool, dict[str, Any]]:
        actions = np.asarray(action, dtype=np.float32)
        if actions.shape != (self.config.max_cars, self.ACTION_SIZE):
            raise ValueError(
                f"action must have shape ({self.config.max_cars}, {self.ACTION_SIZE})"
            )
        actions = np.clip(actions, -1.0, 1.0)

        previous_active = np.array(
            [vehicle.active for vehicle in self.vehicles], dtype=bool
        )
        previous_progress = np.array(
            [vehicle.progress for vehicle in self.vehicles], dtype=np.float32
        )
        phase_before_step, _ = self._signal_phase()
        red_violations = np.zeros(self.config.max_cars, dtype=bool)
        yellow_violations = np.zeros(self.config.max_cars, dtype=bool)
        left_yield_violations = np.zeros(self.config.max_cars, dtype=bool)
        right_yield_violations = np.zeros(self.config.max_cars, dtype=bool)
        right_on_red_entries = np.zeros(self.config.max_cars, dtype=bool)
        right_lane_violations = np.zeros(self.config.max_cars, dtype=bool)
        lane_drift_warnings = np.zeros(self.config.max_cars, dtype=bool)
        safety_overrides = np.zeros(self.config.max_cars, dtype=bool)
        unsafe_requests = np.zeros(self.config.max_cars, dtype=bool)

        for vehicle in self.vehicles:
            if not vehicle.active:
                continue
            acceleration_command = float(actions[vehicle.vehicle_id, 0])
            acceleration = (
                acceleration_command * self.config.max_acceleration
                if acceleration_command >= 0.0
                else acceleration_command * self.config.comfortable_braking
            )
            steering = float(actions[vehicle.vehicle_id, 1])
            acceleration = float(
                np.clip(
                    acceleration,
                    -self.config.comfortable_braking,
                    self.config.max_acceleration,
                )
            )
            acceleration, override, unsafe_request = self._filter_acceleration(
                vehicle,
                acceleration,
                acceleration_command,
            )
            safety_overrides[vehicle.vehicle_id] = override
            unsafe_requests[vehicle.vehicle_id] = unsafe_request
            was_before_stop = not self._has_crossed_stop_line(vehicle)
            movement_permitted_before = self._movement_permitted(vehicle)
            entry_blocked = self._intersection_entry_risk(vehicle)
            left_conflict = self._left_turn_conflict(vehicle)
            right_conflict = self._right_turn_conflict(vehicle)
            right_on_red = self._can_turn_right_on_red(vehicle)
            vehicle.step(
                acceleration,
                steering,
                self.config.dt,
                self.config.max_speed,
                self.config.lateral_speed,
                self._max_lateral_offset(),
                self.config.lane_centering_gain,
                self.config.lane_edge_steering_damping,
                self.config.vehicle_length,
            )
            lane_drift_warnings[vehicle.vehicle_id] = self._lane_drift_warning(vehicle)
            crossed_stop = was_before_stop and self._has_crossed_stop_line(vehicle)
            if (
                crossed_stop
                and self.episode_safety_filter_enabled
                and (not movement_permitted_before or entry_blocked)
            ):
                vehicle.progress = self._center_progress_for_front_distance(vehicle, 0.05)
                vehicle.speed = 0.0
                vehicle.acceleration = -self.config.comfortable_braking
                safety_overrides[vehicle.vehicle_id] = True
                unsafe_requests[vehicle.vehicle_id] = True
                crossed_stop = False
            if crossed_stop:
                if vehicle.route == "right" and not self._is_rightmost_lane(vehicle):
                    right_lane_violations[vehicle.vehicle_id] = True
                if self._movement_has_green(vehicle):
                    pass
                elif self._clearance_eligible_to_proceed(vehicle):
                    pass
                elif right_on_red:
                    right_on_red_entries[vehicle.vehicle_id] = True
                    if right_conflict:
                        right_yield_violations[vehicle.vehicle_id] = True
                else:
                    vehicle.crossed_on_red = True
                    if self._movement_has_yellow(vehicle):
                        yellow_violations[vehicle.vehicle_id] = True
                    else:
                        red_violations[vehicle.vehicle_id] = True
                if left_conflict:
                    left_yield_violations[vehicle.vehicle_id] = True

        closed_signal_violations = red_violations | yellow_violations
        progress_delta = float(
            sum(
                max(0.0, vehicle.progress - previous_progress[vehicle.vehicle_id])
                for vehicle in self.vehicles
                if previous_active[vehicle.vehicle_id]
            )
        )
        self._update_stall_timers(previous_progress)
        self._predictive_cache_key = None
        self._predictive_cache = None
        collision_flags = self._detect_collisions()
        proximity_flags, proximity_events = self._detect_proximity_violations(collision_flags)
        collision_phase_metrics = self._collision_phase_metrics()
        self.elapsed_seconds += self.config.dt
        self.step_count += 1
        phase_after_step, _ = self._signal_phase()
        if phase_after_step != phase_before_step:
            self._update_clearance_eligibility_on_phase_change(phase_before_step)
        self._sync_signal_phase_tracker()

        rewards = self._calculate_rewards(
            previous_progress,
            collision_flags,
            red_violations,
            yellow_violations,
            closed_signal_violations,
            left_yield_violations,
            right_yield_violations,
            right_on_red_entries,
            right_lane_violations,
            proximity_flags,
            lane_drift_warnings,
            safety_overrides,
            unsafe_requests,
        )
        failed_flags = (
            collision_flags
            | closed_signal_violations
            | left_yield_violations
            | right_yield_violations
            | right_lane_violations
        )
        failure_cause_counts = {
            "failed_by_red": int(red_violations.sum()),
            "failed_by_yellow": int(yellow_violations.sum()),
            "failed_by_collision": int(collision_flags.sum()),
            "failed_by_left_yield": int(left_yield_violations.sum()),
            "failed_by_right_yield": int(right_yield_violations.sum()),
            "failed_by_lane_violation": int(right_lane_violations.sum()),
        }
        queue_metrics = self._queue_step_metrics(closed_signal_violations)
        collision_location_metrics = self._collision_location_metrics(collision_flags)
        completed_delta = 0
        failed_delta = 0
        timeout_delta = 0
        timeout_stuck_delta = 0
        truncated = self.step_count >= self.config.max_steps
        for vehicle in self.vehicles:
            if previous_active[vehicle.vehicle_id] and not vehicle.active:
                self.completed_vehicles += 1
                completed_delta += 1
            if failed_flags[vehicle.vehicle_id] and vehicle.active:
                vehicle.failed = True
                vehicle.active = False
                self._clearance_eligible[vehicle.vehicle_id] = False
                self._dilemma_clearance_eligible[vehicle.vehicle_id] = False
                self.failed_vehicles += 1
                failed_delta += 1
            elif truncated and vehicle.active:
                if (
                    vehicle.legal_stall_seconds >= self.config.stuck_timeout_seconds
                    or vehicle.blocked_stall_seconds >= self.config.stuck_timeout_seconds
                ):
                    timeout_stuck_delta += 1
                vehicle.failed = True
                vehicle.active = False
                self._clearance_eligible[vehicle.vehicle_id] = False
                self._dilemma_clearance_eligible[vehicle.vehicle_id] = False
                rewards[vehicle.vehicle_id] -= self.config.timeout_failure_penalty
                self.failed_vehicles += 1
                failed_delta += 1
                timeout_delta += 1
        safety_override_count = int(safety_overrides.sum())
        self.safety_overrides += safety_override_count
        terminated = not any(vehicle.active for vehicle in self.vehicles)
        observation = self._get_observation()
        info = self._get_info(rewards)
        info["collisions"] = int(collision_flags.sum() // 2)
        info["proximity_violations"] = int(proximity_flags.sum())
        info["proximity_events"] = proximity_events
        info["red_light_violations"] = int(red_violations.sum())
        info["yellow_light_violations"] = int(yellow_violations.sum())
        info["closed_signal_violations"] = int(closed_signal_violations.sum())
        info["left_yield_violations"] = int(left_yield_violations.sum())
        info["right_yield_violations"] = int(right_yield_violations.sum())
        info["right_lane_violations"] = int(right_lane_violations.sum())
        info.update(failure_cause_counts)
        info.update(collision_location_metrics)
        info.update(collision_phase_metrics)
        info.update(queue_metrics)
        info["lane_drift_warnings"] = int(lane_drift_warnings.sum())
        info["right_on_red_entries"] = int(right_on_red_entries.sum())
        info["safety_overrides"] = safety_override_count
        info["unsafe_requests"] = int(unsafe_requests.sum())
        info["completed_delta"] = completed_delta
        info["failed_delta"] = failed_delta
        info["timeout_failures"] = timeout_delta
        info["stuck_timeout_failures"] = timeout_stuck_delta
        info["progress_delta"] = progress_delta
        info["safety_score"] = self._safety_score(
            completed_delta,
            failed_delta,
            int(collision_flags.sum() // 2),
            int(proximity_flags.sum()),
            proximity_events,
            int(closed_signal_violations.sum()),
            int(left_yield_violations.sum()),
            int(right_yield_violations.sum()),
            int(right_lane_violations.sum()),
            int(lane_drift_warnings.sum()),
            safety_override_count,
            progress_delta,
        )

        if self.render_mode == "human":
            self.render()
        return observation, rewards, terminated, truncated, info

    def _update_stall_timers(self, previous_progress: np.ndarray) -> None:
        for vehicle in self.vehicles:
            if not vehicle.active:
                continue
            progress_delta = max(0.0, vehicle.progress - previous_progress[vehicle.vehicle_id])
            front_gap, _, _ = self._front_vehicle_metrics(vehicle)
            legal_clear = (
                self._movement_permitted(vehicle)
                and front_gap > self.config.minimum_front_gap
            )
            low_motion = (
                progress_delta < 0.05
                and vehicle.speed < self.config.legal_stall_speed_threshold
            )
            if legal_clear and low_motion:
                vehicle.legal_stall_seconds += self.config.dt
                vehicle.blocked_stall_seconds = 0.0
            elif not legal_clear and vehicle.speed < self.config.legal_stall_speed_threshold:
                vehicle.blocked_stall_seconds += self.config.dt
                vehicle.legal_stall_seconds = 0.0
            else:
                vehicle.legal_stall_seconds = 0.0
                vehicle.blocked_stall_seconds = 0.0

    def _vehicle_corners(self, vehicle: Vehicle) -> np.ndarray:
        center, heading = vehicle.pose()
        forward = np.array([np.cos(heading), np.sin(heading)])
        lateral = np.array([-np.sin(heading), np.cos(heading)])
        half_length = self.config.vehicle_length / 2.0
        half_width = self.config.vehicle_width / 2.0
        return np.array(
            [
                center + forward * half_length + lateral * half_width,
                center + forward * half_length - lateral * half_width,
                center - forward * half_length - lateral * half_width,
                center - forward * half_length + lateral * half_width,
            ]
        )

    def _vehicle_corners_at(
        self,
        vehicle: Vehicle,
        progress: float,
        lateral_offset: float | None = None,
    ) -> np.ndarray:
        center, heading = vehicle.path.sample(progress)
        normal = np.array([-np.sin(heading), np.cos(heading)])
        offset = vehicle.lateral_offset if lateral_offset is None else lateral_offset
        center = center + normal * offset
        forward = np.array([np.cos(heading), np.sin(heading)])
        lateral = np.array([-np.sin(heading), np.cos(heading)])
        half_length = self.config.vehicle_length / 2.0
        half_width = self.config.vehicle_width / 2.0
        return np.array(
            [
                center + forward * half_length + lateral * half_width,
                center + forward * half_length - lateral * half_width,
                center - forward * half_length - lateral * half_width,
                center - forward * half_length + lateral * half_width,
            ]
        )

    def _polygons_overlap(self, first_corners: np.ndarray, second_corners: np.ndarray) -> bool:
        axes = []
        for corners in (first_corners, second_corners):
            for index in (0, 1):
                edge = corners[(index + 1) % 4] - corners[index]
                axis = np.array([-edge[1], edge[0]])
                axis /= max(np.linalg.norm(axis), 1e-8)
                axes.append(axis)
        for axis in axes:
            first_min, first_max = self._project_polygon(first_corners, axis)
            second_min, second_max = self._project_polygon(second_corners, axis)
            if first_max < second_min or second_max < first_min:
                return False
        return True

    def _polygon_clearance(self, first_corners: np.ndarray, second_corners: np.ndarray) -> float:
        if self._polygons_overlap(first_corners, second_corners):
            return 0.0
        best = float("inf")
        for corners, other in ((first_corners, second_corners), (second_corners, first_corners)):
            for point in corners:
                for index in range(4):
                    start = other[index]
                    end = other[(index + 1) % 4]
                    best = min(best, self._point_segment_distance(point, start, end))
        return best

    @staticmethod
    def _project_polygon(points: np.ndarray, axis: np.ndarray) -> tuple[float, float]:
        projected = points @ axis
        return float(projected.min()), float(projected.max())

    def _rectangles_overlap(self, first: Vehicle, second: Vehicle) -> bool:
        return self._polygons_overlap(
            self._vehicle_corners(first),
            self._vehicle_corners(second),
        )

    @staticmethod
    def _point_segment_distance(
        point: np.ndarray,
        start: np.ndarray,
        end: np.ndarray,
    ) -> float:
        segment = end - start
        length_sq = float(np.dot(segment, segment))
        if length_sq <= 1e-12:
            return float(np.linalg.norm(point - start))
        fraction = float(np.clip(np.dot(point - start, segment) / length_sq, 0.0, 1.0))
        closest = start + fraction * segment
        return float(np.linalg.norm(point - closest))

    def _rectangle_clearance(self, first: Vehicle, second: Vehicle) -> float:
        return self._polygon_clearance(
            self._vehicle_corners(first),
            self._vehicle_corners(second),
        )

    def _can_skip_proximity_clearance(self, first: Vehicle, second: Vehicle) -> bool:
        first_position, _ = first.pose()
        second_position, _ = second.pose()
        half_diagonal = 0.5 * float(
            np.hypot(self.config.vehicle_length, self.config.vehicle_width)
        )
        threshold = 2.0 * half_diagonal + self.config.proximity_clearance
        return float(np.linalg.norm(first_position - second_position)) > threshold

    def _detect_collisions(self) -> np.ndarray:
        flags = np.zeros(self.config.max_cars, dtype=bool)
        self._last_collision_pairs = set()
        active = [vehicle for vehicle in self.vehicles if vehicle.active]
        for first_index, first in enumerate(active):
            for second in active[first_index + 1 :]:
                pair = (
                    min(first.vehicle_id, second.vehicle_id),
                    max(first.vehicle_id, second.vehicle_id),
                )
                if pair not in self._collision_pairs and self._rectangles_overlap(
                    first, second
                ):
                    self._collision_pairs.add(pair)
                    self._last_collision_pairs.add(pair)
                    first.collided = True
                    second.collided = True
                    flags[first.vehicle_id] = True
                    flags[second.vehicle_id] = True
        return flags

    def _proximity_responsible_ids(self, first: Vehicle, second: Vehicle) -> tuple[int, ...]:
        same_lane_following = (
            first.approach == second.approach
            and first.lane == second.lane
            and first.route == second.route
        )
        if same_lane_following:
            rear = first if first.progress < second.progress else second
            return (rear.vehicle_id,)
        return first.vehicle_id, second.vehicle_id

    def _detect_proximity_violations(self, collisions: np.ndarray) -> tuple[np.ndarray, int]:
        flags = np.zeros(self.config.max_cars, dtype=bool)
        events = 0
        active = [vehicle for vehicle in self.vehicles if vehicle.active]
        for first_index, first in enumerate(active):
            for second in active[first_index + 1 :]:
                if collisions[first.vehicle_id] or collisions[second.vehicle_id]:
                    continue
                if self._can_skip_proximity_clearance(first, second):
                    continue
                if self._rectangle_clearance(first, second) < self.config.proximity_clearance:
                    events += 1
                    for vehicle_id in self._proximity_responsible_ids(first, second):
                        flags[vehicle_id] = True
        return flags, events

    # Week 5: reward traffic compliance, safety, progress, spacing, and lane path.
    def _calculate_rewards(
        self,
        previous_progress: np.ndarray,
        collisions: np.ndarray,
        red_violations: np.ndarray,
        yellow_violations: np.ndarray,
        closed_signal_violations: np.ndarray,
        left_yield_violations: np.ndarray,
        right_yield_violations: np.ndarray,
        right_on_red_entries: np.ndarray,
        right_lane_violations: np.ndarray,
        proximity_violations: np.ndarray,
        lane_drift_warnings: np.ndarray,
        safety_overrides: np.ndarray,
        unsafe_requests: np.ndarray,
    ) -> np.ndarray:
        rewards = np.zeros(self.config.max_cars, dtype=np.float32)
        for vehicle in self.vehicles:
            vehicle_id = vehicle.vehicle_id
            progress = max(0.0, vehicle.progress - previous_progress[vehicle_id])
            max_step_progress = max(self.config.max_speed * self.config.dt, 1e-3)
            normalized_progress = min(1.5, progress / max_step_progress)
            speed_ratio = min(1.0, vehicle.speed / max(self.config.max_speed, 1e-3))
            accel_ratio = max(0.0, vehicle.acceleration) / max(self.config.max_acceleration, 1e-3)
            brake_ratio = max(0.0, -vehicle.acceleration) / max(self.config.comfortable_braking, 1e-3)
            distance_to_stop = self._distance_to_stop_line(vehicle)
            movement_permitted = self._movement_permitted(vehicle)
            front_gap, front_relative_speed, front_ttc = self._front_vehicle_metrics(vehicle)
            has_front_vehicle = front_gap < self.config.road_length
            stopping_zone = max(10.0, vehicle.speed * 2.0)
            must_yield_before_stop = (
                not movement_permitted
                and 0.0 < distance_to_stop < stopping_zone
            )
            reward = self.config.progress_reward * normalized_progress
            if must_yield_before_stop:
                # Outcome-first red/yield shaping: do not teach a specific braking
                # profile here. The policy is judged by whether it reaches the
                # stop zone legally, not by a smooth deceleration trace.
                reward -= 0.10 * normalized_progress
                if vehicle.speed < 0.5:
                    reward += 0.12
            closed_signal_before_stop = (
                not self._movement_has_green(vehicle)
                and not self._can_turn_right_on_red(vehicle)
                and 0.0 < distance_to_stop < self.config.queue_approach_distance
            )
            stopping_margin = distance_to_stop - self._stopping_distance(vehicle)
            red_stop_required = closed_signal_before_stop and distance_to_stop < 45.0
            if closed_signal_before_stop:
                # Remove the generic progress reward on red; red progress is
                # rewarded only when it moves the car toward a legal stop zone.
                reward -= self.config.progress_reward * normalized_progress
            if red_stop_required and self.config.closed_signal_stop_potential_coefficient > 0.0:
                reward += self._closed_signal_stop_potential_reward(vehicle, previous_progress)
                target_error, target_has_front = self._closed_signal_stop_target_error(vehicle)
                if target_error is not None:
                    target_error_abs = abs(target_error)
                    target_window = max(self.config.closed_signal_stop_potential_window, 1e-3)
                    stopped = vehicle.speed < 0.35
                    reward -= self.config.closed_signal_accel_penalty * accel_ratio
                    if target_error_abs <= target_window:
                        reward += self.config.closed_signal_stop_potential_hold_reward
                        reward -= self.config.closed_signal_stop_potential_speed_penalty * speed_ratio
                        if stopped:
                            reward += self.config.closed_signal_hold_reward
                    elif target_error < -target_window:
                        overshoot_ratio = min(
                            1.0,
                            (-target_error - target_window) / max(self.config.vehicle_length, 1e-3),
                        )
                        reward -= self.config.closed_signal_margin_penalty * overshoot_ratio
                        reward -= 0.5 * self.config.closed_signal_stop_window_speed_penalty * speed_ratio
                    if target_has_front:
                        follower_gap_min = self.config.queue_follower_gap_target_min
                        if front_gap < follower_gap_min:
                            gap_error = min(1.0, (follower_gap_min - front_gap) / max(follower_gap_min, 1e-3))
                            reward -= self.config.front_min_gap_penalty * gap_error
                            reward -= self.config.front_closing_accel_penalty * accel_ratio
                    elif distance_to_stop < 12.0 and vehicle.speed > 0.5:
                        near_stop = 1.0 - max(0.0, distance_to_stop) / 12.0
                        reward -= 0.5 * self.config.closed_signal_near_stop_speed_penalty * speed_ratio * near_stop
            elif red_stop_required and not has_front_vehicle:
                reward -= self.config.closed_signal_accel_penalty * accel_ratio
                if distance_to_stop < 12.0 and vehicle.speed > 0.5:
                    near_stop = 1.0 - max(0.0, distance_to_stop) / 12.0
                    reward -= self.config.closed_signal_near_stop_speed_penalty * speed_ratio * near_stop
                in_stop_window = (
                    self.config.queue_stop_target_min
                    <= distance_to_stop
                    <= self.config.queue_stop_target_max
                )
                stopped = vehicle.speed < 0.35
                far_before_line = distance_to_stop > self.config.queue_stop_target_max
                if in_stop_window:
                    reward += self.config.queue_stop_position_reward
                    reward -= self.config.closed_signal_stop_window_speed_penalty * speed_ratio
                    if stopped:
                        reward += self.config.closed_signal_stop_window_zero_speed_reward
                        reward += self.config.closed_signal_hold_reward
                elif far_before_line:
                    gap_to_target = max(0.0, distance_to_stop - self.config.queue_stop_target_max)
                    distance_error_ratio = min(1.0, gap_to_target / 8.0)
                    desired_speed = min(
                        self.config.queue_approach_max_speed,
                        max(0.45, self.config.closed_signal_approach_speed_gain * gap_to_target),
                    )
                    speed_shortfall_ratio = min(
                        1.0,
                        max(0.0, desired_speed - vehicle.speed)
                        / max(self.config.queue_approach_max_speed, 1e-3),
                    )
                    reward += self.config.queue_approach_reward * normalized_progress * (1.0 + 0.5 * distance_error_ratio)
                    if vehicle.speed < desired_speed:
                        reward += 0.35 * self.config.queue_approach_reward * accel_ratio * distance_error_ratio
                        reward -= 0.35 * self.config.queue_far_idle_penalty * speed_shortfall_ratio * distance_error_ratio
                    if stopped or normalized_progress < 0.02:
                        reward -= self.config.queue_far_idle_penalty * (0.35 + 0.65 * distance_error_ratio)
                    if brake_ratio > 0.0 and vehicle.speed < desired_speed:
                        reward -= 0.45 * self.config.queue_far_idle_penalty * brake_ratio * distance_error_ratio
                else:
                    overshoot_ratio = min(
                        1.0,
                        max(0.0, self.config.queue_stop_target_min - distance_to_stop)
                        / max(self.config.vehicle_length, 1e-3),
                    )
                    reward -= self.config.closed_signal_margin_penalty * overshoot_ratio
                    reward -= self.config.closed_signal_stop_window_speed_penalty * speed_ratio
            elif red_stop_required and has_front_vehicle:
                follower_gap_min = self.config.queue_follower_gap_target_min
                follower_gap_max = self.config.queue_follower_gap_target_max
                stopped = vehicle.speed < 0.35
                in_gap_window = follower_gap_min <= front_gap <= follower_gap_max
                if in_gap_window:
                    reward += self.config.queue_front_safe_gap_reward
                    if stopped and front_relative_speed < 0.3:
                        reward += self.config.closed_signal_hold_reward
                    reward -= 0.25 * max(0.0, vehicle.speed - self.config.queue_approach_max_speed) / max(self.config.max_speed, 1e-3)
                elif front_gap > follower_gap_max:
                    gap_error = min(1.0, (front_gap - follower_gap_max) / 8.0)
                    if stopped or normalized_progress < 0.02:
                        reward -= self.config.queue_follower_large_gap_penalty * (0.35 + 0.65 * gap_error)
                    else:
                        reward += self.config.queue_follower_approach_reward * normalized_progress * (1.0 + 0.5 * gap_error)
                    if vehicle.speed < self.config.queue_approach_max_speed:
                        reward += 0.25 * self.config.queue_follower_approach_reward * accel_ratio * gap_error
                else:
                    gap_error = min(1.0, (follower_gap_min - front_gap) / max(follower_gap_min, 1e-3))
                    reward -= self.config.front_min_gap_penalty * gap_error
                    reward -= self.config.closed_signal_stop_window_speed_penalty * speed_ratio
                    reward -= self.config.front_closing_accel_penalty * accel_ratio
            reward -= 0.01  # Discourage blocking the intersection indefinitely.
            if not closed_signal_before_stop:
                reward -= 0.004 * abs(vehicle.acceleration)
            # Week 6: lateral control must converge to the assigned route center.
            lane_limit = max(self._max_lateral_offset(), 1e-3)
            lateral_ratio = abs(vehicle.lateral_offset) / lane_limit
            reward -= 0.16 * lateral_ratio
            reward -= 0.02 * abs(vehicle.steering)
            if lane_drift_warnings[vehicle_id]:
                reward -= 0.8
            if vehicle.lateral_offset * vehicle.steering > 0.0:
                reward -= 0.08 * abs(vehicle.steering)

            close_gap_threshold = self.config.vehicle_length + 2.0
            if front_gap < close_gap_threshold:
                reward -= self.config.front_close_gap_penalty * (close_gap_threshold - front_gap)
            if front_gap < self.config.minimum_front_gap:
                reward -= self.config.front_min_gap_penalty * (self.config.minimum_front_gap - front_gap)
            if front_ttc < self.config.ttc_warning_seconds:
                reward -= self.config.front_ttc_warning_penalty * (self.config.ttc_warning_seconds - front_ttc)
            if front_ttc < self.config.ttc_critical_seconds:
                reward -= self.config.front_ttc_critical_penalty
            if front_relative_speed > 0.05:
                closing_ratio = min(1.0, front_relative_speed / max(self.config.max_speed, 1e-3))
                reward -= self.config.front_closing_accel_penalty * closing_ratio * max(0.0, vehicle.acceleration)
                if vehicle.acceleration < -0.2 and front_gap < self.config.queue_front_safe_gap_max:
                    reward += self.config.front_deceleration_reward * closing_ratio

            if safety_overrides[vehicle_id]:
                reward -= self.config.safety_override_penalty
            if unsafe_requests[vehicle_id]:
                reward -= self.config.unsafe_acceleration_penalty
            if proximity_violations[vehicle_id]:
                reward -= 28.0
            (
                predicted_collision,
                predicted_proximity,
                conflict_time,
                other_time_to_stop,
                ego_priority,
                intersection_occupied,
                conflicting_approach,
                min_future_clearance,
                *_rest,
            ) = self._predictive_features()[vehicle_id]
            reward -= self.config.predicted_conflict_penalty * predicted_collision
            reward -= self.config.predicted_proximity_penalty * predicted_proximity
            low_priority_conflict = (
                (predicted_collision > 0.0 or predicted_proximity > 0.0 or conflicting_approach > 0.0)
                and ego_priority < 0.5
                and distance_to_stop > -self.config.vehicle_length
            )
            if low_priority_conflict:
                urgency = 1.0 - min(conflict_time, other_time_to_stop)
                reward -= 0.7 * max(0.0, urgency)
                reward -= 0.25 * max(0.0, vehicle.speed / max(self.config.max_speed, 1e-3))
                reward -= 0.45 * max(0.0, vehicle.acceleration)
                if vehicle.acceleration < -0.2 or vehicle.speed < 0.5:
                    reward += 0.18
            if intersection_occupied > 0.0 and ego_priority < 0.5 and 0.0 < distance_to_stop < self.config.conflict_lookahead_distance:
                reward -= 0.35 * max(0.0, vehicle.speed / max(self.config.max_speed, 1e-3))
            if min_future_clearance < 0.04:
                reward -= 0.25 * (0.04 - min_future_clearance) / 0.04
            green_front_clear = front_gap > self.config.minimum_front_gap
            green_queue_zone = 0.0 < distance_to_stop < self.config.queue_approach_distance
            if movement_permitted and not must_yield_before_stop and not green_front_clear and distance_to_stop > 0.0:
                if vehicle.speed < 0.5 and vehicle.acceleration <= 0.1:
                    reward += self.config.green_blocked_hold_reward
                reward -= self.config.green_blocked_accel_penalty * max(0.0, vehicle.acceleration)
                reward -= self.config.green_blocked_speed_penalty * max(0.0, vehicle.speed - 0.5)
            if movement_permitted and green_front_clear and not must_yield_before_stop:
                speed_ratio = min(1.0, vehicle.speed / max(self.config.max_speed, 1e-3))
                reward += self.config.permitted_speed_reward * speed_ratio
                reward += self.config.permitted_acceleration_reward * accel_ratio
                if (
                    vehicle.route == "left"
                    and self.episode_protected_left_signal
                    and self._movement_has_green(vehicle)
                    and distance_to_stop > 0.0
                ):
                    phase, phase_ratio = self._signal_phase()
                    axis = "NS" if vehicle.approach in ("N", "S") else "EW"
                    left_green_age = (
                        phase_ratio * self.config.left_signal_green_seconds
                        if phase == f"{axis}_LEFT_GREEN"
                        else self.config.left_green_release_launch_seconds
                    )
                    launch_window = left_green_age <= self.config.left_green_release_launch_seconds
                    launch_scale = self.config.left_green_release_launch_scale if launch_window else 1.0
                    reward += launch_scale * self.config.left_green_release_progress_reward * progress
                    if vehicle.speed < 4.0:
                        reward += launch_scale * self.config.left_green_release_acceleration_reward * accel_ratio
                    if (
                        vehicle.speed < self.config.left_green_release_min_launch_speed
                        and progress < 0.05
                        and distance_to_stop > self.config.queue_stop_target_max + 2.0
                    ):
                        distance_ratio = min(
                            1.0,
                            distance_to_stop / max(self.config.queue_approach_distance, 1e-3),
                        )
                        stall_time = max(0.0, vehicle.legal_stall_seconds - 0.2)
                        launch_miss = max(0.0, left_green_age - self.config.left_green_release_launch_seconds)
                        reward -= self.config.left_green_release_stopped_far_penalty * (
                            distance_ratio + 0.35 * stall_time + 0.25 * launch_miss
                        )
                if distance_to_stop > 0.0:
                    if vehicle.speed < 0.25:
                        reward -= self.config.green_zero_speed_penalty
                    elif vehicle.speed < self.config.legal_stall_speed_threshold:
                        slow_ratio = 1.0 - vehicle.speed / max(self.config.legal_stall_speed_threshold, 1e-3)
                        reward -= self.config.green_slow_speed_penalty * slow_ratio
                    if progress < 0.02:
                        reward -= self.config.green_no_progress_penalty
                if green_queue_zone:
                    restart_needed = (
                        vehicle.legal_stall_seconds > 0.2
                        or vehicle.speed < self.config.legal_stall_speed_threshold
                    )
                    clear_gap_ratio = min(1.5, front_gap / max(self.config.minimum_front_gap, 1e-3))
                    if restart_needed:
                        reward += self.config.green_queue_progress_reward * normalized_progress * clear_gap_ratio
                        if vehicle.speed < 4.0:
                            accel_scale = 1.0 + min(1.0, max(0.0, vehicle.legal_stall_seconds - 0.2))
                            reward += self.config.green_queue_acceleration_reward * accel_ratio * accel_scale
                    else:
                        reward += 0.35 * self.config.green_queue_progress_reward * normalized_progress
                    if front_gap <= self.config.queue_front_safe_gap_max and restart_needed:
                        reward += self.config.green_follower_safe_gap_reward * normalized_progress
                    if (
                        vehicle.speed < 0.5
                        and progress < 0.04
                        and distance_to_stop > self.config.queue_stop_target_max + 2.0
                    ):
                        distance_ratio = min(
                            1.0,
                            distance_to_stop / max(self.config.queue_approach_distance, 1e-3),
                        )
                        stall_time = max(0.0, vehicle.legal_stall_seconds - 0.4)
                        reward -= self.config.green_queue_stopped_far_penalty * (distance_ratio + 0.35 * stall_time)
                if vehicle.speed < 1.0:
                    reward -= self.config.permitted_idle_penalty
                elif speed_ratio < 0.35:
                    reward -= 0.2 * (0.35 - speed_ratio)
                if vehicle.speed < self.config.legal_stall_speed_threshold and progress < 0.05:
                    stall_ratio = 1.0 - vehicle.speed / max(self.config.legal_stall_speed_threshold, 1e-3)
                    stall_time = max(0.0, vehicle.legal_stall_seconds - self.config.legal_stall_grace_seconds)
                    reward -= self.config.legal_stall_penalty * max(0.0, stall_ratio)
                    reward -= self.config.legal_stall_time_penalty * stall_time
                    if green_queue_zone:
                        reward -= self.config.green_queue_idle_penalty * max(0.0, stall_ratio)
                        reward -= self.config.green_queue_stall_time_penalty * stall_time

            right_on_red_available = (
                self._can_turn_right_on_red(vehicle)
                and movement_permitted
                and front_gap > self.config.minimum_front_gap
            )
            if right_on_red_entries[vehicle_id] and not right_yield_violations[vehicle_id]:
                reward += self.config.right_on_red_entry_reward
            elif right_on_red_available and 0.0 < distance_to_stop < self.config.right_yield_distance:
                reward += self.config.right_on_red_approach_reward * progress
                if vehicle.speed < self.config.legal_stall_speed_threshold and progress < 0.05:
                    stall_ratio = 1.0 - vehicle.speed / max(self.config.legal_stall_speed_threshold, 1e-3)
                    reward -= self.config.right_on_red_idle_penalty * max(0.0, stall_ratio)
            if collisions[vehicle_id]:
                reward -= 450.0
            if red_violations[vehicle_id]:
                reward -= self.config.red_light_violation_penalty
            if yellow_violations[vehicle_id]:
                reward -= self.config.yellow_light_violation_penalty
            if closed_signal_violations[vehicle_id] and not (red_violations[vehicle_id] or yellow_violations[vehicle_id]):
                reward -= self.config.red_light_violation_penalty
            if left_yield_violations[vehicle_id]:
                reward -= 4.0
            if right_yield_violations[vehicle_id]:
                reward -= 4.0
            if right_lane_violations[vehicle_id]:
                reward -= 5.0
            if (
                not vehicle.active
                and not vehicle.failed
                and self._rear_progress(vehicle, previous_progress[vehicle_id]) < vehicle.path.length
            ):
                reward += self.config.clean_completion_bonus

            # Week 7: jerk, explicit speed-limit, and merge-yield terms belong here.
            # Week 9: pedestrian braking and lane-change safety terms belong here.
            # Week 10: goal progress and risky late lane-change terms belong here.
            rewards[vehicle_id] = reward
        return rewards

    def _max_lateral_offset(self) -> float:
        return max(
            0.0,
            (self.config.lane_width - self.config.vehicle_width) / 2.0
            - self.config.lane_edge_margin,
        )

    def _lane_drift_warning(self, vehicle: Vehicle) -> bool:
        return abs(vehicle.lateral_offset) >= (
            self.config.lane_drift_warning_ratio * self._max_lateral_offset()
        )

    # Week 6: selectable protected-left or permissive-left signal plan.
    def _signal_cycle_seconds(self) -> float:
        green = self.config.signal_green_seconds
        yellow = max(0.0, self.config.signal_yellow_seconds)
        all_red = max(0.0, self.config.signal_all_red_seconds)
        if self.episode_protected_left_signal:
            return 2.0 * (
                self.config.left_signal_green_seconds + all_red + green + yellow + all_red
            )
        return 2.0 * (green + yellow + all_red)

    def _signal_phase(self) -> tuple[str, float]:
        green = self.config.signal_green_seconds
        yellow = max(0.0, self.config.signal_yellow_seconds)
        all_red = max(0.0, self.config.signal_all_red_seconds)
        if self.episode_protected_left_signal:
            left = self.config.left_signal_green_seconds
            segment = left + all_red + green + yellow + all_red
            time_in_cycle = self.elapsed_seconds % (2.0 * segment)
            axis = "NS" if time_in_cycle < segment else "EW"
            local_time = time_in_cycle % segment
            if local_time < left:
                return f"{axis}_LEFT_GREEN", local_time / max(left, 1e-6)
            local_time -= left
            if all_red > 0.0 and local_time < all_red:
                return f"{axis}_LEFT_ALL_RED", local_time / max(all_red, 1e-6)
            local_time -= all_red
            if local_time < green:
                return f"{axis}_GREEN", local_time / max(green, 1e-6)
            local_time -= green
            if yellow > 0.0 and local_time < yellow:
                return f"{axis}_YELLOW", local_time / max(yellow, 1e-6)
            local_time -= yellow
            if all_red > 0.0:
                return f"{axis}_ALL_RED", local_time / max(all_red, 1e-6)
            return f"{axis}_YELLOW", 1.0

        cycle = 2.0 * (green + yellow + all_red)
        time_in_cycle = self.elapsed_seconds % cycle
        segment = green + yellow + all_red
        axis = "NS" if time_in_cycle < segment else "EW"
        local_time = time_in_cycle % segment
        if local_time < green:
            return f"{axis}_GREEN", local_time / max(green, 1e-6)
        local_time -= green
        if yellow > 0.0 and local_time < yellow:
            return f"{axis}_YELLOW", local_time / max(yellow, 1e-6)
        local_time -= yellow
        if all_red > 0.0:
            return f"{axis}_ALL_RED", local_time / max(all_red, 1e-6)
        return f"{axis}_YELLOW", 1.0

    @staticmethod
    def _is_all_red_phase(phase: str) -> bool:
        return phase.endswith("_ALL_RED")

    def _signal_phase_duration(self, phase: str) -> float:
        if phase.endswith("_LEFT_GREEN"):
            return max(self.config.left_signal_green_seconds, 1e-6)
        if phase.endswith("_GREEN"):
            return max(self.config.signal_green_seconds, 1e-6)
        if phase.endswith("_YELLOW"):
            return max(self.config.signal_yellow_seconds, 1e-6)
        if self._is_all_red_phase(phase):
            return max(self.config.signal_all_red_seconds, 1e-6)
        return max(self.config.dt, 1e-6)

    def _sync_signal_phase_tracker(self) -> None:
        phase, ratio = self._signal_phase()
        self._signal_phase_name = phase
        self._signal_phase_elapsed_seconds = float(
            ratio * self._signal_phase_duration(phase)
        )

    def _ensure_clearance_latch_size(self) -> None:
        if self._clearance_eligible.shape[0] == self.config.max_cars:
            return
        previous = self._clearance_eligible
        previous_dilemma = self._dilemma_clearance_eligible
        self._clearance_eligible = np.zeros(self.config.max_cars, dtype=bool)
        self._dilemma_clearance_eligible = np.zeros(
            self.config.max_cars, dtype=bool
        )
        count = min(previous.shape[0], self._clearance_eligible.shape[0])
        self._clearance_eligible[:count] = previous[:count]
        self._dilemma_clearance_eligible[:count] = previous_dilemma[:count]

    def _phase_permitted_movement(self, phase: str, vehicle: Vehicle) -> bool:
        axis = "NS" if vehicle.approach in ("N", "S") else "EW"
        if self.episode_protected_left_signal and vehicle.route == "left":
            return phase == f"{axis}_LEFT_GREEN"
        return phase in {f"{axis}_GREEN", f"{axis}_YELLOW"}

    def _physically_unable_to_stop_before_line(self, vehicle: Vehicle) -> bool:
        distance = self._distance_to_stop_line(vehicle)
        if distance <= 0.0:
            return False
        physical_braking = max(self.config.comfortable_braking, 1e-6)
        required_deceleration = vehicle.speed * vehicle.speed / (2.0 * distance)
        return required_deceleration > physical_braking

    def _update_clearance_eligibility_on_phase_change(
        self,
        previous_phase: str | None = None,
    ) -> None:
        self._ensure_clearance_latch_size()
        current_phase, _ = self._signal_phase()
        for vehicle in self.vehicles:
            if not vehicle.active:
                self._clearance_eligible[vehicle.vehicle_id] = False
                self._dilemma_clearance_eligible[vehicle.vehicle_id] = False
                continue
            if self._has_crossed_stop_line(vehicle) and not vehicle.crossed_on_red:
                self._clearance_eligible[vehicle.vehicle_id] = True
            elif (
                self.config.dilemma_zone_clearance_enabled
                and previous_phase is not None
                and self._is_all_red_phase(current_phase)
                and self._phase_permitted_movement(previous_phase, vehicle)
                and self._physically_unable_to_stop_before_line(vehicle)
            ):
                self._clearance_eligible[vehicle.vehicle_id] = True
                self._dilemma_clearance_eligible[vehicle.vehicle_id] = True

    def _clearance_eligible_to_proceed(self, vehicle: Vehicle) -> bool:
        self._ensure_clearance_latch_size()
        return (
            vehicle.active
            and vehicle.vehicle_id < self._clearance_eligible.shape[0]
            and bool(self._clearance_eligible[vehicle.vehicle_id])
        )

    def _movement_has_green(self, vehicle: Vehicle) -> bool:
        return self._has_green(vehicle.approach, vehicle.route)

    def _movement_has_yellow(self, vehicle: Vehicle) -> bool:
        phase, _ = self._signal_phase()
        axis = "NS" if vehicle.approach in ("N", "S") else "EW"
        return phase == f"{axis}_YELLOW"

    def _has_green(self, approach: str, route: str = "straight") -> bool:
        phase, _ = self._signal_phase()
        axis = "NS" if approach in ("N", "S") else "EW"
        if self.episode_protected_left_signal and route == "left":
            return phase == f"{axis}_LEFT_GREEN"
        return phase == f"{axis}_GREEN"

    def _left_turn_conflict(self, vehicle: Vehicle) -> bool:
        if (
            self.episode_protected_left_signal
            or vehicle.route != "left"
            or not self._movement_has_green(vehicle)
        ):
            return False
        opposite = {"N": "S", "S": "N", "E": "W", "W": "E"}[
            vehicle.approach
        ]
        for other in self.vehicles:
            if (
                not other.active
                or other.approach != opposite
                or other.route != "straight"
            ):
                continue
            distance_to_stop = self._distance_to_stop_line(other)
            if (
                -2.0 * self.config.intersection_half_size
                <= distance_to_stop
                <= self.config.left_yield_distance
                and other.speed > 0.5
            ):
                return True
        return False

    def _is_rightmost_lane(self, vehicle: Vehicle) -> bool:
        return vehicle.lane == self.episode_lanes_per_approach - 1

    def _can_turn_right_on_red(self, vehicle: Vehicle) -> bool:
        if (
            not self.episode_allow_right_on_red
            or vehicle.route != "right"
            or not self._is_rightmost_lane(vehicle)
            or self._movement_has_green(vehicle)
        ):
            return False
        phase, _ = self._signal_phase()
        if self._is_all_red_phase(phase):
            return False
        axis = "NS" if vehicle.approach in ("N", "S") else "EW"
        return phase != f"{axis}_YELLOW"

    def _right_turn_conflict(self, vehicle: Vehicle) -> bool:
        if not self._can_turn_right_on_red(vehicle):
            return False
        vehicle_axis = "NS" if vehicle.approach in ("N", "S") else "EW"
        for other in self.vehicles:
            if not other.active or other.vehicle_id == vehicle.vehicle_id:
                continue
            other_axis = "NS" if other.approach in ("N", "S") else "EW"
            opposite = {"N": "S", "S": "N", "E": "W", "W": "E"}[
                vehicle.approach
            ]
            conflicts_by_direction = (
                other_axis != vehicle_axis
                or (other.approach == opposite and other.route == "left")
            )
            if not conflicts_by_direction:
                continue
            distance_to_stop = self._distance_to_stop_line(other)
            approaching_conflict = (
                self._movement_has_green(other)
                and -2.0 * self.config.intersection_half_size
                <= distance_to_stop
                <= self.config.right_yield_distance
                and other.speed > 0.5
            )
            inside_intersection = self._inside_intersection(other)
            if approaching_conflict or inside_intersection:
                return True
        return False

    def _movement_permitted(self, vehicle: Vehicle) -> bool:
        if self._clearance_eligible_to_proceed(vehicle):
            return True
        if self._movement_has_green(vehicle):
            return not self._left_turn_conflict(vehicle)
        return self._can_turn_right_on_red(vehicle) and not self._right_turn_conflict(
            vehicle
        )

    def _front_vehicle_metrics(self, vehicle: Vehicle) -> tuple[float, float, float]:
        gap = self.config.road_length * 2.0
        front_speed = vehicle.speed
        for other in self.vehicles:
            if (
                other.vehicle_id == vehicle.vehicle_id
                or not other.active
                or other.approach != vehicle.approach
                or other.lane != vehicle.lane
                or other.progress <= vehicle.progress
            ):
                continue
            candidate_gap = other.progress - vehicle.progress
            if candidate_gap < gap:
                gap = candidate_gap
                front_speed = other.speed
        relative_speed = max(0.0, vehicle.speed - front_speed)
        ttc = gap / max(relative_speed, 1e-3) if relative_speed > 0.05 else self.config.road_length * 2.0
        return float(gap), float(relative_speed), float(ttc)

    def _front_gap(self, vehicle: Vehicle) -> float:
        return self._front_vehicle_metrics(vehicle)[0]

    def _front_vehicle_gap_at(
        self,
        vehicle: Vehicle,
        progress: float,
        progress_lookup: np.ndarray | None = None,
    ) -> float:
        gap = self.config.road_length * 2.0
        for other in self.vehicles:
            if (
                other.vehicle_id == vehicle.vehicle_id
                or not other.active
                or other.approach != vehicle.approach
                or other.lane != vehicle.lane
            ):
                continue
            other_progress = float(
                progress_lookup[other.vehicle_id]
                if progress_lookup is not None and other.vehicle_id < len(progress_lookup)
                else other.progress
            )
            if other_progress <= progress:
                continue
            gap = min(gap, other_progress - progress)
        return float(gap)

    def _queue_position_index(self, vehicle: Vehicle) -> int:
        position = 1
        for other in self.vehicles:
            if (
                other.vehicle_id != vehicle.vehicle_id
                and other.active
                and other.approach == vehicle.approach
                and other.lane == vehicle.lane
                and other.progress > vehicle.progress
            ):
                position += 1
        return position

    def _closed_signal_stop_target_error(
        self,
        vehicle: Vehicle,
        progress: float | None = None,
        progress_lookup: np.ndarray | None = None,
    ) -> tuple[float | None, bool]:
        ego_progress = vehicle.progress if progress is None else float(progress)
        distance_to_stop = self._distance_to_stop_line(vehicle, ego_progress)
        if not (0.0 < distance_to_stop < self.config.queue_approach_distance):
            return None, False
        target_distance = 0.5 * (
            self.config.queue_stop_target_min + self.config.queue_stop_target_max
        )
        line_target_error = float(distance_to_stop - target_distance)
        front_gap = self._front_vehicle_gap_at(vehicle, ego_progress, progress_lookup)
        has_front_vehicle = front_gap < self.config.road_length
        if has_front_vehicle:
            target_gap = 0.5 * (
                self.config.queue_follower_gap_target_min
                + self.config.queue_follower_gap_target_max
            )
            follower_target_error = float(front_gap - target_gap)
            if follower_target_error < line_target_error:
                return follower_target_error, True
        return line_target_error, False

    def _closed_signal_stop_potential_reward(
        self,
        vehicle: Vehicle,
        previous_progress: np.ndarray,
    ) -> float:
        coefficient = max(0.0, float(self.config.closed_signal_stop_potential_coefficient))
        if coefficient <= 0.0:
            return 0.0
        if (
            self._movement_has_green(vehicle)
            or self._can_turn_right_on_red(vehicle)
        ):
            return 0.0
        distance_to_stop = self._distance_to_stop_line(vehicle)
        if not (0.0 < distance_to_stop < min(45.0, self.config.queue_approach_distance)):
            return 0.0
        before_error, _ = self._closed_signal_stop_target_error(
            vehicle,
            float(previous_progress[vehicle.vehicle_id]),
            previous_progress,
        )
        after_error, _ = self._closed_signal_stop_target_error(vehicle)
        if before_error is None or after_error is None:
            return 0.0
        phi_before = -abs(before_error)
        phi_after = -abs(after_error)
        gamma = max(0.0, min(1.0, float(self.config.closed_signal_stop_potential_gamma)))
        return float(coefficient * (gamma * phi_after - phi_before))

    def _collision_location_metrics(self, collision_flags: np.ndarray) -> dict[str, int]:
        metrics = {
            "collision_vehicles_before_stop_line": 0,
            "collision_vehicles_inside_intersection": 0,
            "collision_vehicles_after_stop_line": 0,
        }
        for vehicle in self.vehicles:
            if not collision_flags[vehicle.vehicle_id]:
                continue
            distance_to_stop = self._distance_to_stop_line(vehicle)
            if distance_to_stop > 0.0:
                metrics["collision_vehicles_before_stop_line"] += 1
            elif self._inside_intersection(vehicle):
                metrics["collision_vehicles_inside_intersection"] += 1
            else:
                metrics["collision_vehicles_after_stop_line"] += 1
        return metrics

    def _collision_phase_metrics(self) -> dict[str, float]:
        metrics = {
            "collision_pairs_with_clearance_eligible": 0.0,
            "inside_collision_pairs_with_clearance_eligible": 0.0,
            "inside_collision_pairs_without_clearance_eligible": 0.0,
            "inside_collision_pairs_within_1s_phase_change": 0.0,
            "inside_collision_pairs_within_2s_phase_change": 0.0,
            "inside_collision_pairs_within_3s_phase_change": 0.0,
        }
        by_id = {vehicle.vehicle_id: vehicle for vehicle in self.vehicles}
        for first_id, second_id in self._last_collision_pairs:
            first = by_id.get(first_id)
            second = by_id.get(second_id)
            if first is None or second is None:
                continue
            either_clearance = bool(
                self._clearance_eligible[first_id] or self._clearance_eligible[second_id]
            )
            inside = self._inside_intersection(first) or self._inside_intersection(second)
            if either_clearance:
                metrics["collision_pairs_with_clearance_eligible"] += 1.0
            if inside and either_clearance:
                metrics["inside_collision_pairs_with_clearance_eligible"] += 1.0
            elif inside:
                metrics["inside_collision_pairs_without_clearance_eligible"] += 1.0
            if inside and self._signal_phase_elapsed_seconds <= 1.0:
                metrics["inside_collision_pairs_within_1s_phase_change"] += 1.0
            if inside and self._signal_phase_elapsed_seconds <= 2.0:
                metrics["inside_collision_pairs_within_2s_phase_change"] += 1.0
            if inside and self._signal_phase_elapsed_seconds <= 3.0:
                metrics["inside_collision_pairs_within_3s_phase_change"] += 1.0
        return metrics

    def _queue_step_metrics(self, closed_signal_violations: np.ndarray) -> dict[str, float]:
        metrics = {
            "front_gap_violations": 0.0,
            "queue_stop_position_error_sum": 0.0,
            "queue_stop_position_samples": 0.0,
            "queue_stop_position_error_lead_sum": 0.0,
            "queue_stop_position_error_lead_samples": 0.0,
            "queue_stop_position_error_second_sum": 0.0,
            "queue_stop_position_error_second_samples": 0.0,
            "queue_stop_position_error_third_plus_sum": 0.0,
            "queue_stop_position_error_third_plus_samples": 0.0,
            "queue_follower_gap_error_sum": 0.0,
            "queue_follower_gap_samples": 0.0,
            "cars_stopped_too_far_from_stop_line": 0.0,
            "lead_green_start_delay_seconds": 0.0,
            "follower_green_start_delay_seconds": 0.0,
            "second_green_start_delay_seconds": 0.0,
            "third_plus_green_start_delay_seconds": 0.0,
            "queue_discharge_delay_seconds": 0.0,
            "lead_green_stuck_events": 0.0,
            "follower_green_stuck_events": 0.0,
            "second_green_stuck_events": 0.0,
            "third_plus_green_stuck_events": 0.0,
            "green_stopped_too_far_events": 0.0,
            "queue_red_crossings": float(closed_signal_violations.sum()),
        }
        for vehicle in self.vehicles:
            if not vehicle.active:
                continue
            distance_to_stop = self._distance_to_stop_line(vehicle)
            front_gap, _, _ = self._front_vehicle_metrics(vehicle)
            has_front_vehicle = front_gap < self.config.road_length
            queue_position = self._queue_position_index(vehicle)
            if has_front_vehicle and front_gap < self.config.minimum_front_gap:
                metrics["front_gap_violations"] += 1.0

            closed_queue_zone = (
                not self._movement_permitted(vehicle)
                and not self._can_turn_right_on_red(vehicle)
                and 0.0 < distance_to_stop < self.config.queue_approach_distance
            )
            if closed_queue_zone and queue_position <= 1:
                below = max(0.0, self.config.queue_stop_target_min - distance_to_stop)
                above = max(0.0, distance_to_stop - self.config.queue_stop_target_max)
                error = below + above
                metrics["queue_stop_position_error_sum"] += error
                metrics["queue_stop_position_samples"] += 1.0
                metrics["queue_stop_position_error_lead_sum"] += error
                metrics["queue_stop_position_error_lead_samples"] += 1.0
                if vehicle.speed < 0.4 and distance_to_stop > self.config.queue_stop_target_max + 2.0:
                    metrics["cars_stopped_too_far_from_stop_line"] += 1.0
            elif closed_queue_zone and has_front_vehicle:
                below = max(0.0, self.config.queue_follower_gap_target_min - front_gap)
                above = max(0.0, front_gap - self.config.queue_follower_gap_target_max)
                error = below + above
                metrics["queue_stop_position_error_sum"] += error
                metrics["queue_stop_position_samples"] += 1.0
                metrics["queue_follower_gap_error_sum"] += error
                metrics["queue_follower_gap_samples"] += 1.0
                if queue_position == 2:
                    metrics["queue_stop_position_error_second_sum"] += error
                    metrics["queue_stop_position_error_second_samples"] += 1.0
                else:
                    metrics["queue_stop_position_error_third_plus_sum"] += error
                    metrics["queue_stop_position_error_third_plus_samples"] += 1.0
                if vehicle.speed < 0.4 and front_gap > self.config.queue_follower_gap_target_max + 2.0:
                    metrics["cars_stopped_too_far_from_stop_line"] += 1.0

            green_approach_zone = self._movement_permitted(vehicle) and distance_to_stop > 0.0
            slow_on_green = vehicle.speed < self.config.legal_stall_speed_threshold
            if green_approach_zone and slow_on_green:
                if queue_position <= 1:
                    metrics["lead_green_start_delay_seconds"] += self.config.dt
                    metrics["lead_green_stuck_events"] += 1.0
                elif queue_position == 2:
                    metrics["follower_green_start_delay_seconds"] += self.config.dt
                    metrics["follower_green_stuck_events"] += 1.0
                    metrics["second_green_start_delay_seconds"] += self.config.dt
                    metrics["second_green_stuck_events"] += 1.0
                else:
                    metrics["follower_green_start_delay_seconds"] += self.config.dt
                    metrics["follower_green_stuck_events"] += 1.0
                    metrics["third_plus_green_start_delay_seconds"] += self.config.dt
                    metrics["third_plus_green_stuck_events"] += 1.0
                if distance_to_stop > self.config.queue_stop_target_max + 2.0:
                    metrics["green_stopped_too_far_events"] += 1.0
                metrics["queue_discharge_delay_seconds"] += self.config.dt
        return metrics

    def _stopping_distance(self, vehicle: Vehicle) -> float:
        return vehicle.speed**2 / (2.0 * max(self.config.comfortable_braking, 1e-3))

    def _inside_intersection(self, vehicle: Vehicle) -> bool:
        front_progress = self._front_progress(vehicle)
        rear_progress = self._rear_progress(vehicle)
        far_exit_progress = vehicle.stop_progress + 2.0 * self.config.intersection_half_size
        return front_progress >= vehicle.stop_progress and rear_progress <= far_exit_progress

    def _intersection_entry_risk(self, vehicle: Vehicle) -> bool:
        if not self.config.intersection_reservation_enabled:
            return False
        distance_to_stop = self._distance_to_stop_line(vehicle)
        if distance_to_stop <= 0.0:
            return False
        lookahead = max(
            self.config.intersection_reservation_distance,
            self._stopping_distance(vehicle) + 2.0,
        )
        if distance_to_stop > lookahead or not self._movement_permitted(vehicle):
            return False
        for other in self.vehicles:
            if other.vehicle_id == vehicle.vehicle_id or not other.active:
                continue
            if not self._has_conflicting_route(vehicle, other):
                continue
            if self._inside_intersection(other):
                return True
            other_distance_to_stop = self._distance_to_stop_line(other)
            if (
                0.0 < other_distance_to_stop <= self.config.intersection_reservation_distance
                and self._movement_permitted(other)
            ):
                other_has_priority = (
                    other_distance_to_stop < distance_to_stop - 1.0
                    or (
                        abs(other_distance_to_stop - distance_to_stop) <= 1.0
                        and other.vehicle_id < vehicle.vehicle_id
                    )
                )
                if other_has_priority:
                    return True
        return False

    def _proximity_risk(self, vehicle: Vehicle) -> bool:
        for other in self.vehicles:
            if other.vehicle_id == vehicle.vehicle_id or not other.active:
                continue
            if (
                self._rectangle_clearance(vehicle, other)
                < self.config.proximity_filter_clearance
            ):
                return True
        return False

    def _time_to_stop_line(self, vehicle: Vehicle) -> float:
        distance = self._distance_to_stop_line(vehicle)
        if distance <= 0.0:
            return 0.0
        return distance / max(vehicle.speed, 0.1)

    def _has_conflicting_route(self, first: Vehicle, second: Vehicle) -> bool:
        if first.approach == second.approach and first.lane == second.lane:
            return True
        first_key = self._route_conflict_key(first)
        second_key = self._route_conflict_key(second)
        key = (first_key, second_key) if first_key <= second_key else (second_key, first_key)
        cached = self._route_conflict_cache.get(key)
        if cached is not None:
            return cached
        conflict = self._route_footprints_conflict(first, second)
        self._route_conflict_cache[key] = conflict
        return conflict

    def _route_conflict_key(self, vehicle: Vehicle) -> tuple[object, ...]:
        return (
            vehicle.approach,
            vehicle.lane,
            vehicle.route,
            vehicle.destination_lane,
            self.episode_lanes_per_approach,
            round(vehicle.stop_progress, 3),
            round(vehicle.path.length, 3),
        )

    def _route_footprints_conflict(self, first: Vehicle, second: Vehicle) -> bool:
        clear_distance = 2.0 * self.config.intersection_half_size + 18.0
        first_start = max(0.0, first.stop_progress - self._half_vehicle_length())
        second_start = max(0.0, second.stop_progress - self._half_vehicle_length())
        first_end = min(first.path.length, first.stop_progress + clear_distance)
        second_end = min(second.path.length, second.stop_progress + clear_distance)
        first_samples = np.linspace(first_start, first_end, 9)
        second_samples = np.linspace(second_start, second_end, 9)
        conflict_clearance = self.config.proximity_clearance + 0.25
        for first_progress in first_samples:
            first_corners = self._vehicle_corners_at(first, float(first_progress), lateral_offset=0.0)
            for second_progress in second_samples:
                second_corners = self._vehicle_corners_at(second, float(second_progress), lateral_offset=0.0)
                if self._polygon_clearance(first_corners, second_corners) < conflict_clearance:
                    return True
        return False

    def _predictive_state_key(self) -> tuple[tuple[int, bool, float, float, float], ...]:
        return tuple(
            (
                vehicle.vehicle_id,
                vehicle.active,
                round(vehicle.progress, 3),
                round(vehicle.speed, 3),
                round(vehicle.lateral_offset, 3),
            )
            for vehicle in self.vehicles
        )

    def _predictive_features(self) -> np.ndarray:
        key = self._predictive_state_key()
        if self._predictive_cache_key == key and self._predictive_cache is not None:
            return self._predictive_cache

        horizon = self.config.prediction_horizon_seconds
        step = self.config.prediction_step_seconds
        times = np.arange(step, horizon + 1e-6, step)
        features = np.zeros((self.config.max_cars, 10), dtype=np.float32)
        features[:, 2] = 1.0
        features[:, 3] = 1.0
        features[:, 4] = 1.0
        features[:, 7] = 1.0
        active = [vehicle for vehicle in self.vehicles if vehicle.active]
        time_to_stop = {
            vehicle.vehicle_id: min(self._time_to_stop_line(vehicle), horizon)
            for vehicle in active
        }
        future_corners: dict[tuple[int, float], np.ndarray] = {}
        future_centers: dict[tuple[int, float], np.ndarray] = {}
        for vehicle in active:
            lateral_limit = max(self._max_lateral_offset(), 1e-3)
            lateral_ratio = abs(vehicle.lateral_offset) / lateral_limit
            center_steer = np.clip(-vehicle.lateral_offset / lateral_limit, -1.0, 1.0)
            features[vehicle.vehicle_id, 2] = 1.0
            features[vehicle.vehicle_id, 3] = time_to_stop[vehicle.vehicle_id] / max(horizon, 1e-3)
            features[vehicle.vehicle_id, 4] = 1.0
            features[vehicle.vehicle_id, 7] = 1.0
            features[vehicle.vehicle_id, 8] = np.clip(lateral_ratio, 0.0, 1.0)
            features[vehicle.vehicle_id, 9] = float(center_steer)
            for time in times:
                progress = min(vehicle.path.length + self._half_vehicle_length(), vehicle.progress + vehicle.speed * time)
                time_key = float(time)
                center, heading = vehicle.path.sample(progress)
                normal = np.array([-np.sin(heading), np.cos(heading)])
                center = center + normal * vehicle.lateral_offset
                future_centers[(vehicle.vehicle_id, time_key)] = center
                future_corners[(vehicle.vehicle_id, time_key)] = self._vehicle_corners_at(vehicle, progress)

        intersection_window = 2.0 * self.config.intersection_half_size + self.config.vehicle_length
        arrival_window = horizon + self.config.prediction_step_seconds
        far_center_threshold = (
            2.0 * self.config.vehicle_length
            + self.config.vehicle_width
            + self.config.proximity_clearance
            + 2.0
        )
        for first_index, first in enumerate(active):
            first_time = time_to_stop[first.vehicle_id]
            for second in active[first_index + 1 :]:
                if not self._has_conflicting_route(first, second):
                    continue
                second_time = time_to_stop[second.vehicle_id]
                first_occupied = self._inside_intersection(first)
                second_occupied = self._inside_intersection(second)
                first_distance = self._distance_to_stop_line(first)
                second_distance = self._distance_to_stop_line(second)
                if second_occupied:
                    features[first.vehicle_id, 5] = 1.0
                    features[first.vehicle_id, 4] = 0.0
                if first_occupied:
                    features[second.vehicle_id, 5] = 1.0
                    features[second.vehicle_id, 4] = 0.0
                if (
                    0.0 < second_distance <= self.config.conflict_lookahead_distance
                    and self._movement_permitted(second)
                ):
                    features[first.vehicle_id, 6] = 1.0
                if (
                    0.0 < first_distance <= self.config.conflict_lookahead_distance
                    and self._movement_permitted(first)
                ):
                    features[second.vehicle_id, 6] = 1.0

                second_priority = (
                    second_occupied
                    or second_time < first_time - 0.25
                    or (abs(second_time - first_time) <= 0.25 and second.vehicle_id < first.vehicle_id)
                )
                first_priority = (
                    first_occupied
                    or first_time < second_time - 0.25
                    or (abs(second_time - first_time) <= 0.25 and first.vehicle_id < second.vehicle_id)
                )
                if second_priority:
                    features[first.vehicle_id, 4] = 0.0
                if first_priority:
                    features[second.vehicle_id, 4] = 0.0

                same_lane = (
                    first.approach == second.approach
                    and first.lane == second.lane
                )
                first_near_conflict = -intersection_window <= first_distance <= self.config.conflict_lookahead_distance
                second_near_conflict = -intersection_window <= second_distance <= self.config.conflict_lookahead_distance
                exact_geometry_needed = (
                    not same_lane
                    and (first_near_conflict or second_near_conflict)
                    and abs(first_time - second_time) <= arrival_window
                )
                if not exact_geometry_needed:
                    continue

                for time in times:
                    time_key = float(time)
                    first_center = future_centers[(first.vehicle_id, time_key)]
                    second_center = future_centers[(second.vehicle_id, time_key)]
                    if np.linalg.norm(first_center - second_center) > far_center_threshold:
                        continue
                    first_corners = future_corners[(first.vehicle_id, time_key)]
                    second_corners = future_corners[(second.vehicle_id, time_key)]
                    clearance = self._polygon_clearance(first_corners, second_corners)
                    clearance_norm = np.clip(clearance / self.config.road_length, 0.0, 1.0)
                    features[first.vehicle_id, 7] = min(features[first.vehicle_id, 7], clearance_norm)
                    features[second.vehicle_id, 7] = min(features[second.vehicle_id, 7], clearance_norm)
                    if clearance < self.config.proximity_clearance:
                        for ego, other_time in ((first, second_time), (second, first_time)):
                            vehicle_id = ego.vehicle_id
                            features[vehicle_id, 1] = 1.0
                            features[vehicle_id, 2] = min(features[vehicle_id, 2], float(time) / max(horizon, 1e-3))
                            features[vehicle_id, 3] = min(features[vehicle_id, 3], other_time / max(horizon, 1e-3))
                    if self._polygons_overlap(first_corners, second_corners):
                        for ego, other_time in ((first, second_time), (second, first_time)):
                            vehicle_id = ego.vehicle_id
                            features[vehicle_id, 0] = 1.0
                            features[vehicle_id, 1] = 1.0
                            features[vehicle_id, 2] = min(features[vehicle_id, 2], float(time) / max(horizon, 1e-3))
                            features[vehicle_id, 3] = min(features[vehicle_id, 3], other_time / max(horizon, 1e-3))
                        break

        self._predictive_cache_key = key
        self._predictive_cache = np.clip(features, -1.0, 1.0)
        return self._predictive_cache

    def _predictive_conflict_metrics(self, vehicle: Vehicle) -> tuple[float, ...]:
        return tuple(float(value) for value in self._predictive_features()[vehicle.vehicle_id])

    def _safety_risk(self, vehicle: Vehicle) -> tuple[bool, bool]:
        distance_to_stop = self._distance_to_stop_line(vehicle)
        stopping_distance = self._stopping_distance(vehicle)
        movement_permitted = self._movement_permitted(vehicle)
        closed_signal_risk = (
            not movement_permitted
            and 0.0 < distance_to_stop < max(10.0, stopping_distance + 4.0)
        )
        front_gap, _, front_ttc = self._front_vehicle_metrics(vehicle)
        front_risk = (
            front_gap < self.config.minimum_front_gap
            or front_ttc < self.config.ttc_warning_seconds
        )
        conflict_risk = self._left_turn_conflict(vehicle) or self._right_turn_conflict(vehicle)
        reservation_risk = self._intersection_entry_risk(vehicle)
        return (
            closed_signal_risk
            or front_risk
            or conflict_risk
            or reservation_risk,
            front_risk,
        )

    def _filter_acceleration(
        self,
        vehicle: Vehicle,
        acceleration: float,
        acceleration_command: float,
    ) -> tuple[float, bool, bool]:
        unsafe, front_risk = self._safety_risk(vehicle)
        unsafe_request = unsafe and acceleration_command > 0.05
        if not self.episode_safety_filter_enabled or not unsafe:
            return acceleration, False, unsafe_request
        if vehicle.speed < 0.2:
            held_acceleration = min(acceleration, 0.0)
            return held_acceleration, acceleration > 0.0, unsafe_request
        forced_brake = -self.config.comfortable_braking
        if front_risk:
            forced_brake = -self.config.comfortable_braking
        if acceleration <= forced_brake + 1e-6:
            return acceleration, False, unsafe_request
        return min(acceleration, forced_brake), True, unsafe_request

    @staticmethod
    def _safety_score(
        completed_delta: int,
        failed_delta: int,
        collisions: int,
        proximity: int,
        proximity_events: int,
        red_violations: int,
        left_yield: int,
        right_yield: int,
        right_lane: int,
        lane_drift: int,
        safety_overrides: int,
        progress_delta: float,
    ) -> float:
        return float(
            140.0 * completed_delta
            + 1.5 * progress_delta
            - 80.0 * failed_delta
            - 160.0 * collisions
            - 8.0 * proximity
            - 4.0 * proximity_events
            - 90.0 * red_violations
            - 60.0 * (left_yield + right_yield)
            - 50.0 * right_lane
            - 0.35 * lane_drift
            - 2.0 * safety_overrides
        )

    def _nearest_vehicle(self, vehicle: Vehicle) -> float:
        position, _ = vehicle.pose()
        distance = self.config.road_length * 2.0
        for other in self.vehicles:
            if other.vehicle_id == vehicle.vehicle_id or not other.active:
                continue
            other_position, _ = other.pose()
            distance = min(distance, float(np.linalg.norm(position - other_position)))
        return distance

    def _get_observation(self) -> np.ndarray:
        observation = np.zeros(
            (self.config.max_cars, self.OBSERVATION_SIZE), dtype=np.float32
        )
        phase, phase_progress = self._signal_phase()
        for vehicle in self.vehicles:
            if not vehicle.active:
                continue
            position, heading = vehicle.pose()
            distance_to_stop = self._distance_to_stop_line(vehicle)
            route_one_hot = [float(vehicle.route == route) for route in ROUTES]
            axis_green = float(self._movement_has_green(vehicle))
            axis_yellow = float(
                phase
                == f"{'NS' if vehicle.approach in ('N', 'S') else 'EW'}_YELLOW"
            )
            front_gap, front_relative_speed, front_ttc = self._front_vehicle_metrics(vehicle)
            predictive_values = self._predictive_features()[vehicle.vehicle_id]
            values = [
                vehicle.speed / self.config.max_speed,
                vehicle.acceleration / self.config.comfortable_braking,
                np.clip(
                    distance_to_stop / self.config.road_length,
                    -1.0,
                    1.0,
                ),
                axis_green,
                axis_yellow,
                1.0 - axis_green - axis_yellow,
                np.clip(
                    front_gap / self.config.road_length, 0.0, 1.0
                ),
                np.clip(
                    self._nearest_vehicle(vehicle) / self.config.road_length,
                    0.0,
                    1.0,
                ),
                vehicle.progress / vehicle.path.length,
                vehicle.lane / max(1, self.episode_lanes_per_approach - 1),
                *route_one_hot,
                np.sin(heading),
                np.cos(heading),
                phase_progress,
                vehicle.destination_lane
                / max(1, self.episode_lanes_per_approach - 1),
                np.clip(
                    vehicle.lateral_offset / self.config.lane_width, -1.0, 1.0
                ),
                float(self._left_turn_conflict(vehicle)),
                float(self._can_turn_right_on_red(vehicle)),
                float(self._right_turn_conflict(vehicle)),
                float(self._is_rightmost_lane(vehicle)),
                np.clip(
                    front_relative_speed / self.config.max_speed,
                    0.0,
                    1.0,
                ),
                np.clip(
                    front_ttc / 10.0,
                    0.0,
                    1.0,
                ),
                np.clip(
                    self._stopping_distance(vehicle)
                    / max(abs(distance_to_stop), 1.0),
                    0.0,
                    1.0,
                ),
                float(self._movement_permitted(vehicle)),
                *predictive_values[:8],
            ]
            observation[vehicle.vehicle_id] = np.asarray(values, dtype=np.float32)
        return np.clip(observation, -1.0, 1.0)

    def _get_info(self, rewards: np.ndarray) -> dict[str, Any]:
        active_mask = np.zeros(self.config.max_cars, dtype=np.float32)
        legal_stall_seconds = np.zeros(self.config.max_cars, dtype=np.float32)
        blocked_stall_seconds = np.zeros(self.config.max_cars, dtype=np.float32)
        for vehicle in self.vehicles:
            active_mask[vehicle.vehicle_id] = float(vehicle.active)
            legal_stall_seconds[vehicle.vehicle_id] = float(vehicle.legal_stall_seconds)
            blocked_stall_seconds[vehicle.vehicle_id] = float(vehicle.blocked_stall_seconds)
        active_legal_stalls = legal_stall_seconds[active_mask.astype(bool)]
        intent_labels = self._intent_labels()
        return {
            "active_mask": active_mask,
            "legal_stall_seconds": legal_stall_seconds,
            "blocked_stall_seconds": blocked_stall_seconds,
            "intent_labels": intent_labels,
            "component_route_labels": self._component_route_labels(intent_labels),
            "legal_stall_vehicles": int(
                (active_legal_stalls >= self.config.legal_stall_grace_seconds).sum()
            ),
            "max_legal_stall_seconds": float(
                active_legal_stalls.max() if active_legal_stalls.size else 0.0
            ),
            "mean_active_reward": float(
                rewards[active_mask.astype(bool)].mean()
                if active_mask.any()
                else 0.0
            ),
            "completed_vehicles": self.completed_vehicles,
            "completed_clean": self.completed_vehicles,
            "failed_vehicles": self.failed_vehicles,
            "cumulative_safety_overrides": self.safety_overrides,
            "signal_phase": self._signal_phase()[0],
            "elapsed_seconds": self.elapsed_seconds,
            "episode_lanes_per_approach": self.episode_lanes_per_approach,
            "episode_protected_left_signal": self.episode_protected_left_signal,
            "episode_allow_right_on_red": self.episode_allow_right_on_red,
            "episode_safety_filter_enabled": self.episode_safety_filter_enabled,
        }

    def _ensure_intent_latch_size(self) -> None:
        if self._intent_stop_latched.shape[0] == self.config.max_cars:
            return
        previous = self._intent_stop_latched
        previous_creep = self._intent_creep_latched
        self._intent_stop_latched = np.zeros(self.config.max_cars, dtype=bool)
        self._intent_creep_latched = np.zeros(
            self.config.max_cars, dtype=bool
        )
        count = min(previous.shape[0], self._intent_stop_latched.shape[0])
        self._intent_stop_latched[:count] = previous[:count]
        self._intent_creep_latched[:count] = previous_creep[:count]

    def _closed_signal_brake_label_state(self, vehicle: Vehicle) -> tuple[bool, bool]:
        target_error, _ = self._closed_signal_stop_target_error(vehicle)
        if target_error is None:
            return False, False
        tolerance = max(0.0, float(self.config.intent_stop_label_target_tolerance))
        speed = max(0.0, float(vehicle.speed))
        near_target = abs(target_error) <= tolerance
        stopped_near_target = speed < 0.5 and near_target
        if stopped_near_target:
            return True, True

        available_distance = max(0.0, float(target_error))
        decel_distance = max(available_distance, 0.25)
        safety = max(1.0, float(self.config.intent_stop_label_brake_safety_factor))
        required_decel = safety * speed * speed / (2.0 * decel_distance)
        threshold = (
            max(0.0, float(self.config.intent_stop_label_decel_ratio))
            * max(float(self.config.comfortable_braking), 1e-3)
        )
        activation_distance = max(0.0, float(self.config.intent_stop_label_activation_distance))
        should_brake = target_error <= activation_distance or required_decel >= threshold
        return bool(should_brake), False

    def _closed_signal_reapproach_label(self, vehicle: Vehicle) -> bool:
        if not self.config.intent_creep_reapproach_enabled:
            return False
        target_error, _ = self._closed_signal_stop_target_error(vehicle)
        if target_error is None:
            return False
        return bool(
            target_error > self.config.intent_creep_reapproach_min_target_error
            and vehicle.speed <= self.config.intent_creep_reapproach_max_speed
        )

    def _creep_requires_emergency_brake(self, vehicle: Vehicle) -> bool:
        target_error, _ = self._closed_signal_stop_target_error(vehicle)
        if target_error is None or target_error <= 0.0:
            return True
        speed = max(0.0, float(vehicle.speed))
        physical_decel = speed * speed / (2.0 * max(float(target_error), 0.25))
        return bool(physical_decel >= max(float(self.config.comfortable_braking), 1e-3))

    def _intent_labels(self) -> np.ndarray:
        self._ensure_intent_latch_size()
        labels = np.full(self.config.max_cars, self.INTENT_IGNORE, dtype=np.int64)
        for vehicle in self.vehicles:
            if not vehicle.active:
                if vehicle.vehicle_id < self._intent_stop_latched.shape[0]:
                    self._intent_stop_latched[vehicle.vehicle_id] = False
                    self._intent_creep_latched[vehicle.vehicle_id] = False
                continue
            distance_to_stop = self._distance_to_stop_line(vehicle)
            front_gap, _, front_ttc = self._front_vehicle_metrics(vehicle)
            front_risk = (
                front_gap < self.config.minimum_front_gap
                or front_ttc < self.config.ttc_warning_seconds
            )
            conflict_risk = (
                self._left_turn_conflict(vehicle)
                or self._right_turn_conflict(vehicle)
                or self._intersection_entry_risk(vehicle)
            )
            movement_permitted = self._movement_permitted(vehicle)
            right_on_red = self._can_turn_right_on_red(vehicle)
            closed_before_stop = (
                not movement_permitted
                and not right_on_red
                and distance_to_stop > 0.0
            )
            if not closed_before_stop:
                self._intent_stop_latched[vehicle.vehicle_id] = False
                self._intent_creep_latched[vehicle.vehicle_id] = False

            if self._movement_has_yellow(vehicle) and distance_to_stop <= 0.0:
                labels[vehicle.vehicle_id] = self.INTENT_GO
            elif closed_before_stop:
                should_brake, stopped_near_target = self._closed_signal_brake_label_state(vehicle)
                reapproach = self._closed_signal_reapproach_label(vehicle)
                creep_latched = bool(
                    self._intent_creep_latched[vehicle.vehicle_id]
                )
                latched = (
                    bool(self.config.intent_stop_label_latch_enabled)
                    and bool(self._intent_stop_latched[vehicle.vehicle_id])
                )
                if stopped_near_target:
                    self._intent_creep_latched[vehicle.vehicle_id] = False
                    self._intent_stop_latched[vehicle.vehicle_id] = bool(
                        self.config.intent_stop_label_latch_enabled
                    )
                    labels[vehicle.vehicle_id] = self.INTENT_HOLD
                elif creep_latched and self._creep_requires_emergency_brake(vehicle):
                    self._intent_creep_latched[vehicle.vehicle_id] = False
                    self._intent_stop_latched[vehicle.vehicle_id] = True
                    labels[vehicle.vehicle_id] = self.INTENT_STOP
                elif creep_latched or reapproach:
                    self._intent_creep_latched[vehicle.vehicle_id] = True
                    self._intent_stop_latched[vehicle.vehicle_id] = True
                    labels[vehicle.vehicle_id] = self.INTENT_STOP
                elif latched or should_brake:
                    if self.config.intent_stop_label_latch_enabled:
                        self._intent_stop_latched[vehicle.vehicle_id] = True
                    labels[vehicle.vehicle_id] = self.INTENT_STOP
                elif front_risk or conflict_risk:
                    labels[vehicle.vehicle_id] = self.INTENT_YIELD
                else:
                    labels[vehicle.vehicle_id] = self.INTENT_IGNORE
            elif front_risk or conflict_risk:
                labels[vehicle.vehicle_id] = self.INTENT_YIELD
            elif movement_permitted or right_on_red:
                labels[vehicle.vehicle_id] = self.INTENT_GO
            else:
                labels[vehicle.vehicle_id] = self.INTENT_HOLD
        return labels

    def _component_route_labels(self, intent_labels: np.ndarray) -> np.ndarray:
        routes = np.full(self.config.max_cars, -1, dtype=np.int64)
        for vehicle in self.vehicles:
            if not vehicle.active:
                continue
            vehicle_id = vehicle.vehicle_id
            label = int(intent_labels[vehicle_id])
            if label in (self.INTENT_STOP, self.INTENT_HOLD):
                routes[vehicle_id] = 0
            elif label == self.INTENT_GO:
                routes[vehicle_id] = 2

            if not self.config.intent_creep_reapproach_enabled:
                continue
            distance = self._distance_to_stop_line(vehicle)
            target_error, _ = self._closed_signal_stop_target_error(vehicle)
            closed_before_stop = (
                not self._movement_permitted(vehicle)
                and not self._can_turn_right_on_red(vehicle)
                and distance > 0.0
            )
            outside_hold_window = (
                target_error is not None
                and target_error > self.config.intent_stop_label_target_tolerance
            )
            observable_creep_state = (
                closed_before_stop
                and outside_hold_window
                and vehicle.speed <= self.config.intent_creep_route_max_speed
            )
            if observable_creep_state:
                routes[vehicle_id] = 1
        return routes

    def render(self) -> np.ndarray | None:
        if self._renderer is None:
            from intersection_rl.rendering import IntersectionRenderer

            self._renderer = IntersectionRenderer(self.config, self.render_mode)
        return self._renderer.render(self)

    def close(self) -> None:
        if self._renderer is not None:
            self._renderer.close()
            self._renderer = None

