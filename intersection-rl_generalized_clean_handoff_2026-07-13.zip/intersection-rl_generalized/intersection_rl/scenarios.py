from __future__ import annotations

from dataclasses import dataclass

from intersection_rl.config import EnvConfig
from intersection_rl.multitask import MultiTaskIntersectionEnv, ScenarioTask


@dataclass(frozen=True, slots=True)
class DemoScenario:
    name: str
    lanes: int
    cars: int
    seed: int


DEMO_SCENARIOS = {
    "demo_redgreen_2l": DemoScenario("demo_redgreen_2l", 2, 16, 730),
    "demo_redgreen_3l": DemoScenario("demo_redgreen_3l", 3, 24, 730),
    "demo_redgreen_4l": DemoScenario("demo_redgreen_4l", 4, 32, 730),
}


def policy_env_config(
    *,
    max_cars: int,
    lanes: int,
    seed: int,
    episode_seconds: float,
    all_red_seconds: float,
) -> EnvConfig:
    return EnvConfig(
        max_cars=max_cars,
        min_cars=1,
        lanes_per_approach=lanes,
        episode_seconds=episode_seconds,
        signal_all_red_seconds=max(0.0, float(all_red_seconds)),
        protected_left_signal=True,
        allow_right_on_red=False,
        right_turns_enabled=False,
        strict_lane_mapping=True,
        safety_filter_enabled=False,
        intersection_reservation_enabled=False,
        curriculum_enabled=False,
        curriculum_progression_enabled=False,
        randomize_initial_signal_phase=True,
        initial_lateral_noise=0.0,
        seed=seed,
    )


def redgreen_task(
    *,
    name: str,
    lanes: int,
    cars: int,
    episode_seconds: float,
    dense: bool,
) -> ScenarioTask:
    if dense:
        lead_min, lead_max = 0.2, 1.0
        speed_min, speed_max = 0.0, 1.0
    else:
        lead_min, lead_max = 10.0, 32.0
        speed_min, speed_max = 0.0, 2.0
    return ScenarioTask(
        name=name,
        min_lanes=lanes,
        max_lanes=lanes,
        min_cars=cars,
        max_cars=cars,
        min_episode_seconds=episode_seconds,
        max_episode_seconds=episode_seconds,
        signal_mode="redgreen",
        lead_gap_min=lead_min,
        lead_gap_max=lead_max,
        queue_gap_min=7.0,
        queue_gap_max=7.5,
        closed_spawn_speed_min=speed_min,
        closed_spawn_speed_max=speed_max,
        spawn_signal_filter="all",
        randomize_longitudinal_positions=True,
        initial_green_only=True,
    )


def build_demo_redgreen_env(
    scenario: DemoScenario,
    *,
    max_cars: int,
    episode_seconds: float = 60.0,
    all_red_seconds: float = 3.5,
    render_mode: str | None = None,
) -> MultiTaskIntersectionEnv:
    config = policy_env_config(
        max_cars=max_cars,
        lanes=scenario.lanes,
        seed=scenario.seed,
        episode_seconds=episode_seconds,
        all_red_seconds=all_red_seconds,
    )
    config.spawn_random_lead_gap_min = 10.0
    config.spawn_random_lead_gap_max = 32.0
    config.spawn_random_queue_gap_min = 7.5
    config.spawn_random_queue_gap_max = 12.0
    config.spawn_random_closed_speed_min = 0.5
    config.spawn_random_closed_speed_max = 2.5
    config.spawn_random_green_speed_min = 2.0
    config.spawn_random_green_speed_max = 5.0
    config.spawn_speed_safety_factor = 1.35
    config.intent_creep_reapproach_enabled = True
    task = redgreen_task(
        name=scenario.name,
        lanes=scenario.lanes,
        cars=scenario.cars,
        episode_seconds=episode_seconds,
        dense=False,
    )
    return MultiTaskIntersectionEnv(config, tasks=(task,), render_mode=render_mode)
