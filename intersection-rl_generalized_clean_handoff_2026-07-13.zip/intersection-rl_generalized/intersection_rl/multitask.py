from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from intersection_rl.config import EnvConfig
from intersection_rl.env import IntersectionEnv


@dataclass(frozen=True, slots=True)
class ScenarioTask:
    name: str
    min_lanes: int
    max_lanes: int
    min_cars: int
    max_cars: int
    min_episode_seconds: float
    max_episode_seconds: float
    weight: float = 1.0
    signal_mode: str = "random"
    lead_gap_min: float = 16.0
    lead_gap_max: float = 16.0
    queue_gap_min: float = 11.5
    queue_gap_max: float = 11.5
    closed_spawn_speed_min: float = 0.0
    closed_spawn_speed_max: float = 0.0
    spawn_permitted_movements_only: bool = False
    spawn_signal_filter: str = "all"
    spawn_progress_offset_min: float | None = None
    spawn_progress_offset_max: float | None = None
    allow_right_on_red: bool = False
    right_turns_enabled: bool = False
    randomize_longitudinal_positions: bool = False
    initial_green_only: bool = False


DEFAULT_TASKS = (
    ScenarioTask('green_basic', 2, 4, 4, 4, 60.0, 90.0, 3.2, 'green', 24.0, 44.0, 12.0, 14.0, 0.0, 0.0, True, 'green'),
    ScenarioTask('green_queue_basic', 2, 4, 4, 4, 60.0, 90.0, 2.6, 'green', 10.0, 22.0, 11.5, 13.5, 0.0, 0.0, True, 'green'),
    ScenarioTask('left_green_basic', 2, 4, 2, 4, 60.0, 90.0, 3.2, 'left_green', 10.0, 28.0, 12.0, 14.0, 0.0, 0.0, True, 'green'),
    ScenarioTask('left_green_queue_basic', 2, 4, 2, 4, 75.0, 120.0, 2.4, 'left_green', 4.5, 14.0, 10.5, 12.5, 0.0, 0.0, True, 'green'),
    ScenarioTask('left_redgreen_release', 2, 4, 2, 4, 60.0, 75.0, 4.0, 'left_release', 10.0, 22.0, 7.0, 7.5, 2.0, 5.0, False, 'next_left_release'),
    ScenarioTask('left_redgreen_release_balanced', 2, 4, 2, 4, 60.0, 75.0, 0.55, 'left_release', 10.0, 22.0, 7.0, 7.5, 2.0, 5.0, False, 'next_left_release'),
    ScenarioTask('redgreen_next_release', 2, 4, 2, 6, 60.0, 75.0, 1.2, 'release', 8.0, 22.0, 7.0, 7.5, 2.0, 5.0, False, 'next_release'),
    ScenarioTask('right_on_red_basic', 2, 4, 2, 4, 25.0, 35.0, 2.4, 'right_on_red', 8.0, 22.0, 11.0, 13.0, 0.0, 2.0, False, 'right_red', None, None, True, True),
    ScenarioTask('right_on_red_conflict', 2, 4, 4, 8, 30.0, 40.0, 2.0, 'right_on_red', 8.0, 24.0, 11.0, 13.0, 0.0, 2.5, False, 'right_red_conflict', None, None, True, True),
    ScenarioTask('right_on_red_queue', 2, 4, 8, 8, 30.0, 45.0, 1.6, 'right_on_red', 6.0, 18.0, 10.5, 12.0, 0.0, 1.5, False, 'right_red', None, None, True, True),
    ScenarioTask('right_on_red_mixed', 2, 4, 8, 20, 75.0, 100.0, 0.8, 'redgreen', 8.0, 26.0, 10.5, 12.5, 0.0, 2.0, False, 'all', None, None, True, True),
    ScenarioTask('green_1to2_per_lane_2l', 2, 2, 4, 8, 60.0, 90.0, 2.4, 'green', 6.0, 24.0, 10.5, 12.5, 0.0, 0.0, True, 'green'),
    ScenarioTask('green_1to2_per_lane_3l', 3, 3, 6, 12, 60.0, 90.0, 2.2, 'green', 6.0, 24.0, 10.5, 12.5, 0.0, 0.0, True, 'green'),
    ScenarioTask('green_1to2_per_lane_4l', 4, 4, 8, 16, 60.0, 90.0, 2.0, 'green', 6.0, 24.0, 10.5, 12.5, 0.0, 0.0, True, 'green'),
    ScenarioTask('red_stop_basic', 2, 4, 4, 4, 60.0, 90.0, 1.4, 'green', 24.0, 44.0, 12.0, 14.0, 0.0, 0.2, False, 'closed'),
    ScenarioTask('lead_red_stop_precision_2l', 2, 2, 4, 4, 45.0, 60.0, 3.0, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 0.0, False, 'closed'),
    ScenarioTask('lead_red_stop_precision_3l', 3, 3, 6, 6, 45.0, 60.0, 2.8, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 0.0, False, 'closed'),
    ScenarioTask('lead_red_stop_precision_4l', 4, 4, 8, 8, 45.0, 60.0, 2.6, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 0.0, False, 'closed'),
    ScenarioTask('lead_red_approach_2l', 2, 2, 4, 4, 45.0, 60.0, 3.0, 'green', 2.0, 8.0, 7.0, 7.5, 0.2, 1.5, False, 'closed'),
    ScenarioTask('lead_red_approach_3l', 3, 3, 6, 6, 45.0, 60.0, 2.8, 'green', 2.0, 8.0, 7.0, 7.5, 0.2, 1.5, False, 'closed'),
    ScenarioTask('lead_red_approach_4l', 4, 4, 8, 8, 45.0, 60.0, 2.6, 'green', 2.0, 8.0, 7.0, 7.5, 0.2, 1.5, False, 'closed'),
    ScenarioTask('red_queue_1_per_lane_2l', 2, 2, 8, 8, 45.0, 60.0, 2.4, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 2.5, False, 'closed'),
    ScenarioTask('red_queue_1_per_lane_3l', 3, 3, 12, 12, 45.0, 60.0, 2.2, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 2.5, False, 'closed'),
    ScenarioTask('red_queue_1_per_lane_4l', 4, 4, 16, 16, 45.0, 60.0, 2.0, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 2.5, False, 'closed'),
    ScenarioTask('red_queue_2_per_lane_2l', 2, 2, 16, 16, 60.0, 80.0, 1.2, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 2.0, False, 'closed'),
    ScenarioTask('red_queue_2_per_lane_3l', 3, 3, 24, 24, 60.0, 80.0, 1.0, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 2.0, False, 'closed'),
    ScenarioTask('red_queue_2_per_lane_4l', 4, 4, 32, 32, 60.0, 80.0, 0.8, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 2.0, False, 'closed'),
    ScenarioTask('red_brake_basic', 2, 4, 4, 4, 60.0, 90.0, 2.8, 'green', 10.0, 30.0, 12.0, 14.0, 2.0, 6.0, False, 'closed'),
    ScenarioTask('red_creep_release_basic', 2, 4, 4, 4, 60.0, 90.0, 1.8, 'green', 6.0, 18.0, 12.0, 14.0, 0.0, 1.5, False, 'closed'),
    ScenarioTask('red_creep_far_stationary_2l', 2, 2, 4, 4, 60.0, 60.0, 1.0, 'redgreen', 10.0, 32.0, 7.5, 12.0, 0.0, 0.0, False, 'closed', None, None, False, False, True, True),
    ScenarioTask('red_creep_far_stationary_3l', 3, 3, 6, 6, 60.0, 60.0, 1.0, 'redgreen', 10.0, 32.0, 7.5, 12.0, 0.0, 0.0, False, 'closed', None, None, False, False, True, True),
    ScenarioTask('red_creep_far_stationary_4l', 4, 4, 8, 8, 60.0, 60.0, 1.0, 'redgreen', 10.0, 32.0, 7.5, 12.0, 0.0, 0.0, False, 'closed', None, None, False, False, True, True),
    ScenarioTask('redgreen_mixed_basic', 2, 4, 4, 4, 60.0, 90.0, 0.25, 'redgreen', 10.0, 32.0, 12.0, 14.0, 1.0, 4.0, False, 'all'),
    ScenarioTask('redgreen_1_per_lane_2l', 2, 2, 8, 8, 60.0, 90.0, 2.0, 'redgreen', 10.0, 32.0, 7.0, 7.5, 0.0, 2.0, False, 'all'),
    ScenarioTask('redgreen_1_per_lane_3l', 3, 3, 12, 12, 60.0, 90.0, 2.0, 'redgreen', 10.0, 32.0, 7.0, 7.5, 0.0, 2.0, False, 'all'),
    ScenarioTask('redgreen_1_per_lane_4l', 4, 4, 16, 16, 60.0, 90.0, 2.0, 'redgreen', 10.0, 32.0, 7.0, 7.5, 0.0, 2.0, False, 'all'),
    ScenarioTask('redgreen_2_per_lane_2l', 2, 2, 16, 16, 75.0, 100.0, 0.55, 'redgreen', 10.0, 24.0, 7.0, 7.5, 0.0, 1.0, False, 'all'),
    ScenarioTask('redgreen_2_per_lane_3l', 3, 3, 24, 24, 75.0, 100.0, 0.45, 'redgreen', 10.0, 24.0, 7.0, 7.5, 0.0, 1.0, False, 'all'),
    ScenarioTask('redgreen_2_per_lane_4l', 4, 4, 32, 32, 75.0, 100.0, 0.35, 'redgreen', 10.0, 24.0, 7.0, 7.5, 0.0, 1.0, False, 'all'),
    ScenarioTask('dense_green_discharge_3_per_green_lane_2l', 2, 2, 6, 6, 60.0, 75.0, 1.6, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 0.0, True, 'green'),
    ScenarioTask('dense_green_discharge_3_per_green_lane_3l', 3, 3, 12, 12, 60.0, 75.0, 1.5, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 0.0, True, 'green'),
    ScenarioTask('dense_green_discharge_3_per_green_lane_4l', 4, 4, 18, 18, 60.0, 75.0, 1.4, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 0.0, True, 'green'),
    ScenarioTask('dense_red_queue_3_per_lane_2l', 2, 2, 24, 24, 60.0, 75.0, 2.4, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 1.5, False, 'closed'),
    ScenarioTask('dense_red_queue_3_per_lane_3l', 3, 3, 36, 36, 60.0, 75.0, 2.2, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 1.5, False, 'closed'),
    ScenarioTask('dense_red_queue_3_per_lane_4l', 4, 4, 48, 48, 60.0, 75.0, 2.0, 'green', 0.2, 1.0, 7.0, 7.5, 0.0, 1.5, False, 'closed'),
    ScenarioTask('dense_redgreen_release_3_per_lane_2l', 2, 2, 24, 24, 60.0, 75.0, 2.4, 'redgreen', 0.2, 1.0, 7.0, 7.5, 0.0, 1.0, False, 'all'),
    ScenarioTask('dense_redgreen_release_3_per_lane_3l', 3, 3, 36, 36, 60.0, 75.0, 2.2, 'redgreen', 0.2, 1.0, 7.0, 7.5, 0.0, 1.0, False, 'all'),
    ScenarioTask('dense_redgreen_release_3_per_lane_4l', 4, 4, 48, 48, 60.0, 75.0, 2.0, 'redgreen', 0.2, 1.0, 7.0, 7.5, 0.0, 1.0, False, 'all'),
    ScenarioTask('yellow_stop_basic', 2, 4, 4, 4, 60.0, 90.0, 1.1, 'yellow', 28.0, 48.0, 12.0, 14.0, 0.3, 1.2, False, 'yellow'),
    ScenarioTask('yellow_clear_basic', 2, 4, 4, 4, 60.0, 90.0, 0.9, 'yellow', 8.0, 14.0, 12.0, 14.0, 2.0, 4.0, False, 'yellow', 2.0, 8.0),
    ScenarioTask('signal_mixed_basic', 2, 4, 4, 4, 60.0, 90.0, 0.6, 'random', 18.0, 42.0, 12.0, 14.0, 0.0, 1.0, False, 'all'),
    ScenarioTask('sparse_mixed', 2, 4, 8, 20, 60.0, 90.0, 1.4, 'random', 16.0, 16.0, 11.5, 11.5, 0.0, 0.0),
    ScenarioTask('medium_mixed', 2, 4, 16, 36, 75.0, 120.0, 1.4, 'random', 16.0, 16.0, 11.5, 11.5, 0.0, 0.0),
    ScenarioTask('dense_3to4_lane', 3, 4, 36, 50, 100.0, 150.0, 1.1, 'random', 16.0, 16.0, 11.5, 11.5, 0.0, 0.0),
    ScenarioTask('red_heavy', 2, 4, 8, 50, 75.0, 140.0, 0.85, 'red', 18.0, 36.0, 10.5, 12.5, 0.0, 0.35),
    ScenarioTask('yellow_approach', 2, 4, 8, 50, 75.0, 140.0, 0.75, 'yellow', 24.0, 44.0, 10.5, 12.5, 0.4, 1.8),
    ScenarioTask('stop_line_drill', 2, 4, 8, 32, 60.0, 120.0, 0.75, 'red', 14.0, 28.0, 10.5, 12.5, 0.0, 0.25),
    ScenarioTask('yellow_stop_drill', 2, 4, 8, 32, 60.0, 120.0, 0.65, 'yellow', 22.0, 40.0, 10.5, 12.5, 0.4, 1.8),
    ScenarioTask('dense_queue_stop', 2, 4, 20, 50, 90.0, 150.0, 0.85, 'red', 16.0, 30.0, 10.5, 12.5, 0.0, 0.25),
    ScenarioTask('dense_green_queue', 2, 4, 20, 50, 90.0, 150.0, 1.8, 'green', 8.0, 18.0, 10.5, 12.5, 0.0, 0.0),
    ScenarioTask('green_queue_discharge', 2, 4, 16, 50, 90.0, 150.0, 2.0, 'green', 4.5, 14.0, 10.5, 12.5, 0.0, 0.0),
    ScenarioTask('protected_left_heavy', 2, 4, 8, 50, 75.0, 150.0, 1.2, 'random', 16.0, 16.0, 11.5, 11.5, 0.0, 0.0),
)


class MultiTaskIntersectionEnv(IntersectionEnv):
    """Intersection environment that samples one scenario family per episode."""

    def __init__(
        self,
        config: EnvConfig | None = None,
        tasks: tuple[ScenarioTask, ...] = DEFAULT_TASKS,
        render_mode: str | None = None,
    ) -> None:
        super().__init__(config=config, render_mode=render_mode)
        self.tasks = tasks
        self.current_task: ScenarioTask | None = None
        self._base_signal_green_seconds = self.config.signal_green_seconds
        self._base_signal_yellow_seconds = self.config.signal_yellow_seconds
        self._base_left_signal_green_seconds = self.config.left_signal_green_seconds
        self._base_signal_all_red_seconds = self.config.signal_all_red_seconds

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        rng = np.random.default_rng(seed) if seed is not None else self.np_random
        if options and "task_name" in options:
            task = next(task for task in self.tasks if task.name == options["task_name"])
        else:
            weights = np.asarray([task.weight for task in self.tasks], dtype=np.float64)
            weights = weights / weights.sum()
            task = self.tasks[int(rng.choice(len(self.tasks), p=weights))]
        self.current_task = task

        lanes = int(rng.integers(task.min_lanes, task.max_lanes + 1))
        self.config.lanes_per_approach = lanes
        self.config.episode_seconds = float(
            rng.uniform(task.min_episode_seconds, task.max_episode_seconds)
        )
        self.config.signal_green_seconds = self._base_signal_green_seconds
        self.config.signal_yellow_seconds = self._base_signal_yellow_seconds
        self.config.left_signal_green_seconds = self._base_left_signal_green_seconds
        self.config.signal_all_red_seconds = self._base_signal_all_red_seconds
        clearance_min = self.config.signal_all_red_seconds_min
        clearance_max = self.config.signal_all_red_seconds_max
        if clearance_min is not None or clearance_max is not None:
            lower = max(
                0.0,
                float(clearance_min if clearance_min is not None else clearance_max),
            )
            upper = max(
                lower,
                float(clearance_max if clearance_max is not None else clearance_min),
            )
            self.config.signal_all_red_seconds = float(rng.uniform(lower, upper))
        if task.signal_mode in {"redgreen", "left_release", "release", "right_on_red"}:
            self.config.signal_yellow_seconds = 0.0
        if task.signal_mode == "green":
            self.config.signal_green_seconds = max(
                self.config.signal_green_seconds,
                self.config.episode_seconds + self.config.signal_yellow_seconds + 5.0,
            )
        if task.signal_mode == "left_green":
            self.config.left_signal_green_seconds = max(
                self.config.left_signal_green_seconds,
                self.config.episode_seconds + self.config.signal_yellow_seconds + 5.0,
            )
        self.config.protected_left_signal = True
        self.config.allow_right_on_red = task.allow_right_on_red
        self.config.right_turns_enabled = task.right_turns_enabled
        self.config.strict_lane_mapping = True
        self.config.initial_lateral_noise = 0.0
        self.config.spawn_lead_gap = float(rng.uniform(task.lead_gap_min, task.lead_gap_max))
        self.config.spawn_queue_gap = float(rng.uniform(task.queue_gap_min, task.queue_gap_max))
        self.config.spawn_red_speed = float(rng.uniform(task.closed_spawn_speed_min, task.closed_spawn_speed_max))
        self.config.spawn_permitted_movements_only = task.spawn_permitted_movements_only
        self.config.spawn_signal_filter = task.spawn_signal_filter
        self.config.spawn_progress_offset_min = task.spawn_progress_offset_min
        self.config.spawn_progress_offset_max = task.spawn_progress_offset_max
        self.config.spawn_randomize_longitudinal_positions = task.randomize_longitudinal_positions
        self.config.spawn_random_lead_gap_min = task.lead_gap_min
        self.config.spawn_random_lead_gap_max = task.lead_gap_max
        self.config.spawn_random_queue_gap_min = task.queue_gap_min
        self.config.spawn_random_queue_gap_max = task.queue_gap_max
        self.config.spawn_random_closed_speed_min = task.closed_spawn_speed_min
        self.config.spawn_random_closed_speed_max = task.closed_spawn_speed_max
        self.config.curriculum_enabled = False
        self.config.curriculum_progression_enabled = False
        self.config.safety_filter_enabled = False
        self.config.intersection_reservation_enabled = False
        self.config.randomize_initial_signal_phase = task.signal_mode in {"random", "redgreen"}
        self.config.randomize_initial_green_phase_only = task.initial_green_only
        self.config.min_cars = 1
        self.config.max_cars = max(self.config.max_cars, task.max_cars)

        capacity = self._lane_capacity(lanes)
        min_cars = min(task.min_cars, capacity)
        max_cars = min(task.max_cars, capacity, self.config.max_cars)
        if min_cars > max_cars:
            min_cars = max_cars
        vehicle_count = int(rng.integers(min_cars, max_cars + 1))
        merged_options = dict(options or {})
        merged_options["vehicle_count"] = int(merged_options.get("vehicle_count", vehicle_count))
        if task.signal_mode not in {"random", "redgreen"}:
            merged_options["initial_signal_time"] = self._sample_signal_time(task.signal_mode)
        observation, info = super().reset(seed=seed, options=merged_options)
        info["task_name"] = task.name
        info["task_lanes"] = lanes
        return observation, info

    def _sample_signal_time(self, signal_mode: str) -> float:
        left = self.config.left_signal_green_seconds
        green = self.config.signal_green_seconds
        yellow = self.config.signal_yellow_seconds
        all_red = max(0.0, self.config.signal_all_red_seconds)
        through_start = left + all_red
        segment = left + all_red + green + yellow + all_red
        axis_offset = 0.0 if float(self.np_random.random()) < 0.5 else segment
        if signal_mode == "yellow":
            yellow_start_window = min(yellow, max(1.0, 0.05 * yellow))
            local = through_start + green + float(self.np_random.uniform(0.0, yellow_start_window))
        elif signal_mode == "green":
            green_start_window = min(green, max(1.0, 0.05 * green))
            local = through_start + float(self.np_random.uniform(0.0, green_start_window))
        elif signal_mode == "left_green":
            left_start_window = min(left, max(1.0, 0.05 * left))
            local = float(self.np_random.uniform(0.0, left_start_window))
        elif signal_mode == "left_release":
            delay = float(self.np_random.uniform(3.0, 5.0))
            local = max(0.0, segment - delay)
        elif signal_mode == "release":
            delay = float(self.np_random.uniform(3.0, 5.0))
            if float(self.np_random.random()) < 0.5:
                local = max(0.0, through_start - delay)
            else:
                local = max(0.0, segment - delay)
        else:
            green_start_window = min(green, max(1.0, 0.05 * green))
            local = through_start + float(self.np_random.uniform(0.0, green_start_window))
        return axis_offset + local
