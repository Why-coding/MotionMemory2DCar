from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from intersection_rl.config import EnvConfig, PPOConfig
from intersection_rl.env import IntersectionEnv
from intersection_rl.graph_observation import GraphObserver
from intersection_rl.graph_ppo import GraphActorCritic
from intersection_rl.ppo import PPOTrainer, SharedActorCritic
from intersection_rl.runtime import assert_project_runtime, print_provenance_banner
from intersection_rl.scenarios import (
    DEMO_SCENARIOS,
    DemoScenario,
    build_demo_redgreen_env,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def add_environment_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--lanes", type=int, choices=range(1, 6), default=2,
        help="incoming lanes per approach (1-5)",
    )
    parser.add_argument(
        "--cars", type=int,
        help="exact number of cars; defaults to a random 8-12",
    )
    parser.add_argument(
        "--left-signal",
        choices=("protected", "yield"),
        default="yield",
        help="protected left arrow or permissive left turn with yielding",
    )
    parser.add_argument(
        "--right-on-red",
        choices=("on", "off"),
        default="on",
        help="allow right turns on red after yielding",
    )
    parser.add_argument(
        "--right-turns",
        choices=("on", "off"),
        default="on",
        help="spawn right-turn routes; turn this off for the current protected red/green phase",
    )
    parser.add_argument(
        "--yellow",
        choices=("on", "off"),
        default="on",
        help="enable yellow signal time; turn this off for the current red/green no-yellow phase",
    )
    parser.add_argument(
        "--safety-shield",
        choices=("on", "off"),
        default="on",
        help="training-aware safety filter for red/yield/front-gap hazards",
    )
    parser.add_argument(
        "--episode-seconds",
        type=float,
        default=60.0,
        help="episode horizon in simulated seconds",
    )
    parser.add_argument(
        "--all-red-seconds",
        type=float,
        default=0.0,
        help="all-red clearance interval inserted between legal green phases",
    )


def environment_config(args: argparse.Namespace) -> EnvConfig:
    if args.cars is not None and args.cars < 1:
        raise ValueError("--cars must be at least 1")
    car_counts = (
        {"min_cars": args.cars, "max_cars": args.cars}
        if args.cars is not None
        else {}
    )
    return EnvConfig(
        lanes_per_approach=args.lanes,
        protected_left_signal=args.left_signal == "protected",
        allow_right_on_red=args.right_on_red == "on",
        right_turns_enabled=args.right_turns == "on",
        signal_yellow_seconds=3.0 if args.yellow == "on" else 0.0,
        signal_all_red_seconds=max(0.0, float(args.all_red_seconds)),
        safety_filter_enabled=args.safety_shield == "on",
        intersection_reservation_enabled=False,
        episode_seconds=args.episode_seconds,
        seed=args.seed,
        **car_counts
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Four-way intersection simulator and PPO policy"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    simulate = subparsers.add_parser("simulate", help="Run the visual simulator")
    simulate.add_argument("--episodes", type=int, default=3)
    simulate.add_argument("--seed", type=int)
    add_environment_arguments(simulate)
    simulate.add_argument(
        "--demo-redgreen",
        action="store_true",
        help="use the policy-matched red/green demo builder",
    )
    simulate.add_argument(
        "--demo-scenario",
        choices=tuple(DEMO_SCENARIOS),
        help="named, seeded policy-matched demo scenario",
    )
    simulate.add_argument(
        "--policy",
        type=Path,
        help="Optional .npz checkpoint; demo presets default to the promoted policy",
    )
    simulate.add_argument(
        "--render",
        choices=("human", "off"),
        default="human",
        help="open the Pygame window or run the identical scenario headlessly",
    )
    simulate.add_argument(
        "--random-start",
        choices=("on", "off"),
        default="on",
        help="randomize the initial signal phase for visual simulation",
    )

    train = subparsers.add_parser("train", help="Train the shared PPO policy")
    train.add_argument("--steps", type=int, default=100_000)
    train.add_argument("--seed", type=int, default=7)
    train.add_argument(
        "--save-interval-updates",
        type=int,
        default=10,
        help="save an intermediate checkpoint every N PPO updates; 0 disables",
    )
    train.add_argument(
        "--curriculum",
        action="store_true",
        help="randomize lanes, active cars, left-signal mode, and right-on-red per episode",
    )
    train.add_argument(
        "--curriculum-stage",
        type=int,
        choices=range(1, 6),
        help="staged curriculum preset from easy traffic to full Week 6 traffic",
    )
    train.add_argument("--curriculum-min-lanes", type=int, default=2)
    train.add_argument("--curriculum-max-lanes", type=int, default=5)
    train.add_argument("--curriculum-min-cars", type=int, default=5)
    train.add_argument("--curriculum-max-cars", type=int, default=64)
    add_environment_arguments(train)
    train.add_argument(
        "--checkpoint", type=Path, default=Path("checkpoints/ppo_intersection.npz")
    )
    train.add_argument(
        "--init-checkpoint",
        type=Path,
        help="optional checkpoint used to warm-start this training run",
    )

    evaluate = subparsers.add_parser("evaluate", help="Evaluate a checkpoint")
    evaluate.add_argument("policy", type=Path)
    evaluate.add_argument("--episodes", type=int, default=20)
    evaluate.add_argument("--seed", type=int, default=101)
    add_environment_arguments(evaluate)
    return parser


def rule_based_actions(env: IntersectionEnv) -> np.ndarray:
    """A Week 5 baseline used to inspect the simulator before training."""
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    for vehicle in env.vehicles:
        if not vehicle.active:
            continue
        distance_to_stop = env._distance_to_stop_line(vehicle)
        front_gap = env._front_gap(vehicle)
        should_stop = (
            not env._movement_permitted(vehicle)
            and 0.0 < distance_to_stop < max(8.0, vehicle.speed * 1.5)
        )
        too_close = front_gap < env.config.vehicle_length + 5.0
        acceleration = 0.0
        if should_stop or too_close:
            acceleration = -1.0
        elif vehicle.speed < env.config.max_speed * 0.75:
            acceleration = 0.6
        steering = float(np.clip(-vehicle.lateral_offset, -1.0, 1.0))
        actions[vehicle.vehicle_id] = [acceleration, steering]
    return actions


def curriculum_stage_config(stage: int) -> dict[str, object]:
    presets: dict[int, dict[str, object]] = {
        1: {
            "min_lanes": 1,
            "max_lanes": 2,
            "min_cars": 4,
            "max_cars": 8,
            "left_signal": True,
            "right_on_red": False,
            "randomize_left": False,
            "randomize_right": False,
        },
        2: {
            "min_lanes": 2,
            "max_lanes": 2,
            "min_cars": 8,
            "max_cars": 12,
            "left_signal": True,
            "right_on_red": False,
            "randomize_left": False,
            "randomize_right": False,
        },
        3: {
            "min_lanes": 2,
            "max_lanes": 3,
            "min_cars": 8,
            "max_cars": 16,
            "left_signal": True,
            "right_on_red": True,
            "randomize_left": False,
            "randomize_right": True,
        },
        4: {
            "min_lanes": 3,
            "max_lanes": 4,
            "min_cars": 12,
            "max_cars": 32,
            "left_signal": False,
            "right_on_red": True,
            "randomize_left": True,
            "randomize_right": True,
        },
        5: {
            "min_lanes": 4,
            "max_lanes": 5,
            "min_cars": 20,
            "max_cars": 64,
            "left_signal": False,
            "right_on_red": True,
            "randomize_left": True,
            "randomize_right": True,
        },
    }
    return presets[stage]


def load_model(env: IntersectionEnv, checkpoint: Path) -> SharedActorCritic:
    model = SharedActorCritic(
        env.OBSERVATION_SIZE, PPOConfig().hidden_size, env.ACTION_SIZE
    )
    model.load(checkpoint)
    return model


def _checkpoint_format(checkpoint: Path) -> str:
    data = np.load(checkpoint, allow_pickle=False)
    try:
        if "format" not in data.files:
            return "legacy_mlp_npz"
        return str(data["format"])
    finally:
        data.close()


def load_graph_model(checkpoint: Path) -> tuple[GraphActorCritic, GraphObserver]:
    data = np.load(checkpoint, allow_pickle=False)
    try:
        max_nodes = int(data["max_nodes"])
        model = GraphActorCritic(
            int(data["ego_size"]),
            int(data["node_size"]),
            int(data["edge_size"]),
            max_nodes,
            hidden_size=int(data["hidden_size"]),
            layers=int(data["layers"]),
        )
    finally:
        data.close()
    model.load(checkpoint)
    model.eval()
    return model, GraphObserver(max_vehicle_nodes=max_nodes - 2)


def _update_stop_line_diagnostics(
    env: IntersectionEnv,
    diagnostics: dict[str, set[int]],
) -> None:
    for vehicle in env.vehicles:
        if vehicle.crossed_on_red:
            diagnostics["true_overshoots"].add(vehicle.vehicle_id)
        if env._dilemma_clearance_eligible[vehicle.vehicle_id]:
            diagnostics["dilemma_clearers"].add(vehicle.vehicle_id)
        if not vehicle.active:
            continue
        movement_closed = (
            not env._movement_has_green(vehicle)
            and not env._movement_has_yellow(vehicle)
        )
        if not movement_closed:
            continue
        distance = env._distance_to_stop_line(vehicle)
        if distance <= 0.0:
            key = (
                "legal_clearers"
                if env._clearance_eligible[vehicle.vehicle_id]
                else "true_overshoots"
            )
            diagnostics[key].add(vehicle.vehicle_id)
        elif distance > env.config.intent_creep_reapproach_min_target_error and vehicle.speed <= 0.5:
            diagnostics["stopped_short"].add(vehicle.vehicle_id)


def _demo_scenario(args: argparse.Namespace, seed: int) -> DemoScenario | None:
    if args.demo_scenario:
        selected = DEMO_SCENARIOS[args.demo_scenario]
        return DemoScenario(
            selected.name,
            selected.lanes,
            selected.cars,
            seed,
        )
    if args.demo_redgreen:
        return DemoScenario(
            "demo_redgreen_custom",
            args.lanes,
            args.cars if args.cars is not None else 8 * args.lanes,
            seed,
        )
    return None


def simulate(args: argparse.Namespace) -> None:
    named = DEMO_SCENARIOS.get(args.demo_scenario) if args.demo_scenario else None
    seed = int(args.seed if args.seed is not None else (named.seed if named else 7))
    demo = _demo_scenario(args, seed)
    policy = args.policy
    if demo is not None and policy is None:
        policy = (
            PROJECT_ROOT
            / "checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz"
        )
    if demo is not None:
        all_red_seconds = (
            args.all_red_seconds
            if args.all_red_seconds > 0.0
            else 3.5
        )
        env = build_demo_redgreen_env(
            demo,
            max_cars=50,
            episode_seconds=args.episode_seconds,
            all_red_seconds=all_red_seconds,
            render_mode="human" if args.render == "human" else None,
        )
        env_config = env.config
        scenario_name = demo.name
    else:
        env_config = environment_config(args)
        env_config.randomize_initial_signal_phase = args.random_start == "on"
        env = IntersectionEnv(
            env_config,
            render_mode="human" if args.render == "human" else None,
        )
        scenario_name = "raw"
    print_provenance_banner(
        command="simulate",
        project_root=PROJECT_ROOT,
        checkpoint=policy,
        seed=seed,
        all_red_seconds=env_config.signal_all_red_seconds,
        extra={
            "scenario": scenario_name,
            "lanes": demo.lanes if demo else args.lanes,
            "cars": demo.cars if demo else (args.cars or "random"),
            "spawn_mode": (
                "feasible_random"
                if demo is not None
                or env_config.spawn_randomize_longitudinal_positions
                else "queue_slots"
            ),
        },
    )
    rng = np.random.default_rng(seed)
    legacy_model: SharedActorCritic | None = None
    graph_model: GraphActorCritic | None = None
    graph_observer: GraphObserver | None = None
    if policy:
        checkpoint_format = _checkpoint_format(policy)
        if checkpoint_format == "graph_attention_torch_state_npz":
            graph_model, graph_observer = load_graph_model(policy)
            if env.config.max_cars > graph_observer.spec.max_vehicle_nodes:
                raise ValueError(
                    f"policy supports max {graph_observer.spec.max_vehicle_nodes} cars, "
                    f"but simulator max_cars is {env.config.max_cars}"
                )
            print(f"loaded_graph_policy={policy}")
        else:
            legacy_model = load_model(env, policy)
            print(f"loaded_legacy_policy={policy}")
    try:
        for episode in range(args.episodes):
            observation, info = env.reset(seed=seed + episode)
            done = False
            episode_reward = 0.0
            event_totals = {
                "red": 0,
                "yellow": 0,
                "collisions": 0,
                "proximity": 0,
                "timeouts": 0,
                "stuck": 0,
            }
            diagnostics = {
                "legal_clearers": set(),
                "dilemma_clearers": set(),
                "true_overshoots": set(),
                "stopped_short": set(),
            }
            failure_records: dict[int, dict[str, object]] = {}
            creep_component_samples = 0
            creep_route_selected = 0
            creep_brake_sum = 0.0
            creep_component_sum = 0.0
            creep_go_sum = 0.0
            _update_stop_line_diagnostics(env, diagnostics)
            while not done:
                phase_before, _ = env._signal_phase()
                phase_age_before = env._signal_phase_elapsed_seconds
                active_before = {
                    vehicle.vehicle_id: {
                        "phase": phase_before,
                        "phase_age": round(phase_age_before, 3),
                        "distance": round(env._distance_to_stop_line(vehicle), 3),
                        "speed": round(vehicle.speed, 3),
                    }
                    for vehicle in env.vehicles
                    if vehicle.active
                }
                if graph_model is not None and graph_observer is not None:
                    graph_observation = graph_observer.encode(env)
                    actions, _, _ = graph_model.act(graph_observation, deterministic=True)
                    weights = graph_model.action_mixture_weights(graph_observation)
                    components = graph_model.action_component_means(graph_observation)
                    if weights is not None and components is not None:
                        labels = env._intent_labels()
                        routes = env._component_route_labels(labels)
                        for vehicle in env.vehicles:
                            if (
                                vehicle.active
                                and routes[vehicle.vehicle_id]
                                == graph_model.CREEP_COMPONENT
                            ):
                                creep_component_samples += 1
                                creep_route_selected += int(
                                    np.argmax(weights[vehicle.vehicle_id])
                                    == graph_model.CREEP_COMPONENT
                                )
                                creep_brake_sum += float(
                                    components[vehicle.vehicle_id, graph_model.BRAKE_COMPONENT]
                                )
                                creep_component_sum += float(
                                    components[vehicle.vehicle_id, graph_model.CREEP_COMPONENT]
                                )
                                creep_go_sum += float(
                                    components[vehicle.vehicle_id, graph_model.GO_COMPONENT]
                                )
                elif legacy_model is not None:
                    actions, _, _ = legacy_model.act(
                        observation, rng, deterministic=True
                    )
                else:
                    actions = rule_based_actions(env)
                observation, rewards, terminated, truncated, info = env.step(actions)
                episode_reward += float(rewards.sum())
                event_totals["red"] += int(info.get("red_light_violations", 0))
                event_totals["yellow"] += int(info.get("yellow_light_violations", 0))
                event_totals["collisions"] += int(info.get("collisions", 0))
                event_totals["proximity"] += int(info.get("proximity_events", 0))
                event_totals["timeouts"] += int(info.get("timeout_failures", 0))
                event_totals["stuck"] += int(info.get("stuck_timeout_failures", 0))
                for vehicle in env.vehicles:
                    if (
                        vehicle.vehicle_id in active_before
                        and not vehicle.active
                        and vehicle.failed
                        and vehicle.vehicle_id not in failure_records
                    ):
                        state = active_before[vehicle.vehicle_id]
                        if vehicle.crossed_on_red:
                            cause = "red_crossing"
                        elif vehicle.collided:
                            cause = "collision"
                        elif truncated:
                            stuck = (
                                vehicle.legal_stall_seconds
                                >= env.config.stuck_timeout_seconds
                                or vehicle.blocked_stall_seconds
                                >= env.config.stuck_timeout_seconds
                            )
                            cause = "stuck_timeout" if stuck else "moving_timeout"
                        else:
                            cause = "rule_failure"
                        failure_records[vehicle.vehicle_id] = {
                            "cause": cause,
                            **state,
                        }
                _update_stop_line_diagnostics(env, diagnostics)
                done = terminated or truncated
            print(
                f"episode={episode + 1} scenario={scenario_name} "
                f"reward={episode_reward:.2f} "
                f"completed_clean={info['completed_clean']} "
                f"failed={info['failed_vehicles']} "
                f"red={event_totals['red']} "
                f"yellow={event_totals['yellow']} "
                f"collisions={event_totals['collisions']} "
                f"proximity_events={event_totals['proximity']} "
                f"timeouts={event_totals['timeouts']} "
                f"stuck_timeouts={event_totals['stuck']} "
                f"legal_clearers={sorted(diagnostics['legal_clearers'])} "
                f"dilemma_clearers={sorted(diagnostics['dilemma_clearers'])} "
                f"true_overshoots={sorted(diagnostics['true_overshoots'])} "
                f"stopped_short={sorted(diagnostics['stopped_short'])} "
                f"failure_records={failure_records} "
                f"creep_samples={creep_component_samples} "
                f"creep_route_selected_share={creep_route_selected / max(creep_component_samples, 1):.3f} "
                f"creep_brake_mean={creep_brake_sum / max(creep_component_samples, 1):+.3f} "
                f"creep_component_mean={creep_component_sum / max(creep_component_samples, 1):+.3f} "
                f"creep_go_mean={creep_go_sum / max(creep_component_samples, 1):+.3f} "
                f"shield={info['cumulative_safety_overrides']}"
            )
    finally:
        env.close()


def train(args: argparse.Namespace) -> None:
    print_provenance_banner(
        command="legacy_train",
        project_root=PROJECT_ROOT,
        checkpoint=args.init_checkpoint or args.checkpoint,
        seed=args.seed,
        extra={"output_checkpoint": args.checkpoint},
    )
    if args.curriculum_stage is not None:
        stage = curriculum_stage_config(args.curriculum_stage)
        env_config = EnvConfig(
            min_cars=int(stage["min_cars"]),
            max_cars=int(stage["max_cars"]),
            lanes_per_approach=int(stage["max_lanes"]),
            protected_left_signal=bool(stage["left_signal"]),
            allow_right_on_red=bool(stage["right_on_red"]),
            safety_filter_enabled=args.safety_shield == "on",
            safety_filter_dropout_rate=0.35 if args.curriculum_stage in (2, 3) and args.safety_shield == "on" else 0.0,
            intersection_reservation_enabled=False,
            episode_seconds=args.episode_seconds,
            seed=args.seed,
            curriculum_enabled=True,
            curriculum_min_lanes=int(stage["min_lanes"]),
            curriculum_max_lanes=int(stage["max_lanes"]),
            curriculum_min_cars=int(stage["min_cars"]),
            curriculum_max_cars=int(stage["max_cars"]),
            curriculum_randomize_left_signal=bool(stage["randomize_left"]),
            curriculum_randomize_right_on_red=bool(stage["randomize_right"]),
            curriculum_progression_enabled=args.curriculum_stage in (1, 2, 3),
            curriculum_stage=args.curriculum_stage,
        )
        if args.curriculum_stage in (2, 3):
            env_config.progress_reward = 0.72
            env_config.clean_completion_bonus = 145.0
            env_config.permitted_idle_penalty = 2.8
            env_config.timeout_failure_penalty = 40.0
    elif args.curriculum:
        env_config = EnvConfig(
            min_cars=args.curriculum_min_cars,
            max_cars=args.curriculum_max_cars,
            lanes_per_approach=args.curriculum_max_lanes,
            protected_left_signal=args.left_signal == "protected",
            allow_right_on_red=args.right_on_red == "on",
            safety_filter_enabled=args.safety_shield == "on",
            intersection_reservation_enabled=False,
            episode_seconds=args.episode_seconds,
            seed=args.seed,
            curriculum_enabled=True,
            curriculum_min_lanes=args.curriculum_min_lanes,
            curriculum_max_lanes=args.curriculum_max_lanes,
            curriculum_min_cars=args.curriculum_min_cars,
            curriculum_max_cars=args.curriculum_max_cars,
        )
    else:
        env_config = environment_config(args)
        env_config.intersection_reservation_enabled = False
    env = IntersectionEnv(env_config)
    stage1_training = args.curriculum_stage == 1
    stage2_training = args.curriculum_stage == 2
    stage3_training = args.curriculum_stage == 3
    staged_training = stage1_training or stage2_training or stage3_training
    validation_interval = 5 if stage2_training or stage3_training else (25 if stage1_training else 0)
    config = PPOConfig(
        total_steps=args.steps,
        seed=args.seed,
        checkpoint_interval_updates=args.save_interval_updates,
        learning_rate=2e-5 if stage2_training or stage3_training else 3e-4,
        update_epochs=2 if stage2_training or stage3_training else 8,
        clip_ratio=0.1 if stage2_training or stage3_training else 0.2,
        target_kl=0.008 if stage2_training or stage3_training else 0.03,
        entropy_coefficient=0.0 if stage2_training or stage3_training else 0.0003,
        validation_interval_updates=validation_interval,
        validation_episodes=20 if staged_training else PPOConfig().validation_episodes,
        validation_cars=12 if stage2_training else (14 if stage3_training else (8 if stage1_training else 0)),
        validation_lanes=3 if stage3_training else (2 if staged_training else 0),
        validation_safety_shield=False if staged_training else args.safety_shield == "on",
        validation_compare_safety_shield=staged_training and args.safety_shield == "on",
        validation_protected_left_signal=True,
        validation_allow_right_on_red=True if stage3_training else False,
        validation_patience=4 if stage2_training or stage3_training else 0,
        validation_min_delta=75.0 if stage2_training or stage3_training else 0.0,
    )
    try:
        trainer = PPOTrainer(env, config)
        if args.init_checkpoint is not None:
            trainer.model.load(args.init_checkpoint)
        trainer.train(args.checkpoint)
        print(f"saved={args.checkpoint}")
    finally:
        env.close()


def evaluate(args: argparse.Namespace) -> None:
    env_config = environment_config(args)
    provenance = print_provenance_banner(
        command="legacy_evaluate",
        project_root=PROJECT_ROOT,
        checkpoint=args.policy,
        seed=args.seed,
        all_red_seconds=env_config.signal_all_red_seconds,
        extra={"episodes": args.episodes, "lanes": args.lanes, "cars": args.cars or "random"},
    )
    env = IntersectionEnv(env_config)
    model = load_model(env, args.policy)
    rng = np.random.default_rng(args.seed)
    rewards: list[float] = []
    completions: list[int] = []
    failures: list[int] = []
    shields: list[int] = []
    incomplete: list[int] = []
    collisions = 0
    red_violations = 0
    left_yield_violations = 0
    right_yield_violations = 0
    right_lane_violations = 0
    right_on_red_entries = 0
    proximity_violations = 0
    proximity_events = 0
    lane_drift_warnings = 0
    unsafe_requests = 0
    active_action_samples = 0
    env_steps = 0
    try:
        for episode in range(args.episodes):
            observation, info = env.reset(seed=args.seed + episode)
            done = False
            episode_reward = 0.0
            while not done:
                active_action_samples += int(info["active_mask"].sum())
                actions, _, _ = model.act(observation, rng, deterministic=True)
                observation, reward, terminated, truncated, info = env.step(actions)
                env_steps += 1
                episode_reward += float(reward.sum())
                collisions += info["collisions"]
                proximity_violations += info["proximity_violations"]
                proximity_events += info.get("proximity_events", 0)
                red_violations += info["red_light_violations"]
                left_yield_violations += info["left_yield_violations"]
                right_yield_violations += info["right_yield_violations"]
                right_lane_violations += info["right_lane_violations"]
                right_on_red_entries += info.get("right_on_red_entries", 0)
                lane_drift_warnings += info.get("lane_drift_warnings", 0)
                unsafe_requests += info.get("unsafe_requests", 0)
                done = terminated or truncated
            rewards.append(episode_reward)
            completions.append(info["completed_clean"])
            failures.append(info["failed_vehicles"])
            shields.append(info["cumulative_safety_overrides"])
            incomplete.append(max(0, args.cars - info["completed_clean"] - info["failed_vehicles"]) if args.cars else 0)
    finally:
        env.close()

    total_vehicle_slots = args.episodes * (args.cars if args.cars is not None else env.config.max_cars)
    action_denominator = max(active_action_samples, 1)
    vehicle_denominator = max(total_vehicle_slots, 1)

    def pct_action(value: int) -> float:
        return 100.0 * value / action_denominator

    def pct_vehicle(value: float) -> float:
        return 100.0 * value / vehicle_denominator

    mean_completed = float(np.mean(completions))
    mean_failed = float(np.mean(failures))
    mean_incomplete = float(np.mean(incomplete))
    completed_pct = pct_vehicle(sum(completions))
    failed_pct = pct_vehicle(sum(failures))
    incomplete_pct = pct_vehicle(sum(incomplete))
    shield_action_pct = pct_action(sum(shields))
    collisions_per_ep = collisions / args.episodes
    proximity_action_pct = pct_action(proximity_violations)
    red_vehicle_pct = pct_vehicle(red_violations)
    lane_drift_action_pct = pct_action(lane_drift_warnings)
    unsafe_action_pct = pct_action(unsafe_requests)
    vehicle_hours = active_action_samples * env.config.dt / 3600.0
    print(
        f"episodes={args.episodes} mean_reward={np.mean(rewards):.2f} "
        f"mean_completed={mean_completed:.2f} completed_pct={completed_pct:.2f} "
        f"mean_failed={mean_failed:.2f} failed_pct={failed_pct:.2f} "
        f"mean_incomplete={mean_incomplete:.2f} incomplete_pct={incomplete_pct:.2f} "
        f"mean_shield={np.mean(shields):.2f} shield_actions={sum(shields)} shield_action_pct={shield_action_pct:.2f} "
        f"collisions={collisions} collisions_per_ep={collisions_per_ep:.2f} collision_vehicle_pct={pct_vehicle(2 * collisions):.2f} "
        f"proximity_vehicles={proximity_violations} proximity_events={proximity_events} proximity_action_pct={proximity_action_pct:.2f} "
        f"red_violations={red_violations} red_vehicle_pct={red_vehicle_pct:.2f} "
        f"left_yield={left_yield_violations} right_yield={right_yield_violations} "
        f"right_on_red_entries={right_on_red_entries} right_lane={right_lane_violations} "
        f"lane_drift={lane_drift_warnings} lane_drift_action_pct={lane_drift_action_pct:.2f} "
        f"unsafe_requests={unsafe_requests} unsafe_action_pct={unsafe_action_pct:.2f} "
        f"active_action_samples={active_action_samples} env_steps={env_steps} "
        f"vehicle_hours={vehicle_hours:.3f}"
    )

    results_path = Path("results/evaluations.csv")
    results_path.parent.mkdir(parents=True, exist_ok=True)
    row = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **provenance,
        "policy": str(args.policy),
        "episodes": args.episodes,
        "seed": args.seed,
        "lanes": args.lanes,
        "cars": args.cars if args.cars is not None else env.config.max_cars,
        "left_signal": args.left_signal,
        "right_on_red": args.right_on_red,
        "safety_shield": args.safety_shield,
        "episode_seconds": args.episode_seconds,
        "mean_reward": float(np.mean(rewards)),
        "mean_completed": mean_completed,
        "completed_pct": completed_pct,
        "mean_failed": mean_failed,
        "failed_pct": failed_pct,
        "mean_incomplete": mean_incomplete,
        "incomplete_pct": incomplete_pct,
        "mean_shield": float(np.mean(shields)),
        "shield_actions": sum(shields),
        "shield_action_pct": shield_action_pct,
        "collisions": collisions,
        "collisions_per_ep": collisions_per_ep,
        "collision_vehicle_pct": pct_vehicle(2 * collisions),
        "proximity_vehicles": proximity_violations,
        "proximity_events": proximity_events,
        "proximity_events_per_ep": proximity_events / args.episodes,
        "proximity_action_pct": proximity_action_pct,
        "red_violations": red_violations,
        "red_violations_per_ep": red_violations / args.episodes,
        "red_vehicle_pct": red_vehicle_pct,
        "left_yield": left_yield_violations,
        "right_yield": right_yield_violations,
        "right_on_red_entries": right_on_red_entries,
        "right_lane": right_lane_violations,
        "lane_drift": lane_drift_warnings,
        "lane_drift_action_pct": lane_drift_action_pct,
        "unsafe_requests": unsafe_requests,
        "unsafe_action_pct": unsafe_action_pct,
        "active_action_samples": active_action_samples,
        "env_steps": env_steps,
        "vehicle_hours": vehicle_hours,
    }
    write_header = not results_path.exists()
    with results_path.open("a", newline="") as results_file:
        writer = csv.DictWriter(results_file, fieldnames=list(row))
        if write_header:
            writer.writeheader()
        writer.writerow(row)
    print(f"logged={results_path}")


def main() -> None:
    assert_project_runtime(PROJECT_ROOT)
    args = build_parser().parse_args()
    {"simulate": simulate, "train": train, "evaluate": evaluate}[args.command](args)


if __name__ == "__main__":
    main()
