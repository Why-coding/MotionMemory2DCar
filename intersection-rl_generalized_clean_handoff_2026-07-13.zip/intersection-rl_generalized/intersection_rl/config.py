from dataclasses import dataclass


@dataclass(slots=True)
class EnvConfig:
    """Configuration for the intersection simulator."""

    # Week 5: initial two-lane, signalized, four-way intersection.
    max_cars: int = 12
    min_cars: int = 8
    lanes_per_approach: int = 2
    lane_width: float = 4.0
    road_length: float = 65.0
    intersection_half_size: float = 10.0
    dt: float = 0.2
    episode_seconds: float = 60.0
    signal_green_seconds: float = 12.0
    signal_yellow_seconds: float = 3.0
    signal_all_red_seconds: float = 0.0
    signal_all_red_seconds_min: float | None = None
    signal_all_red_seconds_max: float | None = None
    protected_left_signal: bool = False
    left_signal_green_seconds: float = 5.0
    left_yield_distance: float = 22.0
    allow_right_on_red: bool = True
    right_yield_distance: float = 24.0
    lateral_speed: float = 1.2
    lane_centering_gain: float = 0.9
    lane_edge_steering_damping: float = 0.75
    initial_lateral_noise: float = 0.0
    strict_lane_mapping: bool = True
    right_turns_enabled: bool = True
    spawn_lead_gap: float = 16.0
    spawn_queue_gap: float = 11.5
    spawn_red_speed: float = 0.0
    spawn_green_min_speed: float = 2.0
    spawn_green_max_speed: float = 5.0
    spawn_progress_offset_min: float | None = None
    spawn_progress_offset_max: float | None = None
    spawn_permitted_movements_only: bool = False
    spawn_signal_filter: str = "all"
    spawn_randomize_longitudinal_positions: bool = False
    spawn_random_lead_gap_min: float = 4.0
    spawn_random_lead_gap_max: float = 30.0
    spawn_random_queue_gap_min: float = 8.0
    spawn_random_queue_gap_max: float = 14.0
    spawn_random_closed_speed_min: float = 0.5
    spawn_random_closed_speed_max: float = 2.5
    spawn_random_green_speed_min: float = 2.0
    spawn_random_green_speed_max: float = 5.0
    spawn_speed_safety_factor: float = 1.35
    max_speed: float = 13.4
    max_acceleration: float = 2.5
    comfortable_braking: float = 4.0
    vehicle_length: float = 4.5
    vehicle_width: float = 1.8
    collision_distance: float = 3.2
    proximity_clearance: float = 0.65
    lane_edge_margin: float = 0.1
    lane_drift_warning_ratio: float = 0.8
    safety_filter_enabled: bool = True
    safety_filter_dropout_rate: float = 0.0
    intersection_reservation_enabled: bool = True
    intersection_reservation_distance: float = 12.0
    proximity_filter_clearance: float = 1.5
    safety_override_penalty: float = 0.35
    unsafe_acceleration_penalty: float = 2.0
    ttc_warning_seconds: float = 3.0
    ttc_critical_seconds: float = 1.5
    minimum_front_gap: float = 7.0
    prediction_horizon_seconds: float = 2.0
    prediction_step_seconds: float = 0.5
    conflict_lookahead_distance: float = 18.0
    predicted_conflict_penalty: float = 4.0
    predicted_proximity_penalty: float = 3.5
    progress_reward: float = 1.20
    permitted_speed_reward: float = 0.80
    permitted_acceleration_reward: float = 0.35
    permitted_idle_penalty: float = 1.50
    legal_stall_penalty: float = 1.20
    legal_stall_speed_threshold: float = 0.8
    legal_stall_grace_seconds: float = 1.5
    legal_stall_time_penalty: float = 0.45
    stuck_timeout_seconds: float = 6.0
    right_on_red_entry_reward: float = 45.0
    right_on_red_approach_reward: float = 1.2
    right_on_red_idle_penalty: float = 6.0
    red_light_violation_penalty: float = 320.0
    yellow_light_violation_penalty: float = 100.0
    closed_signal_speed_penalty: float = 0.8
    closed_signal_accel_penalty: float = 0.10
    closed_signal_margin_penalty: float = 2.0
    closed_signal_near_stop_speed_penalty: float = 3.00
    closed_signal_brake_reward: float = 0.75
    closed_signal_hold_reward: float = 0.35
    closed_signal_stop_window_speed_penalty: float = 1.80
    closed_signal_stop_window_zero_speed_reward: float = 1.20
    closed_signal_progress_penalty: float = 1.8
    closed_signal_target_speed_penalty: float = 0.0
    closed_signal_approach_speed_gain: float = 0.55
    closed_signal_stop_potential_coefficient: float = 0.0
    closed_signal_stop_potential_gamma: float = 0.99
    closed_signal_stop_potential_window: float = 0.45
    closed_signal_stop_potential_hold_reward: float = 0.25
    closed_signal_stop_potential_speed_penalty: float = 0.50
    intent_stop_label_brake_safety_factor: float = 1.25
    intent_stop_label_decel_ratio: float = 1.0
    intent_stop_label_activation_distance: float = 2.0
    intent_stop_label_target_tolerance: float = 1.0
    intent_stop_label_latch_enabled: bool = True
    intent_creep_reapproach_enabled: bool = False
    intent_creep_reapproach_min_target_error: float = 2.0
    intent_creep_reapproach_max_speed: float = 0.5
    intent_creep_route_max_speed: float = 2.0
    randomize_initial_signal_phase: bool = False
    randomize_initial_green_phase_only: bool = False
    dilemma_zone_clearance_enabled: bool = True
    front_close_gap_penalty: float = 0.85
    front_min_gap_penalty: float = 0.55
    front_ttc_warning_penalty: float = 0.75
    front_ttc_critical_penalty: float = 3.0
    front_closing_accel_penalty: float = 1.0
    front_deceleration_reward: float = 0.22
    queue_front_speed_match_penalty: float = 0.35
    queue_front_safe_gap_reward: float = 0.45
    queue_front_safe_gap_max: float = 7.5
    queue_follower_gap_target_min: float = 7.0
    queue_follower_gap_target_max: float = 7.5
    queue_follower_large_gap_penalty: float = 1.40
    queue_follower_approach_reward: float = 1.30
    queue_stop_target_min: float = 0.1
    queue_stop_target_max: float = 1.0
    queue_approach_distance: float = 65.0
    queue_approach_max_speed: float = 3.0
    queue_approach_reward: float = 1.60
    queue_stop_position_reward: float = 1.80
    queue_far_idle_penalty: float = 2.40
    green_queue_progress_reward: float = 1.30
    green_queue_acceleration_reward: float = 0.24
    green_queue_idle_penalty: float = 1.40
    green_queue_stall_time_penalty: float = 0.65
    green_queue_stopped_far_penalty: float = 1.60
    green_zero_speed_penalty: float = 2.20
    green_slow_speed_penalty: float = 1.20
    green_no_progress_penalty: float = 1.80
    green_follower_safe_gap_reward: float = 0.12
    left_red_far_stop_penalty: float = 0.0
    left_green_release_progress_reward: float = 0.0
    left_green_release_acceleration_reward: float = 0.0
    left_green_release_stopped_far_penalty: float = 0.0
    left_green_release_launch_seconds: float = 2.0
    left_green_release_min_launch_speed: float = 1.2
    left_green_release_launch_scale: float = 1.25
    green_blocked_hold_reward: float = 0.22
    green_blocked_accel_penalty: float = 1.1
    green_blocked_speed_penalty: float = 0.55
    clean_completion_bonus: float = 220.0
    timeout_failure_penalty: float = 200.0
    seed: int | None = None
    curriculum_enabled: bool = False
    curriculum_min_lanes: int = 1
    curriculum_max_lanes: int = 5
    curriculum_min_cars: int = 5
    curriculum_max_cars: int = 64
    curriculum_randomize_left_signal: bool = True
    curriculum_randomize_right_on_red: bool = True
    curriculum_progression_enabled: bool = False
    curriculum_stage: int = 0
    curriculum_phase1_episodes: int = 100
    curriculum_phase2_episodes: int = 250
    curriculum_phase3_episodes: int = 600
    stage2_phase1_episodes: int = 300
    stage2_phase2_episodes: int = 650
    stage2_phase3_episodes: int = 950
    stage2_phase4_episodes: int = 1250
    stage3_phase1_episodes: int = 250
    stage3_phase2_episodes: int = 550
    stage3_phase3_episodes: int = 850
    stage3_phase4_episodes: int = 1150
    stage3_phase5_episodes: int = 1450
    stage3_phase6_episodes: int = 1750
    stage3_right_turn_probability: float = 0.45

    def __post_init__(self) -> None:
        if not 1 <= self.lanes_per_approach <= 5:
            raise ValueError("lanes_per_approach must be between 1 and 5")
        if self.min_cars < 1 or self.max_cars < self.min_cars:
            raise ValueError("car counts must satisfy 1 <= min_cars <= max_cars")
        if not 1 <= self.curriculum_min_lanes <= self.curriculum_max_lanes <= 5:
            raise ValueError("curriculum lanes must satisfy 1 <= min <= max <= 5")
        if not 1 <= self.curriculum_min_cars <= self.curriculum_max_cars:
            raise ValueError("curriculum cars must satisfy 1 <= min <= max")
        if self.curriculum_enabled and self.max_cars < self.curriculum_max_cars:
            raise ValueError("max_cars must be >= curriculum_max_cars")
        if self.curriculum_enabled and self.min_cars > self.curriculum_min_cars:
            raise ValueError("min_cars must be <= curriculum_min_cars")
        maximum_lane_count = max(self.lanes_per_approach, self.curriculum_max_lanes)
        minimum_intersection_size = maximum_lane_count * self.lane_width
        self.intersection_half_size = max(
            self.intersection_half_size, minimum_intersection_size
        )

    @property
    def max_steps(self) -> int:
        return round(self.episode_seconds / self.dt)


@dataclass(slots=True)
class PPOConfig:
    """Hyperparameters for the dependency-light NumPy PPO implementation."""

    # Week 6: completed lane scaling, turn signals, right-on-red, and yielding.
    # Week 7: replace kinematics with kinodynamics, speed limits, and merges.
    # Week 8: add parking lanes, parked cars, crosswalks, and pedestrians.
    # Week 9: add jaywalking and vehicle lane changes.
    # Week 10: add per-car goals and cut-in scenario generation.
    # Week 11: add unprotected turns, noise, occlusion, and ROS bag adapters.
    # Week 12: calibrate and deploy the policy in the Nissan simulator.

    # Week 5: shared PPO policy for all active cars.
    total_steps: int = 100_000
    rollout_steps: int = 256
    update_epochs: int = 8
    minibatch_size: int = 512
    hidden_size: int = 64
    action_distribution: str = "legacy_gaussian"
    action_min_log_std: float = -2.302585092994046
    action_max_log_std: float = 0.0
    action_initial_log_std_longitudinal: float = -0.8
    action_initial_log_std_steering: float = -1.5
    learning_rate: float = 3e-4
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_ratio: float = 0.2
    target_kl: float = 0.03
    value_coefficient: float = 0.5
    value_loss_huber_beta: float = 0.0
    entropy_coefficient: float = 0.0003
    intent_loss_coefficient: float = 0.01
    intent_loss_warmup_updates: int = 10
    intent_loss_ramp_updates: int = 30
    intent_detach_shared: bool = True
    intent_action_loss_coefficient: float = 0.0
    intent_action_loss_decay_start_updates: int = 0
    intent_action_loss_decay_updates: int = 0
    intent_action_loss_final_coefficient: float = 0.0
    intent_action_loss_red_only: bool = False
    mixture_gate_loss_coefficient: float = 0.0
    mixture_gate_loss_decay_start_updates: int = 0
    mixture_gate_loss_decay_updates: int = 0
    mixture_gate_loss_final_coefficient: float = 0.0
    mixture_gate_loss_detach_shared: bool = True
    mixture_gate_separate_optimizer: bool = False
    mixture_gate_learning_rate: float = 3e-3
    mixture_gate_max_grad_norm: float = 5.0
    mixture_gate_prewarm_steps: int = 0
    mixture_gate_prewarm_batch_size: int = 1024
    mixture_gate_prewarm_stop_weight_threshold: float = 0.85
    mixture_gate_prewarm_creep_weight_threshold: float = 0.85
    mixture_gate_prewarm_go_weight_threshold: float = 0.85
    mixture_gate_prewarm_ambiguous_threshold: float = 0.05
    mixture_creep_prewarm_action_loss_threshold: float = 0.02
    stop_after_mixture_prewarm: bool = False
    mixture_gate_freeze_ppo_until_saturated: bool = False
    mixture_gate_unfreeze_weight_threshold: float = 0.80
    mixture_gate_unfreeze_argmax_threshold: float = 0.98
    mixture_gate_unfreeze_ambiguous_threshold: float = 0.05
    mixture_gate_unfreeze_patience_updates: int = 10
    mixture_gate_loss_decay_after_unfreeze: bool = False
    go_component_reference_kl_coefficient: float = 0.0
    physics_action_target_road_length: float = 65.0
    physics_action_target_max_speed: float = 13.4
    physics_action_target_max_acceleration: float = 2.5
    physics_action_target_comfortable_braking: float = 4.0
    physics_action_target_stop_margin: float = 3.0
    physics_action_target_brake_safety_factor: float = 1.25
    physics_action_target_red_crawl_speed: float = 3.0
    physics_action_target_red_approach_gain: float = 0.55
    physics_action_target_red_min_brake_accel: float = 0.0
    physics_action_target_queue_following_enabled: bool = False
    physics_action_target_queue_gap_min: float = 7.0
    physics_action_target_queue_gap_max: float = 7.5
    physics_action_target_queue_lead_margin: float = 0.8
    physics_action_target_green_speed: float = 8.0
    physics_action_target_time_constant: float = 1.0
    reference_kl_coefficient: float = 0.0
    reference_kl_all_coefficient: float = 0.0
    reference_kl_stop_hold_only: bool = True
    reference_kl_green_only: bool = False
    phase_advantage_normalization: bool = True
    phase_balanced_minibatches: bool = True
    safety_replay_workers: int = 0
    stop_action_exploration_probability: float = 0.0
    stop_action_exploration_mean: float = -0.65
    stop_action_exploration_std: float = 0.20
    safety_replay_tasks: tuple[str, ...] = (
        "red_heavy",
        "yellow_stop_drill",
        "stop_line_drill",
        "dense_queue_stop",
    )
    rollout_closed_signal_stop_threshold: float = 0.0
    rollout_guard_warmup_updates: int = 0
    task_phase1_updates: int = 0
    task_phase2_updates: int = 0
    max_grad_norm: float = 0.5
    checkpoint_interval_updates: int = 10
    reward_clip: float = 20.0
    validation_interval_updates: int = 0
    validation_episodes: int = 8
    validation_workers: int = 1
    validation_cars: int = 0
    validation_lanes: int = 0
    validation_safety_shield: bool = False
    validation_compare_safety_shield: bool = False
    validation_protected_left_signal: bool = True
    validation_allow_right_on_red: bool = False
    validation_patience: int = 0
    validation_eval_mode: str = "standard"
    validation_min_delta: float = 0.0
    validation_all_red_seconds: float = 3.5
    validation_regime_gates_enabled: bool = False
    validation_target_completed_pct: float = 75.0
    validation_target_collisions_per_ep: float = 1.5
    validation_target_red_per_ep: float = 2.0
    validation_target_proximity_events_per_ep: float = 9.0
    seed: int = 7
