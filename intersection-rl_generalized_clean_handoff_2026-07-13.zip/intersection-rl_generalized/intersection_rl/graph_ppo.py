from __future__ import annotations

import csv
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, replace
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.distributions import Normal, kl_divergence
import torch.nn.functional as F

from intersection_rl.config import PPOConfig
from intersection_rl.graph_observation import GraphObserver
from intersection_rl.runtime import (
    GEOMETRY_CONVENTION,
    checkpoint_metadata,
    warn_on_checkpoint_geometry,
)




class SquashedNormal:
    """Tanh-squashed diagonal Gaussian over [-1, 1] actions.

    PPO stores and re-evaluates log probabilities in action space. The tanh
    Jacobian correction keeps the probability ratio consistent with the action
    actually sent to the environment.
    """

    epsilon = 1.0e-6

    def __init__(self, loc: torch.Tensor, scale: torch.Tensor) -> None:
        self.loc = loc
        self.scale = scale
        self.base_dist = Normal(loc, scale)

    @property
    def mean(self) -> torch.Tensor:
        return torch.tanh(self.loc)

    @property
    def stddev(self) -> torch.Tensor:
        return self.scale

    def sample(self) -> torch.Tensor:
        return torch.tanh(self.base_dist.sample())

    def rsample(self) -> torch.Tensor:
        return torch.tanh(self.base_dist.rsample())

    def log_prob(self, value: torch.Tensor) -> torch.Tensor:
        clipped = torch.clamp(value, -1.0 + self.epsilon, 1.0 - self.epsilon)
        pre_tanh = 0.5 * (torch.log1p(clipped) - torch.log1p(-clipped))
        correction = 2.0 * (np.log(2.0) - pre_tanh - F.softplus(-2.0 * pre_tanh))
        return self.base_dist.log_prob(pre_tanh) - correction

    def entropy(self) -> torch.Tensor:
        # The transformed entropy has no simple closed form. This proxy is
        # stable for PPO entropy regularization and diagnostics.
        return self.base_dist.entropy()

    def kl_divergence(self, other: object) -> torch.Tensor:
        if isinstance(other, SquashedNormal):
            return kl_divergence(self.base_dist, other.base_dist)
        return kl_divergence(self.base_dist, other)  # type: ignore[arg-type]


class MixedSquashedNormal:
    """Longitudinal mixture plus squashed Gaussian steering.

    The three-component policy uses brake, creep, and go at indices 0, 1,
    and 2. The distribution remains generic so legacy two-component tests and
    checkpoints can still be evaluated during migration. Deterministic control
    uses the argmax component mean rather than averaging modes.
    """

    epsilon = 1.0e-6

    def __init__(
        self,
        longitudinal_locs: torch.Tensor,
        longitudinal_scales: torch.Tensor,
        gate_logits: torch.Tensor,
        steering_loc: torch.Tensor,
        steering_scale: torch.Tensor,
    ) -> None:
        self.longitudinal_locs = longitudinal_locs
        self.longitudinal_scales = longitudinal_scales
        self.gate_logits = gate_logits
        self.steering_loc = steering_loc
        self.steering_scale = steering_scale
        self.longitudinal_base_dist = Normal(longitudinal_locs, longitudinal_scales)
        self.steering_base_dist = Normal(steering_loc, steering_scale)

    @staticmethod
    def _atanh(value: torch.Tensor) -> torch.Tensor:
        clipped = torch.clamp(value, -1.0 + MixedSquashedNormal.epsilon, 1.0 - MixedSquashedNormal.epsilon)
        return 0.5 * (torch.log1p(clipped) - torch.log1p(-clipped))

    @staticmethod
    def _tanh_correction(pre_tanh: torch.Tensor) -> torch.Tensor:
        return 2.0 * (np.log(2.0) - pre_tanh - F.softplus(-2.0 * pre_tanh))

    @property
    def mixture_weights(self) -> torch.Tensor:
        return torch.softmax(self.gate_logits, dim=-1)

    @property
    def component_means(self) -> torch.Tensor:
        return torch.tanh(self.longitudinal_locs)

    @property
    def mean(self) -> torch.Tensor:
        component = torch.argmax(self.gate_logits, dim=-1, keepdim=True)
        longitudinal_loc = torch.gather(self.longitudinal_locs, dim=-1, index=component)
        return torch.cat((torch.tanh(longitudinal_loc), torch.tanh(self.steering_loc)), dim=-1)

    @property
    def stddev(self) -> torch.Tensor:
        component = torch.argmax(self.gate_logits, dim=-1, keepdim=True)
        longitudinal_scale = torch.gather(self.longitudinal_scales, dim=-1, index=component)
        return torch.cat((longitudinal_scale, self.steering_scale), dim=-1)

    def sample(self) -> torch.Tensor:
        component = torch.multinomial(self.mixture_weights, num_samples=1)
        longitudinal_loc = torch.gather(self.longitudinal_locs, dim=-1, index=component)
        longitudinal_scale = torch.gather(self.longitudinal_scales, dim=-1, index=component)
        longitudinal_pre_tanh = Normal(longitudinal_loc, longitudinal_scale).sample()
        steering_pre_tanh = self.steering_base_dist.sample()
        return torch.cat((torch.tanh(longitudinal_pre_tanh), torch.tanh(steering_pre_tanh)), dim=-1)

    def rsample(self) -> torch.Tensor:
        return self.sample()

    def log_prob(self, value: torch.Tensor) -> torch.Tensor:
        longitudinal_pre_tanh = self._atanh(value[:, 0]).unsqueeze(-1)
        longitudinal_correction = self._tanh_correction(longitudinal_pre_tanh.squeeze(-1))
        component_log_probs = self.longitudinal_base_dist.log_prob(longitudinal_pre_tanh)
        gate_log_probs = torch.log_softmax(self.gate_logits, dim=-1)
        longitudinal_log_prob = torch.logsumexp(gate_log_probs + component_log_probs, dim=-1)
        longitudinal_log_prob = longitudinal_log_prob - longitudinal_correction

        steering_pre_tanh = self._atanh(value[:, 1]).unsqueeze(-1)
        steering_correction = self._tanh_correction(steering_pre_tanh)
        steering_log_prob = self.steering_base_dist.log_prob(steering_pre_tanh) - steering_correction
        return torch.stack((longitudinal_log_prob, steering_log_prob.squeeze(-1)), dim=-1)

    def entropy(self) -> torch.Tensor:
        weights = self.mixture_weights
        gate_log_probs = torch.log_softmax(self.gate_logits, dim=-1)
        component_entropy = self.longitudinal_base_dist.entropy()
        longitudinal_entropy = (weights * component_entropy).sum(dim=-1) - (weights * gate_log_probs).sum(dim=-1)
        steering_entropy = self.steering_base_dist.entropy().squeeze(-1)
        return torch.stack((longitudinal_entropy, steering_entropy), dim=-1)

    def kl_divergence(self, other: object) -> torch.Tensor:
        steering_self = Normal(self.steering_loc, self.steering_scale)
        if isinstance(other, MixedSquashedNormal):
            weights = self.mixture_weights
            gate_log_probs = torch.log_softmax(self.gate_logits, dim=-1)
            other_gate_log_probs = torch.log_softmax(other.gate_logits, dim=-1)
            component_kl = kl_divergence(self.longitudinal_base_dist, other.longitudinal_base_dist)
            gate_kl = (weights * (gate_log_probs - other_gate_log_probs)).sum(dim=-1)
            longitudinal_kl = (weights * component_kl).sum(dim=-1) + gate_kl
            steering_other = Normal(other.steering_loc, other.steering_scale)
            steering_kl = kl_divergence(steering_self, steering_other).squeeze(-1)
            return torch.stack((longitudinal_kl, steering_kl), dim=-1)
        if isinstance(other, SquashedNormal):
            go_self = Normal(self.longitudinal_locs[:, -1], self.longitudinal_scales[:, -1])
            other_longitudinal = Normal(other.loc[:, 0], other.scale[:, 0])
            longitudinal_kl = kl_divergence(go_self, other_longitudinal)
            other_steering = Normal(other.loc[:, 1:2], other.scale[:, 1:2])
            steering_kl = kl_divergence(steering_self, other_steering).squeeze(-1)
            return torch.stack((longitudinal_kl, steering_kl), dim=-1)
        return kl_divergence(steering_self, other)  # type: ignore[arg-type]


def _mixture_gate_ambiguity(
    weights: torch.Tensor, margin: float = 0.2
) -> torch.Tensor:
    if weights.shape[-1] < 2:
        return torch.zeros(weights.shape[:-1], dtype=torch.bool, device=weights.device)
    top_two = torch.topk(weights, k=2, dim=-1).values
    return (top_two[..., 0] - top_two[..., 1]) < max(0.0, float(margin))


def _policy_kl(dist: object, reference_dist: object) -> torch.Tensor:
    if hasattr(dist, "kl_divergence"):
        return dist.kl_divergence(reference_dist)  # type: ignore[no-any-return, attr-defined]
    return kl_divergence(dist, reference_dist)  # type: ignore[arg-type]


def _go_component_kl(dist: object, reference_dist: object) -> torch.Tensor:
    if not hasattr(dist, "longitudinal_locs"):
        return torch.zeros((), dtype=torch.float32)
    current = dist  # type: ignore[assignment]
    current_go = Normal(current.longitudinal_locs[:, -1], current.longitudinal_scales[:, -1])
    if hasattr(reference_dist, "longitudinal_locs"):
        reference = reference_dist  # type: ignore[assignment]
        reference_go = Normal(reference.longitudinal_locs[:, -1], reference.longitudinal_scales[:, -1])
        reference_steering = Normal(reference.steering_loc, reference.steering_scale)
    elif hasattr(reference_dist, "loc") and hasattr(reference_dist, "scale"):
        reference = reference_dist  # type: ignore[assignment]
        reference_go = Normal(reference.loc[:, 0], reference.scale[:, 0])
        reference_steering = Normal(reference.loc[:, 1:2], reference.scale[:, 1:2])
    else:
        return torch.zeros_like(current.longitudinal_locs[:, -1])
    longitudinal_kl = kl_divergence(current_go, reference_go)
    steering_kl = kl_divergence(
        Normal(current.steering_loc, current.steering_scale),
        reference_steering,
    ).squeeze(-1)
    return longitudinal_kl + steering_kl


class GraphAttentionBlock(nn.Module):
    """One ego-readout graph-attention block with typed edge conditioning."""

    def __init__(self, hidden_size: int) -> None:
        super().__init__()
        self.query = nn.Linear(hidden_size, hidden_size)
        self.key = nn.Linear(hidden_size, hidden_size)
        self.value = nn.Linear(hidden_size, hidden_size)
        self.edge_key = nn.Linear(hidden_size, hidden_size)
        self.edge_value = nn.Linear(hidden_size, hidden_size)
        self.edge_bias = nn.Linear(hidden_size, 1)
        self.update = nn.Sequential(
            nn.Linear(2 * hidden_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, hidden_size),
        )
        self.norm = nn.LayerNorm(hidden_size)

    def forward(
        self,
        ego: torch.Tensor,
        nodes: torch.Tensor,
        edges: torch.Tensor,
        node_mask: torch.Tensor,
    ) -> torch.Tensor:
        query = self.query(ego).unsqueeze(1)
        keys = self.key(nodes) + self.edge_key(edges)
        values = self.value(nodes) + self.edge_value(edges)
        scores = (query * keys).sum(dim=-1) / np.sqrt(float(ego.shape[-1]))
        scores = scores + self.edge_bias(edges).squeeze(-1)
        valid = node_mask > 0.5
        scores = scores.masked_fill(~valid, -1.0e9)
        weights = torch.softmax(scores, dim=-1)
        weights = torch.where(valid, weights, torch.zeros_like(weights))
        weights = weights / torch.clamp(weights.sum(dim=-1, keepdim=True), min=1.0e-6)
        context = torch.sum(weights.unsqueeze(-1) * values, dim=1)
        return self.norm(ego + self.update(torch.cat((ego, context), dim=-1)))


class GraphActorCritic(nn.Module):
    """Typed road-agent graph attention actor-critic.

    Each controlled vehicle receives one ego-centric graph. The graph contains
    all active vehicle nodes plus lane/map and signal context nodes. Edge
    features encode same-lane, front/back, adjacent-lane, observable
    interaction geometry, signal, and context relationships.
    """

    min_log_std = -2.5
    max_log_std = -0.8
    acceleration_shortcut_indices = (0, 2, 14)
    gate_route_feature_indices = (0, 2, 13, 14, 22, 25)
    gate_route_feature_scales = (13.4, 65.0, 1.0, 1.0, 65.0, 1.0)
    gate_route_road_length = 65.0
    gate_route_line_target = 0.55
    gate_route_queue_target = 7.25
    creep_servo_max_speed = 13.4
    creep_servo_road_length = 65.0
    creep_servo_line_margin = 0.8
    creep_servo_queue_target = 7.25
    BRAKE_COMPONENT = 0
    CREEP_COMPONENT = 1
    GO_COMPONENT = 2
    MIXTURE_COMPONENTS = 3

    def __init__(
        self,
        ego_size: int,
        node_size: int,
        edge_size: int,
        max_nodes: int,
        hidden_size: int = 128,
        action_size: int = 2,
        layers: int = 2,
        seed: int = 7,
        action_distribution: str = "legacy_gaussian",
        action_min_log_std: float = -2.302585092994046,
        action_max_log_std: float = 0.0,
        action_initial_log_std: tuple[float, float] = (-0.8, -1.5),
    ) -> None:
        super().__init__()
        torch.manual_seed(seed)
        self.ego_size = ego_size
        self.node_size = node_size
        self.edge_size = edge_size
        self.max_nodes = max_nodes
        self.hidden_size = hidden_size
        self.action_size = action_size
        self.action_distribution = action_distribution
        if self.action_distribution not in {"legacy_gaussian", "squashed_gaussian", "squashed_mixture"}:
            raise ValueError(f"Unsupported action_distribution={self.action_distribution!r}")
        self.action_min_log_std = float(action_min_log_std)
        self.action_max_log_std = float(action_max_log_std)
        if self.action_min_log_std > self.action_max_log_std:
            raise ValueError("action_min_log_std must be <= action_max_log_std")
        self.action_initial_log_std = tuple(float(value) for value in action_initial_log_std)
        self.intent_size = 4
        self.layers = layers
        self.ego_encoder = nn.Sequential(
            nn.Linear(ego_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.Tanh(),
        )
        self.node_encoder = nn.Sequential(
            nn.Linear(node_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.Tanh(),
        )
        self.edge_encoder = nn.Sequential(
            nn.Linear(edge_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.Tanh(),
        )
        self.attention_layers = nn.ModuleList(
            GraphAttentionBlock(hidden_size) for _ in range(layers)
        )
        self.body = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh(),
        )
        if action_size != 2:
            raise ValueError("GraphActorCritic expects [longitudinal, steering] actions")
        self.acceleration_head = nn.Linear(hidden_size, 1)
        self.acceleration_shortcut_head = nn.Linear(len(self.acceleration_shortcut_indices), 1)
        self.brake_acceleration_head = nn.Linear(hidden_size, 1)
        self.brake_acceleration_shortcut_head = nn.Linear(len(self.acceleration_shortcut_indices), 1)
        self.creep_acceleration_head = nn.Linear(hidden_size, 1)
        self.creep_acceleration_shortcut_head = nn.Linear(len(self.acceleration_shortcut_indices), 1)
        self.creep_servo_residual_head = nn.Sequential(
            nn.Linear(2, 32),
            nn.Tanh(),
            nn.Linear(32, 1),
        )
        self.acceleration_gate_head = nn.Linear(hidden_size, self.MIXTURE_COMPONENTS)
        self.acceleration_gate_shortcut_head = nn.Linear(
            len(self.acceleration_shortcut_indices), self.MIXTURE_COMPONENTS
        )
        self.acceleration_gate_route_head = nn.Sequential(
            nn.Linear(len(self.gate_route_feature_indices) + 1, 16),
            nn.Tanh(),
            nn.Linear(16, self.MIXTURE_COMPONENTS),
        )
        self.brake_log_std_head = nn.Linear(hidden_size, 1)
        self.creep_log_std_head = nn.Linear(hidden_size, 1)
        self.steering_head = nn.Linear(hidden_size, 1)
        self.log_std_head = nn.Linear(hidden_size, action_size)
        self.value_head = nn.Linear(hidden_size, 1)
        self.intent_head = nn.Linear(hidden_size, self.intent_size)
        self.log_std = nn.Parameter(torch.tensor([-1.0, -1.8], dtype=torch.float32))
        self.creep_component_enabled = self.action_distribution == "squashed_mixture"
        self._init_weights()

    def _init_weights(self) -> None:
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.orthogonal_(module.weight, gain=np.sqrt(2.0))
                nn.init.zeros_(module.bias)
        nn.init.orthogonal_(self.acceleration_head.weight, gain=0.01)
        nn.init.zeros_(self.acceleration_head.bias)
        nn.init.zeros_(self.acceleration_shortcut_head.weight)
        nn.init.zeros_(self.acceleration_shortcut_head.bias)
        nn.init.orthogonal_(self.brake_acceleration_head.weight, gain=0.01)
        nn.init.zeros_(self.brake_acceleration_head.bias)
        nn.init.zeros_(self.brake_acceleration_shortcut_head.weight)
        nn.init.zeros_(self.brake_acceleration_shortcut_head.bias)
        nn.init.orthogonal_(self.creep_acceleration_head.weight, gain=0.01)
        nn.init.zeros_(self.creep_acceleration_head.bias)
        nn.init.zeros_(self.creep_acceleration_shortcut_head.weight)
        nn.init.zeros_(self.creep_acceleration_shortcut_head.bias)
        nn.init.zeros_(self.creep_servo_residual_head[-1].weight)
        nn.init.zeros_(self.creep_servo_residual_head[-1].bias)
        nn.init.zeros_(self.acceleration_gate_head.weight)
        nn.init.zeros_(self.acceleration_gate_head.bias)
        nn.init.zeros_(self.acceleration_gate_shortcut_head.weight)
        nn.init.zeros_(self.acceleration_gate_shortcut_head.bias)
        nn.init.zeros_(self.acceleration_gate_route_head[-1].weight)
        nn.init.zeros_(self.acceleration_gate_route_head[-1].bias)
        nn.init.zeros_(self.brake_log_std_head.weight)
        nn.init.zeros_(self.brake_log_std_head.bias)
        nn.init.zeros_(self.creep_log_std_head.weight)
        nn.init.zeros_(self.creep_log_std_head.bias)
        nn.init.orthogonal_(self.steering_head.weight, gain=0.01)
        nn.init.zeros_(self.steering_head.bias)
        nn.init.zeros_(self.log_std_head.weight)
        nn.init.zeros_(self.log_std_head.bias)
        with torch.no_grad():
            self.acceleration_head.bias[0] = 0.15
            self.brake_acceleration_head.bias[0] = -0.60
            self.creep_acceleration_head.bias[0] = 0.10
            self.acceleration_gate_head.bias.copy_(
                torch.tensor([-0.25, -10.0, 0.25], dtype=self.acceleration_gate_head.bias.dtype)
            )
            initial_log_std = torch.as_tensor(self.action_initial_log_std, dtype=self.log_std_head.bias.dtype)
            if initial_log_std.numel() != self.action_size:
                initial_log_std = torch.full_like(self.log_std_head.bias, float(initial_log_std.flatten()[0]))
            clipped_initial = torch.clamp(initial_log_std, self.action_min_log_std, self.action_max_log_std)
            self.log_std_head.bias.copy_(clipped_initial)
            self.brake_log_std_head.bias[0] = clipped_initial[0]
            self.creep_log_std_head.bias[0] = clipped_initial[0]
        nn.init.orthogonal_(self.value_head.weight, gain=1.0)
        nn.init.zeros_(self.value_head.bias)
        nn.init.orthogonal_(self.intent_head.weight, gain=0.01)
        nn.init.zeros_(self.intent_head.bias)
        with torch.no_grad():
            self.intent_head.bias[0] = 0.25
            self.intent_head.bias[2] = 0.35

    @property
    def device(self) -> torch.device:
        return next(self.parameters()).device

    def _tensor(self, array: np.ndarray) -> torch.Tensor:
        return torch.as_tensor(array, dtype=torch.float32, device=self.device)

    def _acceleration_shortcut_features(self, ego: torch.Tensor) -> torch.Tensor:
        return ego[:, self.acceleration_shortcut_indices]

    def _shared_features(
        self,
        ego: torch.Tensor,
        nodes: torch.Tensor,
        edges: torch.Tensor,
        node_mask: torch.Tensor,
    ) -> torch.Tensor:
        ego_features = self.ego_encoder(ego)
        node_features = self.node_encoder(nodes)
        edge_features = self.edge_encoder(edges)
        for layer in self.attention_layers:
            ego_features = layer(ego_features, node_features, edge_features, node_mask)
        return self.body(ego_features)

    def _go_acceleration_loc(self, features: torch.Tensor, ego: torch.Tensor) -> torch.Tensor:
        return self.acceleration_head(features) + self.acceleration_shortcut_head(
            self._acceleration_shortcut_features(ego)
        )

    def _brake_acceleration_loc(self, features: torch.Tensor, ego: torch.Tensor) -> torch.Tensor:
        return self.brake_acceleration_head(features) + self.brake_acceleration_shortcut_head(
            self._acceleration_shortcut_features(ego)
        )

    def _creep_servo_features(self, ego: torch.Tensor) -> torch.Tensor:
        speed = ego[:, 0] * self.creep_servo_max_speed
        distance_to_stop = ego[:, 2] * self.creep_servo_road_length
        front_gap = ego[:, 22] * self.creep_servo_road_length
        line_available = distance_to_stop - self.creep_servo_line_margin
        follower_available = front_gap - self.creep_servo_queue_target
        available_distance = torch.where(
            front_gap < 0.95 * self.creep_servo_road_length,
            torch.minimum(line_available, follower_available),
            line_available,
        )
        return torch.stack((speed, available_distance), dim=-1)

    def _creep_acceleration_loc(self, features: torch.Tensor, ego: torch.Tensor) -> torch.Tensor:
        return (
            self.creep_acceleration_head(features)
            + self.creep_acceleration_shortcut_head(self._acceleration_shortcut_features(ego))
            + self.creep_servo_residual_head(self._creep_servo_features(ego))
        )

    def set_creep_component_enabled(self, enabled: bool) -> None:
        self.creep_component_enabled = bool(enabled)

    def _gate_route_features(self, ego: torch.Tensor) -> torch.Tensor:
        route_features = ego[:, self.gate_route_feature_indices]
        scales = torch.as_tensor(
            self.gate_route_feature_scales,
            dtype=route_features.dtype,
            device=route_features.device,
        )
        route_features = route_features * scales
        distance_to_stop = route_features[:, 1]
        front_gap = route_features[:, 4]
        line_target_error = distance_to_stop - self.gate_route_line_target
        follower_target_error = front_gap - self.gate_route_queue_target
        target_error = torch.where(
            front_gap < self.gate_route_road_length,
            torch.minimum(line_target_error, follower_target_error),
            line_target_error,
        )
        return torch.cat((route_features, target_error.unsqueeze(-1)), dim=-1)

    def _acceleration_gate_logits(self, features: torch.Tensor, ego: torch.Tensor) -> torch.Tensor:
        logits = self.acceleration_gate_head(features) + self.acceleration_gate_shortcut_head(
            self._acceleration_shortcut_features(ego)
        )
        logits = logits + self.acceleration_gate_route_head(
            self._gate_route_features(ego)
        )
        if self.action_distribution == "squashed_mixture" and not self.creep_component_enabled:
            logits = logits.clone()
            logits[:, self.CREEP_COMPONENT] = torch.finfo(logits.dtype).min
        return logits

    def mixture_gate_logits(
        self,
        ego: torch.Tensor,
        nodes: torch.Tensor,
        edges: torch.Tensor,
        node_mask: torch.Tensor,
        detach_features: bool = False,
    ) -> torch.Tensor:
        features = self._shared_features(ego, nodes, edges, node_mask)
        if detach_features:
            features = features.detach()
        return self._acceleration_gate_logits(features, ego)

    def creep_component_mean(
        self,
        ego: torch.Tensor,
        nodes: torch.Tensor,
        edges: torch.Tensor,
        node_mask: torch.Tensor,
        detach_features: bool = False,
    ) -> torch.Tensor:
        features = self._shared_features(ego, nodes, edges, node_mask)
        if detach_features:
            features = features.detach()
        return torch.tanh(self._creep_acceleration_loc(features, ego)).squeeze(-1)

    def _mixture_log_std(
        self,
        features: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        go_and_steering = torch.clamp(
            self.log_std_head(features), self.action_min_log_std, self.action_max_log_std
        )
        brake = torch.clamp(
            self.brake_log_std_head(features), self.action_min_log_std, self.action_max_log_std
        )
        creep = torch.clamp(
            self.creep_log_std_head(features), self.action_min_log_std, self.action_max_log_std
        )
        longitudinal_log_std = torch.cat((brake, creep, go_and_steering[:, 0:1]), dim=-1)
        steering_log_std = go_and_steering[:, 1:2]
        return longitudinal_log_std, steering_log_std

    def _forward_outputs(
        self,
        ego: torch.Tensor,
        nodes: torch.Tensor,
        edges: torch.Tensor,
        node_mask: torch.Tensor,
        detach_intent_features: bool = False,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        features = self._shared_features(ego, nodes, edges, node_mask)
        intent_features = features.detach() if detach_intent_features else features
        intent_logits = self.intent_head(intent_features)
        steering_loc = self.steering_head(features)
        if self.action_distribution == "squashed_mixture":
            longitudinal_locs = torch.cat(
                (
                    self._brake_acceleration_loc(features, ego),
                    self._creep_acceleration_loc(features, ego),
                    self._go_acceleration_loc(features, ego),
                ),
                dim=-1,
            )
            gate_logits = self._acceleration_gate_logits(features, ego)
            selected = torch.argmax(gate_logits, dim=-1, keepdim=True)
            acceleration_loc = torch.gather(longitudinal_locs, dim=-1, index=selected)
            action_loc = torch.cat((acceleration_loc, steering_loc), dim=-1)
            longitudinal_log_std, steering_log_std = self._mixture_log_std(features)
            selected_log_std = torch.gather(longitudinal_log_std, dim=-1, index=selected)
            log_std = torch.cat((selected_log_std, steering_log_std), dim=-1)
        else:
            acceleration_loc = self._go_acceleration_loc(features, ego)
            action_loc = torch.cat((acceleration_loc, steering_loc), dim=-1)
            if self.action_distribution == "squashed_gaussian":
                log_std = torch.clamp(
                    self.log_std_head(features), self.action_min_log_std, self.action_max_log_std
                )
            else:
                log_std = torch.clamp(
                    self.log_std, self.action_min_log_std, self.action_max_log_std
                ).expand_as(action_loc)
        bounded_mean = torch.tanh(action_loc)
        values = self.value_head(features).squeeze(-1)
        return bounded_mean, values, intent_logits, action_loc, log_std

    def _forward_tensor(
        self,
        ego: torch.Tensor,
        nodes: torch.Tensor,
        edges: torch.Tensor,
        node_mask: torch.Tensor,
        detach_intent_features: bool = False,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        mean, values, intent_logits, _, _ = self._forward_outputs(
            ego, nodes, edges, node_mask, detach_intent_features=detach_intent_features
        )
        return mean, values, intent_logits

    def forward(self, observation: dict[str, np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
        with torch.no_grad():
            mean, values, _ = self._forward_tensor(
                self._tensor(observation["ego"]),
                self._tensor(observation["nodes"]),
                self._tensor(observation["edges"]),
                self._tensor(observation["node_mask"]),
            )
        return mean.cpu().numpy(), values.cpu().numpy()

    def distribution(
        self,
        ego: torch.Tensor,
        nodes: torch.Tensor,
        edges: torch.Tensor,
        node_mask: torch.Tensor,
        detach_intent_features: bool = False,
    ) -> tuple[object, torch.Tensor, torch.Tensor, torch.Tensor]:
        features = self._shared_features(ego, nodes, edges, node_mask)
        intent_features = features.detach() if detach_intent_features else features
        intent_logits = self.intent_head(intent_features)
        values = self.value_head(features).squeeze(-1)
        steering_loc = self.steering_head(features)
        if self.action_distribution == "squashed_mixture":
            longitudinal_locs = torch.cat(
                (
                    self._brake_acceleration_loc(features, ego),
                    self._creep_acceleration_loc(features, ego),
                    self._go_acceleration_loc(features, ego),
                ),
                dim=-1,
            )
            longitudinal_log_std, steering_log_std = self._mixture_log_std(features)
            dist = MixedSquashedNormal(
                longitudinal_locs,
                torch.exp(longitudinal_log_std),
                self._acceleration_gate_logits(features, ego),
                steering_loc,
                torch.exp(steering_log_std),
            )
            return dist, dist.mean, values, intent_logits
        acceleration_loc = self._go_acceleration_loc(features, ego)
        action_loc = torch.cat((acceleration_loc, steering_loc), dim=-1)
        if self.action_distribution == "squashed_gaussian":
            log_std = torch.clamp(
                self.log_std_head(features), self.action_min_log_std, self.action_max_log_std
            )
            dist = SquashedNormal(action_loc, torch.exp(log_std))
            return dist, dist.mean, values, intent_logits
        mean = torch.tanh(action_loc)
        log_std = torch.clamp(self.log_std, self.action_min_log_std, self.action_max_log_std).expand_as(mean)
        return Normal(mean, torch.exp(log_std)), mean, values, intent_logits

    def act(
        self,
        observation: dict[str, np.ndarray],
        deterministic: bool = False,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        with torch.no_grad():
            ego = self._tensor(observation["ego"])
            nodes = self._tensor(observation["nodes"])
            edges = self._tensor(observation["edges"])
            node_mask = self._tensor(observation["node_mask"])
            dist, mean, values, _ = self.distribution(ego, nodes, edges, node_mask)
            actions = mean if deterministic else dist.sample()
            log_probs = dist.log_prob(actions).sum(dim=-1)
            actions = torch.clamp(actions, -1.0, 1.0)
        return (
            actions.cpu().numpy().astype(np.float32),
            log_probs.cpu().numpy().astype(np.float32),
            values.cpu().numpy().astype(np.float32),
        )

    def action_std(self, observation: dict[str, np.ndarray]) -> np.ndarray:
        with torch.no_grad():
            ego = self._tensor(observation["ego"])
            nodes = self._tensor(observation["nodes"])
            edges = self._tensor(observation["edges"])
            node_mask = self._tensor(observation["node_mask"])
            dist, _, _, _ = self.distribution(ego, nodes, edges, node_mask)
            stddev = dist.stddev
        return stddev.cpu().numpy().astype(np.float32)

    def action_mixture_weights(self, observation: dict[str, np.ndarray]) -> np.ndarray | None:
        if self.action_distribution != "squashed_mixture":
            return None
        with torch.no_grad():
            ego = self._tensor(observation["ego"])
            nodes = self._tensor(observation["nodes"])
            edges = self._tensor(observation["edges"])
            node_mask = self._tensor(observation["node_mask"])
            features = self._shared_features(ego, nodes, edges, node_mask)
            weights = torch.softmax(self._acceleration_gate_logits(features, ego), dim=-1)
        return weights.cpu().numpy().astype(np.float32)

    def action_component_means(
        self,
        observation: dict[str, np.ndarray],
    ) -> np.ndarray | None:
        if self.action_distribution != "squashed_mixture":
            return None
        with torch.no_grad():
            dist, _, _, _ = self.distribution(
                self._tensor(observation["ego"]),
                self._tensor(observation["nodes"]),
                self._tensor(observation["edges"]),
                self._tensor(observation["node_mask"]),
            )
            component_means = dist.component_means
        return component_means.cpu().numpy().astype(np.float32)

    def predict_intents(self, observation: dict[str, np.ndarray]) -> np.ndarray:
        with torch.no_grad():
            _, _, intent_logits = self._forward_tensor(
                self._tensor(observation["ego"]),
                self._tensor(observation["nodes"]),
                self._tensor(observation["edges"]),
                self._tensor(observation["node_mask"]),
            )
        return torch.argmax(intent_logits, dim=-1).cpu().numpy().astype(np.int64)

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        state = {name: tensor.detach().cpu().numpy() for name, tensor in self.state_dict().items()}
        metadata = {
            "format": np.array("graph_attention_torch_state_npz"),
            "ego_size": np.array(self.ego_size),
            "node_size": np.array(self.node_size),
            "edge_size": np.array(self.edge_size),
            "max_nodes": np.array(self.max_nodes),
            "hidden_size": np.array(self.hidden_size),
            "action_size": np.array(self.action_size),
            "intent_size": np.array(self.intent_size),
            "layers": np.array(self.layers),
            "actor_head": np.array("separate_accel_steer_creep_v3"),
            "actor_distribution": np.array(self.action_distribution),
            "mixture_components": np.array(self.MIXTURE_COMPONENTS),
            "creep_component_enabled": np.array(int(self.creep_component_enabled)),
            "geometry_convention": np.array(GEOMETRY_CONVENTION),
            "acceleration_shortcut_indices": np.asarray(self.acceleration_shortcut_indices, dtype=np.int64),
            "action_min_log_std": np.array(self.action_min_log_std),
            "action_max_log_std": np.array(self.action_max_log_std),
        }
        np.savez(path, **state, **metadata)

    def load(self, path: str | Path) -> None:
        warn_on_checkpoint_geometry(checkpoint_metadata(path), path)
        data = np.load(path, allow_pickle=False)
        supported_actor_heads = {
            "separate_accel_steer_v1",
            "separate_accel_steer_creep_v2",
            "separate_accel_steer_creep_v3",
        }
        if "actor_head" in data.files:
            actor_head = str(data["actor_head"])
            if actor_head not in supported_actor_heads:
                raise ValueError(
                    f"Checkpoint actor_head={actor_head!r}; expected one of {sorted(supported_actor_heads)!r}. "
                    "Retrain from scratch after the actor-head redesign."
                )
        elif "policy_head.weight" in data.files or "mode_policy_head.weight" in data.files:
            raise ValueError(
                "Checkpoint uses the old intent-blended actor head. "
                "Retrain from scratch with the separate acceleration/steering actor."
            )
        if "actor_distribution" in data.files:
            actor_distribution = str(data["actor_distribution"])
        else:
            actor_distribution = "legacy_gaussian"
        if actor_distribution not in {"legacy_gaussian", "squashed_gaussian", "squashed_mixture"}:
            raise ValueError(f"Checkpoint actor_distribution={actor_distribution!r} is unsupported")
        keep_mixture_warm_start = (
            self.action_distribution == "squashed_mixture"
            and actor_distribution in {"legacy_gaussian", "squashed_gaussian"}
        )
        if not keep_mixture_warm_start:
            self.action_distribution = actor_distribution
        source_components = int(data["mixture_components"]) if "mixture_components" in data.files else 2
        legacy_mixture = actor_distribution == "squashed_mixture" and source_components == 2
        if keep_mixture_warm_start or legacy_mixture:
            self.creep_component_enabled = False
        elif "creep_component_enabled" in data.files:
            self.creep_component_enabled = bool(int(data["creep_component_enabled"]))
        if "action_min_log_std" in data.files:
            self.action_min_log_std = float(data["action_min_log_std"])
        if "action_max_log_std" in data.files:
            self.action_max_log_std = float(data["action_max_log_std"])
        state = self.state_dict()
        loaded_state = dict(state)
        for name in state:
            if name not in data.files:
                continue
            source = torch.as_tensor(data[name], dtype=state[name].dtype)
            if source.shape != state[name].shape:
                if (
                    legacy_mixture
                    and name in {"acceleration_gate_head.weight", "acceleration_gate_shortcut_head.weight"}
                    and source.shape[0] == 2
                    and state[name].shape[0] == self.MIXTURE_COMPONENTS
                ):
                    migrated = state[name].clone()
                    migrated[self.BRAKE_COMPONENT] = source[0]
                    migrated[self.GO_COMPONENT] = source[1]
                    loaded_state[name] = migrated
                    continue
                if (
                    legacy_mixture
                    and name in {"acceleration_gate_head.bias", "acceleration_gate_shortcut_head.bias"}
                    and source.shape == (2,)
                    and state[name].shape == (self.MIXTURE_COMPONENTS,)
                ):
                    migrated = state[name].clone()
                    migrated[self.BRAKE_COMPONENT] = source[0]
                    migrated[self.GO_COMPONENT] = source[1]
                    loaded_state[name] = migrated
                    continue
                if (
                    name == "acceleration_gate_route_head.0.weight"
                    and source.ndim == 2
                    and source.shape[0] == state[name].shape[0]
                    and source.shape[1] + 1 == state[name].shape[1]
                ):
                    migrated = state[name].clone()
                    migrated[:, : source.shape[1]] = source
                    migrated[:, source.shape[1] :] = 0.0
                    loaded_state[name] = migrated
                    continue
                raise ValueError(
                    f"Checkpoint tensor {name} has shape {tuple(source.shape)}; "
                    f"expected {tuple(state[name].shape)}"
                )
            loaded_state[name] = source
        self.load_state_dict(loaded_state)


@dataclass(slots=True)
class GraphRollout:
    ego: np.ndarray
    nodes: np.ndarray
    edges: np.ndarray
    node_mask: np.ndarray
    actions: np.ndarray
    log_probs: np.ndarray
    rewards: np.ndarray
    values: np.ndarray
    dones: np.ndarray
    masks: np.ndarray
    intent_labels: np.ndarray
    component_route_labels: np.ndarray
    last_values: np.ndarray
    info_metrics: dict[str, float]

    def advantages_and_returns(
        self, gamma: float, gae_lambda: float
    ) -> tuple[np.ndarray, np.ndarray]:
        advantages = np.zeros_like(self.rewards)
        gae = np.zeros(self.rewards.shape[1], dtype=np.float32)
        for time_index in reversed(range(len(self.rewards))):
            next_values = (
                self.last_values
                if time_index == len(self.rewards) - 1
                else self.values[time_index + 1]
            )
            nonterminal = 1.0 - self.dones[time_index]
            delta = (
                self.rewards[time_index]
                + gamma * next_values * nonterminal
                - self.values[time_index]
            )
            gae = delta + gamma * gae_lambda * nonterminal * gae
            gae *= self.masks[time_index]
            advantages[time_index] = gae
        return advantages, advantages + self.values



def _model_state_numpy(model: GraphActorCritic) -> dict[str, np.ndarray]:
    return {name: tensor.detach().cpu().numpy() for name, tensor in model.state_dict().items()}


def _load_state_numpy(model: GraphActorCritic, state_np: dict[str, np.ndarray]) -> None:
    state = model.state_dict()
    loaded_state = dict(state)
    for name, tensor in state.items():
        if name in state_np:
            loaded_state[name] = torch.as_tensor(state_np[name], dtype=tensor.dtype)
    model.load_state_dict(loaded_state)


def _act_with_stop_exploration(
    model: GraphActorCritic,
    observation: dict[str, np.ndarray],
    intent_labels: np.ndarray,
    probability: float,
    brake_mean: float,
    brake_std: float,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if probability <= 0.0:
        return model.act(observation)
    with torch.no_grad():
        ego = model._tensor(observation["ego"])
        nodes = model._tensor(observation["nodes"])
        edges = model._tensor(observation["edges"])
        node_mask = model._tensor(observation["node_mask"])
        dist, mean, values, _ = model.distribution(ego, nodes, edges, node_mask)
        actions = dist.sample()
        labels = np.asarray(intent_labels, dtype=np.int64)
        stop_mask_np = labels == 0
        if stop_mask_np.any():
            explore_np = stop_mask_np & (rng.random(labels.shape) < probability)
            if explore_np.any():
                explore = torch.as_tensor(explore_np, dtype=torch.bool, device=model.device)
                brake_distribution = Normal(
                    torch.full_like(actions[:, 0], float(brake_mean)),
                    torch.full_like(actions[:, 0], max(float(brake_std), 1e-3)),
                )
                brake_actions = brake_distribution.sample()
                actions[:, 0] = torch.where(explore, brake_actions, actions[:, 0])
                actions = torch.clamp(actions, -1.0, 1.0)
                longitudinal_log_probs = dist.log_prob(actions)[:, 0]
                longitudinal_log_probs = torch.where(
                    explore,
                    brake_distribution.log_prob(actions[:, 0]),
                    longitudinal_log_probs,
                )
                steering_log_probs = dist.log_prob(actions)[:, 1]
                log_probs = longitudinal_log_probs + steering_log_probs
            else:
                actions = torch.clamp(actions, -1.0, 1.0)
                log_probs = dist.log_prob(actions).sum(dim=-1)
        else:
            actions = torch.clamp(actions, -1.0, 1.0)
            log_probs = dist.log_prob(actions).sum(dim=-1)
    return (
        actions.cpu().numpy().astype(np.float32),
        log_probs.cpu().numpy().astype(np.float32),
        values.cpu().numpy().astype(np.float32),
    )


def _collect_graph_rollout_worker(payload: dict) -> GraphRollout:
    from intersection_rl.multitask import MultiTaskIntersectionEnv

    torch.set_num_threads(1)
    env_config = replace(payload["env_config"], seed=payload["seed"])
    env = MultiTaskIntersectionEnv(env_config, tasks=payload["tasks"])
    observer = GraphObserver(max_vehicle_nodes=payload["max_vehicle_nodes"])
    model = GraphActorCritic(
        payload["ego_size"],
        payload["node_size"],
        payload["edge_size"],
        payload["max_nodes"],
        hidden_size=payload["hidden_size"],
        action_size=payload["action_size"],
        layers=payload["layers"],
        seed=payload["seed"],
        action_distribution=payload.get("action_distribution", "legacy_gaussian"),
        action_min_log_std=payload.get("action_min_log_std", -2.302585092994046),
        action_max_log_std=payload.get("action_max_log_std", 0.0),
        action_initial_log_std=tuple(payload.get("action_initial_log_std", (-0.8, -1.5))),
    )
    _load_state_numpy(model, payload["model_state"])
    model.eval()
    reset_options = {"task_name": payload["task_name"]} if payload.get("task_name") else None
    _, info = env.reset(seed=payload["seed"], options=reset_options)
    observation = observer.encode(env)
    rollout_rng = np.random.default_rng(payload["seed"] + 99173)
    storage: dict[str, list[np.ndarray]] = {
        key: []
        for key in (
            "ego", "nodes", "edges", "node_mask", "actions",
            "log_probs", "rewards", "values", "dones", "masks", "intent_labels",
            "component_route_labels",
        )
    }
    info_metrics = GraphPPOTrainer._empty_metrics()
    try:
        for _ in range(payload["rollout_steps"]):
            labels = info.get("intent_labels", np.full(env.config.max_cars, -1, dtype=np.int64))
            actions, log_probs, values = _act_with_stop_exploration(
                model,
                observation,
                labels,
                payload.get("stop_action_exploration_probability", 0.0),
                payload.get("stop_action_exploration_mean", -0.65),
                payload.get("stop_action_exploration_std", 0.20),
                rollout_rng,
            )
            mask = info["active_mask"].copy()
            active_count = float(mask.sum())
            _, rewards, terminated, truncated, next_info = env.step(actions)
            rewards = np.clip(rewards, -payload["reward_clip"], payload["reward_clip"])
            GraphPPOTrainer._accumulate_step_metrics(info_metrics, next_info, active_count)
            done = terminated or truncated
            storage["ego"].append(observation["ego"].copy())
            storage["nodes"].append(observation["nodes"].copy())
            storage["edges"].append(observation["edges"].copy())
            storage["node_mask"].append(observation["node_mask"].copy())
            storage["actions"].append(actions)
            storage["log_probs"].append(log_probs)
            storage["rewards"].append(rewards)
            storage["values"].append(values)
            storage["dones"].append(np.full_like(rewards, float(done)))
            storage["masks"].append(mask)
            storage["intent_labels"].append(info.get("intent_labels", np.full_like(mask, -1, dtype=np.int64)).copy())
            storage["component_route_labels"].append(
                info.get("component_route_labels", np.full_like(mask, -1, dtype=np.int64)).copy()
            )
            info = next_info
            observation = observer.encode(env)
            if done:
                _, info = env.reset(options=reset_options)
                observation = observer.encode(env)
        _, last_values = model.forward(observation)
    finally:
        env.close()
    arrays = {key: np.asarray(value) for key, value in storage.items()}
    return GraphRollout(**arrays, last_values=last_values, info_metrics=info_metrics)



def _run_graph_validation_worker(payload: dict) -> dict[str, float]:
    from intersection_rl.env import IntersectionEnv
    from intersection_rl.multitask import MultiTaskIntersectionEnv, ScenarioTask
    from intersection_rl.scenarios import redgreen_task

    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass

    validation_config = replace(
        payload["env_config"],
        min_cars=1,
        max_cars=payload["max_cars"],
        lanes_per_approach=payload["lanes"],
        episode_seconds=payload["episode_seconds"],
        curriculum_enabled=False,
        curriculum_progression_enabled=False,
        protected_left_signal=True,
        allow_right_on_red=False,
        right_turns_enabled=False,
        strict_lane_mapping=True,
        initial_lateral_noise=0.0,
        randomize_initial_signal_phase=True,
        safety_filter_enabled=False,
        safety_filter_dropout_rate=0.0,
        intersection_reservation_enabled=False,
    )
    eval_mode = payload.get("validation_eval_mode", "standard")
    allow_ror = False
    right_turns = False
    queue_gap_min = 12.0
    queue_gap_max = 14.0
    if eval_mode in {"green", "left_green", "left_release", "right_on_red", "red", "lead_red_stop", "lead_red_approach", "red_queue", "dense_redgreen", "mixed", "redgreen"}:
        if eval_mode == "red":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 10.0, 30.0
            speed_min, speed_max = 2.0, 6.0
            permitted_only = False
        elif eval_mode == "lead_red_stop":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 0.2, 1.0
            speed_min, speed_max = 0.0, 0.0
            permitted_only = False
        elif eval_mode == "lead_red_approach":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 2.0, 8.0
            speed_min, speed_max = 0.2, 1.5
            permitted_only = False
        elif eval_mode == "red_queue":
            signal_mode = "green"
            spawn_filter = "closed"
            lead_min, lead_max = 0.2, 1.0
            speed_min, speed_max = 0.0, 2.5
            queue_gap_min, queue_gap_max = 7.0, 7.5
            permitted_only = False
        elif eval_mode == "dense_redgreen":
            signal_mode = "redgreen"
            spawn_filter = "all"
            lead_min, lead_max = 0.2, 1.0
            speed_min, speed_max = 0.0, 1.0
            queue_gap_min, queue_gap_max = 7.0, 7.5
            permitted_only = False
        elif eval_mode == "mixed":
            signal_mode = "green"
            spawn_filter = "all"
            lead_min, lead_max = 18.0, 42.0
            speed_min, speed_max = 0.0, 1.0
            permitted_only = False
        elif eval_mode == "right_on_red":
            signal_mode = "right_on_red"
            spawn_filter = "right_red_conflict"
            lead_min, lead_max = 8.0, 24.0
            speed_min, speed_max = 0.0, 2.5
            permitted_only = False
            allow_ror = True
            right_turns = True
        elif eval_mode == "redgreen":
            signal_mode = "redgreen"
            spawn_filter = "all"
            lead_min, lead_max = 10.0, 32.0
            speed_min, speed_max = 0.0, 2.0
            permitted_only = False
        elif eval_mode == "left_green":
            signal_mode = "left_green"
            spawn_filter = "green"
            lead_min, lead_max = 4.5, 18.0
            speed_min, speed_max = 0.0, 0.0
            permitted_only = True
        elif eval_mode == "left_release":
            signal_mode = "left_release"
            spawn_filter = "next_left_release"
            lead_min, lead_max = 10.0, 22.0
            speed_min, speed_max = 2.0, 5.0
            permitted_only = False
        else:
            signal_mode = "green"
            spawn_filter = "green"
            lead_min, lead_max = 6.0, 24.0
            speed_min, speed_max = 0.0, 0.0
            permitted_only = True
        task = ScenarioTask(
            f"validation_{eval_mode}",
            payload["lanes"],
            payload["lanes"],
            payload["cars"],
            payload["cars"],
            payload["episode_seconds"],
            payload["episode_seconds"],
            1.0,
            signal_mode,
            lead_min,
            lead_max,
            queue_gap_min,
            queue_gap_max,
            speed_min,
            speed_max,
            permitted_only,
            spawn_filter,
            None,
            None,
            allow_ror,
            right_turns,
        )
        if eval_mode in {"dense_redgreen", "redgreen"}:
            task = redgreen_task(
                name=f"validation_{eval_mode}",
                lanes=payload["lanes"],
                cars=payload["cars"],
                episode_seconds=payload["episode_seconds"],
                dense=eval_mode == "dense_redgreen",
            )
        env = MultiTaskIntersectionEnv(validation_config, tasks=(task,))
    else:
        env = IntersectionEnv(validation_config)
    observer = GraphObserver(max_vehicle_nodes=payload["max_vehicle_nodes"])
    model = GraphActorCritic(
        payload["ego_size"],
        payload["node_size"],
        payload["edge_size"],
        payload["max_nodes"],
        hidden_size=payload["hidden_size"],
        action_size=payload["action_size"],
        layers=payload["layers"],
        seed=payload["seed"],
        action_distribution=payload.get("action_distribution", "legacy_gaussian"),
        action_min_log_std=payload.get("action_min_log_std", -2.302585092994046),
        action_max_log_std=payload.get("action_max_log_std", 0.0),
        action_initial_log_std=tuple(payload.get("action_initial_log_std", (-0.8, -1.5))),
    )
    _load_state_numpy(model, payload["model_state"])
    model.eval()
    metrics = GraphPPOTrainer._empty_metrics()
    try:
        for episode in range(payload["episode_start"], payload["episode_stop"]):
            env.reset(
                seed=payload["base_seed"] + episode,
                options={"vehicle_count": payload["cars"]},
            )
            observation = observer.encode(env)
            info = env._get_info(np.zeros(env.config.max_cars, dtype=np.float32))
            done = False
            while not done:
                predicted_intents = model.predict_intents(observation)
                GraphPPOTrainer._accumulate_intent_metrics(
                    metrics,
                    info.get("intent_labels", np.full(env.config.max_cars, -1, dtype=np.int64)),
                    predicted_intents,
                    info.get("active_mask", np.zeros(env.config.max_cars, dtype=np.float32)),
                )
                actions, _, _ = model.act(observation, deterministic=True)
                _, _, terminated, truncated, info = env.step(actions)
                GraphPPOTrainer._accumulate_step_metrics(
                    metrics,
                    info,
                    float(info.get("active_mask", np.zeros(payload["cars"])).sum()),
                )
                observation = observer.encode(env)
                done = terminated or truncated
    finally:
        env.close()
    metrics["episodes"] = float(payload["episode_stop"] - payload["episode_start"])
    metrics["cars"] = float(payload["cars"])
    metrics["lanes"] = float(payload["lanes"])
    return metrics


class GraphPPOTrainer:
    """PPO trainer for the final typed graph-attention shared policy."""

    def __init__(
        self,
        env,
        config: PPOConfig,
        observer: GraphObserver,
        layers: int = 2,
        rollout_workers: int = 1,
        validation_workers: int = 1,
    ) -> None:
        self.env = env
        self.config = config
        self.observer = observer
        self.rollout_workers = max(1, int(rollout_workers))
        self.validation_workers = max(1, int(validation_workers))
        self.rng = np.random.default_rng(config.seed)
        torch.manual_seed(config.seed)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        spec = observer.spec
        self.model = GraphActorCritic(
            spec.ego_size,
            spec.node_size,
            spec.edge_size,
            spec.max_nodes,
            hidden_size=config.hidden_size,
            layers=layers,
            seed=config.seed,
            action_distribution=config.action_distribution,
            action_min_log_std=config.action_min_log_std,
            action_max_log_std=config.action_max_log_std,
            action_initial_log_std=(
                config.action_initial_log_std_longitudinal,
                config.action_initial_log_std_steering,
            ),
        ).to(self.device)
        self.reference_model: GraphActorCritic | None = None
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=config.learning_rate)
        self._mixture_gate_params = list(self._mixture_gate_parameters())
        self._creep_component_params = list(self._creep_component_parameters())
        self.gate_optimizer = (
            torch.optim.Adam(self._mixture_gate_params, lr=config.mixture_gate_learning_rate)
            if config.mixture_gate_separate_optimizer and self._mixture_gate_params
            else None
        )
        self.creep_optimizer = (
            torch.optim.Adam(self._creep_component_params, lr=config.mixture_gate_learning_rate)
            if config.mixture_gate_separate_optimizer and self._creep_component_params
            else None
        )
        self._mixture_gate_saturated_updates = 0
        self._mixture_gate_ppo_unfrozen = not bool(config.mixture_gate_freeze_ppo_until_saturated)
        self._mixture_gate_unfreeze_update: int | None = None
        self._mixture_gate_prewarm_metrics: dict[str, float] = {}
        _, self.info = env.reset(seed=config.seed)
        self.observation = observer.encode(env)

    def _mixture_gate_parameters(self) -> tuple[nn.Parameter, ...]:
        if not hasattr(self, "model"):
            return tuple()
        modules = (
            getattr(self.model, "acceleration_gate_head", None),
            getattr(self.model, "acceleration_gate_shortcut_head", None),
            getattr(self.model, "acceleration_gate_route_head", None),
        )
        params: list[nn.Parameter] = []
        for module in modules:
            if module is not None:
                params.extend(list(module.parameters()))
        return tuple(params)

    def _creep_component_parameters(self) -> tuple[nn.Parameter, ...]:
        if not hasattr(self, "model"):
            return tuple()
        modules = (
            getattr(self.model, "creep_acceleration_head", None),
            getattr(self.model, "creep_acceleration_shortcut_head", None),
            getattr(self.model, "creep_servo_residual_head", None),
            getattr(self.model, "creep_log_std_head", None),
        )
        params: list[nn.Parameter] = []
        for module in modules:
            if module is not None:
                params.extend(list(module.parameters()))
        return tuple(params)

    def _creep_action_targets_from_ego(self, ego: torch.Tensor) -> torch.Tensor:
        speed = torch.clamp(
            ego[:, 0] * self.config.physics_action_target_max_speed, min=0.0
        )
        distance_to_stop = ego[:, 2] * self.config.physics_action_target_road_length
        front_gap = ego[:, 22] * self.config.physics_action_target_road_length
        if self.config.physics_action_target_queue_following_enabled:
            queue_following = front_gap < 0.95 * self.config.physics_action_target_road_length
        else:
            queue_following = torch.zeros_like(speed, dtype=torch.bool)
        queue_gap_min = max(float(self.config.physics_action_target_queue_gap_min), 0.0)
        queue_gap_max = max(float(self.config.physics_action_target_queue_gap_max), queue_gap_min)
        queue_gap_target = 0.5 * (queue_gap_min + queue_gap_max)
        line_margin = max(
            float(
                self.config.physics_action_target_queue_lead_margin
                if self.config.physics_action_target_queue_following_enabled
                else self.config.physics_action_target_stop_margin
            ),
            0.0,
        )
        line_available = distance_to_stop - line_margin
        follower_available = front_gap - queue_gap_target
        available_distance = torch.where(
            queue_following,
            torch.minimum(line_available, follower_available),
            line_available,
        )
        available_distance = torch.clamp(available_distance, min=0.0)
        braking = max(float(self.config.physics_action_target_comfortable_braking), 1.0e-3)
        safety = max(float(self.config.physics_action_target_brake_safety_factor), 1.0)
        safe_speed = torch.sqrt(torch.clamp(2.0 * braking * available_distance / safety, min=0.0))
        crawl_speed = max(float(self.config.physics_action_target_red_crawl_speed), 0.0)
        approach_gain = max(float(self.config.physics_action_target_red_approach_gain), 0.0)
        desired_speed = torch.minimum(torch.full_like(speed, crawl_speed), safe_speed)
        desired_speed = torch.minimum(desired_speed, approach_gain * available_distance)
        desired_speed = torch.where(
            available_distance <= 1.0, torch.zeros_like(desired_speed), desired_speed
        )
        time_constant = max(float(self.config.physics_action_target_time_constant), 1.0e-3)
        max_accel = max(float(self.config.physics_action_target_max_acceleration), 1.0e-3)
        target_accel = torch.clamp(
            (desired_speed - speed) / time_constant,
            min=-braking,
            max=max_accel,
        )
        normalized = torch.where(
            target_accel >= 0.0,
            target_accel / max_accel,
            target_accel / braking,
        )
        return torch.clamp(normalized, -1.0, 1.0)

    def _augment_creep_prewarm_ego(
        self,
        ego: torch.Tensor,
        creep_mask: torch.Tensor,
        step: int,
    ) -> torch.Tensor:
        augmented = ego.clone()
        indices = torch.nonzero(creep_mask, as_tuple=False).squeeze(-1)
        if indices.numel() == 0:
            return augmented
        speed_grid = torch.tensor(
            [0.0, 0.5, 1.5, 2.5, 4.0],
            dtype=augmented.dtype,
            device=augmented.device,
        )
        sample_offsets = torch.arange(indices.numel(), device=augmented.device)
        speed_offsets = sample_offsets + max(0, step - 1)
        speeds = speed_grid[speed_offsets % speed_grid.numel()]
        augmented[indices, 0] = speeds / max(
            float(self.config.physics_action_target_max_speed), 1.0e-3
        )

        available_grid = torch.tensor(
            [0.25, 0.5, 0.8, 1.2, 2.0, 4.0, 8.0, 20.0],
            dtype=augmented.dtype,
            device=augmented.device,
        )
        distance_offsets = sample_offsets + max(0, step - 1) // speed_grid.numel()
        available = available_grid[distance_offsets % available_grid.numel()]
        road_length = max(float(self.config.physics_action_target_road_length), 1.0e-3)
        line_margin = max(
            float(
                self.config.physics_action_target_queue_lead_margin
                if self.config.physics_action_target_queue_following_enabled
                else self.config.physics_action_target_stop_margin
            ),
            0.0,
        )
        augmented[indices, 2] = (available + line_margin) / road_length
        if self.config.physics_action_target_queue_following_enabled:
            original_front_gap = ego[indices, 22] * road_length
            queue_following = original_front_gap < 0.95 * road_length
            queue_gap = 0.5 * (
                max(float(self.config.physics_action_target_queue_gap_min), 0.0)
                + max(
                    float(self.config.physics_action_target_queue_gap_max),
                    max(float(self.config.physics_action_target_queue_gap_min), 0.0),
                )
            )
            augmented_front_gap = torch.where(
                queue_following,
                available + queue_gap,
                torch.full_like(available, road_length),
            )
            augmented[indices, 22] = augmented_front_gap / road_length
        return augmented

    def _clear_mixture_gate_gradients(self) -> None:
        for parameter in self._mixture_gate_params:
            parameter.grad = None

    @staticmethod
    def _gradient_norm(parameters) -> float:
        total = 0.0
        for parameter in parameters:
            grad = getattr(parameter, "grad", None)
            if grad is None:
                continue
            value = float(grad.detach().norm().item())
            total += value * value
        return float(total ** 0.5)

    @staticmethod
    def _autograd_norm(loss: torch.Tensor, parameters, retain_graph: bool = True) -> float:
        params = [parameter for parameter in parameters if parameter.requires_grad]
        if not params:
            return 0.0
        grads = torch.autograd.grad(
            loss,
            params,
            retain_graph=retain_graph,
            allow_unused=True,
        )
        total = 0.0
        for grad in grads:
            if grad is None:
                continue
            value = float(grad.detach().norm().item())
            total += value * value
        return float(total ** 0.5)

    def _mixture_gate_ppo_frozen(self) -> bool:
        return (
            self.gate_optimizer is not None
            and self.config.mixture_gate_freeze_ppo_until_saturated
            and not self._mixture_gate_ppo_unfrozen
        )

    def _update_mixture_gate_freeze_state(self, metrics: dict[str, float], update_index: int) -> None:
        if not self.config.mixture_gate_freeze_ppo_until_saturated:
            metrics["mixture_gate_ppo_frozen"] = 0.0
            metrics["mixture_gate_saturated_updates"] = float(self._mixture_gate_saturated_updates)
            metrics["mixture_gate_updates_since_unfreeze"] = float(
                0 if self._mixture_gate_unfreeze_update is None else max(0, update_index - self._mixture_gate_unfreeze_update)
            )
            return
        weight_threshold = max(0.0, float(self.config.mixture_gate_unfreeze_weight_threshold))
        argmax_threshold = max(0.0, float(self.config.mixture_gate_unfreeze_argmax_threshold))
        ambiguous_threshold = max(0.0, float(self.config.mixture_gate_unfreeze_ambiguous_threshold))
        patience = max(1, int(self.config.mixture_gate_unfreeze_patience_updates))
        route_names = ("brake", "creep", "go")
        present = all(
            float(metrics.get(f"mixture_route_{name}_samples", 0.0)) > 0.0
            for name in route_names
        )
        weight_ok = weight_threshold <= 0.0 or all(
            float(metrics.get(f"mixture_route_{name}_weight", 0.0)) >= weight_threshold
            for name in route_names
        )
        gate_stable = (
            present
            and weight_ok
            and all(
                float(metrics.get(f"mixture_route_{name}_argmax", 0.0)) >= argmax_threshold
                for name in route_names
            )
            and all(
                float(metrics.get(f"mixture_route_{name}_ambiguous", 1.0)) <= ambiguous_threshold
                for name in route_names
            )
        )
        if gate_stable:
            self._mixture_gate_saturated_updates += 1
        else:
            self._mixture_gate_saturated_updates = 0
        if self._mixture_gate_saturated_updates >= patience and not self._mixture_gate_ppo_unfrozen:
            self._mixture_gate_ppo_unfrozen = True
            self._mixture_gate_unfreeze_update = update_index
        metrics["mixture_gate_ppo_frozen"] = float(self._mixture_gate_ppo_frozen())
        metrics["mixture_gate_saturated_updates"] = float(self._mixture_gate_saturated_updates)
        metrics["mixture_gate_updates_since_unfreeze"] = float(
            0 if self._mixture_gate_unfreeze_update is None else max(0, update_index - self._mixture_gate_unfreeze_update)
        )

    def load_reference_policy(self, checkpoint_path: str | Path) -> None:
        spec = self.observer.spec
        reference = GraphActorCritic(
            spec.ego_size,
            spec.node_size,
            spec.edge_size,
            spec.max_nodes,
            hidden_size=self.config.hidden_size,
            layers=self.model.layers,
            seed=self.config.seed,
            action_distribution=self.config.action_distribution,
            action_min_log_std=self.config.action_min_log_std,
            action_max_log_std=self.config.action_max_log_std,
            action_initial_log_std=(
                self.config.action_initial_log_std_longitudinal,
                self.config.action_initial_log_std_steering,
            ),
        ).to(self.device)
        reference.load(checkpoint_path)
        if self.model.creep_component_enabled:
            reference.set_creep_component_enabled(True)
        reference.eval()
        for parameter in reference.parameters():
            parameter.requires_grad_(False)
        self.reference_model = reference

    def collect_rollout(self) -> GraphRollout:
        storage: dict[str, list[np.ndarray]] = {
            key: []
            for key in (
                "ego", "nodes", "edges", "node_mask", "actions",
                "log_probs", "rewards", "values", "dones", "masks", "intent_labels",
            "component_route_labels",
            )
        }
        info_metrics = self._empty_metrics()
        for _ in range(self.config.rollout_steps):
            labels = self.info.get("intent_labels", np.full(self.env.config.max_cars, -1, dtype=np.int64))
            actions, log_probs, values = _act_with_stop_exploration(
                self.model,
                self.observation,
                labels,
                self.config.stop_action_exploration_probability,
                self.config.stop_action_exploration_mean,
                self.config.stop_action_exploration_std,
                self.rng,
            )
            mask = self.info["active_mask"].copy()
            active_count = float(mask.sum())
            _, rewards, terminated, truncated, next_info = self.env.step(actions)
            rewards = np.clip(rewards, -self.config.reward_clip, self.config.reward_clip)
            self._accumulate_step_metrics(info_metrics, next_info, active_count)
            done = terminated or truncated
            storage["ego"].append(self.observation["ego"].copy())
            storage["nodes"].append(self.observation["nodes"].copy())
            storage["edges"].append(self.observation["edges"].copy())
            storage["node_mask"].append(self.observation["node_mask"].copy())
            storage["actions"].append(actions)
            storage["log_probs"].append(log_probs)
            storage["rewards"].append(rewards)
            storage["values"].append(values)
            storage["dones"].append(np.full_like(rewards, float(done)))
            storage["masks"].append(mask)
            storage["intent_labels"].append(self.info.get("intent_labels", np.full_like(mask, -1, dtype=np.int64)).copy())
            storage["component_route_labels"].append(
                self.info.get("component_route_labels", np.full_like(mask, -1, dtype=np.int64)).copy()
            )
            self.info = next_info
            self.observation = self.observer.encode(self.env)
            if done:
                _, self.info = self.env.reset()
                self.observation = self.observer.encode(self.env)
        _, last_values = self.model.forward(self.observation)
        arrays = {key: np.asarray(value) for key, value in storage.items()}
        return GraphRollout(**arrays, last_values=last_values, info_metrics=info_metrics)


    def _scheduled_tasks(self, update_index: int):
        tasks = tuple(getattr(self.env, "tasks", ()))
        if not tasks:
            return tasks
        if self.config.task_phase1_updates > 0 and update_index <= self.config.task_phase1_updates:
            names = {
                'green_basic',
                'green_queue_basic',
                'left_green_basic',
                'left_green_queue_basic',
                'red_stop_basic',
                'red_brake_basic',
                'red_creep_release_basic',
                'red_queue_1_per_lane_2l',
                'red_queue_1_per_lane_3l',
                'red_queue_1_per_lane_4l',
                'green_1to2_per_lane_2l',
                'green_1to2_per_lane_3l',
                'green_1to2_per_lane_4l',
                'red_queue_2_per_lane_2l',
                'red_queue_2_per_lane_3l',
                'red_queue_2_per_lane_4l',
                'dense_green_discharge_3_per_green_lane_2l',
                'dense_green_discharge_3_per_green_lane_3l',
                'dense_green_discharge_3_per_green_lane_4l',
                'dense_red_queue_3_per_lane_2l',
                'dense_red_queue_3_per_lane_3l',
                'dense_red_queue_3_per_lane_4l',
            }
            selected = tuple(task for task in tasks if task.name in names)
            return selected if selected else tasks
        if self.config.task_phase2_updates > 0 and update_index <= self.config.task_phase2_updates:
            names = {
                'green_basic',
                'green_queue_basic',
                'red_stop_basic',
                'red_brake_basic',
                'red_creep_release_basic',
                'left_green_basic',
                'left_green_queue_basic',
                'red_queue_1_per_lane_2l',
                'red_queue_1_per_lane_3l',
                'red_queue_1_per_lane_4l',
                'yellow_stop_basic',
                'red_heavy',
                'yellow_stop_drill',
                'dense_queue_stop',
                'green_queue_discharge',
                'sparse_mixed',
                'medium_mixed',
                'protected_left_heavy',
                'green_1to2_per_lane_2l',
                'green_1to2_per_lane_3l',
                'green_1to2_per_lane_4l',
                'red_queue_2_per_lane_2l',
                'red_queue_2_per_lane_3l',
                'red_queue_2_per_lane_4l',
                'redgreen_next_release',
                'redgreen_1_per_lane_2l',
                'redgreen_1_per_lane_3l',
                'redgreen_1_per_lane_4l',
                'redgreen_2_per_lane_2l',
                'redgreen_2_per_lane_3l',
                'redgreen_2_per_lane_4l',
                'dense_green_discharge_3_per_green_lane_2l',
                'dense_green_discharge_3_per_green_lane_3l',
                'dense_green_discharge_3_per_green_lane_4l',
                'dense_red_queue_3_per_lane_2l',
                'dense_red_queue_3_per_lane_3l',
                'dense_red_queue_3_per_lane_4l',
                'dense_redgreen_release_3_per_lane_2l',
                'dense_redgreen_release_3_per_lane_3l',
                'dense_redgreen_release_3_per_lane_4l',
            }
            selected = tuple(task for task in tasks if task.name in names)
            return selected if selected else tasks
        return tasks

    def collect_rollouts(self, update_index: int = 1) -> list[GraphRollout]:
        if self.rollout_workers <= 1:
            return [self.collect_rollout()]
        spec = self.observer.spec
        state_np = _model_state_numpy(self.model)
        seeds = self.rng.integers(1, 2**31 - 1, size=self.rollout_workers, dtype=np.int64)
        tasks = self._scheduled_tasks(update_index)
        scheduled_names = {task.name for task in tasks}
        safety_tasks = tuple(
            task_name for task_name in self.config.safety_replay_tasks if task_name in scheduled_names
        )
        safety_workers = min(max(0, int(self.config.safety_replay_workers)), self.rollout_workers)
        payloads = [
            {
                "env_config": replace(self.env.config, seed=int(seed)),
                "tasks": tasks,
                "max_vehicle_nodes": spec.max_vehicle_nodes,
                "ego_size": spec.ego_size,
                "node_size": spec.node_size,
                "edge_size": spec.edge_size,
                "max_nodes": spec.max_nodes,
                "hidden_size": self.model.hidden_size,
                "action_size": self.model.action_size,
                "layers": self.model.layers,
                "action_distribution": self.config.action_distribution,
                "action_min_log_std": self.config.action_min_log_std,
                "action_max_log_std": self.config.action_max_log_std,
                "action_initial_log_std": (
                    self.config.action_initial_log_std_longitudinal,
                    self.config.action_initial_log_std_steering,
                ),
                "model_state": state_np,
                "rollout_steps": self.config.rollout_steps,
                "reward_clip": self.config.reward_clip,
                "stop_action_exploration_probability": self.config.stop_action_exploration_probability,
                "stop_action_exploration_mean": self.config.stop_action_exploration_mean,
                "stop_action_exploration_std": self.config.stop_action_exploration_std,
                "seed": int(seed),
                "task_name": (
                    safety_tasks[index % len(safety_tasks)]
                    if index < safety_workers and len(safety_tasks) > 0
                    else None
                ),
            }
            for index, seed in enumerate(seeds)
        ]
        with ProcessPoolExecutor(max_workers=self.rollout_workers) as executor:
            return list(executor.map(_collect_graph_rollout_worker, payloads))

    @staticmethod
    def _normalize_array(values: np.ndarray) -> np.ndarray:
        return (values - values.mean()) / (values.std() + 1e-8)

    def _normalize_advantages_by_phase(
        self, advantages: np.ndarray, intent_labels: np.ndarray
    ) -> np.ndarray:
        normalized = np.empty_like(advantages, dtype=np.float32)
        fallback = self._normalize_array(advantages).astype(np.float32)
        normalized[:] = fallback
        for label in range(self.model.intent_size):
            mask = intent_labels == label
            if int(mask.sum()) >= 2:
                normalized[mask] = self._normalize_array(advantages[mask]).astype(np.float32)
        return normalized

    def _minibatch_indices(
        self, indices: np.ndarray, intent_labels: np.ndarray
    ) -> list[np.ndarray]:
        if not self.config.phase_balanced_minibatches:
            shuffled = indices.copy()
            self.rng.shuffle(shuffled)
            return [
                shuffled[start : start + self.config.minibatch_size]
                for start in range(0, len(shuffled), self.config.minibatch_size)
            ]

        groups: list[np.ndarray] = []
        for label in range(self.model.intent_size):
            group = indices[intent_labels[indices] == label]
            if len(group) > 0:
                group = group.copy()
                self.rng.shuffle(group)
                groups.append(group)
        unknown = indices[intent_labels[indices] < 0]
        if len(unknown) > 0:
            unknown = unknown.copy()
            self.rng.shuffle(unknown)
            groups.append(unknown)
        if not groups:
            shuffled = indices.copy()
            self.rng.shuffle(shuffled)
            return [
                shuffled[start : start + self.config.minibatch_size]
                for start in range(0, len(shuffled), self.config.minibatch_size)
            ]

        positions = [0 for _ in groups]
        batches: list[np.ndarray] = []
        total_remaining = sum(len(group) for group in groups)
        while total_remaining > 0:
            active = [i for i, group in enumerate(groups) if positions[i] < len(group)]
            quota = max(1, self.config.minibatch_size // max(len(active), 1))
            batch_parts: list[np.ndarray] = []
            for group_index in active:
                group = groups[group_index]
                start = positions[group_index]
                stop = min(len(group), start + quota)
                if stop > start:
                    batch_parts.append(group[start:stop])
                    taken = stop - start
                    positions[group_index] = stop
                    total_remaining -= taken
            while sum(len(part) for part in batch_parts) < self.config.minibatch_size:
                active = [i for i, group in enumerate(groups) if positions[i] < len(group)]
                if not active:
                    break
                for group_index in active:
                    if sum(len(part) for part in batch_parts) >= self.config.minibatch_size:
                        break
                    group = groups[group_index]
                    start = positions[group_index]
                    batch_parts.append(group[start : start + 1])
                    positions[group_index] = start + 1
                    total_remaining -= 1
            batch = np.concatenate(batch_parts, axis=0)
            self.rng.shuffle(batch)
            batches.append(batch)
        return batches

    def update(self, rollout: GraphRollout | list[GraphRollout], update_index: int = 1) -> dict[str, float]:
        rollouts = rollout if isinstance(rollout, list) else [rollout]
        ego_parts: list[np.ndarray] = []
        node_parts: list[np.ndarray] = []
        edge_parts: list[np.ndarray] = []
        node_mask_parts: list[np.ndarray] = []
        action_parts: list[np.ndarray] = []
        log_prob_parts: list[np.ndarray] = []
        advantage_parts: list[np.ndarray] = []
        return_parts: list[np.ndarray] = []
        reward_parts: list[np.ndarray] = []
        intent_parts: list[np.ndarray] = []
        route_parts: list[np.ndarray] = []
        info_metrics = self._empty_metrics()

        for item in rollouts:
            advantages, returns = item.advantages_and_returns(
                self.config.gamma, self.config.gae_lambda
            )
            active = item.masks.reshape(-1).astype(bool)
            if not np.any(active):
                continue
            ego_parts.append(item.ego.reshape(-1, item.ego.shape[-1])[active])
            node_parts.append(item.nodes.reshape(-1, item.nodes.shape[-2], item.nodes.shape[-1])[active])
            edge_parts.append(item.edges.reshape(-1, item.edges.shape[-2], item.edges.shape[-1])[active])
            node_mask_parts.append(item.node_mask.reshape(-1, item.node_mask.shape[-1])[active])
            action_parts.append(item.actions.reshape(-1, item.actions.shape[-1])[active])
            log_prob_parts.append(item.log_probs.reshape(-1)[active])
            advantage_parts.append(advantages.reshape(-1)[active])
            return_parts.append(returns.reshape(-1)[active])
            reward_parts.append(item.rewards.reshape(-1)[active])
            intent_parts.append(item.intent_labels.reshape(-1)[active])
            route_parts.append(item.component_route_labels.reshape(-1)[active])
            for key, value in item.info_metrics.items():
                info_metrics[key] = info_metrics.get(key, 0.0) + float(value)

        if not action_parts:
            metrics = self._empty_metrics()
            metrics["rollout_mean_reward"] = 0.0
            return metrics

        ego = np.concatenate(ego_parts, axis=0)
        nodes = np.concatenate(node_parts, axis=0)
        edges = np.concatenate(edge_parts, axis=0)
        node_mask = np.concatenate(node_mask_parts, axis=0)
        actions = np.concatenate(action_parts, axis=0)
        old_log_probs = np.concatenate(log_prob_parts, axis=0)
        advantages = np.concatenate(advantage_parts, axis=0)
        returns = np.concatenate(return_parts, axis=0)
        intent_labels = np.concatenate(intent_parts, axis=0).astype(np.int64)
        component_route_labels = np.concatenate(route_parts, axis=0).astype(np.int64)
        if self.config.phase_advantage_normalization:
            advantages = self._normalize_advantages_by_phase(advantages, intent_labels)
        else:
            advantages = self._normalize_array(advantages)

        ego_t = torch.as_tensor(ego, dtype=torch.float32, device=self.device)
        nodes_t = torch.as_tensor(nodes, dtype=torch.float32, device=self.device)
        edges_t = torch.as_tensor(edges, dtype=torch.float32, device=self.device)
        node_mask_t = torch.as_tensor(node_mask, dtype=torch.float32, device=self.device)
        act_t = torch.as_tensor(actions, dtype=torch.float32, device=self.device)
        old_log_t = torch.as_tensor(old_log_probs, dtype=torch.float32, device=self.device)
        adv_t = torch.as_tensor(advantages, dtype=torch.float32, device=self.device)
        ret_t = torch.as_tensor(returns, dtype=torch.float32, device=self.device)
        intent_t = torch.as_tensor(intent_labels, dtype=torch.long, device=self.device)
        route_t = torch.as_tensor(component_route_labels, dtype=torch.long, device=self.device)

        indices = np.arange(len(actions))
        intent_loss_weight = self._intent_loss_weight(update_index)
        intent_action_loss_weight = self._intent_action_loss_weight(update_index)
        mixture_gate_loss_weight = self._mixture_gate_loss_weight(update_index)
        metrics: dict[str, float] = {
            "intent_loss_weight": intent_loss_weight,
            "intent_detached": float(self.config.intent_detach_shared),
            "intent_action_loss_weight": intent_action_loss_weight,
            "intent_action_loss_red_only": float(self.config.intent_action_loss_red_only),
            "mixture_gate_loss_weight": mixture_gate_loss_weight,
            "mixture_gate_detached": float(self.config.mixture_gate_loss_detach_shared),
            "reference_kl_weight": float(self.config.reference_kl_coefficient),
            "go_component_reference_kl_weight": float(self.config.go_component_reference_kl_coefficient),
            "reference_kl_green_only": float(self.config.reference_kl_green_only),
            "phase_adv_norm": float(self.config.phase_advantage_normalization),
            "phase_balanced_mb": float(self.config.phase_balanced_minibatches),
            "safety_replay_workers": float(self.config.safety_replay_workers),
        }
        for label, name in enumerate(("stop", "hold", "go", "yield")):
            metrics[f"phase_samples_{name}"] = float(np.sum(intent_labels == label))
        std_label_sums = {name: 0.0 for name in ("stop", "hold", "go")}
        std_label_counts = {name: 0.0 for name in ("stop", "hold", "go")}
        action_label_sums = {name: 0.0 for name in ("stop", "hold", "go")}
        action_label_counts = {name: 0.0 for name in ("stop", "hold", "go")}
        action_label_brake_counts = {name: 0.0 for name in ("stop", "hold", "go")}
        mixture_weight_sums = {name: 0.0 for name in ("stop", "hold", "go")}
        mixture_weight_counts = {name: 0.0 for name in ("stop", "hold", "go")}
        mixture_argmax_counts = {name: 0.0 for name in ("stop", "hold", "go")}
        mixture_ambiguous_counts = {name: 0.0 for name in ("stop", "hold", "go")}
        route_weight_sums = [0.0] * self.model.MIXTURE_COMPONENTS
        route_counts = [0.0] * self.model.MIXTURE_COMPONENTS
        route_argmax_counts = [0.0] * self.model.MIXTURE_COMPONENTS
        route_ambiguous_counts = [0.0] * self.model.MIXTURE_COMPONENTS
        green_opening_gap_weight_sum = 0.0
        green_opening_gap_count = 0.0
        green_opening_gap_argmax_count = 0.0
        green_opening_gap_ambiguous_count = 0.0
        gradient_diagnostics: dict[str, float] = {}
        update_count = 0
        stop_update = False
        for _ in range(self.config.update_epochs):
            batches = self._minibatch_indices(indices, intent_labels)
            for batch_np in batches:
                batch = torch.as_tensor(batch_np, dtype=torch.long, device=self.device)
                dist, _, values, intent_logits = self.model.distribution(
                    ego_t[batch],
                    nodes_t[batch],
                    edges_t[batch],
                    node_mask_t[batch],
                    detach_intent_features=self.config.intent_detach_shared,
                )
                batch_intents = intent_t[batch]
                longitudinal_std = dist.stddev[:, 0].detach()
                longitudinal_mean = dist.mean[:, 0].detach()
                mixture_weights = getattr(dist, "mixture_weights", None)
                if mixture_weights is not None:
                    detached_weights = mixture_weights.detach()
                    brake_weights = detached_weights[:, 0]
                    go_weights = detached_weights[:, self.model.GO_COMPONENT]
                    gate_argmax = torch.argmax(detached_weights, dim=-1)
                    ambiguous_gate = _mixture_gate_ambiguity(detached_weights)
                    batch_routes = route_t[batch]
                    for component in range(self.model.MIXTURE_COMPONENTS):
                        route_mask = batch_routes == component
                        if not route_mask.any():
                            continue
                        count = float(route_mask.float().sum().item())
                        target_weight = detached_weights[:, component][route_mask]
                        route_counts[component] += count
                        route_weight_sums[component] += float(target_weight.sum().item())
                        route_argmax_counts[component] += float(
                            (gate_argmax[route_mask] == component).float().sum().item()
                        )
                        route_ambiguous_counts[component] += float(
                            ambiguous_gate[route_mask].float().sum().item()
                        )
                else:
                    brake_weights = go_weights = gate_argmax = ambiguous_gate = None
                for label, name in ((0, "stop"), (1, "hold"), (2, "go")):
                    std_mask = batch_intents == label
                    if label == 2:
                        std_mask = std_mask & (ego_t[batch, 14] > 0.5)
                    if std_mask.any():
                        count = float(std_mask.float().sum().item())
                        std_label_sums[name] += float(longitudinal_std[std_mask].sum().item())
                        std_label_counts[name] += count
                        action_label_sums[name] += float(longitudinal_mean[std_mask].sum().item())
                        action_label_counts[name] += count
                        action_label_brake_counts[name] += float((longitudinal_mean[std_mask] < -0.05).float().sum().item())
                        if brake_weights is not None and go_weights is not None and gate_argmax is not None and ambiguous_gate is not None:
                            routed_weight = brake_weights if label in (0, 1) else go_weights
                            routed_component = self.model.BRAKE_COMPONENT if label in (0, 1) else self.model.GO_COMPONENT
                            mixture_weight_sums[name] += float(routed_weight[std_mask].sum().item())
                            mixture_weight_counts[name] += count
                            mixture_argmax_counts[name] += float((gate_argmax[std_mask] == routed_component).float().sum().item())
                            mixture_ambiguous_counts[name] += float(ambiguous_gate[std_mask].float().sum().item())
                if go_weights is not None and gate_argmax is not None and ambiguous_gate is not None:
                    ego_batch_for_gate = ego_t[batch]
                    min_gap_norm = self.env.config.minimum_front_gap / max(self.env.config.road_length, 1e-3)
                    green_opening_gap = (
                        (batch_intents == 2)
                        & (ego_batch_for_gate[:, 14] > 0.5)
                        & (ego_batch_for_gate[:, 2] > 0.0)
                        & (ego_batch_for_gate[:, 22] > min_gap_norm)
                        & (ego_batch_for_gate[:, 22] < 0.95)
                        & (ego_batch_for_gate[:, 23] < 0.05)
                    )
                    if green_opening_gap.any():
                        count = float(green_opening_gap.float().sum().item())
                        green_opening_gap_weight_sum += float(go_weights[green_opening_gap].sum().item())
                        green_opening_gap_count += count
                        green_opening_gap_argmax_count += float((gate_argmax[green_opening_gap] == self.model.GO_COMPONENT).float().sum().item())
                        green_opening_gap_ambiguous_count += float(ambiguous_gate[green_opening_gap].float().sum().item())
                log_probs = dist.log_prob(act_t[batch]).sum(dim=-1)
                entropy = dist.entropy().sum(dim=-1).mean()
                ratio = torch.exp(log_probs - old_log_t[batch])
                unclipped = ratio * adv_t[batch]
                clipped = torch.clamp(
                    ratio,
                    1.0 - self.config.clip_ratio,
                    1.0 + self.config.clip_ratio,
                ) * adv_t[batch]
                policy_loss = -torch.min(unclipped, clipped).mean()
                value_error = values - ret_t[batch]
                value_loss_mse = 0.5 * torch.mean(value_error ** 2)
                if self.config.value_loss_huber_beta > 0.0:
                    value_loss = F.smooth_l1_loss(
                        values,
                        ret_t[batch],
                        beta=float(self.config.value_loss_huber_beta),
                        reduction="mean",
                    )
                else:
                    value_loss = value_loss_mse
                value_error_abs_mean = torch.mean(torch.abs(value_error.detach()))
                value_error_abs_max = torch.max(torch.abs(value_error.detach()))
                return_variance = torch.var(ret_t[batch], unbiased=False)
                explained_variance = torch.where(
                    return_variance > 1.0e-8,
                    1.0 - torch.var(ret_t[batch] - values.detach(), unbiased=False) / return_variance,
                    torch.zeros_like(return_variance),
                )
                reference_kl_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                reference_kl_all_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                reference_kl_samples = torch.zeros((), dtype=torch.float32, device=self.device)
                if self.reference_model is not None and self.config.reference_kl_coefficient > 0.0:
                    with torch.no_grad():
                        reference_dist, _, _, _ = self.reference_model.distribution(
                            ego_t[batch],
                            nodes_t[batch],
                            edges_t[batch],
                            node_mask_t[batch],
                        )
                    sample_kl = _policy_kl(dist, reference_dist).sum(dim=-1)
                    if self.config.reference_kl_green_only:
                        ego_for_kl = ego_t[batch]
                        green_context = (ego_for_kl[:, 11] > 0.5) & (ego_for_kl[:, 14] > 0.5)
                        critical = (intent_t[batch] == 2) & green_context
                        all_labeled = critical
                    elif self.config.reference_kl_stop_hold_only:
                        critical = (intent_t[batch] == 0) | (intent_t[batch] == 1)
                        all_labeled = intent_t[batch] >= 0
                    else:
                        critical = intent_t[batch] >= 0
                        all_labeled = critical
                    if all_labeled.any():
                        reference_kl_all_loss = sample_kl[all_labeled].mean()
                    if critical.any():
                        reference_kl_loss = sample_kl[critical].mean()
                        reference_kl_samples = critical.float().sum()
                go_component_reference_kl_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                go_component_reference_kl_samples = torch.zeros((), dtype=torch.float32, device=self.device)
                if (
                    self.reference_model is not None
                    and self.config.go_component_reference_kl_coefficient > 0.0
                    and self.model.action_distribution == "squashed_mixture"
                ):
                    with torch.no_grad():
                        go_reference_dist, _, _, _ = self.reference_model.distribution(
                            ego_t[batch],
                            nodes_t[batch],
                            edges_t[batch],
                            node_mask_t[batch],
                        )
                    go_component_kl = _go_component_kl(dist, go_reference_dist)
                    ego_for_go_kl = ego_t[batch]
                    green_permitted = (ego_for_go_kl[:, 11] > 0.5) & (ego_for_go_kl[:, 14] > 0.5)
                    go_labeled = (intent_t[batch] == 2) & green_permitted
                    if go_labeled.any():
                        go_component_reference_kl_loss = go_component_kl[go_labeled].mean()
                        go_component_reference_kl_samples = go_labeled.float().sum()

                valid_intent = intent_t[batch] >= 0
                if valid_intent.any():
                    valid_labels = intent_t[batch][valid_intent]
                    class_counts = torch.bincount(valid_labels, minlength=self.model.intent_size).float()
                    class_weights = valid_labels.numel() / (self.model.intent_size * class_counts.clamp_min(1.0))
                    class_floor = torch.tensor([0.60, 1.0, 1.2, 1.2], dtype=torch.float32, device=self.device)
                    class_ceiling = torch.tensor([1.3, 2.5, 2.5, 2.5], dtype=torch.float32, device=self.device)
                    class_weights = torch.minimum(torch.maximum(class_weights.to(self.device), class_floor), class_ceiling)
                    intent_loss = F.cross_entropy(
                        intent_logits[valid_intent],
                        valid_labels,
                        weight=class_weights,
                    )
                    intent_pred = torch.argmax(intent_logits[valid_intent], dim=-1)
                    intent_accuracy = (intent_pred == valid_labels).float().mean()
                else:
                    intent_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                    intent_accuracy = torch.zeros((), dtype=torch.float32, device=self.device)
                mixture_gate_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                mixture_gate_loss_samples = torch.zeros((), dtype=torch.float32, device=self.device)
                mixture_gate_accuracy = torch.zeros((), dtype=torch.float32, device=self.device)
                if (
                    mixture_gate_loss_weight > 0.0
                    and self.model.action_distribution == "squashed_mixture"
                ):
                    gate_valid = route_t[batch] >= 0
                    if gate_valid.any():
                        gate_logits = self.model.mixture_gate_logits(
                            ego_t[batch],
                            nodes_t[batch],
                            edges_t[batch],
                            node_mask_t[batch],
                            detach_features=self.config.mixture_gate_loss_detach_shared,
                        )
                        gate_targets = route_t[batch]
                        valid_targets = gate_targets[gate_valid]
                        class_counts = torch.bincount(valid_targets, minlength=self.model.MIXTURE_COMPONENTS).float()
                        class_weights = valid_targets.numel() / (self.model.MIXTURE_COMPONENTS * class_counts.clamp_min(1.0))
                        class_weights = torch.clamp(class_weights.to(self.device), 0.5, 2.0)
                        mixture_gate_loss = F.cross_entropy(
                            gate_logits[gate_valid],
                            valid_targets,
                            weight=class_weights,
                        )
                        gate_pred = torch.argmax(gate_logits[gate_valid], dim=-1)
                        mixture_gate_accuracy = (gate_pred == valid_targets).float().mean()
                        mixture_gate_loss_samples = gate_valid.float().sum()

                intent_action_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                intent_action_loss_samples = torch.zeros((), dtype=torch.float32, device=self.device)
                creep_action_loss = torch.zeros((), dtype=torch.float32, device=self.device)
                creep_action_samples = torch.zeros((), dtype=torch.float32, device=self.device)
                creep_routed_component_mean = torch.zeros((), dtype=torch.float32, device=self.device)
                creep_action_target_mean = torch.zeros((), dtype=torch.float32, device=self.device)
                regular_brake_samples = torch.zeros((), dtype=torch.float32, device=self.device)
                regular_brake_component_mean = torch.zeros((), dtype=torch.float32, device=self.device)
                regular_brake_action_target_mean = torch.zeros((), dtype=torch.float32, device=self.device)
                action_valid = intent_t[batch] >= 0
                if intent_action_loss_weight > 0.0 and action_valid.any():
                    action_mean = dist.mean[:, 0]
                    labels = intent_t[batch]
                    ego_batch = ego_t[batch]
                    speed = torch.clamp(
                        ego_batch[:, 0] * self.config.physics_action_target_max_speed,
                        min=0.0,
                    )
                    distance_to_stop = ego_batch[:, 2] * self.config.physics_action_target_road_length
                    green = ego_batch[:, 11] > 0.5
                    closed = ego_batch[:, 13] > 0.5
                    movement_permitted = ego_batch[:, 14] > 0.5
                    front_gap = ego_batch[:, 22] * self.config.physics_action_target_road_length
                    front_too_close = ego_batch[:, 25] > 0.5
                    before_stop_line = distance_to_stop > 0.0
                    front_clear = ~front_too_close

                    time_constant = max(float(self.config.physics_action_target_time_constant), 1e-3)
                    max_accel = max(float(self.config.physics_action_target_max_acceleration), 1e-3)
                    comfortable_braking = max(float(self.config.physics_action_target_comfortable_braking), 1e-3)
                    stop_margin = max(float(self.config.physics_action_target_stop_margin), 0.0)
                    brake_safety = max(float(self.config.physics_action_target_brake_safety_factor), 1.0)
                    green_speed = max(float(self.config.physics_action_target_green_speed), 0.0)
                    red_crawl_speed = max(float(self.config.physics_action_target_red_crawl_speed), 0.0)
                    red_approach_gain = max(float(self.config.physics_action_target_red_approach_gain), 0.0)
                    red_min_brake = max(float(self.config.physics_action_target_red_min_brake_accel), 0.0)
                    queue_gap_min = max(float(self.config.physics_action_target_queue_gap_min), 0.0)
                    queue_gap_max = max(float(self.config.physics_action_target_queue_gap_max), queue_gap_min)
                    queue_gap_target = 0.5 * (queue_gap_min + queue_gap_max)
                    queue_lead_margin = max(float(self.config.physics_action_target_queue_lead_margin), 0.0)

                    if self.config.physics_action_target_queue_following_enabled:
                        queue_following = front_gap < 0.95 * self.config.physics_action_target_road_length
                    else:
                        queue_following = torch.zeros_like(speed, dtype=torch.bool)
                    queue_stop_distance = torch.where(
                        queue_following,
                        front_gap,
                        distance_to_stop,
                    )
                    queue_target_margin = torch.where(
                        queue_following,
                        torch.full_like(speed, queue_gap_target),
                        torch.full_like(speed, queue_lead_margin if self.config.physics_action_target_queue_following_enabled else stop_margin),
                    )

                    target_stop_distance = queue_target_margin
                    available_distance = torch.clamp(queue_stop_distance - target_stop_distance, min=0.0)
                    decel_distance = torch.clamp(available_distance, min=0.25)
                    required_decel = brake_safety * speed.square() / (2.0 * decel_distance)
                    safe_stop_speed = torch.sqrt(
                        torch.clamp(
                            2.0 * comfortable_braking * available_distance / brake_safety,
                            min=0.0,
                        )
                    )
                    profile_speed = red_approach_gain * available_distance
                    red_desired_speed = torch.minimum(
                        torch.full_like(speed, red_crawl_speed),
                        safe_stop_speed,
                    )
                    red_desired_speed = torch.minimum(red_desired_speed, profile_speed)
                    red_desired_speed = torch.where(
                        queue_stop_distance <= target_stop_distance + 1.0,
                        torch.zeros_like(red_desired_speed),
                        red_desired_speed,
                    )
                    red_target_accel = torch.clamp(
                        (red_desired_speed - speed) / time_constant,
                        min=-comfortable_braking,
                        max=max_accel,
                    )
                    too_fast_for_stop = speed > safe_stop_speed + 0.1
                    red_target_accel = torch.where(
                        too_fast_for_stop,
                        -torch.clamp(required_decel, min=0.0, max=comfortable_braking),
                        red_target_accel,
                    )
                    if red_min_brake > 0.0:
                        profile_brake_needed = (
                            closed
                            & before_stop_line
                            & (queue_stop_distance < 45.0)
                            & (speed > red_desired_speed + 0.05)
                        )
                        min_brake_accel = torch.full_like(red_target_accel, -red_min_brake)
                        red_target_accel = torch.where(
                            profile_brake_needed,
                            torch.minimum(red_target_accel, min_brake_accel),
                            red_target_accel,
                        )
                    green_target_accel = torch.clamp(
                        (torch.full_like(speed, green_speed) - speed) / time_constant,
                        min=-comfortable_braking,
                        max=max_accel,
                    )
                    hold_target_accel = torch.clamp(-0.6 * speed / time_constant, min=-comfortable_braking, max=0.0)
                    yield_target_accel = torch.clamp(-1.0 * speed / time_constant, min=-comfortable_braking, max=0.0)

                    target_accel = torch.zeros_like(action_mean)
                    target_accel = torch.where(labels == 0, red_target_accel, target_accel)
                    target_accel = torch.where(labels == 1, hold_target_accel, target_accel)
                    target_accel = torch.where(labels == 2, green_target_accel, target_accel)
                    target_accel = torch.where(labels == 3, yield_target_accel, target_accel)

                    legal_green_clear = movement_permitted & green & front_clear
                    green_blocked = movement_permitted & green & front_too_close & before_stop_line
                    red_before_stop = closed & before_stop_line
                    if self.config.intent_action_loss_red_only:
                        action_valid = action_valid & red_before_stop
                    intent_action_loss_samples = action_valid.float().sum()
                    target_accel = torch.where(legal_green_clear, green_target_accel, target_accel)
                    target_accel = torch.where(green_blocked, hold_target_accel, target_accel)
                    target_accel = torch.where(red_before_stop, red_target_accel, target_accel)

                    action_target = torch.where(
                        target_accel >= 0.0,
                        target_accel / max_accel,
                        target_accel / comfortable_braking,
                    )
                    action_target = torch.clamp(action_target, -1.0, 1.0)

                    action_weight = torch.ones_like(action_mean)
                    action_weight = torch.where(labels == 0, torch.full_like(action_weight, 4.0), action_weight)
                    action_weight = torch.where(labels == 2, torch.full_like(action_weight, 1.5), action_weight)
                    action_weight = torch.where(labels == 1, torch.full_like(action_weight, 1.8), action_weight)
                    action_weight = torch.where(labels == 3, torch.full_like(action_weight, 2.0), action_weight)
                    action_weight = torch.where(legal_green_clear, torch.full_like(action_weight, 2.0), action_weight)
                    action_weight = torch.where(green_blocked, torch.full_like(action_weight, 2.5), action_weight)
                    action_weight = torch.where(red_before_stop, torch.full_like(action_weight, 10.0), action_weight)

                    if action_valid.any():
                        supervised_action_mean = action_mean
                        component_means = getattr(dist, "component_means", None)
                        if component_means is not None:
                            route_indices = route_t[batch].clamp(
                                min=0, max=component_means.shape[1] - 1
                            ).unsqueeze(-1)
                            routed_component_mean = torch.gather(
                                component_means, dim=-1, index=route_indices
                            ).squeeze(-1)
                            supervised_action_mean = torch.where(
                                red_before_stop,
                                routed_component_mean,
                                supervised_action_mean,
                            )
                        action_error = (
                            supervised_action_mean - action_target
                        ) ** 2
                        intent_action_loss = (
                            action_error[action_valid]
                            * action_weight[action_valid]
                        ).mean()
                        creep_valid = (
                            action_valid
                            & red_before_stop
                            & (route_t[batch] == self.model.CREEP_COMPONENT)
                        )
                        if creep_valid.any():
                            creep_action_samples = creep_valid.float().sum()
                            creep_routed_component_mean = supervised_action_mean[creep_valid].mean()
                            creep_action_target_mean = action_target[creep_valid].mean()
                            creep_action_loss = action_error[creep_valid].mean()
                        regular_brake_valid = (
                            action_valid
                            & red_before_stop
                            & (route_t[batch] == self.model.BRAKE_COMPONENT)
                            & (red_target_accel < -0.1)
                        )
                        if regular_brake_valid.any():
                            regular_brake_samples = regular_brake_valid.float().sum()
                            regular_brake_component_mean = supervised_action_mean[regular_brake_valid].mean()
                            regular_brake_action_target_mean = action_target[regular_brake_valid].mean()
                gate_loss_in_main = 0.0 if self.gate_optimizer is not None else mixture_gate_loss_weight
                loss = (
                    policy_loss
                    + self.config.value_coefficient * value_loss
                    + intent_loss_weight * intent_loss
                    + intent_action_loss_weight * intent_action_loss
                    + gate_loss_in_main * mixture_gate_loss
                    + self.config.reference_kl_coefficient * reference_kl_loss
                    + self.config.reference_kl_all_coefficient * reference_kl_all_loss
                    + self.config.go_component_reference_kl_coefficient * go_component_reference_kl_loss
                    - self.config.entropy_coefficient * entropy
                )
                if not gradient_diagnostics:
                    all_params = list(self.model.parameters())
                    gradient_diagnostics["grad_norm_policy"] = self._autograd_norm(policy_loss, all_params, retain_graph=True)
                    gradient_diagnostics["grad_norm_value"] = self._autograd_norm(
                        self.config.value_coefficient * value_loss, all_params, retain_graph=True
                    )
                    gradient_diagnostics["grad_norm_value_mse"] = self._autograd_norm(
                        self.config.value_coefficient * value_loss_mse, all_params, retain_graph=True
                    )
                    if mixture_gate_loss_weight > 0.0 and self._mixture_gate_params:
                        gradient_diagnostics["grad_norm_gate_ce"] = self._autograd_norm(
                            mixture_gate_loss_weight * mixture_gate_loss,
                            self._mixture_gate_params,
                            retain_graph=True,
                        )
                    else:
                        gradient_diagnostics["grad_norm_gate_ce"] = 0.0
                    if creep_action_samples.item() > 0.0:
                        gradient_diagnostics["grad_norm_creep_action"] = self._autograd_norm(
                            intent_action_loss_weight * creep_action_loss,
                            all_params,
                            retain_graph=True,
                        )
                    else:
                        gradient_diagnostics["grad_norm_creep_action"] = 0.0
                    gradient_diagnostics["value_error_abs_mean"] = float(value_error_abs_mean.item())
                    gradient_diagnostics["value_error_abs_max"] = float(value_error_abs_max.item())
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                if self._mixture_gate_ppo_frozen():
                    self._clear_mixture_gate_gradients()
                main_grad_norm = self._gradient_norm(self.model.parameters())
                main_clip_scale = min(1.0, self.config.max_grad_norm / max(main_grad_norm, 1.0e-12))
                gradient_diagnostics["effective_grad_creep_action"] = (
                    gradient_diagnostics.get("grad_norm_creep_action", 0.0)
                    * main_clip_scale
                )
                nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
                self.optimizer.step()
                gate_step_loss = mixture_gate_loss
                gate_step_samples = mixture_gate_loss_samples
                gate_grad_norm = torch.zeros((), dtype=torch.float32, device=self.device)
                gate_clip_scale = 0.0
                if (
                    self.gate_optimizer is not None
                    and mixture_gate_loss_weight > 0.0
                    and self.model.action_distribution == "squashed_mixture"
                ):
                    self.optimizer.zero_grad(set_to_none=True)
                    self.gate_optimizer.zero_grad(set_to_none=True)
                    gate_valid_step = route_t[batch] >= 0
                    if gate_valid_step.any():
                        gate_logits_step = self.model.mixture_gate_logits(
                            ego_t[batch],
                            nodes_t[batch],
                            edges_t[batch],
                            node_mask_t[batch],
                            detach_features=True,
                        )
                        gate_targets_step = route_t[batch]
                        valid_targets_step = gate_targets_step[gate_valid_step]
                        class_counts_step = torch.bincount(valid_targets_step, minlength=self.model.MIXTURE_COMPONENTS).float()
                        class_weights_step = valid_targets_step.numel() / (self.model.MIXTURE_COMPONENTS * class_counts_step.clamp_min(1.0))
                        class_weights_step = torch.clamp(class_weights_step.to(self.device), 0.5, 2.0)
                        gate_step_loss = F.cross_entropy(
                            gate_logits_step[gate_valid_step],
                            valid_targets_step,
                            weight=class_weights_step,
                        )
                        (mixture_gate_loss_weight * gate_step_loss).backward()
                        gate_pre_clip_norm = self._gradient_norm(self._mixture_gate_params)
                        gate_clip_scale = min(
                            1.0,
                            self.config.mixture_gate_max_grad_norm / max(gate_pre_clip_norm, 1.0e-12),
                        )
                        nn.utils.clip_grad_norm_(self._mixture_gate_params, self.config.mixture_gate_max_grad_norm)
                        self.gate_optimizer.step()
                        gate_grad_norm = torch.tensor(gate_pre_clip_norm, dtype=torch.float32, device=self.device)
                        gate_step_samples = gate_valid_step.float().sum()
                    self.gate_optimizer.zero_grad(set_to_none=True)
                self.optimizer.zero_grad(set_to_none=True)
                with torch.no_grad():
                    self.model.log_std.clamp_(self.model.action_min_log_std, self.model.action_max_log_std)
                approximate_kl = torch.mean(old_log_t[batch] - log_probs).item()
                for key, value in {
                    "policy_loss": float(policy_loss.item()),
                    "value_loss": float(value_loss.item()),
                    "value_loss_mse": float(value_loss_mse.item()),
                    "value_error_abs_mean": float(value_error_abs_mean.item()),
                    "value_error_abs_max": float(value_error_abs_max.item()),
                    "explained_variance": float(explained_variance.item()),
                    "entropy": float(entropy.item()),
                    "intent_loss": float(intent_loss.item()),
                    "intent_accuracy": float(intent_accuracy.item()),
                    "intent_action_loss": float(intent_action_loss.item()),
                    "intent_action_loss_samples": float(intent_action_loss_samples.item()),
                    "creep_action_loss": float(creep_action_loss.item()),
                    "creep_action_samples": float(creep_action_samples.item()),
                    "creep_routed_component_mean": float(creep_routed_component_mean.item()),
                    "creep_action_target_mean": float(creep_action_target_mean.item()),
                    "regular_brake_samples": float(regular_brake_samples.item()),
                    "regular_brake_component_mean": float(regular_brake_component_mean.item()),
                    "regular_brake_action_target_mean": float(regular_brake_action_target_mean.item()),
                    "mixture_gate_loss": float(gate_step_loss.item()),
                    "mixture_gate_loss_samples": float(gate_step_samples.item()),
                    "mixture_gate_accuracy": float(mixture_gate_accuracy.item()),
                    "main_grad_norm": float(main_grad_norm),
                    "main_grad_clip_scale": float(main_clip_scale),
                    "gate_grad_norm": float(gate_grad_norm.item()),
                    "gate_grad_clip_scale": float(gate_clip_scale),
                    "reference_kl": float(reference_kl_loss.item()),
                    "reference_kl_all": float(reference_kl_all_loss.item()),
                    "reference_kl_samples": float(reference_kl_samples.item()),
                    "go_component_reference_kl": float(go_component_reference_kl_loss.item()),
                    "go_component_reference_kl_samples": float(go_component_reference_kl_samples.item()),
                    "approximate_kl": float(approximate_kl),
                }.items():
                    metrics[key] = metrics.get(key, 0.0) + value
                update_count += 1
                if self.config.target_kl > 0.0 and approximate_kl > self.config.target_kl:
                    stop_update = True
                    break
            if stop_update:
                break
        averaged = {
            key: value / max(update_count, 1)
            for key, value in metrics.items()
            if key not in (
                "intent_loss_weight",
                "intent_detached",
                "intent_action_loss_weight",
                "intent_action_loss_red_only",
                "mixture_gate_loss_weight",
                "mixture_gate_detached",
                "reference_kl_weight",
                "go_component_reference_kl_weight",
                "reference_kl_green_only",
                "phase_adv_norm",
                "phase_balanced_mb",
                "safety_replay_workers",
                "phase_samples_stop",
                "phase_samples_hold",
                "phase_samples_go",
                "phase_samples_yield",
            )
        }
        metrics = {
            "intent_loss_weight": intent_loss_weight,
            "intent_detached": float(self.config.intent_detach_shared),
            "intent_action_loss_weight": intent_action_loss_weight,
            "intent_action_loss_red_only": float(self.config.intent_action_loss_red_only),
            "mixture_gate_loss_weight": mixture_gate_loss_weight,
            "mixture_gate_detached": float(self.config.mixture_gate_loss_detach_shared),
            "reference_kl_weight": float(self.config.reference_kl_coefficient),
            "go_component_reference_kl_weight": float(self.config.go_component_reference_kl_coefficient),
            "reference_kl_green_only": float(self.config.reference_kl_green_only),
            "phase_adv_norm": float(self.config.phase_advantage_normalization),
            "phase_balanced_mb": float(self.config.phase_balanced_minibatches),
            "safety_replay_workers": float(self.config.safety_replay_workers),
            "phase_samples_stop": float(np.sum(intent_labels == 0)),
            "phase_samples_hold": float(np.sum(intent_labels == 1)),
            "phase_samples_go": float(np.sum(intent_labels == 2)),
            "phase_samples_yield": float(np.sum(intent_labels == 3)),
            **averaged,
            **gradient_diagnostics,
        }
        for name in ("stop", "hold", "go"):
            metrics[f"std_{name}_label_mean"] = std_label_sums[name] / max(std_label_counts[name], 1.0)
            metrics[f"action_{name}_label_mean"] = action_label_sums[name] / max(action_label_counts[name], 1.0)
            metrics[f"action_{name}_label_brake_share"] = action_label_brake_counts[name] / max(action_label_counts[name], 1.0)
            routed_weight = mixture_weight_sums[name] / max(mixture_weight_counts[name], 1.0)
            routed_argmax = mixture_argmax_counts[name] / max(mixture_weight_counts[name], 1.0)
            ambiguous_share = mixture_ambiguous_counts[name] / max(mixture_weight_counts[name], 1.0)
            metrics[f"mixture_routed_weight_{name}_label_mean"] = routed_weight
            metrics[f"mixture_routed_argmax_{name}_label_share"] = routed_argmax
            metrics[f"mixture_ambiguous_{name}_label_share"] = ambiguous_share
            component_name = "go" if name == "go" else "brake"
            metrics[f"mixture_{component_name}_weight_{name}_label_mean"] = routed_weight
            metrics[f"mixture_{component_name}_argmax_{name}_label_share"] = routed_argmax
        metrics["mixture_go_weight_green_opening_gap_mean"] = green_opening_gap_weight_sum / max(green_opening_gap_count, 1.0)
        metrics["mixture_go_argmax_green_opening_gap_share"] = green_opening_gap_argmax_count / max(green_opening_gap_count, 1.0)
        metrics["mixture_ambiguous_green_opening_gap_share"] = green_opening_gap_ambiguous_count / max(green_opening_gap_count, 1.0)
        metrics["mixture_green_opening_gap_samples"] = green_opening_gap_count
        for component, name in enumerate(("brake", "creep", "go")):
            count = route_counts[component]
            metrics[f"mixture_route_{name}_samples"] = count
            metrics[f"mixture_route_{name}_weight"] = route_weight_sums[component] / max(count, 1.0)
            metrics[f"mixture_route_{name}_argmax"] = route_argmax_counts[component] / max(count, 1.0)
            metrics[f"mixture_route_{name}_ambiguous"] = route_ambiguous_counts[component] / max(count, 1.0)
        self._update_mixture_gate_freeze_state(metrics, update_index)
        active_rewards = np.concatenate(reward_parts, axis=0)
        metrics["rollout_mean_reward"] = float(active_rewards.mean())
        metrics.update(info_metrics)
        return metrics

    def _sample_gate_prewarm_indices(self, labels: np.ndarray, batch_size: int) -> np.ndarray:
        classes = tuple(range(self.model.MIXTURE_COMPONENTS))
        pools = {label: np.flatnonzero(labels == label) for label in classes}
        available = [label for label in classes if len(pools[label]) > 0]
        if not available:
            return np.empty(0, dtype=np.int64)
        batch_size = max(1, int(batch_size))
        base, remainder = divmod(batch_size, len(available))
        parts: list[np.ndarray] = []
        for offset, label in enumerate(available):
            count = base + int(offset < remainder)
            if count <= 0:
                continue
            pool = pools[label]
            parts.append(self.rng.choice(pool, size=count, replace=len(pool) < count))
        batch = np.concatenate(parts, axis=0)
        self.rng.shuffle(batch)
        return batch

    def _evaluate_mixture_gate_tensors(
        self,
        ego_t: torch.Tensor,
        nodes_t: torch.Tensor,
        edges_t: torch.Tensor,
        node_mask_t: torch.Tensor,
        labels_t: torch.Tensor,
    ) -> dict[str, float]:
        names = ("stop", "creep", "go")
        metrics = {"mixture_gate_prewarm_samples": float(labels_t.shape[0])}
        for name in names:
            metrics[f"mixture_gate_prewarm_{name}_count"] = 0.0
            metrics[f"mixture_gate_prewarm_{name}_weight"] = 0.0
            metrics[f"mixture_gate_prewarm_{name}_argmax"] = 0.0
            metrics[f"mixture_gate_prewarm_{name}_ambiguous"] = 1.0
        metrics.update(
            {
                "mixture_creep_prewarm_action_loss": 0.0,
                "mixture_creep_prewarm_action_mean": 0.0,
                "mixture_creep_prewarm_action_target": 0.0,
            }
        )
        if len(labels_t) == 0:
            return metrics

        counts = [0.0] * self.model.MIXTURE_COMPONENTS
        weight_sums = [0.0] * self.model.MIXTURE_COMPONENTS
        argmax_sums = [0.0] * self.model.MIXTURE_COMPONENTS
        ambiguous_sums = [0.0] * self.model.MIXTURE_COMPONENTS
        creep_loss_sum = creep_mean_sum = creep_target_sum = 0.0
        chunk_size = 4096
        with torch.no_grad():
            for start in range(0, int(labels_t.shape[0]), chunk_size):
                stop = min(int(labels_t.shape[0]), start + chunk_size)
                ego = ego_t[start:stop]
                nodes = nodes_t[start:stop]
                edges = edges_t[start:stop]
                node_mask = node_mask_t[start:stop]
                labels = labels_t[start:stop]
                logits = self.model.mixture_gate_logits(
                    ego, nodes, edges, node_mask, detach_features=True
                )
                weights = torch.softmax(logits, dim=-1)
                argmax = torch.argmax(weights, dim=-1)
                ambiguous = _mixture_gate_ambiguity(weights)
                for label in range(self.model.MIXTURE_COMPONENTS):
                    mask = labels == label
                    if not mask.any():
                        continue
                    count = float(mask.float().sum().item())
                    target_weight = weights[:, label][mask]
                    counts[label] += count
                    weight_sums[label] += float(target_weight.sum().item())
                    argmax_sums[label] += float((argmax[mask] == label).float().sum().item())
                    ambiguous_sums[label] += float(ambiguous[mask].float().sum().item())
                creep_mask = labels == self.model.CREEP_COMPONENT
                if creep_mask.any():
                    creep_mean = self.model.creep_component_mean(
                        ego, nodes, edges, node_mask, detach_features=True
                    )
                    creep_target = self._creep_action_targets_from_ego(ego)
                    error = (creep_mean - creep_target).square()
                    creep_loss_sum += float(error[creep_mask].sum().item())
                    creep_mean_sum += float(creep_mean[creep_mask].sum().item())
                    creep_target_sum += float(creep_target[creep_mask].sum().item())
        for label, name in enumerate(names):
            count = counts[label]
            metrics[f"mixture_gate_prewarm_{name}_count"] = count
            metrics[f"mixture_gate_prewarm_{name}_weight"] = weight_sums[label] / max(count, 1.0)
            metrics[f"mixture_gate_prewarm_{name}_argmax"] = argmax_sums[label] / max(count, 1.0)
            metrics[f"mixture_gate_prewarm_{name}_ambiguous"] = ambiguous_sums[label] / max(count, 1.0)
        creep_count = counts[self.model.CREEP_COMPONENT]
        metrics["mixture_creep_prewarm_action_loss"] = creep_loss_sum / max(creep_count, 1.0)
        metrics["mixture_creep_prewarm_action_mean"] = creep_mean_sum / max(creep_count, 1.0)
        metrics["mixture_creep_prewarm_action_target"] = creep_target_sum / max(creep_count, 1.0)
        return metrics

    def _prewarm_mixture_gate_on_rollouts(self, rollouts: list[GraphRollout]) -> dict[str, float]:
        ego_parts: list[np.ndarray] = []
        node_parts: list[np.ndarray] = []
        edge_parts: list[np.ndarray] = []
        node_mask_parts: list[np.ndarray] = []
        label_parts: list[np.ndarray] = []
        for item in rollouts:
            active = item.masks.reshape(-1).astype(bool)
            if not np.any(active):
                continue
            labels = item.component_route_labels.reshape(-1).astype(np.int64)[active]
            active_ego = item.ego.reshape(-1, item.ego.shape[-1])[active]
            supervised = labels >= 0
            if not np.any(supervised):
                continue
            ego_parts.append(active_ego[supervised])
            node_parts.append(item.nodes.reshape(-1, item.nodes.shape[-2], item.nodes.shape[-1])[active][supervised])
            edge_parts.append(item.edges.reshape(-1, item.edges.shape[-2], item.edges.shape[-1])[active][supervised])
            node_mask_parts.append(item.node_mask.reshape(-1, item.node_mask.shape[-1])[active][supervised])
            label_parts.append(labels[supervised])
        if not label_parts:
            return {"mixture_gate_prewarm_samples": 0.0, "mixture_gate_prewarm_steps": 0.0}
        ego = np.concatenate(ego_parts, axis=0)
        nodes = np.concatenate(node_parts, axis=0)
        edges = np.concatenate(edge_parts, axis=0)
        node_mask = np.concatenate(node_mask_parts, axis=0)
        labels_np = np.concatenate(label_parts, axis=0).astype(np.int64)
        ego_t = torch.as_tensor(ego, dtype=torch.float32, device=self.device)
        nodes_t = torch.as_tensor(nodes, dtype=torch.float32, device=self.device)
        edges_t = torch.as_tensor(edges, dtype=torch.float32, device=self.device)
        node_mask_t = torch.as_tensor(node_mask, dtype=torch.float32, device=self.device)
        labels_t = torch.as_tensor(labels_np, dtype=torch.long, device=self.device)
        steps = max(0, int(self.config.mixture_gate_prewarm_steps))
        batch_size = max(1, int(self.config.mixture_gate_prewarm_batch_size))
        metrics = self._evaluate_mixture_gate_tensors(ego_t, nodes_t, edges_t, node_mask_t, labels_t)
        last_loss = 0.0
        last_grad = 0.0
        last_creep_loss = metrics["mixture_creep_prewarm_action_loss"]
        last_creep_grad = 0.0
        reached = False
        step = 0
        for step in range(1, steps + 1):
            batch_np = self._sample_gate_prewarm_indices(labels_np, batch_size)
            if len(batch_np) == 0:
                break
            batch = torch.as_tensor(batch_np, dtype=torch.long, device=self.device)
            logits = self.model.mixture_gate_logits(
                ego_t[batch],
                nodes_t[batch],
                edges_t[batch],
                node_mask_t[batch],
                detach_features=True,
            )
            targets = labels_t[batch]
            class_counts = torch.bincount(
                targets, minlength=self.model.MIXTURE_COMPONENTS
            ).float()
            class_weights = targets.numel() / (
                self.model.MIXTURE_COMPONENTS * class_counts.clamp_min(1.0)
            )
            class_weights = torch.clamp(class_weights.to(self.device), 0.5, 2.0)
            loss = F.cross_entropy(logits, targets, weight=class_weights)
            self.gate_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            grad_norm = self._gradient_norm(self._mixture_gate_params)
            nn.utils.clip_grad_norm_(
                self._mixture_gate_params, self.config.mixture_gate_max_grad_norm
            )
            self.gate_optimizer.step()
            self.gate_optimizer.zero_grad(set_to_none=True)

            creep_mask = targets == self.model.CREEP_COMPONENT
            if creep_mask.any() and self.creep_optimizer is not None:
                creep_ego = self._augment_creep_prewarm_ego(
                    ego_t[batch], creep_mask, step
                )
                creep_mean = self.model.creep_component_mean(
                    creep_ego,
                    nodes_t[batch],
                    edges_t[batch],
                    node_mask_t[batch],
                    detach_features=True,
                )
                creep_target = self._creep_action_targets_from_ego(creep_ego).detach()
                creep_loss = F.mse_loss(
                    creep_mean[creep_mask], creep_target[creep_mask]
                )
                self.creep_optimizer.zero_grad(set_to_none=True)
                creep_loss.backward()
                creep_grad = self._gradient_norm(self._creep_component_params)
                nn.utils.clip_grad_norm_(
                    self._creep_component_params, self.config.mixture_gate_max_grad_norm
                )
                self.creep_optimizer.step()
                self.creep_optimizer.zero_grad(set_to_none=True)
                last_creep_loss = float(creep_loss.item())
                last_creep_grad = float(creep_grad)

            last_loss = float(loss.item())
            last_grad = float(grad_norm)
            if step == 1 or step % 25 == 0 or step == steps:
                metrics = self._evaluate_mixture_gate_tensors(
                    ego_t, nodes_t, edges_t, node_mask_t, labels_t
                )
                present = all(
                    metrics[f"mixture_gate_prewarm_{name}_count"] > 0.0
                    for name in ("stop", "creep", "go")
                )
                reached = (
                    present
                    and metrics["mixture_gate_prewarm_stop_weight"]
                    >= self.config.mixture_gate_prewarm_stop_weight_threshold
                    and metrics["mixture_gate_prewarm_creep_weight"]
                    >= self.config.mixture_gate_prewarm_creep_weight_threshold
                    and metrics["mixture_gate_prewarm_go_weight"]
                    >= self.config.mixture_gate_prewarm_go_weight_threshold
                    and all(
                        metrics[f"mixture_gate_prewarm_{name}_argmax"]
                        >= self.config.mixture_gate_unfreeze_argmax_threshold
                        for name in ("stop", "creep", "go")
                    )
                    and all(
                        metrics[f"mixture_gate_prewarm_{name}_ambiguous"]
                        <= self.config.mixture_gate_prewarm_ambiguous_threshold
                        for name in ("stop", "creep", "go")
                    )
                    and metrics["mixture_creep_prewarm_action_loss"]
                    <= self.config.mixture_creep_prewarm_action_loss_threshold
                    and last_creep_loss
                    <= self.config.mixture_creep_prewarm_action_loss_threshold
                )
                print(
                    f"prewarm_gate step={step:04d} loss={last_loss:.4f} grad={last_grad:.3f} "
                    f"w={metrics['mixture_gate_prewarm_stop_weight']:.3f}/"
                    f"{metrics['mixture_gate_prewarm_creep_weight']:.3f}/"
                    f"{metrics['mixture_gate_prewarm_go_weight']:.3f} "
                    f"arg={metrics['mixture_gate_prewarm_stop_argmax']:.3f}/"
                    f"{metrics['mixture_gate_prewarm_creep_argmax']:.3f}/"
                    f"{metrics['mixture_gate_prewarm_go_argmax']:.3f} "
                    f"amb={metrics['mixture_gate_prewarm_stop_ambiguous']:.3f}/"
                    f"{metrics['mixture_gate_prewarm_creep_ambiguous']:.3f}/"
                    f"{metrics['mixture_gate_prewarm_go_ambiguous']:.3f} "
                    f"creep_loss={metrics['mixture_creep_prewarm_action_loss']:.4f} "
                    f"creep_aug_loss={last_creep_loss:.4f}"
                )
                if reached:
                    break
        metrics["mixture_gate_prewarm_steps"] = float(step)
        metrics["mixture_gate_prewarm_loss"] = last_loss
        metrics["mixture_gate_prewarm_grad_norm"] = last_grad
        metrics["mixture_creep_prewarm_last_loss"] = last_creep_loss
        metrics["mixture_creep_prewarm_grad_norm"] = last_creep_grad
        metrics["mixture_gate_prewarm_reached"] = float(reached)
        return metrics

    def _maybe_prewarm_mixture_gate(self) -> None:
        if self.config.mixture_gate_prewarm_steps <= 0:
            return
        if self.model.action_distribution != "squashed_mixture" or self.gate_optimizer is None:
            print("prewarm_gate skipped: squashed_mixture with separate gate optimizer is required")
            return

        rounds = 3 if self.model.creep_component_enabled else 1
        metrics: dict[str, float] = {}
        total_steps = 0.0
        for prewarm_round in range(1, rounds + 1):
            rollouts: list[GraphRollout] = []
            route_counts = np.zeros(self.model.MIXTURE_COMPONENTS, dtype=np.int64)
            for collection in range(1, 9):
                collected = self.collect_rollouts(update_index=0)
                rollouts.extend(collected)
                for rollout in collected:
                    active = rollout.masks.reshape(-1).astype(bool)
                    labels = rollout.component_route_labels.reshape(-1)[active]
                    for route in range(self.model.MIXTURE_COMPONENTS):
                        route_counts[route] += int(np.sum(labels == route))
                print(
                    f"prewarm_gate round={prewarm_round}/{rounds} "
                    f"collection={collection} route_counts={route_counts.tolist()}"
                )
                if np.all(route_counts >= 64):
                    break
            metrics = self._prewarm_mixture_gate_on_rollouts(rollouts)
            total_steps += metrics.get("mixture_gate_prewarm_steps", 0.0)
            print(
                f"prewarm_gate round_done={prewarm_round}/{rounds} "
                f"reached={int(metrics.get('mixture_gate_prewarm_reached', 0.0))} "
                f"w={metrics.get('mixture_gate_prewarm_stop_weight', 0.0):.3f}/"
                f"{metrics.get('mixture_gate_prewarm_creep_weight', 0.0):.3f}/"
                f"{metrics.get('mixture_gate_prewarm_go_weight', 0.0):.3f} "
                f"arg={metrics.get('mixture_gate_prewarm_stop_argmax', 0.0):.3f}/"
                f"{metrics.get('mixture_gate_prewarm_creep_argmax', 0.0):.3f}/"
                f"{metrics.get('mixture_gate_prewarm_go_argmax', 0.0):.3f} "
                f"creep_loss={metrics.get('mixture_creep_prewarm_action_loss', 0.0):.4f}"
            )
        metrics["mixture_gate_prewarm_total_steps"] = total_steps
        metrics["mixture_gate_prewarm_rounds"] = float(rounds)
        self._mixture_gate_prewarm_metrics = metrics
        if metrics.get("mixture_gate_prewarm_reached", 0.0) < 0.5:
            raise RuntimeError(
                "Three-component prewarm did not meet all route and creep-servo "
                "thresholds on the final on-policy aggregation round; PPO was not started."
            )

    def _intent_loss_weight(self, update_index: int) -> float:
        target = max(0.0, float(self.config.intent_loss_coefficient))
        warmup = max(0, int(self.config.intent_loss_warmup_updates))
        ramp = max(0, int(self.config.intent_loss_ramp_updates))
        if target <= 0.0:
            return 0.0
        if update_index <= warmup:
            return 0.0
        if ramp <= 0:
            return target
        progress = min(1.0, max(0.0, (update_index - warmup) / float(ramp)))
        return target * progress

    def _mixture_gate_loss_weight(self, update_index: int) -> float:
        start = max(0.0, float(self.config.mixture_gate_loss_coefficient))
        final = max(0.0, float(self.config.mixture_gate_loss_final_coefficient))
        decay_start = max(0, int(self.config.mixture_gate_loss_decay_start_updates))
        decay_updates = max(0, int(self.config.mixture_gate_loss_decay_updates))
        if start <= 0.0:
            return 0.0
        if self.config.mixture_gate_loss_decay_after_unfreeze:
            if self._mixture_gate_unfreeze_update is None:
                return start
            decay_start = self._mixture_gate_unfreeze_update + decay_start
        if decay_updates <= 0 or update_index <= decay_start:
            return start
        progress = min(1.0, max(0.0, (update_index - decay_start) / float(decay_updates)))
        return start + progress * (final - start)

    def _intent_action_loss_weight(self, update_index: int) -> float:
        start = max(0.0, float(self.config.intent_action_loss_coefficient))
        final = max(0.0, float(self.config.intent_action_loss_final_coefficient))
        decay_start = max(0, int(self.config.intent_action_loss_decay_start_updates))
        decay_updates = max(0, int(self.config.intent_action_loss_decay_updates))
        if start <= 0.0:
            return 0.0
        if decay_updates <= 0 or update_index <= decay_start:
            return start
        progress = min(1.0, max(0.0, (update_index - decay_start) / float(decay_updates)))
        return start + progress * (final - start)

    def run_validation(
        self,
        update_index: int,
        lanes: int,
        cars: int,
        episode_seconds: float,
        episodes: int,
    ) -> dict[str, float]:
        workers = max(1, min(self.validation_workers, episodes))
        if workers <= 1:
            payload = self._validation_payload(update_index, lanes, cars, episode_seconds, 0, episodes)
            metrics = _run_graph_validation_worker(payload)
        else:
            payloads = []
            for worker_index in range(workers):
                start = worker_index * episodes // workers
                stop = (worker_index + 1) * episodes // workers
                if start == stop:
                    continue
                payloads.append(
                    self._validation_payload(update_index, lanes, cars, episode_seconds, start, stop)
                )
            with ProcessPoolExecutor(max_workers=workers) as executor:
                metrics = self._merge_metrics(list(executor.map(_run_graph_validation_worker, payloads)))
            metrics["episodes"] = float(episodes)
            metrics["cars"] = float(cars)
            metrics["lanes"] = float(lanes)
        metrics["validation_score"] = self._validation_score(metrics)
        return metrics

    def _validation_payload(
        self,
        update_index: int,
        lanes: int,
        cars: int,
        episode_seconds: float,
        episode_start: int,
        episode_stop: int,
    ) -> dict:
        spec = self.observer.spec
        validation_env_config = replace(
            self.env.config,
            signal_all_red_seconds=self.config.validation_all_red_seconds,
            signal_all_red_seconds_min=None,
            signal_all_red_seconds_max=None,
        )
        return {
            "env_config": validation_env_config,
            "max_cars": self.env.config.max_cars,
            "max_vehicle_nodes": spec.max_vehicle_nodes,
            "ego_size": spec.ego_size,
            "node_size": spec.node_size,
            "edge_size": spec.edge_size,
            "max_nodes": spec.max_nodes,
            "hidden_size": self.model.hidden_size,
            "action_size": self.model.action_size,
            "layers": self.model.layers,
            "action_distribution": self.config.action_distribution,
            "action_min_log_std": self.config.action_min_log_std,
            "action_max_log_std": self.config.action_max_log_std,
            "action_initial_log_std": (
                self.config.action_initial_log_std_longitudinal,
                self.config.action_initial_log_std_steering,
            ),
            "model_state": _model_state_numpy(self.model),
            "seed": self.config.seed,
            "base_seed": self.config.seed + update_index * 1000,
            "lanes": lanes,
            "cars": cars,
            "episode_seconds": episode_seconds,
            "episode_start": episode_start,
            "episode_stop": episode_stop,
            "validation_eval_mode": self.config.validation_eval_mode,
        }

    @staticmethod
    def _merge_metrics(items: list[dict[str, float]]) -> dict[str, float]:
        metrics = GraphPPOTrainer._empty_metrics()
        for item in items:
            for key, value in item.items():
                if key in ("episodes", "cars", "lanes", "validation_score"):
                    continue
                metrics[key] = metrics.get(key, 0.0) + float(value)
        return metrics

    def train(
        self,
        checkpoint_path: str | Path,
        validation_scenarios: tuple[tuple[int, int, float], ...] = (
            (2, 8, 60.0),
            (2, 24, 120.0),
            (3, 24, 120.0),
            (3, 36, 150.0),
            (4, 30, 150.0),
            (4, 50, 150.0),
        ),
    ) -> GraphActorCritic:
        checkpoint_path = Path(checkpoint_path)
        metrics_path = checkpoint_path.with_name(f"{checkpoint_path.stem}_train_metrics.csv")
        fields = [
            "update", "steps", "rollout_workers", "validation_workers", "rollout_mean_reward", "policy_loss", "value_loss", "value_loss_mse", "value_error_abs_mean", "value_error_abs_max",
            "grad_norm_policy", "grad_norm_value", "grad_norm_value_mse", "grad_norm_gate_ce", "grad_norm_creep_action", "effective_grad_creep_action", "main_grad_norm", "main_grad_clip_scale", "gate_grad_norm", "gate_grad_clip_scale",
            "entropy", "explained_variance", "intent_loss", "intent_loss_weight", "intent_detached", "intent_accuracy", "intent_action_loss", "intent_action_loss_weight", "intent_action_loss_samples", "intent_action_loss_red_only",
            "creep_action_loss", "creep_action_samples", "creep_routed_component_mean", "creep_action_target_mean",
            "regular_brake_samples", "regular_brake_component_mean", "regular_brake_action_target_mean",
            "mixture_gate_loss", "mixture_gate_loss_weight", "mixture_gate_loss_samples", "mixture_gate_accuracy", "mixture_gate_detached", "mixture_gate_ppo_frozen", "mixture_gate_saturated_updates", "mixture_gate_updates_since_unfreeze", "mixture_gate_prewarm_reached", "mixture_gate_prewarm_steps", "mixture_gate_prewarm_stop_weight", "mixture_gate_prewarm_creep_weight", "mixture_gate_prewarm_go_weight", "mixture_gate_prewarm_stop_argmax", "mixture_gate_prewarm_creep_argmax", "mixture_gate_prewarm_go_argmax", "mixture_gate_prewarm_stop_ambiguous", "mixture_gate_prewarm_creep_ambiguous", "mixture_gate_prewarm_go_ambiguous", "mixture_creep_prewarm_action_loss", "mixture_creep_prewarm_action_mean", "mixture_creep_prewarm_action_target",
            "std_stop_label_mean", "std_hold_label_mean", "std_go_label_mean", "action_stop_label_mean", "action_stop_label_brake_share", "action_hold_label_mean", "action_hold_label_brake_share", "action_go_label_mean", "action_go_label_brake_share",
            "mixture_brake_weight_stop_label_mean", "mixture_brake_argmax_stop_label_share", "mixture_ambiguous_stop_label_share", "mixture_brake_weight_hold_label_mean", "mixture_brake_argmax_hold_label_share", "mixture_ambiguous_hold_label_share", "mixture_go_weight_go_label_mean", "mixture_go_argmax_go_label_share", "mixture_ambiguous_go_label_share", "mixture_go_weight_green_opening_gap_mean", "mixture_go_argmax_green_opening_gap_share", "mixture_ambiguous_green_opening_gap_share", "mixture_green_opening_gap_samples", "intent_eval_accuracy",
            "reference_kl", "reference_kl_weight", "reference_kl_samples", "go_component_reference_kl", "go_component_reference_kl_weight", "go_component_reference_kl_samples", "phase_adv_norm", "phase_balanced_mb", "phase_samples_stop", "phase_samples_hold", "phase_samples_go", "phase_samples_yield", "safety_replay_workers", "rollout_guard_stop", "approximate_kl", "validation_score", "validation_gate_passed", "stale_validations",
            "best_validation_score", "completed_clean", "failed", "timeouts", "stuck_timeouts", "non_timeout_failed", "collisions",
            "collision_vehicles_before_stop_line", "collision_vehicles_inside_intersection", "collision_vehicles_after_stop_line",
            "proximity_events", "red", "yellow", "closed_signal",
            "failed_by_red", "failed_by_yellow", "failed_by_collision", "failed_by_left_yield",
            "failed_by_right_yield", "right_yield", "failed_by_lane_violation", "front_gap_violations",
            "queue_stop_position_error_sum", "queue_stop_position_samples", "queue_stop_position_error_avg",
            "queue_stop_position_error_lead_avg", "queue_stop_position_error_second_avg",
            "queue_stop_position_error_third_plus_avg", "queue_follower_gap_error_avg",
            "cars_stopped_too_far_from_stop_line", "lead_green_start_delay_seconds",
            "follower_green_start_delay_seconds", "second_green_start_delay_seconds",
            "third_plus_green_start_delay_seconds", "queue_discharge_delay_seconds",
            "lead_green_stuck_events", "follower_green_stuck_events", "second_green_stuck_events",
            "third_plus_green_stuck_events", "green_stopped_too_far_events",
            "queue_red_crossings", "progress", "policy_samples", "env_steps", "vehicle_hours", "saved_best", "early_stop",
        ]
        checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
        self._maybe_prewarm_mixture_gate()
        if self._mixture_gate_prewarm_metrics:
            prewarm_path = checkpoint_path.with_name(
                f"{checkpoint_path.stem}_prewarm{checkpoint_path.suffix}"
            )
            self.model.save(prewarm_path)
            if self.config.stop_after_mixture_prewarm:
                self.model.save(checkpoint_path)
                print(f"prewarm_only checkpoint={prewarm_path} ppo_started=0")
                return self.model
        with metrics_path.open("w", newline="") as metrics_file:
            csv.DictWriter(metrics_file, fieldnames=fields).writeheader()
        completed_steps = 0
        update_index = 0
        best_score = -float("inf")
        stale = 0
        while completed_steps < self.config.total_steps:
            rollouts = self.collect_rollouts(update_index=update_index + 1)
            metrics = self.update(rollouts, update_index=update_index + 1)
            completed_steps += self.config.rollout_steps * len(rollouts)
            update_index += 1
            validation_score = ""
            selection_score = None
            validation_gate_passed = (
                not self.config.validation_regime_gates_enabled
                or self.config.validation_interval_updates <= 0
            )
            if self.config.validation_interval_updates > 0 and update_index % self.config.validation_interval_updates == 0:
                validation_runs = [
                    self.run_validation(update_index, lanes, cars, seconds, self.config.validation_episodes)
                    for lanes, cars, seconds in validation_scenarios
                ]
                selection_score = float(np.mean([item["validation_score"] for item in validation_runs]))
                validation_score = selection_score
                if self.config.validation_regime_gates_enabled:
                    validation_gate_passed = self._validation_regime_gates_pass(validation_runs)
            elif self.config.validation_interval_updates <= 0:
                selection_score = metrics["safety_score"]
            improved = (
                selection_score is not None
                and validation_gate_passed
                and selection_score > best_score + self.config.validation_min_delta
            )
            saved_best = False
            early_stop = False
            rollout_guard_stop = (
                self.config.rollout_closed_signal_stop_threshold > 0.0
                and update_index > self.config.rollout_guard_warmup_updates
                and metrics.get("closed_signal", 0.0) > self.config.rollout_closed_signal_stop_threshold
            )
            if improved:
                best_score = selection_score
                stale = 0
                self.model.save(
                    checkpoint_path.with_name(f"{checkpoint_path.stem}_best{checkpoint_path.suffix}")
                )
                saved_best = True
            elif validation_score != "" and self.config.validation_patience > 0:
                stale += 1
                early_stop = stale >= self.config.validation_patience
            if rollout_guard_stop:
                early_stop = True
            if self.config.checkpoint_interval_updates > 0 and update_index % self.config.checkpoint_interval_updates == 0:
                self.model.save(
                    checkpoint_path.with_name(
                        f"{checkpoint_path.stem}_update_{update_index:04d}{checkpoint_path.suffix}"
                    )
                )
            print(
                f"update={update_index:04d} steps={completed_steps:07d} "
                f"rollouts={len(rollouts)} rw={self.rollout_workers} vw={self.validation_workers} "
                f"reward={metrics['rollout_mean_reward']:+.4f} "
                f"policy={metrics.get('policy_loss', 0.0):+.4f} "
                f"value={metrics.get('value_loss', 0.0):.4f} "
                f"value_mse={metrics.get('value_loss_mse', 0.0):.1f} "
                f"gval={metrics.get('grad_norm_value', 0.0):.2f} "
                f"gmain={metrics.get('main_grad_norm', 0.0):.2f} "
                f"clip={metrics.get('main_grad_clip_scale', 1.0):.4f} "
                f"entropy={metrics.get('entropy', 0.0):.3f} "
                f"ev={metrics.get('explained_variance', 0.0):+.3f} "
                f"intent_loss={metrics.get('intent_loss', 0.0):.3f} "
                f"intent_w={metrics.get('intent_loss_weight', 0.0):.4f} "
                f"intent_detach={int(metrics.get('intent_detached', 0.0))} "
                f"intent_acc={metrics.get('intent_accuracy', 0.0):.3f} "
                f"intent_action={metrics.get('intent_action_loss', 0.0):.3f} "
                f"action_w={metrics.get('intent_action_loss_weight', 0.0):.4f} "
                f"action_n={metrics.get('intent_action_loss_samples', 0.0):.0f} "
                f"creep_n={metrics.get('creep_action_samples', 0.0):.0f} "
                f"creep_a={metrics.get('creep_routed_component_mean', 0.0):+.3f} "
                f"creep_t={metrics.get('creep_action_target_mean', 0.0):+.3f} "
                f"creep_g={metrics.get('grad_norm_creep_action', 0.0):.3f} "
                f"creep_eff={metrics.get('effective_grad_creep_action', 0.0):.3f} "
                f"brake_n={metrics.get('regular_brake_samples', 0.0):.0f} "
                f"brake_a={metrics.get('regular_brake_component_mean', 0.0):+.3f} "
                f"brake_t={metrics.get('regular_brake_action_target_mean', 0.0):+.3f} "
                f"stop_a={metrics.get('action_stop_label_mean', 0.0):+.3f} "
                f"go_a={metrics.get('action_go_label_mean', 0.0):+.3f} "
                f"std_stop={metrics.get('std_stop_label_mean', 0.0):.3f} "
                f"std_go={metrics.get('std_go_label_mean', 0.0):.3f} "
                f"gate_loss={metrics.get('mixture_gate_loss', 0.0):.3f} "
                f"gate_w={metrics.get('mixture_gate_loss_weight', 0.0):.3f} "
                f"gate_g={metrics.get('gate_grad_norm', 0.0):.2f} "
                f"gate_clip={metrics.get('gate_grad_clip_scale', 1.0):.3f} "
                f"gate_frozen={int(metrics.get('mixture_gate_ppo_frozen', 0.0))} "
                f"gate_since_unfreeze={metrics.get('mixture_gate_updates_since_unfreeze', 0.0):.0f} "
                f"gate_acc={metrics.get('mixture_gate_accuracy', 0.0):.3f} "
                f"w_stop={metrics.get('mixture_brake_weight_stop_label_mean', 0.0):.3f} "
                f"w_go={metrics.get('mixture_go_weight_go_label_mean', 0.0):.3f} "
                f"w_go_open={metrics.get('mixture_go_weight_green_opening_gap_mean', 0.0):.3f} "
                f"amb_stop={metrics.get('mixture_ambiguous_stop_label_share', 0.0):.3f} "
                f"ref_kl={metrics.get('reference_kl', 0.0):.5f} "
                f"go_ref_kl={metrics.get('go_component_reference_kl', 0.0):.5f} "
                f"kl={metrics.get('approximate_kl', 0.0):+.5f} "
                f"val={validation_score if validation_score != '' else ''} "
                f"gate={int(validation_gate_passed)} "
                f"stale={stale} clean={metrics['completed_clean']:.0f} "
                f"failed={metrics['failed']:.0f} timeout={metrics.get('timeouts', 0.0):.0f} stuck={metrics.get('stuck_timeouts', 0.0):.0f} coll={metrics['collisions']:.0f} "
                f"prox={metrics['proximity_events']:.0f} red={metrics['red']:.0f} "
                f"yellow={metrics['yellow']:.0f} closed={metrics['closed_signal']:.0f} "
                f"guard={int(rollout_guard_stop)} "
                f"phase_stop={metrics.get('phase_samples_stop', 0.0):.0f} "
                f"phase_hold={metrics.get('phase_samples_hold', 0.0):.0f} "
                f"phase_go={metrics.get('phase_samples_go', 0.0):.0f} "
                f"phase_yield={metrics.get('phase_samples_yield', 0.0):.0f} "
                f"samples={metrics['policy_samples']:.0f}"
            )
            row = {
                "update": update_index,
                "steps": completed_steps,
                "rollout_workers": len(rollouts),
                "validation_workers": self.validation_workers,
                "rollout_mean_reward": metrics.get("rollout_mean_reward", 0.0),
                "policy_loss": metrics.get("policy_loss", 0.0),
                "value_loss": metrics.get("value_loss", 0.0),
                "value_loss_mse": metrics.get("value_loss_mse", 0.0),
                "value_error_abs_mean": metrics.get("value_error_abs_mean", 0.0),
                "value_error_abs_max": metrics.get("value_error_abs_max", 0.0),
                "grad_norm_policy": metrics.get("grad_norm_policy", 0.0),
                "grad_norm_value": metrics.get("grad_norm_value", 0.0),
                "grad_norm_value_mse": metrics.get("grad_norm_value_mse", 0.0),
                "grad_norm_gate_ce": metrics.get("grad_norm_gate_ce", 0.0),
                "grad_norm_creep_action": metrics.get("grad_norm_creep_action", 0.0),
                "effective_grad_creep_action": metrics.get("effective_grad_creep_action", 0.0),
                "main_grad_norm": metrics.get("main_grad_norm", 0.0),
                "main_grad_clip_scale": metrics.get("main_grad_clip_scale", 1.0),
                "gate_grad_norm": metrics.get("gate_grad_norm", 0.0),
                "gate_grad_clip_scale": metrics.get("gate_grad_clip_scale", 1.0),
                "entropy": metrics.get("entropy", 0.0),
                "explained_variance": metrics.get("explained_variance", 0.0),
                "intent_loss": metrics.get("intent_loss", 0.0),
                "intent_loss_weight": metrics.get("intent_loss_weight", 0.0),
                "intent_detached": metrics.get("intent_detached", 0.0),
                "intent_accuracy": metrics.get("intent_accuracy", 0.0),
                "intent_action_loss": metrics.get("intent_action_loss", 0.0),
                "intent_action_loss_weight": metrics.get("intent_action_loss_weight", 0.0),
                "intent_action_loss_samples": metrics.get("intent_action_loss_samples", 0.0),
                "intent_action_loss_red_only": metrics.get("intent_action_loss_red_only", 0.0),
                "creep_action_loss": metrics.get("creep_action_loss", 0.0),
                "creep_action_samples": metrics.get("creep_action_samples", 0.0),
                "creep_routed_component_mean": metrics.get("creep_routed_component_mean", 0.0),
                "creep_action_target_mean": metrics.get("creep_action_target_mean", 0.0),
                "regular_brake_samples": metrics.get("regular_brake_samples", 0.0),
                "regular_brake_component_mean": metrics.get("regular_brake_component_mean", 0.0),
                "regular_brake_action_target_mean": metrics.get("regular_brake_action_target_mean", 0.0),
                "intent_eval_accuracy": metrics.get("intent_correct", 0.0) / max(metrics.get("intent_total", 0.0), 1.0),
                "mixture_gate_loss": metrics.get("mixture_gate_loss", 0.0),
                "mixture_gate_loss_weight": metrics.get("mixture_gate_loss_weight", 0.0),
                "mixture_gate_loss_samples": metrics.get("mixture_gate_loss_samples", 0.0),
                "mixture_gate_accuracy": metrics.get("mixture_gate_accuracy", 0.0),
                "mixture_gate_detached": metrics.get("mixture_gate_detached", 0.0),
                "mixture_gate_ppo_frozen": metrics.get("mixture_gate_ppo_frozen", 0.0),
                "mixture_gate_saturated_updates": metrics.get("mixture_gate_saturated_updates", 0.0),
                "mixture_gate_updates_since_unfreeze": metrics.get("mixture_gate_updates_since_unfreeze", 0.0),
                "mixture_gate_prewarm_reached": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_reached", 0.0),
                "mixture_gate_prewarm_steps": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_steps", 0.0),
                "mixture_gate_prewarm_stop_weight": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_stop_weight", 0.0),
                "mixture_gate_prewarm_creep_weight": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_creep_weight", 0.0),
                "mixture_gate_prewarm_go_weight": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_go_weight", 0.0),
                "mixture_gate_prewarm_stop_argmax": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_stop_argmax", 0.0),
                "mixture_gate_prewarm_creep_argmax": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_creep_argmax", 0.0),
                "mixture_gate_prewarm_go_argmax": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_go_argmax", 0.0),
                "mixture_gate_prewarm_stop_ambiguous": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_stop_ambiguous", 0.0),
                "mixture_gate_prewarm_creep_ambiguous": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_creep_ambiguous", 0.0),
                "mixture_gate_prewarm_go_ambiguous": self._mixture_gate_prewarm_metrics.get("mixture_gate_prewarm_go_ambiguous", 0.0),
                "mixture_creep_prewarm_action_loss": self._mixture_gate_prewarm_metrics.get("mixture_creep_prewarm_action_loss", 0.0),
                "mixture_creep_prewarm_action_mean": self._mixture_gate_prewarm_metrics.get("mixture_creep_prewarm_action_mean", 0.0),
                "mixture_creep_prewarm_action_target": self._mixture_gate_prewarm_metrics.get("mixture_creep_prewarm_action_target", 0.0),
                "std_stop_label_mean": metrics.get("std_stop_label_mean", 0.0),
                "std_hold_label_mean": metrics.get("std_hold_label_mean", 0.0),
                "std_go_label_mean": metrics.get("std_go_label_mean", 0.0),
                "action_stop_label_mean": metrics.get("action_stop_label_mean", 0.0),
                "action_stop_label_brake_share": metrics.get("action_stop_label_brake_share", 0.0),
                "action_hold_label_mean": metrics.get("action_hold_label_mean", 0.0),
                "action_hold_label_brake_share": metrics.get("action_hold_label_brake_share", 0.0),
                "action_go_label_mean": metrics.get("action_go_label_mean", 0.0),
                "action_go_label_brake_share": metrics.get("action_go_label_brake_share", 0.0),
                "mixture_brake_weight_stop_label_mean": metrics.get("mixture_brake_weight_stop_label_mean", 0.0),
                "mixture_brake_argmax_stop_label_share": metrics.get("mixture_brake_argmax_stop_label_share", 0.0),
                "mixture_ambiguous_stop_label_share": metrics.get("mixture_ambiguous_stop_label_share", 0.0),
                "mixture_brake_weight_hold_label_mean": metrics.get("mixture_brake_weight_hold_label_mean", 0.0),
                "mixture_brake_argmax_hold_label_share": metrics.get("mixture_brake_argmax_hold_label_share", 0.0),
                "mixture_ambiguous_hold_label_share": metrics.get("mixture_ambiguous_hold_label_share", 0.0),
                "mixture_go_weight_go_label_mean": metrics.get("mixture_go_weight_go_label_mean", 0.0),
                "mixture_go_argmax_go_label_share": metrics.get("mixture_go_argmax_go_label_share", 0.0),
                "mixture_ambiguous_go_label_share": metrics.get("mixture_ambiguous_go_label_share", 0.0),
                "mixture_go_weight_green_opening_gap_mean": metrics.get("mixture_go_weight_green_opening_gap_mean", 0.0),
                "mixture_go_argmax_green_opening_gap_share": metrics.get("mixture_go_argmax_green_opening_gap_share", 0.0),
                "mixture_ambiguous_green_opening_gap_share": metrics.get("mixture_ambiguous_green_opening_gap_share", 0.0),
                "mixture_green_opening_gap_samples": metrics.get("mixture_green_opening_gap_samples", 0.0),
                "reference_kl": metrics.get("reference_kl", 0.0),
                "reference_kl_weight": metrics.get("reference_kl_weight", 0.0),
                "reference_kl_samples": metrics.get("reference_kl_samples", 0.0),
                "go_component_reference_kl": metrics.get("go_component_reference_kl", 0.0),
                "go_component_reference_kl_weight": metrics.get("go_component_reference_kl_weight", 0.0),
                "go_component_reference_kl_samples": metrics.get("go_component_reference_kl_samples", 0.0),
                "phase_adv_norm": metrics.get("phase_adv_norm", 0.0),
                "phase_balanced_mb": metrics.get("phase_balanced_mb", 0.0),
                "phase_samples_stop": metrics.get("phase_samples_stop", 0.0),
                "phase_samples_hold": metrics.get("phase_samples_hold", 0.0),
                "phase_samples_go": metrics.get("phase_samples_go", 0.0),
                "phase_samples_yield": metrics.get("phase_samples_yield", 0.0),
                "safety_replay_workers": metrics.get("safety_replay_workers", 0.0),
                "rollout_guard_stop": int(rollout_guard_stop),
                "approximate_kl": metrics.get("approximate_kl", 0.0),
                "validation_score": validation_score,
                "validation_gate_passed": int(validation_gate_passed),
                "stale_validations": stale,
                "best_validation_score": best_score,
                "completed_clean": metrics.get("completed_clean", 0.0),
                "failed": metrics.get("failed", 0.0),
                "timeouts": metrics.get("timeouts", 0.0),
                "stuck_timeouts": metrics.get("stuck_timeouts", 0.0),
                "non_timeout_failed": max(0.0, metrics.get("failed", 0.0) - metrics.get("timeouts", 0.0)),
                "collisions": metrics.get("collisions", 0.0),
                "collision_vehicles_before_stop_line": metrics.get("collision_vehicles_before_stop_line", 0.0),
                "collision_vehicles_inside_intersection": metrics.get("collision_vehicles_inside_intersection", 0.0),
                "collision_vehicles_after_stop_line": metrics.get("collision_vehicles_after_stop_line", 0.0),
                "proximity_events": metrics.get("proximity_events", 0.0),
                "red": metrics.get("red", 0.0),
                "yellow": metrics.get("yellow", 0.0),
                "closed_signal": metrics.get("closed_signal", 0.0),
                "failed_by_red": metrics.get("failed_by_red", 0.0),
                "failed_by_yellow": metrics.get("failed_by_yellow", 0.0),
                "failed_by_collision": metrics.get("failed_by_collision", 0.0),
                "failed_by_left_yield": metrics.get("failed_by_left_yield", 0.0),
                "failed_by_right_yield": metrics.get("failed_by_right_yield", 0.0),
                "right_yield": metrics.get("right_yield", 0.0),
                "failed_by_lane_violation": metrics.get("failed_by_lane_violation", 0.0),
                "front_gap_violations": metrics.get("front_gap_violations", 0.0),
                "queue_stop_position_error_sum": metrics.get("queue_stop_position_error_sum", 0.0),
                "queue_stop_position_samples": metrics.get("queue_stop_position_samples", 0.0),
                "queue_stop_position_error_avg": metrics.get("queue_stop_position_error_sum", 0.0) / max(metrics.get("queue_stop_position_samples", 0.0), 1.0),
                "queue_stop_position_error_lead_avg": metrics.get("queue_stop_position_error_lead_sum", 0.0) / max(metrics.get("queue_stop_position_error_lead_samples", 0.0), 1.0),
                "queue_stop_position_error_second_avg": metrics.get("queue_stop_position_error_second_sum", 0.0) / max(metrics.get("queue_stop_position_error_second_samples", 0.0), 1.0),
                "queue_stop_position_error_third_plus_avg": metrics.get("queue_stop_position_error_third_plus_sum", 0.0) / max(metrics.get("queue_stop_position_error_third_plus_samples", 0.0), 1.0),
                "queue_follower_gap_error_avg": metrics.get("queue_follower_gap_error_sum", 0.0) / max(metrics.get("queue_follower_gap_samples", 0.0), 1.0),
                "cars_stopped_too_far_from_stop_line": metrics.get("cars_stopped_too_far_from_stop_line", 0.0),
                "lead_green_start_delay_seconds": metrics.get("lead_green_start_delay_seconds", 0.0),
                "follower_green_start_delay_seconds": metrics.get("follower_green_start_delay_seconds", 0.0),
                "second_green_start_delay_seconds": metrics.get("second_green_start_delay_seconds", 0.0),
                "third_plus_green_start_delay_seconds": metrics.get("third_plus_green_start_delay_seconds", 0.0),
                "queue_discharge_delay_seconds": metrics.get("queue_discharge_delay_seconds", 0.0),
                "lead_green_stuck_events": metrics.get("lead_green_stuck_events", 0.0),
                "follower_green_stuck_events": metrics.get("follower_green_stuck_events", 0.0),
                "second_green_stuck_events": metrics.get("second_green_stuck_events", 0.0),
                "third_plus_green_stuck_events": metrics.get("third_plus_green_stuck_events", 0.0),
                "green_stopped_too_far_events": metrics.get("green_stopped_too_far_events", 0.0),
                "queue_red_crossings": metrics.get("queue_red_crossings", 0.0),
                "progress": metrics.get("progress", 0.0),
                "policy_samples": metrics.get("policy_samples", 0.0),
                "env_steps": metrics.get("env_steps", 0.0),
                "vehicle_hours": metrics.get("policy_samples", 0.0) * self.env.config.dt / 3600.0,
                "saved_best": int(saved_best),
                "early_stop": int(early_stop),
            }
            with metrics_path.open("a", newline="") as metrics_file:
                csv.DictWriter(metrics_file, fieldnames=fields).writerow(row)
            if early_stop:
                print(f"early_stop update={update_index:04d} best_val={best_score:+.1f}")
                break
        self.model.save(checkpoint_path)
        return self.model

    @staticmethod
    def _empty_metrics() -> dict[str, float]:
        return {
            "completed_clean": 0.0,
            "failed": 0.0,
            "timeouts": 0.0,
            "stuck_timeouts": 0.0,
            "collisions": 0.0,
            "proximity": 0.0,
            "proximity_events": 0.0,
            "red": 0.0,
            "yellow": 0.0,
            "closed_signal": 0.0,
            "failed_by_red": 0.0,
            "failed_by_yellow": 0.0,
            "failed_by_collision": 0.0,
            "collision_vehicles_before_stop_line": 0.0,
            "collision_vehicles_inside_intersection": 0.0,
            "collision_vehicles_after_stop_line": 0.0,
            "failed_by_left_yield": 0.0,
            "failed_by_right_yield": 0.0,
            "failed_by_lane_violation": 0.0,
            "front_gap_violations": 0.0,
            "queue_stop_position_error_sum": 0.0,
            "queue_stop_position_samples": 0.0,
            "queue_stop_position_error_lead_sum": 0.0,
            "queue_stop_position_error_lead_samples": 0.0,
            "queue_stop_position_error_second_sum": 0.0,
            "queue_stop_position_error_second_samples": 0.0,
            "queue_stop_position_error_third_plus_sum": 0.0,
            "queue_stop_position_error_third_plus_samples": 0.0,
            "queue_follower_gap_error_sum": 0.0,
            "queue_follower_gap_samples": 0.0,
            "cars_stopped_too_far_from_stop_line": 0.0,
            "lead_green_start_delay_seconds": 0.0,
            "follower_green_start_delay_seconds": 0.0,
            "second_green_start_delay_seconds": 0.0,
            "third_plus_green_start_delay_seconds": 0.0,
            "queue_discharge_delay_seconds": 0.0,
            "lead_green_stuck_events": 0.0,
            "follower_green_stuck_events": 0.0,
            "second_green_stuck_events": 0.0,
            "third_plus_green_stuck_events": 0.0,
            "green_stopped_too_far_events": 0.0,
            "queue_red_crossings": 0.0,
            "intent_total": 0.0,
            "intent_correct": 0.0,
            "intent_label_stop": 0.0,
            "intent_pred_stop": 0.0,
            "intent_correct_stop": 0.0,
            "intent_label_hold": 0.0,
            "intent_pred_hold": 0.0,
            "intent_correct_hold": 0.0,
            "intent_label_go": 0.0,
            "intent_pred_go": 0.0,
            "intent_correct_go": 0.0,
            "intent_label_yield": 0.0,
            "intent_pred_yield": 0.0,
            "intent_correct_yield": 0.0,
            "left_yield": 0.0,
            "right_yield": 0.0,
            "right_on_red_entries": 0.0,
            "progress": 0.0,
            "policy_samples": 0.0,
            "env_steps": 0.0,
            "unsafe_requests": 0.0,
            "safety_score": 0.0,
            "mixture_go_weight_green_opening_gap_mean": 0.0,
            "mixture_go_argmax_green_opening_gap_share": 0.0,
            "mixture_ambiguous_green_opening_gap_share": 0.0,
            "mixture_green_opening_gap_samples": 0.0,
        }

    @staticmethod
    def _accumulate_step_metrics(metrics: dict[str, float], info: dict, active_count: float) -> None:
        metrics["completed_clean"] += float(info.get("completed_delta", 0))
        metrics["failed"] += float(info.get("failed_delta", 0))
        metrics["timeouts"] += float(info.get("timeout_failures", 0))
        metrics["stuck_timeouts"] += float(info.get("stuck_timeout_failures", 0))
        metrics["collisions"] += float(info.get("collisions", 0))
        metrics["proximity"] += float(info.get("proximity_violations", 0))
        metrics["proximity_events"] += float(info.get("proximity_events", 0))
        metrics["red"] += float(info.get("red_light_violations", 0))
        metrics["yellow"] += float(info.get("yellow_light_violations", 0))
        metrics["closed_signal"] += float(
            info.get("closed_signal_violations", info.get("red_light_violations", 0))
        )
        for key in (
            "failed_by_red",
            "failed_by_yellow",
            "failed_by_collision",
            "collision_vehicles_before_stop_line",
            "collision_vehicles_inside_intersection",
            "collision_vehicles_after_stop_line",
            "failed_by_left_yield",
            "failed_by_right_yield",
            "failed_by_lane_violation",
            "front_gap_violations",
            "queue_stop_position_error_sum",
            "queue_stop_position_samples",
            "queue_stop_position_error_lead_sum",
            "queue_stop_position_error_lead_samples",
            "queue_stop_position_error_second_sum",
            "queue_stop_position_error_second_samples",
            "queue_stop_position_error_third_plus_sum",
            "queue_stop_position_error_third_plus_samples",
            "queue_follower_gap_error_sum",
            "queue_follower_gap_samples",
            "cars_stopped_too_far_from_stop_line",
            "lead_green_start_delay_seconds",
            "follower_green_start_delay_seconds",
            "second_green_start_delay_seconds",
            "third_plus_green_start_delay_seconds",
            "queue_discharge_delay_seconds",
            "lead_green_stuck_events",
            "follower_green_stuck_events",
            "second_green_stuck_events",
            "third_plus_green_stuck_events",
            "green_stopped_too_far_events",
            "queue_red_crossings",
        ):
            metrics[key] += float(info.get(key, 0.0))
        metrics["left_yield"] += float(info.get("left_yield_violations", 0))
        metrics["right_yield"] += float(info.get("right_yield_violations", 0))
        metrics["right_on_red_entries"] += float(info.get("right_on_red_entries", 0))
        metrics["progress"] += float(info.get("progress_delta", 0.0))
        metrics["policy_samples"] += active_count
        metrics["env_steps"] += 1.0
        metrics["unsafe_requests"] += float(info.get("unsafe_requests", 0))
        metrics["safety_score"] += float(info.get("safety_score", 0.0))


    @staticmethod
    def _accumulate_intent_metrics(
        metrics: dict[str, float],
        labels: np.ndarray,
        predictions: np.ndarray,
        active_mask: np.ndarray,
    ) -> None:
        labels = np.asarray(labels, dtype=np.int64)
        predictions = np.asarray(predictions, dtype=np.int64)
        active = np.asarray(active_mask, dtype=np.float32) > 0.5
        valid = active & (labels >= 0)
        if not np.any(valid):
            return
        valid_labels = labels[valid]
        valid_predictions = predictions[valid]
        correct = valid_labels == valid_predictions
        metrics["intent_total"] += float(valid_labels.size)
        metrics["intent_correct"] += float(correct.sum())
        for index, name in enumerate(("stop", "hold", "go", "yield")):
            label_mask = valid_labels == index
            pred_mask = valid_predictions == index
            metrics[f"intent_label_{name}"] += float(label_mask.sum())
            metrics[f"intent_pred_{name}"] += float(pred_mask.sum())
            metrics[f"intent_correct_{name}"] += float((label_mask & correct).sum())

    @staticmethod
    def _validation_regime_gates_pass(validation_runs: list[dict[str, float]]) -> bool:
        gates = {
            (2, 8): (100.0, 0.0, 0.0, 0.0, 0.0),
            (3, 12): (100.0, 0.0, 0.0, 0.0, 0.0),
            (4, 16): (100.0, 0.0, 0.0, 0.0, 0.0),
            (2, 16): (100.0, 0.0, 0.0, 0.0, 0.0),
            (3, 24): (100.0, 0.0, 0.0, 0.55, 0.0),
            (4, 32): (100.0, 0.0, 0.0, 0.0, 0.0),
            (2, 24): (99.58, 0.10, 0.0, 0.0, 0.0),
            (3, 36): (99.17, 0.30, 0.0, 0.0, 0.0),
            (4, 48): (96.46, 0.40, 0.10, 1.30, 0.40),
        }
        by_cell = {
            (int(run.get("lanes", 0)), int(run.get("cars", 0))): run
            for run in validation_runs
        }
        for cell, thresholds in gates.items():
            run = by_cell.get(cell)
            if run is None:
                return False
            episodes = max(float(run.get("episodes", 0.0)), 1.0)
            cars = max(float(run.get("cars", 0.0)), 1.0)
            completed_pct = 100.0 * float(run.get("completed_clean", 0.0)) / (episodes * cars)
            red_per_ep = float(run.get("closed_signal", 0.0)) / episodes
            collisions_per_ep = float(run.get("collisions", 0.0)) / episodes
            proximity_per_ep = float(run.get("proximity_events", 0.0)) / episodes
            stuck_per_ep = float(run.get("stuck_timeouts", 0.0)) / episodes
            min_complete, max_red, max_collisions, max_proximity, max_stuck = thresholds
            if (
                completed_pct < min_complete
                or red_per_ep > max_red
                or collisions_per_ep > max_collisions
                or proximity_per_ep > max_proximity
                or stuck_per_ep > max_stuck
            ):
                return False
        return True

    def _validation_score(self, metrics: dict[str, float]) -> float:
        episodes = max(metrics.get("episodes", 1.0), 1.0)
        cars = max(metrics.get("cars", 1.0), 1.0)
        total_vehicles = episodes * cars
        completed_pct = 100.0 * metrics.get("completed_clean", 0.0) / total_vehicles
        failed = metrics.get("failed", 0.0)
        timeouts = metrics.get("timeouts", 0.0)
        stuck_timeouts = metrics.get("stuck_timeouts", 0.0)
        non_timeout_failed_pct = 100.0 * max(0.0, failed - timeouts) / total_vehicles
        timeout_pct = 100.0 * timeouts / total_vehicles
        stuck_timeout_pct = 100.0 * stuck_timeouts / total_vehicles
        collisions_per_ep = metrics.get("collisions", 0.0) / episodes
        closed_per_ep = metrics.get("closed_signal", 0.0) / episodes
        proximity_per_ep = metrics.get("proximity_events", 0.0) / episodes
        front_gap_per_ep = metrics.get("front_gap_violations", 0.0) / episodes
        queue_delay_per_ep = metrics.get("queue_discharge_delay_seconds", 0.0) / episodes
        queue_stop_error_avg = metrics.get("queue_stop_position_error_sum", 0.0) / max(
            metrics.get("queue_stop_position_samples", 0.0), 1.0
        )
        stopped_too_far_per_ep = metrics.get("cars_stopped_too_far_from_stop_line", 0.0) / episodes
        green_stuck_per_ep = (
            metrics.get("lead_green_stuck_events", 0.0)
            + metrics.get("follower_green_stuck_events", 0.0)
        ) / episodes
        green_stopped_far_per_ep = metrics.get("green_stopped_too_far_events", 0.0) / episodes
        completion_gap = max(0.0, self.config.validation_target_completed_pct - completed_pct)
        collision_excess = max(0.0, collisions_per_ep - self.config.validation_target_collisions_per_ep)
        red_excess = max(0.0, closed_per_ep - self.config.validation_target_red_per_ep)
        proximity_excess = max(0.0, proximity_per_ep - self.config.validation_target_proximity_events_per_ep)
        if self.config.validation_eval_mode == "dense_redgreen":
            closed_signal = metrics.get("closed_signal", 0.0)
            red_safe_pct = 100.0 * max(0.0, total_vehicles - closed_signal) / total_vehicles
            dense_completion_gap = max(0.0, 92.0 - completed_pct)
            dense_balance_pct = min(completed_pct, red_safe_pct, 100.0 - stuck_timeout_pct)
            return float(
                320.0 * dense_balance_pct
                + 140.0 * completed_pct
                + 110.0 * red_safe_pct
                - 320.0 * non_timeout_failed_pct
                - 280.0 * timeout_pct
                - 390.0 * stuck_timeout_pct
                - 2100.0 * dense_completion_gap
                - 2800.0 * collision_excess
                - 1600.0 * red_excess
                - 750.0 * proximity_excess
                - 520.0 * collisions_per_ep
                - 180.0 * closed_per_ep
                - 80.0 * proximity_per_ep
                - 90.0 * front_gap_per_ep
                - 9.0 * queue_delay_per_ep
                - 85.0 * queue_stop_error_avg
                - 35.0 * stopped_too_far_per_ep
                - 55.0 * green_stuck_per_ep
                - 45.0 * green_stopped_far_per_ep
            )
        if self.config.validation_eval_mode == "redgreen":
            closed_signal = metrics.get("closed_signal", 0.0)
            red_safe_pct = 100.0 * max(0.0, total_vehicles - closed_signal) / total_vehicles
            redgreen_balance_pct = min(completed_pct, red_safe_pct, 100.0 - stuck_timeout_pct)
            return float(
                260.0 * redgreen_balance_pct
                + 110.0 * completed_pct
                + 85.0 * red_safe_pct
                - 260.0 * non_timeout_failed_pct
                - 240.0 * timeout_pct
                - 340.0 * stuck_timeout_pct
                - 1700.0 * completion_gap
                - 2400.0 * collision_excess
                - 1250.0 * red_excess
                - 550.0 * proximity_excess
                - 420.0 * collisions_per_ep
                - 140.0 * closed_per_ep
                - 50.0 * proximity_per_ep
                - 55.0 * front_gap_per_ep
                - 7.0 * queue_delay_per_ep
                - 45.0 * queue_stop_error_avg
                - 18.0 * stopped_too_far_per_ep
                - 35.0 * green_stuck_per_ep
                - 30.0 * green_stopped_far_per_ep
            )
        if self.config.validation_eval_mode == "right_on_red":
            right_yield_per_ep = metrics.get("right_yield", 0.0) / episodes
            right_on_red_entries_per_ep = metrics.get("right_on_red_entries", 0.0) / episodes
            closed_safe_pct = 100.0 * max(0.0, total_vehicles - metrics.get("closed_signal", 0.0)) / total_vehicles
            yield_safe_pct = 100.0 * max(0.0, total_vehicles - metrics.get("right_yield", 0.0)) / total_vehicles
            balance_pct = min(completed_pct, closed_safe_pct, yield_safe_pct, 100.0 - stuck_timeout_pct)
            return float(
                230.0 * balance_pct
                + 120.0 * completed_pct
                + 70.0 * yield_safe_pct
                + 850.0 * right_on_red_entries_per_ep
                - 260.0 * non_timeout_failed_pct
                - 240.0 * timeout_pct
                - 300.0 * stuck_timeout_pct
                - 1600.0 * completion_gap
                - 2400.0 * collision_excess
                - 1200.0 * red_excess
                - 650.0 * proximity_excess
                - 650.0 * right_yield_per_ep
                - 420.0 * collisions_per_ep
                - 120.0 * closed_per_ep
                - 70.0 * proximity_per_ep
                - 80.0 * front_gap_per_ep
                - 8.0 * queue_delay_per_ep
                - 35.0 * green_stuck_per_ep
            )
        if self.config.validation_eval_mode in {"lead_red_stop", "lead_red_approach", "red_queue"}:
            red_safe_pct = 100.0 * max(0.0, total_vehicles - metrics.get("closed_signal", 0.0)) / total_vehicles
            return float(
                300.0 * red_safe_pct
                - 2600.0 * closed_per_ep
                - 2200.0 * collisions_per_ep
                - 800.0 * proximity_per_ep
                - 110.0 * queue_stop_error_avg
                - 28.0 * stopped_too_far_per_ep
                - 35.0 * front_gap_per_ep
            )
        if self.config.validation_eval_mode == "red":
            red_safe_pct = 100.0 * max(0.0, total_vehicles - metrics.get("closed_signal", 0.0)) / total_vehicles
            return float(
                220.0 * red_safe_pct
                - 2200.0 * closed_per_ep
                - 1800.0 * collisions_per_ep
                - 700.0 * proximity_per_ep
                - 95.0 * queue_stop_error_avg
                - 20.0 * stopped_too_far_per_ep
                - 25.0 * front_gap_per_ep
            )
        return float(
            150.0 * completed_pct
            - 180.0 * non_timeout_failed_pct
            - 130.0 * timeout_pct
            - 170.0 * stuck_timeout_pct
            - 1600.0 * completion_gap
            - 1900.0 * collision_excess
            - 950.0 * red_excess
            - 480.0 * proximity_excess
            - 340.0 * collisions_per_ep
            - 95.0 * closed_per_ep
            - 44.0 * proximity_per_ep
            - 35.0 * front_gap_per_ep
            - 5.0 * queue_delay_per_ep
            - 60.0 * queue_stop_error_avg
            - 12.0 * stopped_too_far_per_ep
            - 7.5 * green_stuck_per_ep
            - 10.0 * green_stopped_far_per_ep
        )
