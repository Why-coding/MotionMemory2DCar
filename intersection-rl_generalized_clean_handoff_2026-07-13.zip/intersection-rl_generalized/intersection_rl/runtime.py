from __future__ import annotations

from pathlib import Path
from typing import Any
import warnings

import numpy as np


GEOMETRY_CONVENTION = "front_bumper_v1"


def _scalar_text(value: Any, default: str = "unknown") -> str:
    if value is None:
        return default
    array = np.asarray(value)
    if array.size != 1:
        return default
    return str(array.item())


def checkpoint_metadata(path: str | Path | None) -> dict[str, str]:
    metadata = {
        "checkpoint_format": "none",
        "actor_head": "none",
        "action_distribution": "none",
        "checkpoint_geometry_convention": "none",
    }
    if path is None:
        return metadata

    checkpoint = Path(path)
    if not checkpoint.exists():
        return {key: "missing" for key in metadata}

    with np.load(checkpoint, allow_pickle=False) as data:
        metadata["checkpoint_format"] = (
            _scalar_text(data["format"], "legacy_mlp_npz")
            if "format" in data.files
            else "legacy_mlp_npz"
        )
        metadata["actor_head"] = (
            _scalar_text(data["actor_head"], "legacy_or_unknown")
            if "actor_head" in data.files
            else "legacy_or_unknown"
        )
        metadata["action_distribution"] = (
            _scalar_text(data["actor_distribution"], "legacy_gaussian")
            if "actor_distribution" in data.files
            else "legacy_gaussian"
        )
        metadata["checkpoint_geometry_convention"] = (
            _scalar_text(data["geometry_convention"], "unstamped_legacy")
            if "geometry_convention" in data.files
            else "unstamped_legacy"
        )
    return metadata


def assert_project_runtime(project_root: str | Path) -> Path:
    import intersection_rl

    expected_package = Path(project_root).resolve() / "intersection_rl"
    package_file = Path(intersection_rl.__file__).resolve()
    if not package_file.is_relative_to(expected_package):
        raise RuntimeError(
            "Wrong intersection_rl package imported: "
            f"resolved={package_file} expected_under={expected_package}. "
            "Run through this repository's launchers or reinstall it editable."
        )
    actual_convention = getattr(intersection_rl, "GEOMETRY_CONVENTION", None)
    if actual_convention != GEOMETRY_CONVENTION:
        raise RuntimeError(
            "Geometry convention mismatch: "
            f"package={actual_convention!r} launcher={GEOMETRY_CONVENTION!r}."
        )
    return package_file


def warn_on_checkpoint_geometry(metadata: dict[str, str], checkpoint: str | Path) -> None:
    checkpoint_convention = metadata["checkpoint_geometry_convention"]
    if checkpoint_convention in {"none", "missing", "unstamped_legacy"}:
        return
    if checkpoint_convention != GEOMETRY_CONVENTION:
        warnings.warn(
            f"Checkpoint {checkpoint} uses geometry_convention={checkpoint_convention!r}; "
            f"runtime uses {GEOMETRY_CONVENTION!r}.",
            RuntimeWarning,
            stacklevel=2,
        )


def runtime_provenance(
    project_root: str | Path,
    checkpoint: str | Path | None = None,
) -> dict[str, str]:
    package_file = assert_project_runtime(project_root)
    metadata = checkpoint_metadata(checkpoint)
    if checkpoint is not None:
        warn_on_checkpoint_geometry(metadata, checkpoint)
    return {
        "package_path": str(package_file),
        "geometry_convention": GEOMETRY_CONVENTION,
        "checkpoint_path": str(checkpoint) if checkpoint is not None else "none",
        **metadata,
    }


def print_provenance_banner(
    *,
    command: str,
    project_root: str | Path,
    checkpoint: str | Path | None = None,
    seed: int | None = None,
    seeds: str | None = None,
    all_red_seconds: float | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, str]:
    provenance = runtime_provenance(project_root, checkpoint)
    fields: dict[str, Any] = {
        "command": command,
        **provenance,
        "seed": seed if seed is not None else "none",
        "seeds": seeds if seeds is not None else "none",
        "all_red_seconds": all_red_seconds if all_red_seconds is not None else "none",
    }
    if extra:
        fields.update(extra)
    print("run_provenance " + " ".join(f"{key}={value}" for key, value in fields.items()))
    return provenance
