import sys

import pytest

from intersection_rl.config import EnvConfig
from intersection_rl.multitask import DEFAULT_TASKS, MultiTaskIntersectionEnv, ScenarioTask
from scripts import train_graph_multitask as training


def test_multitask_clearance_range_is_seeded_and_bounded():
    task = ScenarioTask(
        "clearance_probe",
        2,
        2,
        4,
        4,
        10.0,
        10.0,
        signal_mode="redgreen",
    )
    config = EnvConfig(
        max_cars=4,
        min_cars=4,
        signal_all_red_seconds=3.5,
        signal_all_red_seconds_min=3.5,
        signal_all_red_seconds_max=4.5,
    )
    env = MultiTaskIntersectionEnv(config, tasks=(task,))

    env.reset(seed=21)
    first = env.config.signal_all_red_seconds
    env.reset(seed=22)
    second = env.config.signal_all_red_seconds
    env.reset(seed=21)
    repeated = env.config.signal_all_red_seconds

    assert 3.5 <= first <= 4.5
    assert 3.5 <= second <= 4.5
    assert first != second
    assert repeated == pytest.approx(first)


def test_front_bumper_polish_defaults_and_task_weights(monkeypatch):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "train_graph_multitask.py",
            "train",
            "--behavior-stage",
            "front_bumper_polish",
            "--reference-checkpoint",
            "checkpoints/keeper.npz",
        ],
    )
    args = training.parse_args()
    training.apply_behavior_stage_defaults(args)

    assert args.action_distribution == "squashed_mixture"
    assert args.all_red_seconds == pytest.approx(3.5)
    assert args.all_red_seconds_min == pytest.approx(3.5)
    assert args.all_red_seconds_max == pytest.approx(4.5)
    assert args.validation_all_red_seconds == pytest.approx(3.5)
    assert args.validation_regime_gates
    assert args.creep_reapproach_label
    assert args.queue_action_target
    assert args.red_action_target_only
    assert args.red_target_queue_lead_margin == pytest.approx(0.8)
    assert args.red_target_min_brake == pytest.approx(0.0)
    assert args.creep_reapproach_max_speed == pytest.approx(0.5)
    assert args.mixture_gate_learning_rate == pytest.approx(1e-3)
    assert args.mixture_gate_unfreeze_argmax_threshold == pytest.approx(0.95)
    assert args.mixture_gate_separate_optimizer
    assert args.mixture_gate_freeze_ppo_until_saturated
    assert args.reference_kl_green_only
    assert args.go_component_reference_kl_coefficient == pytest.approx(1.0)

    tasks = tuple(
        task for task in training.DEFAULT_TASKS if task.name in set(args.training_tasks)
    )
    weighted = training.apply_density_task_weights(tasks, args.behavior_stage)
    weights = {task.name: task.weight for task in weighted}
    assert sum(weights.values()) == pytest.approx(1.0)
    stress_names = {
        name
        for name in weights
        if name.startswith("dense_green_discharge_3")
        or name.startswith("dense_red_queue_3")
        or name.startswith("dense_redgreen_release_3")
    }
    assert sum(weights[name] for name in stress_names) == pytest.approx(0.405)


def test_red_creep_component_defaults_and_task_weights(monkeypatch):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "train_graph_multitask.py",
            "train",
            "--behavior-stage",
            "red_creep_component",
            "--reference-checkpoint",
            "checkpoints/keeper.npz",
        ],
    )
    args = training.parse_args()
    training.apply_behavior_stage_defaults(args)

    assert args.action_distribution == "squashed_mixture"
    assert args.value_coefficient == pytest.approx(0.1)
    assert args.value_loss_huber_beta == pytest.approx(20.0)
    assert args.validation_regime_gates
    assert args.creep_reapproach_label
    assert args.red_action_target_only
    assert args.red_target_crawl_speed == pytest.approx(1.5)
    assert args.intent_action_loss_coefficient == pytest.approx(0.05)
    assert args.intent_action_loss_final_coefficient == pytest.approx(0.05)
    assert args.intent_action_loss_decay_updates == 0
    assert args.go_component_reference_kl_coefficient == pytest.approx(1.0)
    assert args.mixture_gate_prewarm_steps == 3000
    assert args.stop_after_mixture_prewarm

    tasks = tuple(
        task for task in training.DEFAULT_TASKS if task.name in set(args.training_tasks)
    )
    weighted = training.apply_density_task_weights(tasks, args.behavior_stage)
    weights = {task.name: task.weight for task in weighted}
    assert sum(weights.values()) == pytest.approx(1.0)
    for lanes in (2, 3, 4):
        task = next(item for item in weighted if item.name == f"red_creep_far_stationary_{lanes}l")
        assert task.weight == pytest.approx(0.06)
        assert task.randomize_longitudinal_positions
        assert task.initial_green_only
        assert task.closed_spawn_speed_min == pytest.approx(0.0)
        assert task.closed_spawn_speed_max == pytest.approx(0.0)


def test_red_creep_component_can_explicitly_continue_after_accepted_prewarm(monkeypatch):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "train_graph_multitask.py",
            "train",
            "--behavior-stage",
            "red_creep_component",
            "--reference-checkpoint",
            "checkpoints/keeper.npz",
            "--continue-after-mixture-prewarm",
            "--mixture-gate-prewarm-steps",
            "-1",
        ],
    )
    args = training.parse_args()
    training.apply_behavior_stage_defaults(args)

    assert not args.stop_after_mixture_prewarm
    assert args.mixture_gate_prewarm_steps == -1



def test_far_stationary_creep_task_applies_random_red_spawn_distribution():
    task = next(
        item for item in DEFAULT_TASKS if item.name == "red_creep_far_stationary_3l"
    )
    env = MultiTaskIntersectionEnv(
        EnvConfig(max_cars=50, min_cars=1, signal_all_red_seconds=3.5),
        tasks=(task,),
    )
    try:
        _, info = env.reset(seed=730)
        assert info["signal_phase"].endswith("_GREEN")
        assert env.config.spawn_randomize_longitudinal_positions
        assert env.config.randomize_initial_green_phase_only
        assert len(env.vehicles) == 6
        assert all(not env._movement_permitted(vehicle) for vehicle in env.vehicles)
        assert all(vehicle.speed == pytest.approx(0.0) for vehicle in env.vehicles)
        distances = [env._distance_to_stop_line(vehicle) for vehicle in env.vehicles]
        assert min(distances) >= 10.0
        assert max(distances) <= 32.0
    finally:
        env.close()
