import numpy as np

from intersection_rl.config import EnvConfig
from intersection_rl.cli import curriculum_stage_config, rule_based_actions
from intersection_rl.env import IntersectionEnv
from intersection_rl.graph_observation import GraphObserver
from intersection_rl.geometry import Polyline, build_route_path


def make_env():
    return IntersectionEnv(
        EnvConfig(
            min_cars=8,
            max_cars=12,
            episode_seconds=2.0,
            seed=3,
        )
    )


def rebuild_vehicle_path(env, vehicle):
    vehicle.destination_lane = min(
        vehicle.destination_lane, env.episode_lanes_per_approach - 1
    )
    vehicle.path = Polyline(
        build_route_path(
            vehicle.approach,
            vehicle.lane,
            vehicle.route,
            env.config.lane_width,
            env.config.road_length,
            env.config.intersection_half_size,
            env.episode_lanes_per_approach,
            vehicle.destination_lane,
        )
    )
    vehicle.stop_progress, _ = vehicle.path.project(vehicle.path.points[1])


def set_front_distance_to_stop(env, vehicle, distance_to_stop):
    vehicle.progress = env._center_progress_for_front_distance(vehicle, distance_to_stop)


def test_reset_has_expected_shapes_and_vehicle_count():
    env = make_env()
    observation, info = env.reset(seed=3)
    assert observation.shape == (12, env.OBSERVATION_SIZE)
    assert observation.dtype == np.float32
    assert 8 <= info["active_mask"].sum() <= 12
    assert env.observation_space.contains(observation)


def test_step_returns_per_vehicle_reward():
    env = make_env()
    env.reset(seed=4)
    action = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    observation, reward, terminated, truncated, info = env.step(action)
    assert observation.shape == (12, env.OBSERVATION_SIZE)
    assert reward.shape == (12,)
    assert isinstance(terminated, bool)
    assert isinstance(truncated, bool)
    assert "collisions" in info
    assert "red_light_violations" in info
    assert "yellow_light_violations" in info
    assert "closed_signal_violations" in info
    assert "failed_vehicles" in info


def test_seeded_reset_is_reproducible():
    env = make_env()
    first, _ = env.reset(seed=9)
    second, _ = env.reset(seed=9)
    np.testing.assert_allclose(first, second)


def test_stop_line_distance_uses_front_bumper_in_observers():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=101))
    env.reset(seed=101)
    vehicle = env.vehicles[0]
    set_front_distance_to_stop(env, vehicle, 0.75)
    vehicle.speed = 0.0

    observation = env._get_observation()
    graph = GraphObserver(max_vehicle_nodes=env.config.max_cars).encode(env)

    assert np.isclose(env._distance_to_stop_line(vehicle), 0.75)
    assert np.isclose(observation[vehicle.vehicle_id, 2], 0.75 / env.config.road_length)
    assert np.isclose(graph["ego"][vehicle.vehicle_id, 2], 0.75 / env.config.road_length)
    assert graph["ego"][vehicle.vehicle_id, 3] == 0.0

    set_front_distance_to_stop(env, vehicle, -0.10)
    graph = GraphObserver(max_vehicle_nodes=env.config.max_cars).encode(env)

    assert env._has_crossed_stop_line(vehicle)
    assert graph["ego"][vehicle.vehicle_id, 3] == 1.0


def test_spawn_lead_gap_is_front_bumper_referenced():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            spawn_signal_filter="closed",
            spawn_lead_gap=0.2,
            seed=102,
        )
    )

    env.reset(seed=102)
    vehicle = env.vehicles[0]

    assert np.isclose(env._distance_to_stop_line(vehicle), 0.2)
    assert env._front_progress(vehicle) < vehicle.stop_progress


def test_red_light_violation_uses_front_bumper_crossing():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            safety_filter_enabled=False,
            seed=103,
        )
    )
    env.reset(seed=103)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.lane = min(1, env.episode_lanes_per_approach - 1)
    vehicle.destination_lane = vehicle.lane
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 0.02)
    vehicle.speed = 1.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    _, _, terminated, _, info = env.step(actions)

    assert info["red_light_violations"] == 1
    assert info["closed_signal_violations"] == 1
    assert not vehicle.active
    assert vehicle.failed
    assert terminated


def test_inside_intersection_uses_front_entry_and_rear_exit():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=104))
    env.reset(seed=104)
    vehicle = env.vehicles[0]

    set_front_distance_to_stop(env, vehicle, 0.01)
    assert not env._inside_intersection(vehicle)

    set_front_distance_to_stop(env, vehicle, -0.01)
    assert env._inside_intersection(vehicle)

    far_exit = vehicle.stop_progress + 2.0 * env.config.intersection_half_size
    vehicle.progress = far_exit + env._half_vehicle_length() + 0.01
    assert not env._inside_intersection(vehicle)


def test_completion_waits_until_rear_bumper_clears_path_end():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=105))
    env.reset(seed=105)
    vehicle = env.vehicles[0]
    vehicle.progress = vehicle.path.length + env._half_vehicle_length() - 0.01
    vehicle.speed = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    _, _, _, _, info = env.step(actions)

    assert vehicle.active
    assert info["completed_delta"] == 0

    vehicle.speed = 1.0
    _, _, _, _, info = env.step(actions)

    assert not vehicle.active
    assert info["completed_delta"] == 1


def test_episode_truncates():
    env = make_env()
    env.reset(seed=2)
    action = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    truncated = False
    for _ in range(env.config.max_steps):
        _, _, _, truncated, _ = env.step(action)
    assert truncated


def test_rule_based_driver_returns_valid_actions():
    env = make_env()
    env.reset(seed=5)
    actions = rule_based_actions(env)
    assert env.action_space.contains(actions)


def test_four_lane_environment_supports_exact_car_count():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=4, min_cars=24, max_cars=24, seed=4
        )
    )
    observation, info = env.reset(seed=4)
    assert observation.shape == (24, env.OBSERVATION_SIZE)
    assert info["active_mask"].sum() == 24
    assert env.config.intersection_half_size >= 16.0


def test_renderer_background_is_light_blue():
    env = IntersectionEnv(
        EnvConfig(min_cars=1, max_cars=1), render_mode="rgb_array"
    )
    env.reset(seed=1)
    frame = env.render()
    np.testing.assert_array_equal(frame[0, 0], [173, 216, 230])
    env.close()


def test_five_lane_environment_supports_user_selected_car_count():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=5, min_cars=32, max_cars=32, seed=5
        )
    )
    observation, info = env.reset(seed=5)
    assert observation.shape == (32, env.OBSERVATION_SIZE)
    assert info["active_mask"].sum() == 32
    assert env.config.intersection_half_size >= 20.0


def test_protected_left_phase_separates_left_and_through_movements():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=True,
            seed=1,
        )
    )
    env.reset(seed=1)
    left, through = env.vehicles
    left.approach = through.approach = "N"
    left.route = "left"
    through.route = "straight"
    assert env._signal_phase()[0] == "NS_LEFT_GREEN"
    assert env._movement_has_green(left)
    assert not env._movement_has_green(through)
    env.elapsed_seconds = env.config.left_signal_green_seconds
    assert env._signal_phase()[0] == "NS_GREEN"
    assert not env._movement_has_green(left)
    assert env._movement_has_green(through)



def test_protected_left_all_red_separates_left_and_through_movements():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=True,
            signal_yellow_seconds=0.0,
            signal_all_red_seconds=2.0,
            seed=1,
        )
    )
    env.reset(seed=1)
    left, through = env.vehicles
    left.approach = through.approach = "N"
    left.route = "left"
    through.route = "straight"
    assert env._signal_phase()[0] == "NS_LEFT_GREEN"
    env.elapsed_seconds = env.config.left_signal_green_seconds
    assert env._signal_phase()[0] == "NS_LEFT_ALL_RED"
    assert not env._movement_has_green(left)
    assert not env._movement_has_green(through)
    env.elapsed_seconds = env.config.left_signal_green_seconds + env.config.signal_all_red_seconds
    assert env._signal_phase()[0] == "NS_GREEN"
    assert not env._movement_has_green(left)
    assert env._movement_has_green(through)


def test_all_red_crossing_after_phase_change_is_violation():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            signal_yellow_seconds=0.0,
            signal_all_red_seconds=2.0,
            safety_filter_enabled=False,
            seed=11,
        )
    )
    env.reset(seed=11)
    vehicle = env.vehicles[0]
    vehicle.approach = "N"
    vehicle.route = "left"
    vehicle.lane = 0
    vehicle.destination_lane = 0
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 0.05)
    vehicle.speed = 1.0
    env.elapsed_seconds = env.config.left_signal_green_seconds + 0.2
    env._sync_signal_phase_tracker()
    assert env._signal_phase()[0] == "NS_LEFT_ALL_RED"

    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    _, _, _, _, info = env.step(actions)

    assert info["red_light_violations"] == 1
    assert not env._clearance_eligible[vehicle.vehicle_id]


def test_vehicle_crossed_before_all_red_is_clearance_eligible_and_go_labeled():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            signal_yellow_seconds=0.0,
            signal_all_red_seconds=2.0,
            safety_filter_enabled=False,
            seed=12,
        )
    )
    env.reset(seed=12)
    vehicle = env.vehicles[0]
    vehicle.approach = "N"
    vehicle.route = "left"
    vehicle.lane = 0
    vehicle.destination_lane = 0
    rebuild_vehicle_path(env, vehicle)
    vehicle.progress = vehicle.stop_progress + 0.1
    vehicle.speed = 4.0
    env.elapsed_seconds = env.config.left_signal_green_seconds
    env._update_clearance_eligibility_on_phase_change()
    env._sync_signal_phase_tracker()

    assert env._signal_phase()[0] == "NS_LEFT_ALL_RED"
    assert env._clearance_eligible[vehicle.vehicle_id]
    assert not env._movement_has_green(vehicle)
    assert env._movement_permitted(vehicle)
    assert env._intent_labels()[vehicle.vehicle_id] == env.INTENT_GO


def test_clearance_eligibility_persists_if_next_green_arrives_before_exit():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            signal_yellow_seconds=0.0,
            signal_all_red_seconds=0.2,
            safety_filter_enabled=False,
            seed=13,
        )
    )
    env.reset(seed=13)
    vehicle = env.vehicles[0]
    vehicle.approach = "N"
    vehicle.route = "left"
    vehicle.lane = 0
    vehicle.destination_lane = 0
    rebuild_vehicle_path(env, vehicle)
    vehicle.progress = vehicle.stop_progress + 0.1
    vehicle.speed = 0.0
    env.elapsed_seconds = env.config.left_signal_green_seconds
    env._update_clearance_eligibility_on_phase_change()
    env._sync_signal_phase_tracker()
    assert env._signal_phase()[0] == "NS_LEFT_ALL_RED"
    assert env._clearance_eligible[vehicle.vehicle_id]

    env.elapsed_seconds = env.config.left_signal_green_seconds + env.config.signal_all_red_seconds
    env._sync_signal_phase_tracker()
    assert env._signal_phase()[0] == "NS_GREEN"
    assert env._clearance_eligible[vehicle.vehicle_id]
    assert env._movement_permitted(vehicle)


def test_dilemma_vehicle_is_latched_once_and_crosses_all_red_legally():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            signal_yellow_seconds=0.0,
            signal_all_red_seconds=3.5,
            safety_filter_enabled=False,
            seed=14,
        )
    )
    env.reset(seed=14)
    vehicle = env.vehicles[0]
    vehicle.approach = "N"
    vehicle.route = "left"
    vehicle.lane = 0
    vehicle.destination_lane = 0
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 0.18)
    vehicle.speed = 6.8
    env.elapsed_seconds = env.config.left_signal_green_seconds
    env._sync_signal_phase_tracker()

    env._update_clearance_eligibility_on_phase_change("NS_LEFT_GREEN")

    assert env._clearance_eligible[vehicle.vehicle_id]
    assert env._dilemma_clearance_eligible[vehicle.vehicle_id]
    assert env._movement_permitted(vehicle)

    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    _, _, _, _, info = env.step(actions)

    assert env._has_crossed_stop_line(vehicle)
    assert info["red_light_violations"] == 0
    assert not vehicle.crossed_on_red


def test_dilemma_latch_uses_physical_braking_not_comfort_envelope():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            signal_yellow_seconds=0.0,
            signal_all_red_seconds=3.5,
            intent_stop_label_brake_safety_factor=1.35,
            seed=15,
        )
    )
    env.reset(seed=15)
    vehicle = env.vehicles[0]
    vehicle.approach = "N"
    vehicle.route = "left"
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 2.2)
    vehicle.speed = 4.0
    env.elapsed_seconds = env.config.left_signal_green_seconds
    env._sync_signal_phase_tracker()

    env._update_clearance_eligibility_on_phase_change("NS_LEFT_GREEN")

    assert not env._physically_unable_to_stop_before_line(vehicle)
    assert not env._clearance_eligible[vehicle.vehicle_id]


def test_stoppable_at_transition_cannot_gain_dilemma_eligibility_later():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            signal_yellow_seconds=0.0,
            signal_all_red_seconds=3.5,
            safety_filter_enabled=False,
            seed=16,
        )
    )
    env.reset(seed=16)
    vehicle = env.vehicles[0]
    vehicle.approach = "N"
    vehicle.route = "left"
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 5.0)
    vehicle.speed = 4.0
    env.elapsed_seconds = env.config.left_signal_green_seconds
    env._sync_signal_phase_tracker()
    env._update_clearance_eligibility_on_phase_change("NS_LEFT_GREEN")
    assert not env._clearance_eligible[vehicle.vehicle_id]

    set_front_distance_to_stop(env, vehicle, 0.1)
    vehicle.speed = 8.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    _, _, _, _, info = env.step(actions)

    assert not env._clearance_eligible[vehicle.vehicle_id]
    assert info["red_light_violations"] == 1


def test_unprotected_left_detects_opposing_straight_conflict():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=False,
            seed=2,
        )
    )
    env.reset(seed=2)
    left, opposing = env.vehicles
    left.approach = "N"
    left.route = "left"
    opposing.approach = "S"
    opposing.route = "straight"
    set_front_distance_to_stop(env, opposing, 5.0)
    opposing.speed = 5.0
    assert env._movement_has_green(left)
    assert env._left_turn_conflict(left)


def test_destination_lanes_are_randomized_across_traffic():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=5,
            min_cars=40,
            max_cars=40,
            seed=12,
        )
    )
    env.reset(seed=12)
    destination_lanes = {vehicle.destination_lane for vehicle in env.vehicles}
    assert len(destination_lanes) >= 3
    assert all(0 <= lane < 5 for lane in destination_lanes)


def test_lateral_action_moves_vehicle_toward_route_center():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=3))
    env.reset(seed=3)
    vehicle = env.vehicles[0]
    vehicle.lateral_offset = 0.5
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [0.0, -1.0]  # Coast and steer left.
    env.step(actions)
    assert vehicle.lateral_offset < 0.5


def configure_right_on_red_conflict(env):
    right, crossing = env.vehicles[:2]
    right.approach = "N"
    right.route = "right"
    right.lane = env.config.lanes_per_approach - 1
    crossing.approach = "E"
    crossing.route = "straight"
    set_front_distance_to_stop(env, crossing, 5.0)
    crossing.speed = 5.0
    env.elapsed_seconds = env.config.signal_green_seconds + env.config.signal_yellow_seconds
    return right, crossing


def test_clear_legal_stall_is_tracked():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=False,
            legal_stall_grace_seconds=0.4,
            seed=83,
        )
    )
    env.reset(seed=83)
    vehicle = env.vehicles[0]
    vehicle.approach = "N"
    vehicle.route = "straight"
    vehicle.lane = 0
    vehicle.destination_lane = 0
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 12.0)
    vehicle.speed = 0.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    info = {}
    for _ in range(4):
        _, _, _, _, info = env.step(actions)

    assert vehicle.legal_stall_seconds > env.config.legal_stall_grace_seconds
    assert info["legal_stall_vehicles"] == 1
    assert info["max_legal_stall_seconds"] > env.config.legal_stall_grace_seconds


def test_closed_signal_rewards_slow_queue_progress_over_far_idle():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            safety_filter_enabled=False,
            seed=84,
        )
    )
    env.reset(seed=84)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.lane = 0
    vehicle.destination_lane = 0
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 20.0)
    vehicle.speed = 1.0
    env.elapsed_seconds = 0.0
    slow = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    idle = np.zeros_like(slow)
    slow[vehicle.vehicle_id] = [0.0, 0.0]
    idle[vehicle.vehicle_id] = [-1.0, 0.0]

    _, slow_reward, _, _, _ = env.step(slow)
    env.reset(seed=84)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.lane = 0
    vehicle.destination_lane = 0
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 20.0)
    vehicle.speed = 0.0
    env.elapsed_seconds = 0.0
    _, idle_reward, _, _, _ = env.step(idle)

    assert slow_reward[vehicle.vehicle_id] > idle_reward[vehicle.vehicle_id]




def test_closed_signal_potential_rewards_progress_toward_stop_target():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            safety_filter_enabled=False,
            closed_signal_stop_potential_coefficient=0.5,
            closed_signal_stop_potential_gamma=1.0,
            seed=85,
        )
    )
    env.reset(seed=85)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.lane = 0
    vehicle.destination_lane = 0
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 20.0)
    vehicle.speed = 1.0
    env.elapsed_seconds = 0.0
    slow = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    idle = np.zeros_like(slow)
    slow[vehicle.vehicle_id] = [0.0, 0.0]
    idle[vehicle.vehicle_id] = [-1.0, 0.0]

    _, slow_reward, _, _, _ = env.step(slow)
    env.reset(seed=85)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.lane = 0
    vehicle.destination_lane = 0
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 20.0)
    vehicle.speed = 0.0
    env.elapsed_seconds = 0.0
    _, idle_reward, _, _, _ = env.step(idle)

    assert slow_reward[vehicle.vehicle_id] > idle_reward[vehicle.vehicle_id]


def configure_closed_straight_vehicle(env, vehicle, distance_to_stop, speed):
    vehicle.approach = "E"
    vehicle.route = "straight"
    vehicle.lane = min(1, env.episode_lanes_per_approach - 1)
    vehicle.destination_lane = vehicle.lane
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, distance_to_stop)
    vehicle.speed = speed
    env.elapsed_seconds = 0.0


def test_far_upstream_closed_red_is_unsupervised_for_gate():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            safety_filter_enabled=False,
            seed=190,
        )
    )
    env.reset(seed=190)
    vehicle = env.vehicles[0]
    configure_closed_straight_vehicle(env, vehicle, distance_to_stop=35.0, speed=2.0)

    labels = env._intent_labels()

    assert labels[vehicle.vehicle_id] == env.INTENT_IGNORE


def test_closed_red_enters_stop_label_inside_braking_envelope():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            safety_filter_enabled=False,
            seed=191,
        )
    )
    env.reset(seed=191)
    vehicle = env.vehicles[0]
    configure_closed_straight_vehicle(env, vehicle, distance_to_stop=20.0, speed=13.0)

    labels = env._intent_labels()

    assert labels[vehicle.vehicle_id] == env.INTENT_STOP


def test_closed_red_stop_label_latches_until_green_or_hold():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            safety_filter_enabled=False,
            seed=192,
        )
    )
    env.reset(seed=192)
    vehicle = env.vehicles[0]
    configure_closed_straight_vehicle(env, vehicle, distance_to_stop=20.0, speed=13.0)
    assert env._intent_labels()[vehicle.vehicle_id] == env.INTENT_STOP

    set_front_distance_to_stop(env, vehicle, 35.0)
    vehicle.speed = 0.0
    assert env._intent_labels()[vehicle.vehicle_id] == env.INTENT_STOP

    env.elapsed_seconds = env.config.left_signal_green_seconds + 0.1 + env._signal_cycle_seconds() / 2.0
    assert env._intent_labels()[vehicle.vehicle_id] == env.INTENT_GO
    assert not env._intent_stop_latched[vehicle.vehicle_id]


def test_closed_red_far_stopped_vehicle_uses_creep_route_then_brake_and_hold():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            safety_filter_enabled=False,
            intent_creep_reapproach_enabled=True,
            seed=194,
        )
    )
    env.reset(seed=194)
    vehicle = env.vehicles[0]
    configure_closed_straight_vehicle(env, vehicle, distance_to_stop=20.0, speed=13.0)
    assert env._intent_labels()[vehicle.vehicle_id] == env.INTENT_STOP

    set_front_distance_to_stop(env, vehicle, 8.0)
    vehicle.speed = 0.0
    labels = env._intent_labels()
    assert labels[vehicle.vehicle_id] == env.INTENT_STOP
    assert env._intent_stop_latched[vehicle.vehicle_id]
    assert env._intent_creep_latched[vehicle.vehicle_id]
    assert env._component_route_labels(labels)[vehicle.vehicle_id] == 1

    set_front_distance_to_stop(env, vehicle, 4.0)
    vehicle.speed = 6.0
    labels = env._intent_labels()
    assert labels[vehicle.vehicle_id] == env.INTENT_STOP
    assert env._component_route_labels(labels)[vehicle.vehicle_id] == 0

    set_front_distance_to_stop(env, vehicle, 0.8)
    vehicle.speed = 0.0
    assert env._intent_labels()[vehicle.vehicle_id] == env.INTENT_HOLD
    assert not env._intent_creep_latched[vehicle.vehicle_id]

    env.elapsed_seconds = env.config.left_signal_green_seconds + 0.1 + env._signal_cycle_seconds() / 2.0
    labels = env._intent_labels()
    assert labels[vehicle.vehicle_id] == env.INTENT_GO
    assert env._component_route_labels(labels)[vehicle.vehicle_id] == 2
    assert not env._intent_stop_latched[vehicle.vehicle_id]


def test_fast_far_red_state_is_route_masked_until_braking_engages():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            safety_filter_enabled=False,
            intent_creep_reapproach_enabled=True,
            seed=195,
        )
    )
    env.reset(seed=195)
    vehicle = env.vehicles[0]
    configure_closed_straight_vehicle(env, vehicle, distance_to_stop=40.0, speed=8.0)
    env._intent_stop_latched[vehicle.vehicle_id] = False
    env._intent_creep_latched[vehicle.vehicle_id] = False

    labels = env._intent_labels()

    assert labels[vehicle.vehicle_id] == env.INTENT_IGNORE
    assert env._component_route_labels(labels)[vehicle.vehicle_id] == -1
    assert not env._intent_creep_latched[vehicle.vehicle_id]


def test_closed_signal_target_uses_line_when_lead_is_far_beyond_it():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            intent_creep_reapproach_enabled=True,
            seed=196,
        )
    )
    env.reset(seed=196)
    follower, lead = env.vehicles[:2]
    configure_closed_straight_vehicle(env, follower, distance_to_stop=0.33, speed=1.5)
    configure_closed_straight_vehicle(env, lead, distance_to_stop=-20.0, speed=2.0)

    target_error, follows_lead = env._closed_signal_stop_target_error(follower)
    labels = np.full(env.config.max_cars, env.INTENT_STOP, dtype=np.int64)

    assert np.isclose(target_error, 0.33 - 0.55)
    assert not follows_lead
    assert env._component_route_labels(labels)[follower.vehicle_id] == 0


def test_closed_signal_target_uses_lead_when_queue_gap_is_nearer():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            seed=197,
        )
    )
    env.reset(seed=197)
    follower, lead = env.vehicles[:2]
    configure_closed_straight_vehicle(env, follower, distance_to_stop=10.0, speed=0.0)
    configure_closed_straight_vehicle(env, lead, distance_to_stop=2.0, speed=0.0)

    target_error, follows_lead = env._closed_signal_stop_target_error(follower)

    assert np.isclose(target_error, 8.0 - 7.25)
    assert follows_lead


def test_creep_component_route_is_observable_and_not_latch_dependent():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            intent_creep_reapproach_enabled=True,
            intent_creep_route_max_speed=2.0,
            seed=196,
        )
    )
    env.reset(seed=196)
    vehicle = env.vehicles[0]
    configure_closed_straight_vehicle(env, vehicle, distance_to_stop=4.0, speed=1.5)
    env._intent_creep_latched[vehicle.vehicle_id] = False
    labels = np.full(env.config.max_cars, env.INTENT_STOP, dtype=np.int64)

    assert env._component_route_labels(labels)[vehicle.vehicle_id] == 1

    vehicle.speed = 2.1
    assert env._component_route_labels(labels)[vehicle.vehicle_id] == 0

    set_front_distance_to_stop(env, vehicle, 1.5)
    vehicle.speed = 0.5
    assert env._component_route_labels(labels)[vehicle.vehicle_id] == 0


def test_three_deep_queue_is_go_labeled_together_on_green():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=3,
            max_cars=3,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            safety_filter_enabled=False,
            intersection_reservation_enabled=False,
            seed=195,
        )
    )
    env.reset(seed=195)
    lead, second, third = env.vehicles[:3]
    for vehicle in (lead, second, third):
        vehicle.approach = "E"
        vehicle.route = "straight"
        vehicle.lane = 1
        vehicle.destination_lane = 1
        rebuild_vehicle_path(env, vehicle)
        vehicle.speed = 0.0
        env._intent_stop_latched[vehicle.vehicle_id] = True
    set_front_distance_to_stop(env, lead, 0.8)
    second.progress = lead.progress - 7.25
    third.progress = second.progress - 7.25
    env.elapsed_seconds = (
        env._signal_cycle_seconds() / 2.0
        + env.config.left_signal_green_seconds
        + 0.1
    )

    labels = env._intent_labels()

    assert list(labels[:3]) == [env.INTENT_GO, env.INTENT_GO, env.INTENT_GO]
    assert not env._intent_stop_latched[:3].any()


def test_closed_red_follower_label_uses_front_vehicle_target():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=True,
            allow_right_on_red=False,
            right_turns_enabled=False,
            safety_filter_enabled=False,
            seed=193,
        )
    )
    env.reset(seed=193)
    lead, follower = env.vehicles[:2]
    for vehicle in (lead, follower):
        vehicle.approach = "E"
        vehicle.route = "straight"
        vehicle.lane = min(1, env.episode_lanes_per_approach - 1)
        vehicle.destination_lane = vehicle.lane
        rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, lead, 20.0)
    lead.speed = 0.0
    follower.progress = lead.progress - 10.0
    follower.speed = 6.0
    env.elapsed_seconds = 0.0

    labels = env._intent_labels()

    assert labels[follower.vehicle_id] == env.INTENT_STOP

def test_closed_signal_approach_penalizes_acceleration_before_red_violation():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            seed=11,
        )
    )
    env.reset(seed=11)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    set_front_distance_to_stop(env, vehicle, 6.0)
    vehicle.speed = 2.0
    env.elapsed_seconds = 0.0
    accelerate = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    brake = np.zeros_like(accelerate)
    accelerate[vehicle.vehicle_id] = [1.0, 0.0]
    brake[vehicle.vehicle_id] = [-1.0, 0.0]

    _, accelerate_reward, _, _, _ = env.step(accelerate)
    env.reset(seed=11)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    set_front_distance_to_stop(env, vehicle, 6.0)
    vehicle.speed = 2.0
    env.elapsed_seconds = 0.0
    _, brake_reward, _, _, _ = env.step(brake)

    assert brake_reward[vehicle.vehicle_id] > accelerate_reward[vehicle.vehicle_id]


def test_safety_filter_overrides_unsafe_red_light_acceleration():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            safety_filter_enabled=True,
            seed=13,
        )
    )
    env.reset(seed=13)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    set_front_distance_to_stop(env, vehicle, 4.0)
    vehicle.speed = 5.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [1.0, 0.0]

    _, rewards, _, _, info = env.step(actions)

    assert info["safety_overrides"] == 1
    assert info["unsafe_requests"] == 1
    assert vehicle.acceleration < 0.0
    assert rewards[vehicle.vehicle_id] < 0.0


def test_safety_filter_reserves_intersection_entry():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=False,
            safety_filter_enabled=True,
            seed=33,
        )
    )
    env.reset(seed=33)
    first, second = env.vehicles[:2]
    first.approach = "N"
    first.route = "straight"
    second.approach = "E"
    second.route = "straight"
    rebuild_vehicle_path(env, first)
    rebuild_vehicle_path(env, second)
    set_front_distance_to_stop(env, first, 3.0)
    first.speed = 4.0
    set_front_distance_to_stop(env, second, 4.0)
    second.speed = 4.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[second.vehicle_id] = [1.0, 0.0]

    _, _, _, _, info = env.step(actions)

    assert info["safety_overrides"] >= 1
    assert second.acceleration < 0.0


def test_safety_filter_brakes_for_occupied_intersection():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=False,
            safety_filter_enabled=True,
            seed=34,
        )
    )
    env.reset(seed=34)
    entering, inside = env.vehicles[:2]
    entering.approach = "N"
    entering.route = "straight"
    inside.approach = "E"
    inside.route = "straight"
    entering.lane = 0
    entering.destination_lane = 0
    inside.lane = 1
    inside.destination_lane = 0
    rebuild_vehicle_path(env, entering)
    rebuild_vehicle_path(env, inside)
    set_front_distance_to_stop(env, entering, 3.0)
    entering.speed = 4.0
    inside.progress = inside.stop_progress + 1.0
    inside.speed = 4.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[entering.vehicle_id] = [0.0, 0.0]

    _, _, _, _, info = env.step(actions)

    assert info["safety_overrides"] >= 1
    assert entering.acceleration < 0.0


def test_safety_filter_clamps_before_closed_stop_line():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            safety_filter_enabled=True,
            seed=35,
        )
    )
    env.reset(seed=35)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    set_front_distance_to_stop(env, vehicle, 0.02)
    vehicle.speed = 3.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [1.0, 0.0]

    _, _, _, _, info = env.step(actions)

    assert info["red_light_violations"] == 0
    assert info["safety_overrides"] == 1
    assert env._distance_to_stop_line(vehicle) > 0.0
    assert vehicle.active


def test_safety_filter_can_be_disabled_but_unsafe_request_is_penalized():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=True,
            safety_filter_enabled=False,
            seed=14,
        )
    )
    env.reset(seed=14)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    set_front_distance_to_stop(env, vehicle, 4.0)
    vehicle.speed = 5.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [1.0, 0.0]

    env.step(actions)

    assert vehicle.acceleration > 0.0


def test_observation_includes_safety_features():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=15))
    observation, _ = env.reset(seed=15)
    assert env.OBSERVATION_SIZE == 34
    assert observation.shape == (1, 34)
    assert env.observation_space.contains(observation)


def test_curriculum_stage_presets_start_easy_and_scale_up():
    first = curriculum_stage_config(1)
    last = curriculum_stage_config(5)
    assert first["max_cars"] < last["max_cars"]
    assert first["max_lanes"] < last["max_lanes"]
    assert not first["randomize_left"]
    assert last["randomize_left"]


def test_right_on_red_requires_clear_cross_traffic():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=True,
            seed=6,
        )
    )
    env.reset(seed=6)
    right, crossing = configure_right_on_red_conflict(env)
    assert env._can_turn_right_on_red(right)
    assert env._right_turn_conflict(right)
    assert not env._movement_permitted(right)
    crossing.active = False
    assert not env._right_turn_conflict(right)
    assert env._movement_permitted(right)


def test_right_on_red_can_be_disabled():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=False,
            seed=7,
        )
    )
    env.reset(seed=7)
    right, _ = configure_right_on_red_conflict(env)
    assert not env._can_turn_right_on_red(right)
    assert not env._movement_permitted(right)


def test_legal_right_on_red_entry_gets_reward_without_violation():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=True,
            safety_filter_enabled=False,
            seed=81,
        )
    )
    env.reset(seed=81)
    right, crossing = configure_right_on_red_conflict(env)
    crossing.active = False
    set_front_distance_to_stop(env, right, 0.05)
    right.speed = 3.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    _, rewards, _, _, info = env.step(actions)

    assert info["right_on_red_entries"] == 1
    assert info["right_yield_violations"] == 0
    assert info["red_light_violations"] == 0
    assert info["failed_vehicles"] == 0
    assert rewards[right.vehicle_id] > 0.0


def test_unsafe_right_on_red_records_yield_violation():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=True,
            safety_filter_enabled=False,
            seed=8,
        )
    )
    env.reset(seed=8)
    right, _ = configure_right_on_red_conflict(env)
    set_front_distance_to_stop(env, right, 0.05)
    right.speed = 3.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    _, _, _, _, info = env.step(actions)
    assert info["right_yield_violations"] == 1
    assert info["red_light_violations"] == 0
    assert info["failed_vehicles"] == 1
    assert not right.active


def test_red_light_violator_is_removed_from_active_traffic():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            allow_right_on_red=False,
            safety_filter_enabled=False,
            seed=9,
        )
    )
    env.reset(seed=9)
    vehicle = env.vehicles[0]
    vehicle.approach = "E"
    vehicle.route = "straight"
    set_front_distance_to_stop(env, vehicle, 0.05)
    vehicle.speed = 3.0
    env.elapsed_seconds = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    _, _, terminated, _, info = env.step(actions)
    assert info["red_light_violations"] == 1
    assert info["yellow_light_violations"] == 0
    assert info["closed_signal_violations"] == 1
    assert info["completed_vehicles"] == 0
    assert info["failed_vehicles"] == 1
    assert not vehicle.active
    assert vehicle.failed
    assert terminated


def test_yellow_light_violation_is_separate_from_red_violation():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=1,
            max_cars=1,
            protected_left_signal=False,
            allow_right_on_red=False,
            safety_filter_enabled=False,
            seed=91,
        )
    )
    env.reset(seed=91)
    vehicle = env.vehicles[0]
    vehicle.approach = "N"
    vehicle.route = "straight"
    vehicle.lane = 0
    vehicle.destination_lane = 0
    rebuild_vehicle_path(env, vehicle)
    set_front_distance_to_stop(env, vehicle, 0.05)
    vehicle.speed = 3.0
    env.elapsed_seconds = env.config.signal_green_seconds + 0.1
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    _, _, terminated, _, info = env.step(actions)

    assert info["red_light_violations"] == 0
    assert info["yellow_light_violations"] == 1
    assert info["closed_signal_violations"] == 1
    assert info["failed_vehicles"] == 1
    assert not vehicle.active
    assert vehicle.failed
    assert terminated


def test_right_turns_spawn_only_in_rightmost_lane():
    env = IntersectionEnv(
        EnvConfig(
            lanes_per_approach=5,
            min_cars=80,
            max_cars=80,
            seed=22,
        )
    )
    env.reset(seed=22)
    right_turns = [vehicle for vehicle in env.vehicles if vehicle.route == "right"]
    assert right_turns
    assert all(vehicle.lane == 4 for vehicle in right_turns)


def test_rectangular_collision_detects_side_overlap():
    env = IntersectionEnv(EnvConfig(min_cars=2, max_cars=2, seed=30))
    env.reset(seed=30)
    first, second = env.vehicles[:2]
    second.path = first.path
    second.progress = first.progress
    second.lateral_offset = first.lateral_offset + env.config.vehicle_width * 0.4
    collisions = env._detect_collisions()
    assert collisions[first.vehicle_id]
    assert collisions[second.vehicle_id]


def test_close_rectangles_get_proximity_penalty_without_collision():
    env = IntersectionEnv(EnvConfig(min_cars=2, max_cars=2, seed=31))
    env.reset(seed=31)
    first, second = env.vehicles[:2]
    second.path = first.path
    second.approach = first.approach
    second.lane = first.lane
    second.route = first.route
    second.progress = first.progress + env.config.vehicle_length + 0.5
    second.lateral_offset = first.lateral_offset
    collisions = np.zeros(env.config.max_cars, dtype=bool)
    proximity, events = env._detect_proximity_violations(collisions)
    assert events == 1
    assert proximity[first.vehicle_id]
    assert not proximity[second.vehicle_id]


def test_far_rectangles_skip_exact_proximity_clearance():
    env = IntersectionEnv(EnvConfig(min_cars=2, max_cars=2, seed=82))
    env.reset(seed=82)
    first, second = env.vehicles[:2]
    second.path = first.path
    second.approach = first.approach
    second.lane = first.lane
    second.route = first.route
    second.progress = first.progress + 40.0
    calls = {"count": 0}
    original = env._rectangle_clearance

    def counting_clearance(a, b):
        calls["count"] += 1
        return original(a, b)

    env._rectangle_clearance = counting_clearance
    collisions = np.zeros(env.config.max_cars, dtype=bool)

    proximity, events = env._detect_proximity_violations(collisions)

    assert events == 0
    assert calls["count"] == 0
    assert not proximity[first.vehicle_id]
    assert not proximity[second.vehicle_id]


def test_adjacent_lane_rectangles_are_not_proximity_violations():
    env = IntersectionEnv(EnvConfig(lanes_per_approach=2, min_cars=2, max_cars=2, seed=32))
    env.reset(seed=32)
    first, second = env.vehicles[:2]
    second.path = first.path
    second.progress = first.progress
    second.lateral_offset = first.lateral_offset + env.config.lane_width
    collisions = np.zeros(env.config.max_cars, dtype=bool)
    proximity, events = env._detect_proximity_violations(collisions)
    assert events == 0
    assert not proximity[first.vehicle_id]
    assert not proximity[second.vehicle_id]


def test_curriculum_randomizes_episode_settings_with_fixed_shapes():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=5,
            max_cars=24,
            lanes_per_approach=5,
            curriculum_enabled=True,
            curriculum_min_lanes=2,
            curriculum_max_lanes=5,
            curriculum_min_cars=5,
            curriculum_max_cars=24,
            seed=44,
        )
    )
    shapes = set()
    lane_counts = set()
    active_counts = set()
    left_modes = set()
    right_modes = set()
    for seed in range(44, 60):
        observation, info = env.reset(seed=seed)
        shapes.add(observation.shape)
        lane_counts.add(info["episode_lanes_per_approach"])
        active_counts.add(int(info["active_mask"].sum()))
        left_modes.add(info["episode_protected_left_signal"])
        right_modes.add(info["episode_allow_right_on_red"])
    assert shapes == {(24, env.OBSERVATION_SIZE)}
    assert len(lane_counts) > 1
    assert len(active_counts) > 1
    assert left_modes == {False, True}
    assert right_modes == {False, True}


def test_stage2_curriculum_progression_scales_8_10_11_12_cars():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=8,
            max_cars=12,
            lanes_per_approach=2,
            protected_left_signal=True,
            allow_right_on_red=False,
            curriculum_enabled=True,
            curriculum_min_lanes=2,
            curriculum_max_lanes=2,
            curriculum_min_cars=8,
            curriculum_max_cars=12,
            curriculum_progression_enabled=True,
            curriculum_stage=2,
            stage2_phase1_episodes=2,
            stage2_phase2_episodes=4,
            stage2_phase3_episodes=6,
            seed=50,
        )
    )

    counts = []
    for seed in range(50, 59):
        _, info = env.reset(seed=seed)
        counts.append(int(info["active_mask"].sum()))

    assert counts[:2] == [8, 8]
    assert counts[2:4] == [10, 10]
    assert counts[4:6] == [11, 11]
    assert counts[6:8] == [12, 12]
    assert 8 <= counts[8] <= 12


def test_stage3_curriculum_progression_scales_lanes_and_right_on_red_load():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=8,
            max_cars=16,
            lanes_per_approach=3,
            protected_left_signal=True,
            allow_right_on_red=True,
            curriculum_enabled=True,
            curriculum_min_lanes=2,
            curriculum_max_lanes=3,
            curriculum_min_cars=8,
            curriculum_max_cars=16,
            curriculum_randomize_right_on_red=False,
            curriculum_progression_enabled=True,
            curriculum_stage=3,
            stage3_phase1_episodes=2,
            stage3_phase2_episodes=4,
            stage3_phase3_episodes=6,
            stage3_phase4_episodes=8,
            stage3_phase5_episodes=10,
            stage3_phase6_episodes=12,
            seed=60,
        )
    )

    states = []
    for seed in range(60, 73):
        _, info = env.reset(seed=seed)
        states.append((
            info["episode_lanes_per_approach"],
            int(info["active_mask"].sum()),
            info["episode_allow_right_on_red"],
        ))

    assert states[:2] == [(2, 8, True), (2, 8, True)]
    assert states[2:4] == [(2, 10, True), (2, 10, True)]
    assert states[4:6] == [(2, 12, True), (2, 12, True)]
    assert states[6:8] == [(3, 10, True), (3, 10, True)]
    assert states[8:10] == [(3, 12, True), (3, 12, True)]
    assert states[10:12] == [(3, 14, True), (3, 14, True)]
    final_lanes, final_cars, final_right_on_red = states[12]
    assert 2 <= final_lanes <= 3
    assert 8 <= final_cars <= 16
    assert final_right_on_red


def test_curriculum_caps_active_cars_to_sampled_lane_capacity():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=5,
            max_cars=64,
            lanes_per_approach=5,
            curriculum_enabled=True,
            curriculum_min_lanes=2,
            curriculum_max_lanes=2,
            curriculum_min_cars=5,
            curriculum_max_cars=64,
            seed=55,
        )
    )
    for seed in range(55, 65):
        _, info = env.reset(seed=seed)
        assert info["active_mask"].sum() <= env._lane_capacity(2)
        assert info["active_mask"].sum() <= 64


def test_train_parser_accepts_init_checkpoint():
    from intersection_rl.cli import build_parser

    args = build_parser().parse_args([
        "train",
        "--curriculum-stage",
        "2",
        "--init-checkpoint",
        "checkpoints/stage1_best.npz",
        "--checkpoint",
        "checkpoints/stage2.npz",
    ])

    assert args.curriculum_stage == 2
    assert str(args.init_checkpoint) == "checkpoints/stage1_best.npz"
    assert str(args.checkpoint) == "checkpoints/stage2.npz"


def test_legal_right_on_red_entry_is_not_red_violation():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            allow_right_on_red=True,
            safety_filter_enabled=False,
            seed=36,
        )
    )
    env.reset(seed=36)
    right, crossing = configure_right_on_red_conflict(env)
    crossing.active = False
    set_front_distance_to_stop(env, right, 0.05)
    right.speed = 3.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    _, _, _, _, info = env.step(actions)

    assert info["right_on_red_entries"] == 1
    assert info["red_light_violations"] == 0
    assert info["right_yield_violations"] == 0


def test_lateral_offset_is_clamped_inside_lane():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=37))
    env.reset(seed=37)
    vehicle = env.vehicles[0]
    vehicle.lateral_offset = 0.0
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)
    actions[vehicle.vehicle_id] = [0.0, 1.0]

    for _ in range(50):
        env.step(actions)

    assert abs(vehicle.lateral_offset) <= env._max_lateral_offset()
    assert env._max_lateral_offset() < env.config.lane_width / 2.0



def test_zero_steering_recenters_lateral_offset():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, seed=41))
    env.reset(seed=41)
    vehicle = env.vehicles[0]
    vehicle.lateral_offset = 0.8
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    env.step(actions)

    assert abs(vehicle.lateral_offset) < 0.8


def test_timeout_active_vehicle_counts_as_failed_not_incomplete():
    env = IntersectionEnv(
        EnvConfig(min_cars=1, max_cars=1, episode_seconds=0.2, seed=42)
    )
    env.reset(seed=42)
    actions = np.zeros((env.config.max_cars, env.ACTION_SIZE), dtype=np.float32)

    _, _, terminated, truncated, info = env.step(actions)

    assert truncated
    assert terminated
    assert info["completed_vehicles"] == 0
    assert info["failed_vehicles"] == 1
    assert info["timeout_failures"] == 1
    assert not env.vehicles[0].active
    assert env.vehicles[0].failed

def test_observation_includes_predictive_conflict_features():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            protected_left_signal=False,
            safety_filter_enabled=False,
            seed=38,
        )
    )
    observation, _ = env.reset(seed=38)
    first, second = env.vehicles[:2]
    first.approach = "N"
    first.route = "straight"
    second.approach = "E"
    second.route = "straight"
    rebuild_vehicle_path(env, first)
    rebuild_vehicle_path(env, second)
    set_front_distance_to_stop(env, first, 3.0)
    first.speed = 4.0
    set_front_distance_to_stop(env, second, 3.0)
    second.speed = 4.0
    env.elapsed_seconds = 0.0

    observation = env._get_observation()

    assert observation[first.vehicle_id, 26] >= 0.0
    assert observation[first.vehicle_id, 27] >= 0.0
    assert observation[first.vehicle_id, 30] in (0.0, 1.0)
    assert observation[first.vehicle_id, 31] in (0.0, 1.0)
    assert observation[first.vehicle_id, 32] in (0.0, 1.0)
    assert 0.0 <= observation[first.vehicle_id, 33] <= 1.0
