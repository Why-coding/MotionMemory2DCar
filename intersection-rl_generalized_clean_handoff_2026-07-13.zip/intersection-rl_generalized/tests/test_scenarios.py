import numpy as np

from intersection_rl.cli import _update_stop_line_diagnostics, build_parser
from intersection_rl.scenarios import DEMO_SCENARIOS, build_demo_redgreen_env
from scripts.run_forced_go_creep_probe import creep_route_state


def _snapshot(env):
    return (
        env._signal_phase()[0],
        tuple(
            (
                vehicle.vehicle_id,
                vehicle.approach,
                vehicle.lane,
                vehicle.route,
                round(vehicle.progress, 8),
                round(vehicle.speed, 8),
            )
            for vehicle in env.vehicles
        ),
    )


def test_named_demo_uses_policy_matched_signal_configuration():
    scenario = DEMO_SCENARIOS["demo_redgreen_3l"]
    env = build_demo_redgreen_env(scenario, max_cars=50)
    try:
        _, info = env.reset(seed=scenario.seed)

        assert info["task_name"] == scenario.name
        assert info["signal_phase"].endswith("_GREEN")
        assert "ALL_RED" not in info["signal_phase"]
        assert env.config.signal_all_red_seconds == 3.5
        assert env.episode_protected_left_signal
        assert not env.episode_allow_right_on_red
        assert not env.config.right_turns_enabled
        assert env.config.signal_yellow_seconds == 0.0
        assert not env.episode_safety_filter_enabled
        assert not env.config.intersection_reservation_enabled
        assert len(env.vehicles) == 24
    finally:
        env.close()


def test_demo_seed_matches_between_headless_and_visual_modes():
    scenario = DEMO_SCENARIOS["demo_redgreen_2l"]
    headless = build_demo_redgreen_env(scenario, max_cars=50)
    visual = build_demo_redgreen_env(
        scenario,
        max_cars=50,
        render_mode="rgb_array",
    )
    try:
        headless.reset(seed=scenario.seed)
        visual.reset(seed=scenario.seed)
        assert _snapshot(headless) == _snapshot(visual)
    finally:
        headless.close()
        visual.close()


def test_demo_random_spawns_are_upstream_queue_safe_and_braking_feasible():
    scenario = DEMO_SCENARIOS["demo_redgreen_4l"]
    env = build_demo_redgreen_env(scenario, max_cars=50)
    try:
        env.reset(seed=scenario.seed)
        distances = [env._distance_to_stop_line(vehicle) for vehicle in env.vehicles]
        assert min(distances) >= env.config.spawn_random_lead_gap_min
        assert max(distances) <= (
            env.config.spawn_random_lead_gap_max
            + env.config.spawn_random_queue_gap_max
        )
        assert np.std(distances) > 2.0

        braking = env.config.comfortable_braking
        safety = env.config.spawn_speed_safety_factor
        lanes = {}
        for vehicle in env.vehicles:
            available = max(
                0.0,
                env._distance_to_stop_line(vehicle)
                - env.config.queue_stop_target_max,
            )
            required = safety * vehicle.speed * vehicle.speed / (2.0 * braking)
            assert required <= available + 1e-6
            lanes.setdefault((vehicle.approach, vehicle.lane), []).append(vehicle)

        for lane_vehicles in lanes.values():
            lane_vehicles.sort(key=lambda item: item.progress, reverse=True)
            for front, follower in zip(lane_vehicles, lane_vehicles[1:]):
                center_gap = front.progress - follower.progress
                assert center_gap >= env.config.spawn_random_queue_gap_min
                gap_available = center_gap - env.config.minimum_front_gap
                relative_required = safety * max(
                    0.0,
                    follower.speed * follower.speed - front.speed * front.speed,
                ) / (2.0 * braking)
                assert relative_required <= gap_available + 1e-6
    finally:
        env.close()


def test_demo_red_vehicle_far_short_has_creep_label():
    scenario = DEMO_SCENARIOS["demo_redgreen_2l"]
    env = build_demo_redgreen_env(scenario, max_cars=50)
    try:
        env.reset(seed=scenario.seed)
        leaders = {}
        for item in env.vehicles:
            key = (item.approach, item.lane)
            if key not in leaders or item.progress > leaders[key].progress:
                leaders[key] = item
        candidates = [
            vehicle
            for vehicle in leaders.values()
            if not env._movement_permitted(vehicle)
        ]
        vehicle = candidates[0]
        vehicle.progress = env._center_progress_for_front_distance(vehicle, 6.0)
        vehicle.speed = 0.0
        labels = env._intent_labels()

        assert labels[vehicle.vehicle_id] == env.INTENT_STOP
        assert env._intent_creep_latched[vehicle.vehicle_id]
    finally:
        env.close()


def test_creep_probe_keeps_servo_route_until_emergency_brake_or_hold():
    scenario = DEMO_SCENARIOS["demo_redgreen_2l"]
    env = build_demo_redgreen_env(scenario, max_cars=50)
    try:
        env.reset(seed=scenario.seed)
        vehicle = next(
            item for item in env.vehicles if not env._movement_permitted(item)
        )
        vehicle.progress = env._center_progress_for_front_distance(vehicle, 26.0)
        vehicle.speed = 0.0
        env._intent_labels()
        route, should_brake, creep_latched = creep_route_state(env, vehicle)
        assert route == "creep_window"
        assert not should_brake
        assert creep_latched

        vehicle.progress = env._center_progress_for_front_distance(vehicle, 4.0)
        vehicle.speed = 1.0
        route, should_brake, creep_latched = creep_route_state(env, vehicle)
        assert route == "creep_window"
        assert not should_brake
        assert creep_latched

        vehicle.speed = 6.0
        route, should_brake, creep_latched = creep_route_state(env, vehicle)
        assert route == "brake"
        assert should_brake
        assert not creep_latched
    finally:
        env.close()


def test_stop_line_diagnostics_separate_clearers_overshoots_and_short_stops():
    scenario = DEMO_SCENARIOS["demo_redgreen_2l"]
    env = build_demo_redgreen_env(scenario, max_cars=50)
    try:
        env.reset(seed=scenario.seed)
        closed = [
            vehicle for vehicle in env.vehicles if not env._movement_has_green(vehicle)
        ]
        clearer, overshoot, stopped_short = closed[:3]
        clearer.progress = env._center_progress_for_front_distance(clearer, -0.5)
        env._clearance_eligible[clearer.vehicle_id] = True
        overshoot.progress = env._center_progress_for_front_distance(overshoot, -0.5)
        env._clearance_eligible[overshoot.vehicle_id] = False
        stopped_short.progress = env._center_progress_for_front_distance(
            stopped_short,
            6.0,
        )
        stopped_short.speed = 0.0
        diagnostics = {
            "legal_clearers": set(),
            "true_overshoots": set(),
            "stopped_short": set(),
        }

        _update_stop_line_diagnostics(env, diagnostics)

        assert clearer.vehicle_id in diagnostics["legal_clearers"]
        assert overshoot.vehicle_id in diagnostics["true_overshoots"]
        assert stopped_short.vehicle_id in diagnostics["stopped_short"]
    finally:
        env.close()


def test_cli_exposes_named_and_custom_demo_modes():
    parser = build_parser()
    named = parser.parse_args(
        ["simulate", "--demo-scenario", "demo_redgreen_3l"]
    )
    custom = parser.parse_args(
        ["simulate", "--demo-redgreen", "--lanes", "4", "--cars", "32"]
    )

    assert named.demo_scenario == "demo_redgreen_3l"
    assert custom.demo_redgreen
