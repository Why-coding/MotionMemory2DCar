import numpy as np
import pytest
import torch

from intersection_rl.config import EnvConfig, PPOConfig
from intersection_rl.env import IntersectionEnv
from intersection_rl.ppo import PPOTrainer, SharedActorCritic
from intersection_rl.graph_observation import GraphObserver
from intersection_rl.graph_ppo import (
    GraphActorCritic,
    GraphPPOTrainer,
    MixedSquashedNormal,
    SquashedNormal,
    _mixture_gate_ambiguity,
)
from intersection_rl.runtime import GEOMETRY_CONVENTION


def test_actor_critic_shapes_and_continuous_actions():
    observation_size = IntersectionEnv.OBSERVATION_SIZE
    model = SharedActorCritic(observation_size, 32, 2, seed=1)
    observations = np.zeros((7, observation_size), dtype=np.float32)
    mean, values, _ = model.forward(observations)
    actions, log_probs, act_values = model.act(
        observations, np.random.default_rng(1)
    )
    assert mean.shape == (7, 2)
    assert actions.shape == (7, 2)
    assert log_probs.shape == (7,)
    assert values.shape == (7,)
    assert act_values.shape == (7,)
    assert np.all(actions >= -1.0)
    assert np.all(actions <= 1.0)


def test_short_rollout_and_update_are_finite():
    env = IntersectionEnv(
        EnvConfig(min_cars=8, max_cars=8, episode_seconds=2.0, seed=1)
    )
    config = PPOConfig(
        total_steps=8,
        rollout_steps=8,
        update_epochs=1,
        minibatch_size=32,
        hidden_size=16,
        seed=1,
    )
    trainer = PPOTrainer(env, config)
    rollout = trainer.collect_rollout()
    metrics = trainer.update(rollout)
    assert rollout.actions.shape == (8, 8, 2)
    assert all(np.isfinite(value) for value in metrics.values())


def test_validation_score_path_is_finite():
    env = IntersectionEnv(
        EnvConfig(
            min_cars=8,
            max_cars=12,
            lanes_per_approach=2,
            protected_left_signal=True,
            allow_right_on_red=False,
            episode_seconds=1.0,
            seed=2,
        )
    )
    config = PPOConfig(
        total_steps=8,
        rollout_steps=8,
        update_epochs=1,
        minibatch_size=32,
        hidden_size=16,
        validation_episodes=1,
        validation_cars=8,
        validation_lanes=2,
        seed=2,
    )
    trainer = PPOTrainer(env, config)

    metrics = trainer.run_validation(update_index=1)

    assert np.isfinite(metrics["validation_score"])
    assert metrics["env_steps"] > 0



def test_graph_actor_squashed_shortcut_and_legacy_load(tmp_path):
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            lanes_per_approach=2,
            protected_left_signal=True,
            allow_right_on_red=False,
            episode_seconds=1.0,
            seed=3,
        )
    )
    env.reset(seed=3)
    observer = GraphObserver(max_vehicle_nodes=2)
    observation = observer.encode(env)
    spec = observer.spec
    model = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=16,
        layers=1,
        seed=3,
        action_distribution="squashed_gaussian",
    )

    actions, log_probs, values = model.act(observation, deterministic=False)

    assert actions.shape == (2, 2)
    assert log_probs.shape == (2,)
    assert values.shape == (2,)
    assert np.all(np.isfinite(actions))
    assert np.all(actions >= -1.0)
    assert np.all(actions <= 1.0)
    assert np.allclose(model.acceleration_shortcut_head.weight.detach().numpy(), 0.0)

    checkpoint = tmp_path / "squashed_graph_actor.npz"
    legacy_checkpoint = tmp_path / "squashed_graph_actor_missing_shortcut.npz"
    model.save(checkpoint)
    with np.load(checkpoint, allow_pickle=False) as data:
        assert str(data["geometry_convention"]) == GEOMETRY_CONVENTION
        legacy_data = {
            key: data[key]
            for key in data.files
            if not key.startswith("acceleration_shortcut_head")
            and key != "acceleration_shortcut_indices"
        }
    np.savez(legacy_checkpoint, **legacy_data)

    reloaded = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=16,
        layers=1,
        seed=4,
        action_distribution="squashed_gaussian",
    )
    reloaded.load(legacy_checkpoint)

    assert reloaded.action_distribution == "squashed_gaussian"
    assert np.allclose(reloaded.acceleration_shortcut_head.weight.detach().numpy(), 0.0)
    assert np.allclose(reloaded.acceleration_shortcut_head.bias.detach().numpy(), 0.0)

def test_three_way_gate_ambiguity_uses_top_two_margin():
    weights = torch.tensor(
        [
            [0.50, 0.45, 0.05],
            [0.70, 0.20, 0.10],
            [0.55, 0.45, 0.00],
        ],
        dtype=torch.float32,
    )

    ambiguous = _mixture_gate_ambiguity(weights)

    assert ambiguous.tolist() == [True, False, True]


def test_mixed_squashed_log_prob_matches_single_component():
    locs = torch.tensor([[-0.7, 0.4], [-0.2, 0.8]], dtype=torch.float32)
    scales = torch.tensor([[0.35, 0.55], [0.45, 0.60]], dtype=torch.float32)
    steering_loc = torch.tensor([[0.15], [-0.25]], dtype=torch.float32)
    steering_scale = torch.tensor([[0.30], [0.40]], dtype=torch.float32)
    gate_logits = torch.tensor([[100.0, -100.0], [100.0, -100.0]], dtype=torch.float32)
    mixture = MixedSquashedNormal(locs, scales, gate_logits, steering_loc, steering_scale)
    single = SquashedNormal(
        torch.cat((locs[:, 0:1], steering_loc), dim=-1),
        torch.cat((scales[:, 0:1], steering_scale), dim=-1),
    )
    pre_tanh_actions = torch.tensor([[-0.3, 0.2], [0.5, -0.6]], dtype=torch.float32)
    actions = torch.tanh(pre_tanh_actions)

    assert torch.allclose(mixture.log_prob(actions), single.log_prob(actions), atol=1.0e-5)


def test_mixed_squashed_log_prob_is_finite_at_extreme_actions():
    locs = torch.tensor([[-8.0, 8.0], [8.0, -8.0]], dtype=torch.float32)
    scales = torch.full((2, 2), 0.25, dtype=torch.float32)
    gate_logits = torch.tensor([[2.0, -2.0], [-2.0, 2.0]], dtype=torch.float32)
    steering_loc = torch.zeros((2, 1), dtype=torch.float32)
    steering_scale = torch.full((2, 1), 0.2, dtype=torch.float32)
    dist = MixedSquashedNormal(locs, scales, gate_logits, steering_loc, steering_scale)
    actions = torch.tanh(torch.tensor([[-10.0, 10.0], [10.0, -10.0]], dtype=torch.float32))

    log_probs = dist.log_prob(actions)

    assert torch.isfinite(log_probs).all()


def test_mixed_squashed_deterministic_uses_argmax_component():
    locs = torch.tensor([[-1.0, 0.8], [-1.0, 0.8]], dtype=torch.float32)
    scales = torch.full((2, 2), 0.5, dtype=torch.float32)
    gate_logits = torch.tensor([[-0.5, 0.5], [0.5, -0.5]], dtype=torch.float32)
    steering_loc = torch.zeros((2, 1), dtype=torch.float32)
    steering_scale = torch.full((2, 1), 0.3, dtype=torch.float32)
    dist = MixedSquashedNormal(locs, scales, gate_logits, steering_loc, steering_scale)

    mean = dist.mean

    assert mean[0, 0] > 0.0
    assert mean[1, 0] < 0.0


def test_squashed_mixture_warm_start_from_squashed_checkpoint(tmp_path):
    env = IntersectionEnv(
        EnvConfig(
            min_cars=2,
            max_cars=2,
            lanes_per_approach=2,
            protected_left_signal=True,
            allow_right_on_red=False,
            episode_seconds=1.0,
            seed=5,
        )
    )
    env.reset(seed=5)
    observer = GraphObserver(max_vehicle_nodes=2)
    observation = observer.encode(env)
    spec = observer.spec
    squashed = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=16,
        layers=1,
        seed=5,
        action_distribution="squashed_gaussian",
    )
    checkpoint = tmp_path / "squashed_green_like.npz"
    squashed.save(checkpoint)

    mixture = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=16,
        layers=1,
        seed=99,
        action_distribution="squashed_mixture",
    )
    mixture.load(checkpoint)

    squashed_actions, _, _ = squashed.act(observation, deterministic=True)
    mixture_actions, _, _ = mixture.act(observation, deterministic=True)

    assert mixture.action_distribution == "squashed_mixture"
    assert np.allclose(mixture.acceleration_head.weight.detach().numpy(), squashed.acceleration_head.weight.detach().numpy())
    assert mixture.brake_acceleration_head.bias.detach().numpy()[0] < -0.5
    assert (
        mixture.acceleration_gate_head.bias.detach().numpy()[mixture.GO_COMPONENT]
        > mixture.acceleration_gate_head.bias.detach().numpy()[mixture.BRAKE_COMPONENT]
    )
    assert not mixture.creep_component_enabled
    assert np.allclose(mixture_actions, squashed_actions, atol=1.0e-6)


def test_legacy_two_component_checkpoint_migrates_exactly(tmp_path):
    observer = GraphObserver(max_vehicle_nodes=2)
    spec = observer.spec
    source = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=16,
        layers=1,
        seed=31,
        action_distribution="squashed_mixture",
    )
    source.set_creep_component_enabled(False)
    checkpoint = tmp_path / "three_component_source.npz"
    legacy = tmp_path / "legacy_two_component.npz"
    source.save(checkpoint)
    with np.load(checkpoint, allow_pickle=False) as data:
        payload = {
            key: data[key]
            for key in data.files
            if not key.startswith("creep_")
            and not key.startswith("acceleration_gate_route_head")
            and key not in {"mixture_components", "creep_component_enabled"}
        }
    payload["actor_head"] = np.array("separate_accel_steer_v1")
    for name in (
        "acceleration_gate_head.weight",
        "acceleration_gate_head.bias",
        "acceleration_gate_shortcut_head.weight",
        "acceleration_gate_shortcut_head.bias",
    ):
        payload[name] = payload[name][[source.BRAKE_COMPONENT, source.GO_COMPONENT]]
    np.savez(legacy, **payload)

    ego = np.zeros((5, spec.ego_size), dtype=np.float32)
    nodes = np.zeros((5, spec.max_nodes, spec.node_size), dtype=np.float32)
    edges = np.zeros((5, spec.max_nodes, spec.edge_size), dtype=np.float32)
    node_mask = np.ones((5, spec.max_nodes), dtype=np.float32)
    observation = {"ego": ego, "nodes": nodes, "edges": edges, "node_mask": node_mask}
    source_actions, _, _ = source.act(observation, deterministic=True)
    source_weights = source.action_mixture_weights(observation)

    migrated = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=16,
        layers=1,
        seed=99,
        action_distribution="squashed_mixture",
    )
    migrated.load(legacy)
    migrated_actions, _, _ = migrated.act(observation, deterministic=True)
    migrated_weights = migrated.action_mixture_weights(observation)

    assert not migrated.creep_component_enabled
    assert np.array_equal(migrated_actions, source_actions)
    assert np.array_equal(migrated_weights, source_weights)
    with torch.no_grad():
        dist, _, _, _ = migrated.distribution(
            migrated._tensor(ego),
            migrated._tensor(nodes),
            migrated._tensor(edges),
            migrated._tensor(node_mask),
        )
    assert torch.isfinite(dist.entropy()).all()
    assert np.array_equal(
        migrated.acceleration_gate_head.weight.detach().numpy()[migrated.BRAKE_COMPONENT],
        payload["acceleration_gate_head.weight"][0],
    )
    assert np.array_equal(
        migrated.acceleration_gate_head.weight.detach().numpy()[migrated.GO_COMPONENT],
        payload["acceleration_gate_head.weight"][1],
    )


def test_route_head_checkpoint_migrates_observable_target_error_feature(tmp_path):
    spec = GraphObserver(max_vehicle_nodes=2).spec
    source = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=16,
        layers=1,
        seed=41,
        action_distribution="squashed_mixture",
    )
    checkpoint = tmp_path / "route_feature_v2.npz"
    legacy = tmp_path / "route_feature_v1.npz"
    source.save(checkpoint)
    with np.load(checkpoint, allow_pickle=False) as data:
        payload = {key: data[key] for key in data.files}
    old_weight = payload["acceleration_gate_route_head.0.weight"][:, :-1].copy()
    payload["acceleration_gate_route_head.0.weight"] = old_weight
    np.savez(legacy, **payload)

    migrated = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=16,
        layers=1,
        seed=99,
        action_distribution="squashed_mixture",
    )
    migrated.load(legacy)
    migrated_weight = migrated.acceleration_gate_route_head[0].weight.detach().numpy()

    assert np.array_equal(migrated_weight[:, :-1], old_weight)
    assert np.array_equal(migrated_weight[:, -1], np.zeros(16, dtype=np.float32))


def test_three_component_distribution_and_balanced_prewarm_sampling():
    env = IntersectionEnv(EnvConfig(min_cars=2, max_cars=2, episode_seconds=1.0, seed=32))
    env.reset(seed=32)
    observer = GraphObserver(max_vehicle_nodes=2)
    config = PPOConfig(
        total_steps=8,
        rollout_steps=8,
        update_epochs=1,
        minibatch_size=8,
        hidden_size=16,
        action_distribution="squashed_mixture",
        seed=32,
    )
    trainer = GraphPPOTrainer(env, config, observer, layers=1)
    components = trainer.model.action_component_means(observer.encode(env))
    sampled = trainer._sample_gate_prewarm_indices(
        np.array([0] * 2 + [1] * 2 + [2] * 2, dtype=np.int64), 12
    )

    route_ego = torch.zeros((3, observer.spec.ego_size), dtype=torch.float32)
    route_ego[:, 0] = 2.0 / 13.4
    route_ego[:2, 2] = 3.0 / 65.0
    route_ego[2, 2] = 0.33 / 65.0
    route_ego[0, 22] = 7.5 / 65.0
    route_ego[1, 22] = 1.0
    route_ego[2, 22] = 20.0 / 65.0
    route_features = trainer.model._gate_route_features(route_ego)
    servo_features = trainer.model._creep_servo_features(route_ego)

    assert components is not None
    assert components.shape == (2, 3)
    assert route_features.shape == (3, 7)
    assert torch.allclose(
        route_features[0, [0, 1, 4, 6]],
        torch.tensor([2.0, 3.0, 7.5, 0.25]),
        atol=1.0e-6,
    )
    assert abs(float(route_features[1, 6]) - 2.45) < 1.0e-6
    assert abs(float(route_features[2, 6]) - (0.33 - 0.55)) < 1.0e-6
    assert torch.allclose(
        servo_features[2], torch.tensor([2.0, 0.33 - 0.8]), atol=1.0e-6
    )
    assert torch.count_nonzero(
        trainer.model.creep_servo_residual_head[-1].weight
    ) == 0
    assert np.bincount(
        np.array([0] * 2 + [1] * 2 + [2] * 2, dtype=np.int64)[sampled],
        minlength=3,
    ).tolist() == [4, 4, 4]


def test_creep_speed_servo_target_is_bounded_and_speed_conditioned():
    env = IntersectionEnv(EnvConfig(min_cars=1, max_cars=1, episode_seconds=1.0, seed=33))
    env.reset(seed=33)
    observer = GraphObserver(max_vehicle_nodes=1)
    config = PPOConfig(
        total_steps=8,
        rollout_steps=8,
        update_epochs=1,
        minibatch_size=8,
        hidden_size=16,
        action_distribution="squashed_mixture",
        physics_action_target_red_crawl_speed=1.5,
        physics_action_target_red_approach_gain=0.35,
        physics_action_target_stop_margin=0.8,
        physics_action_target_queue_following_enabled=True,
        physics_action_target_queue_lead_margin=0.8,
        seed=33,
    )
    trainer = GraphPPOTrainer(env, config, observer, layers=1)
    ego = torch.zeros((3, observer.spec.ego_size), dtype=torch.float32)
    ego[:, 2] = torch.tensor([26.0, 26.0, 1.2]) / config.physics_action_target_road_length
    ego[:, 0] = torch.tensor([0.0, 1.5, 1.0]) / config.physics_action_target_max_speed
    ego[:2, 22] = 1.0
    ego[2, 22] = 20.0 / config.physics_action_target_road_length

    targets = trainer._creep_action_targets_from_ego(ego)
    augmented = trainer._augment_creep_prewarm_ego(
        ego, torch.tensor([True, True, True]), step=1
    )
    augmented_speeds = (
        augmented[:, 0] * config.physics_action_target_max_speed
    )
    augmented_line_available = (
        augmented[:, 2] * config.physics_action_target_road_length
        - config.physics_action_target_queue_lead_margin
    )

    assert torch.allclose(
        augmented_speeds, torch.tensor([0.0, 0.5, 1.5]), atol=1.0e-6
    )
    assert torch.allclose(
        augmented_line_available, torch.tensor([0.25, 0.5, 0.8]), atol=1.0e-6
    )
    assert np.isclose(
        float(augmented[2, 22] * config.physics_action_target_road_length),
        0.8 + 7.25,
    )
    assert 0.0 < float(targets[0]) <= 0.600001
    assert abs(float(targets[1])) < 1.0e-6
    assert float(targets[2]) < 0.0
    assert torch.all((targets >= -1.0) & (targets <= 1.0))


def test_graph_checkpoint_warns_on_geometry_mismatch(tmp_path):
    observer = GraphObserver(max_vehicle_nodes=2)
    spec = observer.spec
    model = GraphActorCritic(
        spec.ego_size,
        spec.node_size,
        spec.edge_size,
        spec.max_nodes,
        hidden_size=16,
        layers=1,
        seed=17,
        action_distribution="squashed_gaussian",
    )
    checkpoint = tmp_path / "current_geometry.npz"
    mismatched = tmp_path / "old_geometry.npz"
    model.save(checkpoint)
    with np.load(checkpoint, allow_pickle=False) as data:
        payload = {key: data[key] for key in data.files}
    payload["geometry_convention"] = np.array("center_reference_v0")
    np.savez(mismatched, **payload)

    with pytest.warns(RuntimeWarning, match="geometry_convention"):
        model.load(mismatched)



def _validation_gate_run(lanes, cars, completed_pct=100.0, red=0.0, collisions=0.0, proximity=0.0, stuck=0.0):
    episodes = 8.0
    return {
        "lanes": float(lanes),
        "cars": float(cars),
        "episodes": episodes,
        "completed_clean": completed_pct * episodes * cars / 100.0,
        "closed_signal": red * episodes,
        "collisions": collisions * episodes,
        "proximity_events": proximity * episodes,
        "stuck_timeouts": stuck * episodes,
    }


def test_validation_regime_gates_require_every_solved_cell():
    runs = [
        _validation_gate_run(2, 8),
        _validation_gate_run(3, 12),
        _validation_gate_run(4, 16),
        _validation_gate_run(2, 16),
        _validation_gate_run(3, 24, proximity=0.5),
        _validation_gate_run(4, 32),
        _validation_gate_run(2, 24),
        _validation_gate_run(3, 36, completed_pct=99.17, red=0.25),
        _validation_gate_run(4, 48, completed_pct=96.46, red=0.375, proximity=1.25, stuck=0.375),
    ]

    assert GraphPPOTrainer._validation_regime_gates_pass(runs)

    regressed = list(runs)
    regressed[4] = _validation_gate_run(3, 24, completed_pct=99.0)
    assert not GraphPPOTrainer._validation_regime_gates_pass(regressed)
    assert not GraphPPOTrainer._validation_regime_gates_pass(runs[:-1])
