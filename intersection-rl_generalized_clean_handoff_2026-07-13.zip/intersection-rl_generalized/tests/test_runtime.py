from pathlib import Path

import numpy as np
import pytest

from intersection_rl import GEOMETRY_CONVENTION
from intersection_rl.runtime import (
    assert_project_runtime,
    checkpoint_metadata,
    runtime_provenance,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_runtime_guard_accepts_generalized_source_tree():
    package_file = assert_project_runtime(PROJECT_ROOT)

    assert package_file.is_relative_to(PROJECT_ROOT / "intersection_rl")
    assert GEOMETRY_CONVENTION == "front_bumper_v1"


def test_runtime_guard_rejects_a_different_source_tree(tmp_path):
    with pytest.raises(RuntimeError, match="Wrong intersection_rl package imported"):
        assert_project_runtime(tmp_path)


def test_checkpoint_metadata_reports_actor_and_legacy_geometry(tmp_path):
    checkpoint = tmp_path / "legacy_graph.npz"
    np.savez(
        checkpoint,
        format=np.array("graph_attention_torch_state_npz"),
        actor_head=np.array("separate_accel_steer_v1"),
        actor_distribution=np.array("squashed_mixture"),
    )

    metadata = checkpoint_metadata(checkpoint)

    assert metadata == {
        "checkpoint_format": "graph_attention_torch_state_npz",
        "actor_head": "separate_accel_steer_v1",
        "action_distribution": "squashed_mixture",
        "checkpoint_geometry_convention": "unstamped_legacy",
    }
    provenance = runtime_provenance(PROJECT_ROOT, checkpoint)
    assert provenance["package_path"].startswith(str(PROJECT_ROOT / "intersection_rl"))
    assert provenance["geometry_convention"] == GEOMETRY_CONVENTION
