# Technical Report: Generalized Pure-Policy Intersection RL

Date: 2026-07-13

## 1. Executive Summary

This project develops a shared reinforcement-learning controller for every
vehicle in a configurable four-way intersection. The environment supports one
to five incoming lanes per approach, straight/left/right routes, signalized
movement, queues, collision and proximity accounting, legal clearance, and
randomized traffic tasks. The current validated policy scope is narrower:
protected-left red/green operation with no yellow, no right turns, no
right-on-red, no safety shield, and a 3.5 second all-red clearance interval.

The current production checkpoint is:

```text
checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz
```

Its accepted-latch canonical results are 100% clean in all sparse and dense
cells up to 4 lanes/32 cars, and 99.58%, 99.17%, and 96.46% completion in the
2/24, 3/36, and 4/48 stress cells.

The project is intentionally policy-pure at runtime. In canonical evaluation and
simulation, actions come from the learned policy. Physics labels, intent labels,
mixture routing targets, and auxiliary action targets are training losses. They
are not runtime action overrides. Environment legal semantics such as
clearance eligibility define whether an action is legal; they do not choose the
action.

The most important engineering result is not a single reward function. The
project became reliable by separating five layers that were originally
confounded:

1. Physical and legal environment semantics.
2. Geometry and observation semantics.
3. Scenario and spawn distribution.
4. Policy architecture and action distribution.
5. Training, validation, and promotion methodology.

Repeated failures that initially looked like weak RL were traced to concrete
implementation defects: a saturating actor, gradient-scale imbalance,
incorrect labels, stale imports, signal semantics, missing clearance, center
versus bumper geometry, unobservable phase deadlines, and evaluation/simulation
distribution drift. Each was fixed and pinned by tests or permanent evaluation
protocols.

## 2. Objective And Scope

The original behavioral objective was:

- Vehicles proceed through legal green movements.
- Vehicles approaching red brake before the stop line.
- A lead vehicle stops 0.5-1.0 m before the line by front bumper.
- Followers form a queue with approximately 2.5-3.0 m bumper gaps.
- Queues release promptly and safely on green.
- The same shared policy generalizes across lane and car counts.
- Simulation and evaluation exercise the same environment semantics.

Current in-scope claims:

- Protected-left red/green signaling.
- One to four lanes per approach in the canonical table.
- Up to 50 active cars in current graph training/evaluation.
- Sparse, dense, and three-deep stress queues.
- Random legal initial phase and randomized feasible demo spawns.
- Front-bumper stop/crossing convention.
- Rear-bumper route completion.
- One-shot physical dilemma-zone clearance.
- Pure learned runtime actions.

Not yet claimed:

- Learned yellow behavior.
- Learned right-on-red behavior.
- General protected/permissive mixed left behavior at production quality.
- Safety at arbitrary densities beyond the canonical matrix.
- Robustness to pedestrians, lane changes, occlusion, sensor noise, or real
  vehicle dynamics.
- A promoted checkpoint that simultaneously fixes far-upstream stationary
  demo creep and preserves every stress floor.

## 3. System Architecture

The system has four main runtime layers.

### 3.1 Environment

`IntersectionEnv` owns:

- Signal phase state and transitions.
- Vehicle spawning and route assignment.
- Vehicle kinematics.
- Stop-line, queue, intersection, and completion geometry.
- Collision, proximity, lane, red/yellow, and timeout events.
- Rewards and training labels.
- Rendering state.

The environment follows the Gymnasium API. One call to `step` advances
`dt = 0.2` seconds.

### 3.2 Scenario layer

`ScenarioTask` describes a distribution over:

- Lane count.
- Car count.
- Episode duration.
- Signal mode.
- Lead and queue gaps.
- Closed/green spawn speeds.
- Spawn signal filtering.
- Randomized longitudinal positions.
- Optional yellow-clear distance/speed bands.

`MultiTaskIntersectionEnv` samples a weighted task at reset and applies it to
the shared environment. This is the training distribution mechanism.

`scenarios.py` contains the policy-aligned environment factory and named demo
scenarios. The same builder is used by headless and visual demo modes.

### 3.3 Observation layer

`GraphObserver` creates one ego-centric graph for every active vehicle. All
vehicles share one policy and weights, but each acts from its own graph.

Shapes:

- Ego vector: 27 values.
- Node vector: 24 values.
- Edge vector: 22 values.
- Vehicle nodes: checkpoint-defined maximum.
- Context nodes: one lane/map node and one signal node.
- Mask: valid nodes for each ego.
- Active mask: valid controlled vehicle slots.

The observation does not expose future phase timing or exact time-to-green.
Only current observable state and legal context are provided.

### 3.4 Policy and trainer

`GraphActorCritic` encodes ego, nodes, and edges into a hidden representation,
applies typed edge-conditioned attention, then emits:

- Longitudinal distribution.
- Steering distribution.
- State value.
- Four-class training intent logits.

The current code supports:

- Legacy Gaussian actions.
- Tanh-corrected squashed Gaussian actions.
- Squashed longitudinal mixture plus squashed steering.

`GraphPPOTrainer` collects multi-worker rollouts, computes GAE, trains PPO and
auxiliary losses, runs deterministic validation, applies hard regime gates, and
writes checkpoints/metrics.

## 4. Environment Model

### 4.1 Road and vehicles

Important defaults:

| Quantity | Value |
|---|---:|
| Road length | 65.0 m |
| Intersection half-size | 10.0 m |
| Lane width | 4.0 m |
| Vehicle length | 4.5 m |
| Vehicle width | 1.8 m |
| Maximum speed | 13.4 m/s |
| Maximum acceleration | 2.5 m/s^2 |
| Braking authority | 4.0 m/s^2 |
| Simulation step | 0.2 s |
| Canonical episode | 60 s |

Paths are generated for straight, left, and right routes. The policy controls
longitudinal action and steering; route geometry and lane centering provide the
road-following structure.

### 4.2 Signals

The environment supports:

- North/south and east/west movement.
- Protected left phases.
- Straight phases.
- Optional yellow.
- Optional all-red intervals.
- Random initial phase.
- Initial-green-only randomization for named red/green scenarios.

The current accepted policy protocol uses protected left, no yellow, and 3.5
seconds all-red. Conflicting traffic remains red.

### 4.3 Clearance semantics

Two clearance concepts are permanent.

Legal clearer:

- A vehicle that entered while permitted remains permitted to leave after the
  signal changes.

Dilemma-zone clearer:

- At an actual permitted-to-closed phase transition, the environment captures
  position and speed once.
- It computes whether stopping before the line requires more than physical
  braking authority, 4.0 m/s^2.
- If physically impossible, the vehicle receives clearance eligibility.
- Eligibility is never recomputed.

The one-shot rule prevents an exploit in which a policy accelerates after the
transition to manufacture infeasibility. Comfortable-braking thresholds are not
used for this legal decision.

This latch reduced polish stress red violations from 4.0/4.5/2.8 to
0.1/0.3/0.4 per episode without changing policy weights or actions. The former
events were largely an unobservable phase-end physics problem, not learned red
indiscipline.

### 4.4 Runtime safety systems

The environment contains optional safety filters and intersection reservation.
They can clamp or reject unsafe requests in legacy/curriculum experiments.

Canonical policy claims disable:

- Safety filter.
- Intersection reservation.
- Right-on-red.
- Right turns.
- Yellow.

This is necessary to attribute behavior to the policy.

## 5. Geometry Convention

The project originally mixed vehicle-center and bumper references. The current
marker is:

```text
front_bumper_v1
```

Line-related rules use front bumper:

- Spawn lead distance.
- Distance-to-stop observation.
- Stop target.
- Red/yellow crossing.
- Safety-filter stop clamp.
- Clearance eligibility.
- Intent labels.
- Queue lead target.
- Graph and vector observations.

Exit-related rules use rear bumper:

- Intersection cleared.
- Route completion.
- Timeout classification near route end.

Definitions:

- Front-bumper line distance: positive before the line, zero at the line,
  negative after crossing.
- Lead target: 0.1-1.0 m before the line.
- Follower center/progress gap: 7.0-7.5 m.
- With 4.5 m vehicles, this is a 2.5-3.0 m bumper gap.
- A vehicle completes only after its tail clears the route endpoint.

The geometry conversion changed the ruler seen by both policy and detector.
Existing checkpoints trained on center semantics could appear approximately
2.25 m too deep under the corrected ruler. Rebaselining both policies under the
same semantics preserved fair comparisons.

## 6. Observation Architecture

### 6.1 Ego features

The 27 ego values encode:

1. Speed.
2. Acceleration.
3. Front-bumper distance to stop line.
4. Crossed-line indicator.
5. Stopping distance.
6. Route progress.
7. Lateral offset.
8. Source lane.
9. Destination lane.
10. Lanes per approach.
11. Active-car density.
12. Green.
13. Yellow.
14. Closed signal.
15. Movement permitted, including legal clearance.
16. Protected-left mode.
17. Right-on-red enabled.
18. Ego can legally turn right on red.
19. Rightmost-lane indicator.
20-22. Left/straight/right route one-hot.
23. Front gap.
24. Front relative speed.
25. Front time-to-collision.
26. Minimum-front-gap indicator.
27. Inside-intersection indicator.

Values are normalized and clipped to [-1, 1].

### 6.2 Vehicle nodes

Every active vehicle appears as a node with:

- Relative forward/right position and distance.
- Relative and absolute speed.
- Acceleration.
- Relative heading.
- Ahead/behind relation.
- Same lane/approach/axis.
- Potential crossing conflict.
- Other vehicle stop-line distance and crossing state.
- Other movement green.
- Other inside-intersection state.
- Lane position and left/right/interior role.
- Ego-node indicator.
- Vehicle-node type indicator.

### 6.3 Edge features

Typed edges encode:

- Self edge.
- Same-lane front and behind.
- Same lane, adjacent lane, same approach.
- Potential conflict.
- Intersection occupancy.
- Relative direction.
- Other crossed line.
- Other movement green.
- Ego/other near conflict area.
- Distance, longitudinal separation, relative speed, observed TTC.
- Minimum-gap condition.
- Lane-context, signal-context, and context relevance type fields.

### 6.4 Context nodes

Lane/map context includes lane count, source/destination lane, route,
stop-line distance, route progress, lane role, signal mode, geometry sizes,
speed, and node type.

Signal context includes current green/yellow/closed state, movement permission,
right-on-red legality, route, crossed-line state, stop distance, speed, and
configured phase durations.

The signal node does not expose remaining phase time. This was an intentional
realism constraint and directly motivated the dilemma-zone legal latch.

## 7. Policy Architecture

### 7.1 Shared graph encoder

For each controlled ego:

1. A linear + layer normalization + tanh encoder maps the ego vector.
2. Separate encoders map node and edge vectors.
3. Each graph-attention block builds an ego query.
4. Node keys/values are conditioned by edge embeddings.
5. Edge bias modifies attention scores.
6. Invalid nodes are masked.
7. Weighted node context is combined with ego through a residual update and
   layer normalization.
8. A two-layer tanh body produces the shared actor/critic feature.

The default graph model uses hidden size 128 and two attention layers unless
overridden.

### 7.2 Actor outputs

The actor has separate longitudinal and steering pathways.

Legacy/current polish behavior uses:

- GO acceleration head.
- Brake acceleration head.
- Mixture gate.
- Steering head.
- Component-specific/conditional standard deviations.

The experimental creep-v3 model adds:

- Creep acceleration head.
- Creep shortcut.
- Learned residual servo over physical speed and nearest available stopping
  distance.
- Three-way brake/creep/go gate.

Direct ego shortcuts use speed, stop distance, and movement permission. The
route gate additionally uses speed, stop distance, closed/permitted state,
front gap, inside-intersection state, and a derived queue target error.

The nearest target is:

```text
min(stop-line target error, lead-gap target error)
```

A far lead therefore cannot erase the stop line. A near lead becomes a virtual
stop line for followers.

### 7.3 Action distributions

Legacy Gaussian:

- Mean is tanh-bounded.
- Gaussian sampling is centered on that bounded mean.
- Retained for historical checkpoints.

Squashed Gaussian:

- Samples in unconstrained space.
- Applies tanh.
- Includes the tanh log-probability correction.
- Uses state-dependent standard deviation.

Squashed mixture:

- Longitudinal brake/creep/go component distributions.
- Learned categorical gate.
- Separate steering distribution.
- Deterministic execution selects the gate argmax and component mean.
- Stochastic training samples through the mixed distribution.

### 7.4 Intent head

The four training intents are stop, hold, go, and yield. The intent head is a
diagnostic and auxiliary learner. By default, its feature input is detached so
intent CE does not reshape the shared trunk.

### 7.5 Critic

The critic is a linear value head over shared graph features. PPO supports MSE
or Huber value loss. Huber was added after critic gradients dominated focused
creep/action losses.

## 8. Training Pipeline

```text
arguments
 -> behavior-stage preset
 -> package/geometry/checkpoint provenance
 -> EnvConfig + weighted tasks
 -> parallel MultiTaskIntersectionEnv workers
 -> task reset and signal/spawn sampling
 -> per-vehicle graph observations
 -> stochastic policy actions
 -> environment transition/reward/events/labels
 -> rollout concatenation
 -> GAE returns
 -> phase-normalized advantages
 -> phase-balanced minibatches
 -> PPO and auxiliary optimization
 -> deterministic validation
 -> nine-cell hard gates
 -> best/periodic/final checkpoint and CSV artifacts
```

### 8.1 Rollout sampling

Each worker runs a sampled task. Parameter sharing means every active vehicle
contributes samples to one policy. The trainer records active masks so inactive
slots do not affect losses.

Training can randomize all-red duration while validation remains fixed. The
polish stage uses 3.5-4.5 seconds during training and 3.5 seconds for validation.

### 8.2 GAE and minibatches

Returns use gamma 0.99 and GAE lambda 0.95. Advantages can be normalized by
intent/phase and minibatches can be phase-balanced. These mechanisms prevent
abundant GO samples from overwhelming rare STOP/HOLD states.

### 8.3 PPO loss

The clipped policy objective is:

```text
L_policy = -E[min(r_t A_t, clip(r_t, 1-epsilon, 1+epsilon) A_t)]
```

The total train loss can include:

```text
L =
  L_policy
  + c_v L_value
  - c_e H
  + c_intent L_intent
  + c_action L_action_target
  + c_gate L_gate_CE
  + c_ref KL(policy || reference)
  + c_go KL(go_component || reference_go)
```

Not every term is active in every stage.

### 8.4 Auxiliary physics action target

The target computes available front-bumper distance to the nearer of:

- Stop-line margin.
- Lead-vehicle queue gap.

A safe target speed follows a braking envelope. The acceleration target is
approximately:

```text
a_target = clamp((v_target(distance) - v) / tau, -braking, max_acceleration)
```

The result is normalized to the policy action range. The target supervises
specific red/queue samples only. It does not execute at runtime.

### 8.5 Mixture gate supervision

Route labels train brake/creep/go selection with weighted cross entropy.

Important protections:

- Separate gate optimizer so global PPO clipping does not erase gate CE.
- Detached shared features by default.
- Balanced route classes.
- Prewarm thresholds on mean route weight, argmax share, and ambiguity.
- Abort before PPO if prewarm does not meet thresholds.
- Optional PPO gate freeze until saturation.
- Non-zero CE floor after decay.

### 8.6 Creep servo

Creep is a speed-control problem, not a constant positive acceleration. The
target limits speed near 1.5 m/s and tapers to zero near the stop/queue window.

Prewarm augments creep samples over a deterministic speed-distance grid:

- Speeds: 0, 0.5, 1.5, 2.5, 4.0 m/s.
- Available distances: 0.25, 0.5, 0.8, 1.2, 2, 4, 8, 20 m.

The learned residual head is initialized to zero so migration preserves old
behavior until trained.

### 8.7 Reference policy losses

Fine-tuning uses a frozen reference checkpoint to prevent forgetting. The
project learned that generic low-weight KL was insufficient. The promoted polish
run required GO-component KL coefficient 1.0 after 0.03 caused GO action to fall
below +0.35.

## 9. Evaluation Pipeline

```text
checkpoint + fixed protocol
 -> local-package and geometry assertion
 -> checkpoint metadata read
 -> deterministic scenario construction
 -> seeded reset
 -> graph observation
 -> deterministic mean/argmax policy action
 -> environment transition and event accumulation
 -> episode completion/horizon
 -> aggregate CSV
 -> multi-seed cell aggregation
 -> compare against pre-registered hard floors
 -> promotion/rejection
```

Canonical matrix:

| Regime | Cells | Seeds | Episodes per seed |
|---|---|---|---:|
| Sparse | 2/8, 3/12, 4/16 | 730, 731 | 20 |
| Dense | 2/16, 3/24, 4/32 | 730, 731, 732 | 20 |
| Stress | 2/24, 3/36, 4/48 | 730, 731 | 10 |

All use 60 seconds, 3.5 seconds all-red, `dense_redgreen`, deterministic
actions, and safety systems off.

Primary metrics include completion, red/yellow, collision, proximity, stuck and
moving timeout, stop placement by queue position, follower gap, discharge delay,
route weights, and component actions.

## 10. Simulation Pipeline

```text
simulate arguments
 -> named/custom/raw scenario selection
 -> checkpoint resolution
 -> provenance banner
 -> shared demo builder
 -> legal random initial green
 -> front-bumper-safe feasible random spawning
 -> graph observation
 -> deterministic policy action
 -> environment transition
 -> optional Pygame render of same state
 -> legal/dilemma/overshoot/stopped-short diagnostics
 -> per-vehicle failure classification
 -> episode summary
```

The visual and headless named demo modes share the same environment, reset, seed,
and policy path. Rendering does not construct a second scenario.

Feasible spawn sampling prevents manufactured violations: position and speed are
sampled together, speed is capped by the braking envelope, queues preserve
minimum gaps, and no vehicle spawns past the stop line or inside the box.

## 11. Experiment Methodology

The final workflow follows these rules.

### Derive before training

Read the labeler, observation, latch, and geometry before changing rewards.
Several major failures were label or semantics defects, not reward defects.

### Probe before a full leg

Forced routing and trajectory probes test whether a component can express the
desired behavior. The forced-GO creep probe rejected unsafe routing before a
training day was spent.

### Pre-register expectations

Expected metric movements are written before rebaseline. Geometry and
rear-bumper completion were expected to expose slightly more red and marginal
timeouts. This prevented correct stricter measurements from being mistaken for
regressions.

### Hard regime gates

A checkpoint cannot be selected if any protected cell fails completion/safety
floors, regardless of average validation score.

### Attribute before escalating

Architecture changes require a diagnostic signature. The third component was
added only after brake and GO shared-duty attempts failed for distinct measured
reasons.

### Preserve provenance

Every run prints package path, geometry, checkpoint, actor head, distribution,
seed, and clearance. This closes the class of stale-package and wrong-era
checkpoint errors.

## 12. Bug And Failure History

### 12.1 Safety shield hid policy behavior

Symptom: apparently safe runs did not prove learned safety.

Cause: environment action filters corrected unsafe requests.

Fix: canonical training validation and evaluation disable the shield and
reservation. Shield metrics remain available for separate experiments.

### 12.2 Saturating/entangled actor output

Symptom: one policy mode could not preserve green motion while learning strong
red braking.

Cause: a single longitudinal Gaussian/head had incompatible positive and
negative responsibilities and saturation behavior.

Fix: separate longitudinal/steering heads, then brake/GO mixture, later an
experimental brake/creep/go mixture.

### 12.3 Gradient-scale collapse

Symptom: auxiliary action supervision appeared configured but produced no
behavioral movement.

Cause: value/other gradients and global clipping reduced effective auxiliary
gradient by hundreds of times, historically near a 720x imbalance.

Fix: per-loss gradient diagnostics, Huber value loss, lower value coefficient,
separate gate optimizer, and effective post-clipping gradient metrics.

### 12.4 Incorrect intent/action labels

Symptom: vehicles were supervised to hold or accelerate in the wrong state.

Cause: labels conflated signal intent, component routing, and continuous action
target.

Fix: separate three concepts:

- Intent: stop/hold/go/yield.
- Route: brake/creep/go component.
- Action target: continuous physics acceleration.

### 12.5 Stop-in-place instead of stop-at-line

Symptom: cars stopped 10-17 m before the line and never approached.

Cause: fixed brake actions and red penalties rewarded any halt, while labels
latched without a proportional target.

Fix: distance/speed braking envelope, queue-aware target, potential shaping,
re-approach labels, and explicit placement metrics.

### 12.6 Queue target selected a far lead over the line

Symptom: a distant vehicle ahead could make the follower ignore the closer stop
line.

Cause: line and lead target terms were mixed with the wrong selection rule.

Fix: use the nearer target with `min(line_error, follower_error)` in labels,
gate features, and creep servo. Added tests for far and near leads.

### 12.7 Sequential follower release

Symptom: dense completion looked good but discharge propagated one car at a
time, exposing severe stress delay.

Cause: followers remained conservative until physical gap opened, so delay
compounded by queue depth.

Fix: polish task/label/reward mix improved follower release and discharge from
keeper 10.7/17.1/23.3 s to 10.3/15.0/19.8 s in dense cells. Stress and later
creep work retained discharge as a leading metric.

### 12.8 Yellow contamination in no-yellow work

Symptom: policy behavior and labels changed at phase boundaries that were not
part of the intended curriculum.

Cause: yellow remained enabled in paths described as red/green.

Fix: explicit no-yellow policy environment and scenario presets. Yellow modes
remain separate experimental tasks.

### 12.9 Signal-mode and initial-phase mismatch

Symptom: evaluation and simulation appeared to test different red/green
behavior.

Cause: raw simulation used different fixed phase/spawn semantics.

Fix: shared `policy_env_config`, `redgreen_task`, named demo builder, random
legal initial green, and provenance output.

### 12.10 Missing all-red in visual simulation

Symptom: visual 3l/24 completed 18/24 while canonical evaluation completed
24/24.

Cause: visual CLI used instant phase switching with `all_red_seconds=0`.

Fix: demo preset defaults to 3.5 seconds and uses the shared builder. Do not
retrain from the mismatched 18/24 result.

### 12.11 Legal clearers saw a closed signal

Symptom: vehicles that entered legally froze or braked inside the box when the
phase changed.

Cause: movement-permitted observation reflected only current green, not latched
clearance eligibility.

Fix: legal clearer latch participates in movement permission and observations.
All-red sweep then isolated residual crossing conflicts.

### 12.12 Center versus bumper stop-line bug

Symptom: cars visually straddled the line while metrics considered them legal.

Cause: spawn, target, observer, and detector used inconsistent center/bumper
references.

Fix: shared front-bumper helpers at every line-related call site, rear-bumper
exit helpers, regression tests, geometry marker, and complete rebaseline.

### 12.13 Entry fixed but exit still center-referenced

Symptom: completion could trigger before the vehicle tail cleared.

Fix: intersection occupancy and route completion use rear bumper. Expected
marginal horizon effects were documented before rebaseline.

### 12.14 Stale installed/sibling package

Symptom: corrected code produced old plausible numbers.

Cause: Python imported a sibling/global `intersection_rl` package.

Fix: repository-local launchers prepend the project root, assert package path
and geometry convention, inspect checkpoint metadata, and print provenance.

### 12.15 Random spawns manufactured unavoidable violations

Symptom: a car could spawn close to a red line at high speed with no physical
stopping solution.

Fix: demo position/speed sampling is joint and braking-feasible; queue gaps and
box/line exclusions are enforced.

### 12.16 Unobservable instant phase end

Symptom: a vehicle 0.18 m from the line at 6.81 m/s became red with no warning.

Cause: future phase timing is intentionally absent from observation. No policy
can guarantee stopping under an unannounced deadline without approaching every
green conservatively.

Fix: one-shot physical dilemma-zone clearance. Yellow remains the proper future
observable warning mechanism.

### 12.17 Dilemma latch over-grant risk

Potential exploit: accelerate after phase change until stopping becomes
impossible.

Fix: evaluate once at transition using physical, not comfortable, braking.
Tests ensure a stoppable vehicle cannot gain eligibility one tick later.

### 12.18 Creep routed to GO was unsafe

Symptom: forced GO routing removed stuck cars but caused 8/16/21 red failures.

Cause: GO output near +0.47 was suitable for cruise, not low-speed red approach.

Fix: reject without PPO; try a moderated route, then escalate after its gate
plateau and 119 rollout red events.

### 12.19 Brake component could not share brake and creep

Symptom: dedicated positive creep targets did not overcome established negative
brake output.

Cause: one component was asked to represent nearby opposite-sign behaviors;
effective creep gradient was only about 0.042 in one diagnostic leg.

Fix: pre-committed third brake/creep/go component.

### 12.20 Three-component prewarm lacked speed coverage

Symptom: first prewarm routed creep but remained positive above the 1.5 m/s
target, producing many red failures.

Cause: teacher rollouts mostly contained near-stationary creep states.

Fix: deterministic speed-distance augmentation. Reject checkpoint before PPO.

### 12.21 Three-component gate lacked post-creep hold coverage

Symptom: labels changed to brake/hold at the window but the gate stayed 0.91-0.99
creep.

Fix: supervised on-policy dataset aggregation of transition states. Reject
checkpoint before PPO.

### 12.22 Creep prewarm solved demos but failed deep stress

Symptom: accepted prewarm made sparse/dense canonical cells perfectly clean and
removed demo creep defects, but stress completion fell to
95.83/96.81/93.75%.

Cause: three-deep queues were outside the strongest prewarm coverage. Brake
argmax on stress stop-labelled states fell to about 44-58%, third-plus placement
error rose to 0.75-1.32 m, and discharge reached 19.07/28.80/46.31 s.

Decision: do not promote. Next branch is prewarm-only third-plus routing and
transition coverage.

### 12.23 PPO consolidation degraded a useful prewarm

Symptom: every validation gate failed; dense 2l/16 gained 0.25 proximity events
per episode and discharge slowed.

Diagnosis:

- Gate heads remained PPO-frozen.
- Gate CE accuracy remained 0.930-0.991.
- GO stayed near +0.45.
- Value explained variance improved 0.359 to 0.741.
- Hold action weakened from about -0.295 to -0.174.
- Mean effective creep auxiliary gradient was only 0.0048.
- Main gradient clip scale averaged 0.175.

Conclusion: legacy actor/shared-feature drift under the main optimizer is the
primary yellow-training risk. Gate freezing alone does not freeze the shared
features consumed by the gate and component heads.

## 13. Major Experiment Timeline

### Foundation

A shared PPO controller and scalable intersection environment were implemented,
followed by graph observations for variable traffic. Green-only checkpoints
established movement and route following.

### Red-stop attempts

Direct red rewards and red-only stages repeatedly produced one of two failures:

- All-brake collapse with no completion.
- Green preservation with red crossings.

These runs established that reward tuning alone could not solve action-mode
interference.

### Separate actor and squashed distributions

Longitudinal and steering heads were separated. Squashed distributions fixed
bounded-action/log-probability behavior. Physics action targets and intent
diagnostics were added.

### Mixture architecture

Brake/GO components and a learned gate separated red braking from green motion.
Gate gradient diagnostics exposed global clipping, leading to a separate gate
optimizer and prewarm. GO-component KL coefficient 1.0 prevented later erosion.

### Environment semantics correction

Legal-clearer observation, all-red timing, front-bumper geometry, rear-bumper
completion, local-package guard, and shared scenario builders removed several
silent confounds.

### Front-bumper polish

The v1b 200k leg selected update 35 after 202,752 rollout steps/66 updates. It
made sparse/dense behavior effectively clean and reduced discharge.

### Dilemma-zone semantics

One-shot physical clearance converted most stress red events into legal
clearers, revealing that stress was substantially better than the pre-latch
table implied.

### Creep branch

Named random demos exposed stationary far-upstream red states absent from the
canonical near-line sparse distribution. Brake-shared and GO-shared approaches
failed. A third component with learned servo solved creep locally, but deep
stress and PPO stability remain unresolved.

## 14. Current Results

### 14.1 Production polish, accepted latch semantics

| Regime | Cell | Complete % | Red/ep | Collision/ep | Proximity/ep | Stuck/ep |
|---|---:|---:|---:|---:|---:|---:|
| sparse | 2/8 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| sparse | 3/12 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| sparse | 4/16 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| dense | 2/16 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| dense | 3/24 | 100.00 | 0.00 | 0.00 | 0.55 | 0.00 |
| dense | 4/32 | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| stress | 2/24 | 99.58 | 0.10 | 0.00 | 0.00 | 0.00 |
| stress | 3/36 | 99.17 | 0.30 | 0.00 | 0.00 | 0.00 |
| stress | 4/48 | 96.46 | 0.40 | 0.10 | 1.30 | 0.40 |

### 14.2 Old-selected comparison

Old-selected is also 100% clean in sparse/dense. At stress:

| Cell | Old completion/red | Polish completion/red | Role |
|---:|---:|---:|---|
| 2/24 | 96.67 / 0.8 | 99.58 / 0.1 | Polish wins |
| 3/36 | 98.06 / 0.7 | 99.17 / 0.3 | Polish wins |
| 4/48 | 98.13 / 0.9 | 96.46 / 0.4 | Old wins throughput/safety; polish wins red |

### 14.3 Three-component prewarm

| Regime | Cell | Complete % | Red/ep | Stuck/ep | Moving timeout/ep | Discharge s |
|---|---:|---:|---:|---:|---:|---:|
| sparse | 2/8 | 100.00 | 0.00 | 0.00 | 0.00 | 6.00 |
| sparse | 3/12 | 100.00 | 0.00 | 0.00 | 0.00 | 9.06 |
| sparse | 4/16 | 100.00 | 0.00 | 0.00 | 0.00 | 12.12 |
| dense | 2/16 | 100.00 | 0.00 | 0.00 | 0.00 | 11.13 |
| dense | 3/24 | 100.00 | 0.00 | 0.00 | 0.00 | 17.34 |
| dense | 4/32 | 100.00 | 0.00 | 0.00 | 0.00 | 23.85 |
| stress | 2/24 | 95.83 | 0.10 | 0.00 | 0.90 | 19.07 |
| stress | 3/36 | 96.81 | 0.20 | 0.05 | 0.90 | 28.80 |
| stress | 4/48 | 93.75 | 0.90 | 1.10 | 1.00 | 46.31 |

It is a diagnostic artifact, not a promoted checkpoint.

### 14.4 Named demo comparison

Accepted polish baseline versus prewarm candidate, seed 730:

| Scenario | Polish | Three-component | Remaining candidate failures |
|---|---:|---:|---|
| 2 lanes/16 cars | 12/16 | 16/16 | none |
| 3 lanes/24 cars | 19/24 | 22/24 | one phase-boundary red and one moving horizon timeout |
| 4 lanes/32 cars | 30/32 | 31/32 | one moving horizon timeout |

The red vehicle is already brake-routed under all-red and is not a creep
overshoot. Timeout vehicles are moving at 13.4 m/s beyond the intersection but
have not met rear-bumper route completion at the 60 second horizon.

## 15. Checkpoint Roles

### Production

```text
checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz
```

Default for protected red/green demo and canonical sparse/dense use.

### Extreme stress fallback

```text
checkpoints/protected_redgreen_generalized_v1_selected.npz
```

Retained for 4l/48c comparison and immutable historical backup.

### Creep diagnostic

```text
results/protected_redgreen_creep_three_component_v1_75k/checkpoints/protected_redgreen_creep_three_component_v1_75k_prewarm.npz
```

Demonstrates successful learned creep but fails full promotion.

### Other retained artifacts

- `protected_redgreen_generalized_v1_demo_safe.npz`: immutable backup.
- `protected_green_base_v1_250k_selected.npz`: legacy green base.
- `protected_green_squashed_base_v1_250k_selected.npz`: squashed green base.
- `protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz`:
  corrected-clearance training/reference keeper.

The registry is authoritative if this report and an artifact ever disagree.

## 16. Current Technical Interpretation

The production red/green scope is strong enough for sparse/dense demonstrations
and nearly solved in stress after legal semantics correction. The remaining
demo creep issue is real but distribution-specific: canonical sparse cells use
near-line low-speed spawning, while named demos include nearly stationary cars
10-32 m upstream.

The dedicated creep mechanism is valid. It proved that a learned policy can
close that gap without a runtime rule. Its promotion failure is not the original
creep state; it is deep-queue routing and throughput.

The consolidation failure also changes the yellow plan. Yellow needs PPO after
label/prewarm work, but current PPO can reshape shared actor features while the
gate heads are nominally frozen. Yellow training should begin only after one of
these protections is implemented and verified:

- Freeze legacy actor/shared features during initial feature installation.
- Distill/reference-anchor shared actor features, not only output KL.
- Separate actor and critic trunks so value updates cannot move actor features.
- Use component-specific optimizer ownership that excludes protected legacy
  heads from the main step.
- Require short same-seed stability checks before a long PPO leg.

## 17. Next Work

### Immediate red/green branch

1. Add deterministic three-deep queue samples to gate prewarm/aggregation.
2. Include third-plus stop, creep, hold, and green-release transitions.
3. Keep PPO disabled.
4. Run the trajectory probe on named demos and natural dense re-stop states.
5. Run the full nine-cell matrix.
6. Promote only if all floors pass and dense discharge does not regress.

### Yellow feature after promotion

Yellow will make phase-end intent observable. The intended logic is learned:

- If stopping before the line is feasible, brake and stop.
- If stopping is physically infeasible, proceed and clear.
- If the vehicle entered legally, clearance semantics permit exit.

The braking-envelope target, legal clearer latch, dilemma latch, and
clearance interval already implement most environment-side prerequisites.
Yellow still needs observation/label verification, curriculum tasks,
deterministic probes, and the same permanent red/green regression floor.

### Right-on-red later

Right-on-red attempts historically produced no entries or unsafe behavior.
It requires explicit discovery/routing supervision and conflict/yield
curriculum. It should follow yellow, not precede it.

## 18. Reproducibility And Handoff Rules

Every result must identify:

- Repository/package path.
- Geometry convention.
- Checkpoint path and metadata.
- Signal/yellow/all-red configuration.
- Spawn mode.
- Safety systems.
- Episode horizon.
- Seeds and episode counts.
- Deterministic or stochastic actions.
- Raw and aggregate artifact paths.

Do not compare tables across different clearance, geometry, or latch semantics.
Do not promote a final checkpoint merely because no best checkpoint was saved.
Do not overwrite selected checkpoints. Keep failed artifacts out of
`checkpoints/` and document diagnostic artifacts under `results/`.

## 19. Verification

Current test suite:

```text
114 passed, 1 external Pygame/pkg_resources warning
```

Tests cover:

- Front-bumper observer and crossing.
- Spawn lead gap.
- Intersection entry/exit.
- Rear-bumper completion.
- Dilemma latch one-shot and anti-loophole behavior.
- Scenario/demo construction.
- Checkpoint migration.
- Three-way gate and creep targets.
- Canonical validation gates.
- Runtime package/geometry provenance.
- Training-stage defaults.

## 20. Conclusion

The project now has a defensible red/green controller and, equally important, a
defensible experimental process. The current policy is not presented as a
universal intersection solution. It is a measured protected red/green policy
with explicit scenario, geometry, legal, and density boundaries.

The central lesson is that policy learning quality cannot be judged independently
of environment semantics and evaluation provenance. Once those were made
consistent, the remaining problems became localized: deep-queue route coverage,
shared-feature stability under PPO, yellow decision learning, and later
right-on-red discovery. Those are concrete next engineering tasks rather than
unexplained reward-tuning failures.
