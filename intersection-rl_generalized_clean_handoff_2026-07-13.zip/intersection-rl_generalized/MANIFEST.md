# Clean Handoff Manifest

Date: 2026-07-13

Archive:

```text
intersection-rl_generalized_clean_handoff_2026-07-13.zip
```

## Purpose

This archive is a runnable, reviewable handoff of the current protected
red/green intersection RL project. It includes source, tests, launchers,
documentation, three useful test checkpoints, and compact accepted/diagnostic
result summaries. It intentionally excludes virtual environments, caches,
large raw rollout logs, old failed checkpoints, and stale media.

## Recommended Checkpoints

1. Production protected red/green:

   ```text
   checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz
   ```

2. 4-lane/48-car extreme-stress fallback:

   ```text
   checkpoints/protected_redgreen_generalized_v1_selected.npz
   ```

3. Experimental learned-creep diagnostic, not promoted:

   ```text
   results/protected_redgreen_creep_three_component_v1_75k/checkpoints/protected_redgreen_creep_three_component_v1_75k_prewarm.npz
   ```

## Included

- `README.md`
- `REPORT.md`
- `CHECKPOINT_REGISTRY.md`
- `MANIFEST.md`
- `pyproject.toml`
- `requirements.txt`
- `Dockerfile`, `compose.yaml`, ignore files
- `intersection_rl_generalized_launcher.py`
- Complete `intersection_rl/` Python package
- Complete `scripts/` Python launchers and diagnostics
- Complete `tests/` suite
- The three recommended checkpoints
- Other small retained top-level selected/reference checkpoints in
  `checkpoints/`
- Compact result plans/summaries and aggregate CSVs for:
  - Accepted dilemma-latch rebaseline
  - Named demo latch baseline
  - Promoted front-bumper polish
  - Three-component creep diagnostic and rejected promotion
- Existing compact graphs if present

## Excluded

- `.venv/` and installed packages
- `__pycache__/`, `.pytest_cache/`, and bytecode
- Raw per-seed evaluation logs/CSVs
- Large training rollout artifacts
- Periodic and rejected PPO checkpoint series
- Old simulator GIFs/frames tied to superseded semantics
- Previously generated ZIP archives
- Git metadata

## Verification Before Packaging

- Local package marker: `front_bumper_v1`
- Test suite: 114 passed
- Production, stress fallback, and creep diagnostic checkpoint files exist
- README simulation/evaluation/training help commands resolve
- Archive file list is checked after creation

Read `README.md` first, then `REPORT.md` and `CHECKPOINT_REGISTRY.md`.
