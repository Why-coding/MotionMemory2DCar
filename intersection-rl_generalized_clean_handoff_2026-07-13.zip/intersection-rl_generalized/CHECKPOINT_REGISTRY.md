# Checkpoint Registry

This file is the source of truth for checkpoint roles. Failed exploratory checkpoints should be deleted immediately after evaluation so the `checkpoints/` folder stays small.

## Keep

| Checkpoint | Role | Status | Notes |
|---|---|---|---|
| `checkpoints/protected_redgreen_front_bumper_polish_v1b_200k_selected.npz` | Current front-bumper protected red/green production model | KEEP | Current default. Under accepted dilemma-latch semantics it is 100% clean in every canonical sparse/dense cell; stress is 99.58/99.17/96.46% complete with 0.1/0.3/0.4 red per episode. The three-component creep candidate was not promoted because it missed every stress completion floor despite fixing named-demo creep failures. See `results/dilemma_latch_rebaseline_2026_07_12/REBASELINE_SUMMARY.md` and `results/protected_redgreen_creep_three_component_v1_75k/RUN_SUMMARY.md`. |
| `checkpoints/protected_redgreen_generalized_v1_selected.npz` | 4-lane extreme-stress fallback and immutable backup | KEEP | Accepted-latch rebaseline retires its broad fallback role: polish wins stress 2l/24 and 3l/36, while old-selected wins 4l/48 on completion (98.13% vs 96.46%), collision/proximity/stuck, placement, and discharge, but has higher red (0.9 vs 0.4/ep). Keep demo_safe frozen separately. No yellow or right-on-red. |
| `checkpoints/protected_redgreen_generalized_v1_demo_safe.npz` | Safety backup copy of selected demo model | KEEP | Immutable backup of `protected_redgreen_generalized_v1_selected.npz` before new training. Do not overwrite. |
| `checkpoints/protected_green_base_v1_250k_selected.npz` | Selected protected-green base | KEEP | Legacy continuous-Gaussian green eval passed: 100% completion and 0 collisions on 2/3/4-lane green checks. |
| `checkpoints/protected_green_squashed_base_v1_250k_selected.npz` | Selected squashed-Gaussian protected-green base | KEEP | Current green init/reference for bounded-action experiments. Warm-started mixture smoke eval preserved 100% completion on 2/3/4-lane left-green checks. |
| `checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz` | Corrected-clearance red/green safety candidate | KEEP | Byte-identical copy of `results/protected_redgreen_density_relabel_v1_200k/checkpoints/protected_redgreen_density_relabel_v1_200k_best.npz`. Clearance sweep separated the legal-clearer observation bug from all-red timing: seed-700 4-lane/48-car improved from old pre-fix 9.0 collisions/ep and 39.93% completion to 2.50 collisions/ep and 73.61% completion at 0.0s all-red, then 0.17 collisions/ep and 80.56% completion at 3.5s. Front-bumper re-baseline shows this keeper dominates sparse and 2/3-lane dense red safety, but is not promoted over the original selected demo because 4-lane dense averages 1.22 collisions/ep and stress 4-lane/48-car averages 0.70 collisions/ep plus 3.20 stuck timeouts/ep. See `results/front_bumper_rebaseline_2026_07_11/REBASELINE_SUMMARY.md`. |

## Canonical Front-Bumper Baseline - 2026-07-11

Protocol: `dense_redgreen`, `--all-red-seconds 3.5`, `60s` episodes,
`front_bumper_v1` entry/observation geometry, and rear-bumper completion.
Sparse uses 20 episodes per seed on 730/731; dense uses 20 episodes per seed
on 730/731/732; stress uses 10 episodes per seed on 730/731. Full artifacts:
`results/front_bumper_rebaseline_2026_07_11/REBASELINE_SUMMARY.md`.

Compact values are complete % / red / collision / proximity / stuck per episode.

| Regime | Cell | Old selected | Keeper | Current read |
|---|---:|---:|---:|---|
| sparse | 2l/8 | 88.75 / 0.90 / 0.00 / 0.00 / 0.00 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 | keeper solves this regime |
| sparse | 3l/12 | 89.17 / 1.30 / 0.00 / 0.00 / 0.00 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 | keeper solves this regime |
| sparse | 4l/16 | 89.38 / 1.70 / 0.00 / 0.00 / 0.00 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 | keeper solves this regime |
| dense | 2l/16 | 93.75 / 1.00 / 0.00 / 0.00 / 0.00 | 100.00 / 0.00 / 0.00 / 0.00 / 0.00 | keeper solves this regime |
| dense | 3l/24 | 92.92 / 1.70 / 0.00 / 0.00 / 0.00 | 97.64 / 0.00 / 0.00 / 0.30 / 0.00 | keeper solves; monitor proximity |
| dense | 4l/32 | 93.44 / 2.10 / 0.00 / 0.00 / 0.00 | 90.16 / 0.05 / 1.22 / 0.75 / 0.00 | keeper red-safe; clearance collision blocker |
| stress | 2l/24 | 93.75 / 1.50 / 0.00 / 0.00 / 0.00 | 78.75 / 2.70 / 0.20 / 0.20 / 1.30 | follower discharge/stuck blocker |
| stress | 3l/36 | 93.33 / 2.40 / 0.00 / 0.00 / 0.00 | 82.22 / 2.20 / 0.20 / 0.00 / 3.00 | follower discharge/stuck blocker |
| stress | 4l/48 | 92.92 / 3.40 / 0.00 / 0.00 / 0.00 | 81.88 / 2.80 / 0.70 / 0.90 / 3.20 | follower discharge/stuck blocker |

Promotion status: unchanged. Keep `protected_redgreen_generalized_v1_selected.npz`
as the broad visual fallback and
`protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz` as the
front-bumper-era safety candidate and next training base/reference. The July 11
table is the mandatory no-regression floor for the polish leg.

## Front-Bumper Polish Promotion - 2026-07-11

The v1b update-35 best is promoted as the current front-bumper red/green demo model
for sparse and dense 1-2 cars per inbound lane. It preserves 100% clean sparse and
dense 2-lane behavior, reaches 100% completion at dense 3l/24 with zero red/collision,
and reaches 99.90% at dense 4l/32 with 0.03 red/episode and zero collision/proximity.
Dense discharge improves from keeper 10.7/17.1/23.3s to 10.3/15.0/19.8s.

Stress remains an explicit limitation. Completion improves to 83.33/87.50/91.46% and
stuck falls to 0.0/0.0/0.4 per episode, but red rises to 4.0 and 4.5 per episode in
stress 2l/24 and 3l/36. Keep the old selected checkpoint as stress-throughput fallback.
Full table: `results/protected_redgreen_front_bumper_polish_v1b_200k/RUN_SUMMARY.md`.

## Three-Component Creep Promotion Decision - 2026-07-13

The prewarm-only brake/creep/go checkpoint is not promoted. It solves the
far-upstream stationary-red demo failure without runtime action overrides and
passes all six canonical sparse/dense cells at 100% completion with zero
red/collision/proximity/stuck/moving-timeout events. It also improves the named
demos from 12/16, 19/24, and 30/32 to 16/16, 22/24, and 31/32 while eliminating
all creep-related stuck timeouts and overshoots.

It fails the mandatory stress floor:

| Cell | Prewarm complete/red/collision/proximity/stuck/moving timeout | Polish floor | Decision |
|---:|---:|---:|---|
| 2l/24 | 95.83 / 0.10 / 0.00 / 0.00 / 0.00 / 0.90 | 99.58 / 0.10 / 0.00 / 0.00 / 0.00 | fail |
| 3l/36 | 96.81 / 0.20 / 0.00 / 0.00 / 0.05 / 0.90 | 99.17 / 0.30 / 0.00 / 0.00 / 0.00 | fail |
| 4l/48 | 93.75 / 0.90 / 0.00 / 0.00 / 1.10 / 1.00 | 96.46 / 0.40 / 0.10 / 1.30 / 0.40 | fail |

Dense discharge is also slower than polish: 11.13/17.34/23.85s versus
10.29/15.01/19.83s. Stress gate diagnostics localize the main candidate gap to
third-plus/deep-queue route coverage: brake argmax on stop-labelled states falls
to about 44-58%, and third-plus placement error rises to 0.75-1.32m.

The 76.8k PPO consolidation remains rejected. A same-seed dense 2l/16 audit
shows PPO introduced 0.25 proximity events/episode at both update 5 and update
25 and weakened mean hold action from about -0.295 to -0.174. Gate heads stayed
PPO-frozen, gate CE stayed accurate, GO stayed near +0.45, and value fit improved;
the remaining training risk is legacy actor/shared-feature drift under the main
optimizer, not a gate-unfreeze or value-divergence bug.

Keep the polish checkpoint as production. The next admissible red/green branch is
prewarm-only deterministic third-plus queue routing/transition coverage, followed
by the named probe and full canonical matrix. Do not start yellow PPO from the
rejected prewarm or consolidation artifacts. Full evidence:
`results/protected_redgreen_creep_three_component_v1_75k/RUN_SUMMARY.md`.

## Superseded Corrected-Clearance Baseline - 2026-07-10

Superseded by the canonical front-bumper baseline below. Retained for historical comparison.

Protocol: `dense_redgreen`, `--all-red-seconds 3.5`, `60s` episodes. Sparse/dense rows use 20 episodes per seed; dense uses seeds 730/731/732; sparse uses seeds 730/731; stress uses 10 episodes per seed on seeds 730/731. Full artifacts: `results/corrected_clearance_rebaseline_2026_07_10/REBASELINE_SUMMARY.md`; blocker attribution: `results/corrected_clearance_rebaseline_2026_07_10/diagnostics/BLOCKER_DIAGNOSTICS.md`.

| Regime | Cell | Old selected complete/red/coll/stuck | Keeper complete/red/coll/stuck | Current read |
|---|---:|---:|---:|---|
| sparse | 2l/8 | 88.75% / 0.90 / 0.00 / 0.00 | 100.00% / 0.00 / 0.00 / 0.00 | keeper solves this regime |
| sparse | 3l/12 | 89.17% / 1.30 / 0.00 / 0.00 | 100.00% / 0.00 / 0.00 / 0.00 | keeper solves this regime |
| sparse | 4l/16 | 89.38% / 1.70 / 0.00 / 0.00 | 100.00% / 0.00 / 0.00 / 0.00 | keeper solves this regime |
| dense | 2l/16 | 93.75% / 1.00 / 0.00 / 0.00 | 100.00% / 0.00 / 0.00 / 0.00 | keeper solves this regime |
| dense | 3l/24 | 92.92% / 1.70 / 0.00 / 0.00 | 97.22% / 0.00 / 0.05 / 0.00 | keeper solves this regime |
| dense | 4l/32 | 93.44% / 2.10 / 0.00 / 0.00 | 90.47% / 0.05 / 1.17 / 0.00 | keeper red-safe but needs 4l clearance/collision fix |
| stress | 2l/24 | 93.75% / 1.50 / 0.00 / 0.00 | 79.58% / 2.70 / 0.10 / 1.30 | stress not solved; follower discharge/stuck branch |
| stress | 3l/36 | 93.33% / 2.40 / 0.00 / 0.00 | 82.22% / 2.30 / 0.20 / 2.90 | stress not solved; follower discharge/stuck branch |
| stress | 4l/48 | 92.92% / 3.40 / 0.00 / 0.00 | 82.08% / 2.80 / 0.70 / 3.20 | stress not solved; follower discharge/stuck branch |

Promotion status: keep `protected_redgreen_generalized_v1_selected.npz` as broad visual fallback. Keep `protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz` as the corrected-semantics safety candidate and next training base. Sparse and 2/3-lane dense are solved by the keeper; remaining blockers are 4-lane dense clearance/collision and 3-cars-per-lane follower discharge/stuck.

## Active Naming Convention

| Planned checkpoint | Purpose | Keep rule |
|---|---|---|
| `protected_redgreen_creep_three_component_v1b_deepqueue_prewarm` | Planned prewarm-only third-plus queue route/transition coverage | Keep only if named demos remain creep-clean and all nine canonical floors pass without PPO. |

## Failed/Archived Result Artifacts

- `results/protected_redgreen_front_bumper_polish_v1_200k/`; interrupted mechanism non-keeper. GO action fell to `+0.291` by update 10 because GO-component KL `0.03` ignored the earlier registry finding that `0.2` was insufficient. No checkpoint passed the hard gate for promotion. See its `RUN_SUMMARY.md`.
These are not top-level checkpoint keepers and should not be used for demos:

- `results/protected_redgreen_mixture_greeninit_v1_100k/checkpoints/protected_redgreen_mixture_greeninit_v1_100k_best.npz`; failed diagnostic run. The mixture gate hovered near 0.5 instead of routing stop labels to the brake component, and deterministic redgreen eval completed only about 22-29% with high red violations. See `results/protected_redgreen_mixture_greeninit_v1_100k/RUN_SUMMARY.md`.
- `results/protected_redgreen_mixture_gatefix_probe_v1_75k/checkpoints/protected_redgreen_mixture_gatefix_probe_v1_75k_best.npz`; under-budget diagnostic, not a keeper. The separate gate optimizer and Huber value loss fixed the gate-gradient clipping bug, and gate/action metrics were still improving at the end of the short probe, but deterministic sparse redgreen eval completed only 50.00% / 69.44% / 72.92% on 2/3/4 lanes with about 1.0 red violation per episode. See `results/protected_redgreen_mixture_gatefix_probe_v1_75k/RUN_SUMMARY.md`.
- `results/protected_redgreen_mixture_prewarm_gokl_v1_200k/checkpoints/protected_redgreen_mixture_prewarm_gokl_v1_200k_best.npz`; interrupted diagnostic branch, not a keeper. Gate prewarm worked, but with go-component KL coefficient `0.2`, go-label action eroded below the `+0.35` floor by update 16-19. Relaunched from the same prewarm checkpoint with stronger go KL.
- `results/protected_redgreen_mixture_prewarm_gokl_v1b_200k/checkpoints/protected_redgreen_mixture_prewarm_gokl_v1b_200k_best.npz`; mechanism-success behavioral non-keeper. Gate unfroze at update 36 and held for 30 post-unfreeze updates, but dense redgreen eval completed only 45.83% / 59.72% / 65.10% on 2/3/4 lanes with large queue discharge delays and collision/proximity regressions. See `results/protected_redgreen_mixture_prewarm_gokl_v1b_200k/RUN_SUMMARY.md`.

- `results/protected_redgreen_density_potential_v1_200k/checkpoints/protected_redgreen_density_potential_v1_200k_best.npz`; shaping/density branch non-keeper. The potential-based red queue shaping and weighted 1/2/3-cars-per-inbound-lane curriculum preserved the verified mixture gate, but deterministic eval had poor completion and high collision/proximity failures under the pre-clearance-semantics environment: dense_redgreen best completed only 16.67% / 37.50% / 35.42% at 1 car per inbound lane and 33.33% / 35.42% / 40.10% at 2 cars per inbound lane on 2/3/4 lanes. Those collision/completion verdicts are now environment-confounded by the legal-clearer observation bug. Follow-up replay still localized a real queue bug to distance-unconditioned gate labels: closed-red states were labeled `STOP` uniformly from 24-45m down to the line, producing hard-brake routing far upstream. See `results/protected_redgreen_density_potential_v1_200k/RUN_SUMMARY.md`.

- `results/protected_redgreen_density_relabel_v1_200k/checkpoints/protected_redgreen_density_relabel_v1_200k_best.npz`; source artifact for the corrected-clearance keeper copy. The original relabel/latch eval was pre-clearance-semantics and is superseded: dense_redgreen completed only 16.67% / 36.11% / 35.42% at 1 car per inbound lane on 2/3/4 lanes, and original sparse redgreen completed only 41.67% / 44.44% / 48.96%, but the later clearance sweep showed the same checkpoint is much stronger once legal clearers keep `movement_permitted=True`. The byte-identical top-level keeper is `checkpoints/protected_redgreen_density_relabel_v1_200k_clearance_eval_keeper.npz`. See `results/protected_redgreen_density_relabel_v1_200k/clearance_sweep/SWEEP_SUMMARY.md`.

## Deleted Non-Keepers

Removed during cleanup on 2026-07-07:

- `red_queue_v4_far_recover_40k_best.npz`
- `red_queue_v5_lead_follower_40k*`
- `red_queue_v6_tight_lead_follower_40k*`
- `red_lead_stop_precision_v1_30k*`
- `red_lead_approach_v1_30k*`
- `red_lead_approach_v2_reward_30k*`
- `protected_green_rebuild_v1_120k*` partial interrupted run
- old incompatible copied `behavior_green_v3_300k_best.npz`
- interrupted `red_from_green_v1_protected_redgreen_200k*`; red improved but green completion collapsed, so it was deleted.
- `red_from_green_v2_staged_200k*`; deleted after early evaluation because it increased red violations, kept many cars stopped too far from the stop line, and reduced completion versus the selected demo checkpoint.
- `protected_red_queue_from_green_v1_250k*`; interrupted and deleted at update 15 because validation worsened and proximity/collision counts rose before lead-stop behavior was learned.
- `protected_lead_red_from_green_v1_250k*`; deleted after eval because it reached near-zero red violations by over-braking: 0% completion and 93-100% stuck timeouts on 2/3/4-lane lead-red evals.
- `normalized_red_queue_probe_v1_50k*`; deleted after eval because it avoided all-brake collapse but learned to accelerate through red: 2-lane red_queue had 8.0 red violations/ep and 0% completion; 2-lane redgreen had 28.75% completion and 5.6 red violations/ep.
- `normalized_red_queue_probe_v2_50k*`; deleted after eval because moderate red rebalance still produced zero stop-label braking: 2-lane red_queue had 8.0 red violations/ep and 0% completion; 2-lane redgreen had 29.69% completion and 5.54 red violations/ep.
- `stop_explore_red_queue_probe_v1_50k*`; interrupted and deleted after 3 updates because aggressive stop-action exploration reduced red crossings in rollouts but caused high KL plus collision/proximity spikes.
- `stop_explore_red_queue_probe_v2_50k*`; deleted after eval because gentle stop-action exploration did not transfer into deterministic policy: stop-label brake share stayed 0.0 and 2-lane red_queue still had 8.0 red violations/ep.

## Notes

- Do not use old `behavior_green_v3_300k_best.npz`; it uses the old intent-blended actor head and is incompatible with the current separate acceleration/steering actor.
- Follower queue should be treated as a virtual stop line behind the lead car, but keep a safe visual bumper gap around `2.5-3.0m`, not `0.5-1.5m`.

## Current Queue Geometry

- Lead target: `0.1-1.0m` before stop line, measured from the front bumper after the 2026-07-11 geometry fix.
- Follower target: `2.5-3.0m` bumper gap behind lead, represented internally as `7.0-7.5m` center/progress gap.
- Stop-line entry, spawn lead gap, queue-stop reward/labels, clearance eligibility, vector observation, and graph observation now share the same front-bumper convention. Intersection occupancy and route completion use rear-bumper exit. The first post-geometry re-baseline is expected to move red/placement metrics slightly because former center-behind but bumper-over cases now correctly count as crossings or overshoot. Treat a small red uptick as a stricter ruler until compared against the new front-bumper baseline.
- 2026-07-10 clearance sweep separated two environment effects: legal clearers previously observed a closed signal and braked inside the intersection, then all-red duration handled the remaining phase-timing gap. Re-baseline old and new checkpoints under corrected clearance semantics before promotion decisions.
- 2026-07-11 front-bumper re-baseline completed. It supersedes the 2026-07-10 table as the polish-leg regression floor; the promotion verdict is unchanged. Existing checkpoints are behaviorally invariant in solved cells, while small keeper deltas remain confined to the known 4-lane dense and stress blockers.
- 2026-07-11 front-bumper polish v1b promoted for sparse/dense demos after canonical evaluation. Superseded role note: the 2026-07-12 accepted-latch comparison narrows old-selected to 4-lane/48-car extreme stress; polish is better at 2/3-lane stress.
- 2026-07-11 shared demo builder added with 3.5s all-red, legal randomized initial green, feasible randomized positions/speeds, and headless/visual parity. Randomized approach seed 730 exposed a genuine creep-action limitation: creep labels are correct but the selected brake component remains negative while stopped short. Canonical near-line promotion results remain unchanged; do not retrain from the old raw-simulator 18/24 result.
- Coverage correction: the canonical rows labeled sparse still use the `dense_redgreen` near-line low-speed spawn profile (0.2-1.0m lead target, 0-1m/s closed spawn). They do not test stationary or near-stationary vehicles far upstream. Named demo scenarios are therefore permanent regression coverage, not only filming presets.
- 2026-07-12 dilemma-latch rebaseline accepted. Eligibility is decided once from the permitted-phase transition state using physical 4.0m/s^2 brake authority; later acceleration cannot gain eligibility. Sparse/dense behavior remained effectively invariant, while stress red violations fell from 4.0/4.5/2.8 to 0.1/0.3/0.4 per episode. This shows most former stress red events were physically impossible phase-end stops, not a policy-discipline regression. See results/dilemma_latch_rebaseline_2026_07_12/REBASELINE_SUMMARY.md.
- 2026-07-12 same-semantics old-selected rerun completed. Both checkpoints are 100% clean in canonical sparse/dense. Polish wins stress 2/24 and 3/36; old-selected remains only the 4/48 extreme-stress fallback and immutable backup. Named random demos retain polish as visual default because old-selected adds red/proximity at 3/4 lanes. See results/dilemma_latch_rebaseline_2026_07_12/REBASELINE_SUMMARY.md and results/named_demo_latch_baseline_2026_07_12/RUN_SUMMARY.md.
- 2026-07-12 creep component legs v1/v1b/v1c were diagnostic-only and not promoted. Huber/value control fixed gradient delivery, but brake-component routing could not make far-red creep positive without eroding ordinary red braking; the balanced v1c endpoint failed canonical gates and named demos (16/16, 22/24, 30/32 with 0/2/2 red). The promoted front-bumper polish v1b remains default. Next design: keep STOP intent but route creep independently to the GO component under explicit red-creep supervision. See results/protected_redgreen_creep_component_v1c_75k/RUN_SUMMARY.md.
- 2026-07-12 forced-GO probe and moderated two-way routing were rejected. Raw GO routing converted demo timeouts into 8/16/21 red crossings; moderated component outputs were viable, but the binary gate plateaued below pre-committed saturation and update 1 produced 119 rollout red events. The pre-named brake/creep/go third-component escalation is now active; no checkpoint was promoted. See results/forced_go_creep_probe_2026_07_12/PROBE_SUMMARY.md and results/protected_redgreen_creep_go_route_v1b_75k/RUN_SUMMARY.md.
- 2026-07-10 corrected-clearance re-baseline completed. The new keeper is a strong red-safety candidate and beats old selected on sparse plus 2/3-lane dense, but the original selected remains the broad visual demo fallback until 4-lane dense collisions and stress stuck/discharge are fixed.
- 2026-07-12 three-component brake/creep/go implementation completed before training. Legacy two-component checkpoints migrate with creep compatibility-masked, preserving brake/GO probabilities and deterministic actions exactly; the creep stage explicitly enables route 1. Routing is now 0=brake, 1=creep, 2=go, fast far-red motion remains CE-masked, and creep uses a distance-tapered 1.5m/s speed servo with an emergency-brake escape. Three-class prewarm trains only the gate and creep component, requires all per-class gates plus creep MSE, and aborts before PPO on failure. No checkpoint has been trained or promoted. See results/protected_redgreen_creep_three_component_v1_75k/RUN_PLAN.md.
- 2026-07-12 first three-component prewarm passed gate thresholds but its probe was rejected before PPO: named-demo baseline completion fell to 10/16, 9/24, and 11/32 with 6/15/21 red failures. Traces showed the creep component stayed positive above its 1.5m/s target (+0.161 at 1.5-3m/s, +0.100 above 3m/s) because compatibility-masked teacher rollouts contained mostly near-stationary creep states. The rejected checkpoint is preserved as *_prewarm_unaugmented_rejected.npz. The derived next attempt adds deterministic speed-state augmentation to auxiliary creep prewarm only; gate data, thresholds, rewards, PPO, and runtime control remain unchanged. See results/protected_redgreen_creep_three_component_v1_75k/PREWARM_PROBE_V1_SUMMARY.md.
- 2026-07-12 speed-augmented three-component prewarm was also rejected before PPO. It fixed the component profile and reduced canonical handoff speeds to roughly 0.8-1.9m/s, but named-demo baseline still had 6/9/12 red failures and canonical controls regressed. Traces localized the remaining defect to missing post-creep gate coverage: labels changed correctly to brake/hold at the window while the gate still selected creep with 0.91-0.99 probability. The checkpoint is preserved as *_prewarm_speed_augmented_rejected.npz. The next attempt adds supervised on-policy dataset aggregation for creep-to-hold transition states only. See results/protected_redgreen_creep_three_component_v1_75k/PREWARM_PROBE_V2_SUMMARY.md.

- 2026-07-13 three-component v3 canonical promotion rejected. The prewarm is 100% clean in all sparse/dense cells and removes demo creep stuck/overshoot, but stress completion falls to 95.83/96.81/93.75%, 4l/48 reaches 0.9 red and 1.1 stuck per episode, and dense/stress discharge is slower. PPO consolidation independently weakens hold behavior and introduces dense proximity despite frozen gate heads. Production remains front-bumper polish v1b. Next candidate is prewarm-only third-plus queue coverage; yellow remains parked. See results/protected_redgreen_creep_three_component_v1_75k/RUN_SUMMARY.md.
